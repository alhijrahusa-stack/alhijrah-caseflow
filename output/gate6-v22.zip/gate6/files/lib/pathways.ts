import type { Profile } from './model';
// Central pathway registry: every client-selectable pathway, the form sections it shows, the fields its intake
// needs, its intake status and the official IRCC source checked for this version. Deterministic, no LLM.
// Sources were read on canada.ca on 2026-11-12; `effectiveDate` is the "Page details" date shown on each page.
export const RULES_VERSION='pathways-2026-11-15';
export type CategoryId='pr'|'work'|'study'|'visit'|'trades';
export type PathwayId='express_entry'|'pnp'|'aip'|'rcip'|'fcip'|'work_offer'|'job_search'|'work_other'|'admission'|'study_permit'|'pgwp'|'visitor_visa'|'super_visa'|'eta'|'fstp'|'field_work'|'regional_pr';
export type Section='residence'|'work'|'offer'|'language'|'education'|'recommendation';
export type IntakeStatus='open'|'office_review';
type Service='work'|'immigration'|'study'|'other';
type Req={key:string;ar:string;en:string;test:(p:Profile,d:PathwayDetails)=>boolean};
export type PathwayDetails={jobs:{title:string;start:string}[];recommendationDate:string;industry:string};
// Visitor entry result computed by lib/entry-requirements.ts (passed in to keep this module dependency-free).
export type EntryInfo={code:string;ar:string;en:string};
export type Pathway={id:PathwayId;category:CategoryId;ar:string;en:string;service:Service;sections:Section[];required:Req[];intakeStatus:IntakeStatus;engine:'express_entry'|'program_rules'|'office_review'|'job_matching';targetForm:string;sourceURL:string;effectiveDate:string;noteAr?:string;noteEn?:string};
const IRCC='https://www.canada.ca/en/immigration-refugees-citizenship/services';
const has=(v:unknown)=>typeof v==='string'?v.trim().length>0:v!==null&&v!==undefined;
const R={
 nationality:{key:'nationality',ar:'الجنسية',en:'Citizenship',test:(p:Profile)=>has(p.nationality)},
 country:{key:'country',ar:'بلد الإقامة',en:'Country of residence',test:(p:Profile)=>has(p.country)},
 occupation:{key:'occupation',ar:'المسمى المهني',en:'Occupation',test:(p:Profile)=>has(p.occupation)},
 education:{key:'education',ar:'أعلى مؤهل دراسي',en:'Highest education',test:(p:Profile)=>p.education!=='unknown'},
 language:{key:'language',ar:'مستوى اللغة (CLB/NCLC) من اختبار معتمد',en:'Language level (CLB/NCLC) from an approved test',test:(p:Profile)=>p.englishMin!==null||p.frenchMin!==null},
 french:{key:'frenchMin',ar:'مستوى الفرنسية (NCLC)',en:'French level (NCLC)',test:(p:Profile)=>p.frenchMin!==null},
 jobs:{key:'jobs',ar:'خبرة عمل واحدة على الأقل (المسمى وتاريخ البداية)',en:'At least one job (title and start date)',test:(_p:Profile,d:PathwayDetails)=>d.jobs.some(j=>has(j.title)&&has(j.start))},
 offer:{key:'jobOffer',ar:'الإجابة عن وجود عرض عمل كندي مكتوب',en:'Whether you hold a written Canadian job offer',test:(p:Profile)=>p.jobOffer!=='unknown'},
 offerYes:{key:'jobOffer',ar:'عرض عمل كندي مكتوب',en:'Written Canadian job offer',test:(p:Profile)=>p.jobOffer==='yes'},
 eca:{key:'eca',ar:'الإجابة عن معادلة الشهادة (ECA) أو المؤهل الكندي',en:'Whether you have an ECA or Canadian credential',test:(p:Profile)=>p.eca!=='unknown'},
 noc:{key:'noc',ar:'رمز التصنيف المهني NOC',en:'NOC code',test:(p:Profile)=>has(p.noc)},
 industry:{key:'industry',ar:'قطاع العمل',en:'Work sector',test:(_p:Profile,d:PathwayDetails)=>d.industry!=='unknown'&&has(d.industry)},
} satisfies Record<string,Req>;
export const categories:{id:CategoryId;ar:string;en:string;descAr:string;descEn:string}[]=[
 {id:'pr',ar:'الإقامة الدائمة',en:'Permanent Residence',descAr:'أرغب في الهجرة والاستقرار في كندا بصفة دائمة.',descEn:'I want to immigrate and settle in Canada permanently.'},
 {id:'work',ar:'العمل في كندا',en:'Work in Canada',descAr:'أرغب في العمل في كندا، سواء كنت أمتلك عرض عمل أو أبحث عن فرصة وظيفية.',descEn:'I want to work in Canada, whether I have a job offer or I am looking for one.'},
 {id:'study',ar:'الدراسة في كندا',en:'Study in Canada',descAr:'أرغب في الدراسة بكندا أو استكمال إجراءات القبول أو تصريح العمل بعد التخرج.',descEn:'I want to study in Canada, complete admission, or apply for a post-graduation work permit.'},
 {id:'visit',ar:'الزيارة المؤقتة',en:'Visit Canada',descAr:'أرغب في زيارة كندا للسياحة أو زيارة العائلة أو إقامة مؤقتة.',descEn:'I want to visit Canada for tourism, family, or a temporary stay.'},
 {id:'trades',ar:'المهن والحرف والأعمال الميدانية',en:'Skilled Trades & Field Work',descAr:'لدي خبرة حرفية أو مهنية أو زراعية أو ميدانية، وأرغب في معرفة فرص العمل والهجرة المتاحة دون اشتراط شهادة جامعية لجميع المسارات.',descEn:'I have trade, technical, agricultural or field experience and want to know my work and immigration options, without a university degree being required for every pathway.'},
];
const P=(x:Omit<Pathway,'targetForm'>&{targetForm?:string}):Pathway=>({targetForm:'intake:'+x.id,...x});
export const pathways:Pathway[]=[
 P({id:'express_entry',category:'pr',ar:'الدخول السريع (Express Entry)',en:'Express Entry',service:'immigration',sections:['residence','work','offer','language','education'],required:[R.nationality,R.country,R.occupation,R.education,R.language,R.jobs,R.eca],intakeStatus:'open',engine:'express_entry',sourceURL:`${IRCC}/immigrate-canada/express-entry/check-score/crs-criteria.html`,effectiveDate:'2026-11-03'}),
 P({id:'pnp',category:'pr',ar:'الترشيح الإقليمي (PNP)',en:'Provincial Nominee Program (PNP)',service:'immigration',sections:['residence','work','offer','language','education'],required:[R.nationality,R.country,R.occupation,R.education,R.jobs],intakeStatus:'office_review',engine:'program_rules',sourceURL:`${IRCC}/immigrate-canada/provincial-nominees.html`,effectiveDate:'2026-09-14',noteAr:'لكل مقاطعة مسارات وشروط مستقلة؛ يراجعها المكتب حسب المقاطعة.',noteEn:'Each province runs its own streams; the office reviews them province by province.'}),
 P({id:'aip',category:'pr',ar:'الهجرة الأطلسية (AIP)',en:'Atlantic Immigration Program (AIP)',service:'immigration',sections:['residence','work','offer','language','education'],required:[R.nationality,R.country,R.occupation,R.education,R.language,R.offer],intakeStatus:'open',engine:'program_rules',sourceURL:`${IRCC}/immigrate-canada/atlantic-immigration.html`,effectiveDate:'2026-09-01',noteAr:'يتطلب البرنامج عرض عمل من صاحب عمل معيّن (designated) في إحدى المقاطعات الأطلسية الأربع.',noteEn:'The program requires a job offer from a designated employer in one of the four Atlantic provinces.'}),
 P({id:'rcip',category:'pr',ar:'الهجرة الريفية (RCIP)',en:'Rural Community Immigration (RCIP)',service:'immigration',sections:['residence','work','offer','language','education','recommendation'],required:[R.nationality,R.country,R.occupation,R.education,R.language,R.offer],intakeStatus:'open',engine:'program_rules',sourceURL:`${IRCC}/immigrate-canada/rural-franco-pilots/rural-immigration.html`,effectiveDate:'2026-11-09',noteAr:'سياسة المكتب المعتمدة: يُحدَّد البرنامج بتاريخ اعتماد الطلب للإرسال بتوقيت تورونتو. اعتماد في 2026: البرنامج التجريبي. اعتماد في 2027 أو بعده: البرنامج الدائم، ولا تُقبل فيه توصية مؤرخة في 2026.',noteEn:'Approved office policy: the program follows the approval-for-submission date in Toronto time. Approved in 2026: the pilot. Approved in 2027 or later: the permanent program, which does not accept a recommendation dated in 2026.'}),
 P({id:'fcip',category:'pr',ar:'الهجرة الفرنكوفونية (FCIP)',en:'Francophone Community Immigration (FCIP)',service:'immigration',sections:['residence','work','offer','language','education','recommendation'],required:[R.nationality,R.country,R.occupation,R.education,R.french,R.offer],intakeStatus:'open',engine:'program_rules',sourceURL:`${IRCC}/immigrate-canada/rural-franco-pilots/franco-immigration.html`,effectiveDate:'2026-04-30',noteAr:'برنامج مستقل عن RCIP، يتطلب الفرنسية وعرض عمل من صاحب عمل معيّن في إحدى المجتمعات المشاركة.',noteEn:'Separate from RCIP; requires French and a job offer from a designated employer in a participating community.'}),
 P({id:'work_offer',category:'work',ar:'لدي عرض عمل رسمي',en:'I Have a Job Offer',service:'work',sections:['residence','work','offer','language','education'],required:[R.nationality,R.country,R.occupation,R.offerYes,R.jobs],intakeStatus:'open',engine:'program_rules',sourceURL:`${IRCC}/work-canada/permit/temporary/work-permit.html`,effectiveDate:'2026-10-28',noteAr:'تصريح عمل مرتبط بصاحب العمل؛ نوع التصريح يحدده العرض وحالة LMIA أو الإعفاء منها.',noteEn:'Employer-specific work permit; the permit type depends on the offer and its LMIA or exemption.'}),
 P({id:'job_search',category:'work',ar:'أبحث عن فرصة عمل',en:"I'm Looking for a Job",service:'work',sections:['residence','work','language','education'],required:[R.nationality,R.country,R.occupation,R.jobs],intakeStatus:'open',engine:'job_matching',sourceURL:'',effectiveDate:'',noteAr:'هذا تقييم لخدمة التوظيف ومطابقة الفرص، وليس طلب تصريح عمل.',noteEn:'This is an employment-service assessment, not a work permit application.'}),
 P({id:'work_other',category:'work',ar:'خيارات تصاريح العمل الأخرى',en:'Other Work Permit Options',service:'work',sections:['residence','work','language','education'],required:[R.nationality,R.country,R.occupation],intakeStatus:'office_review',engine:'office_review',sourceURL:`${IRCC}/work-canada/permit/temporary/work-permit.html`,effectiveDate:'2026-10-28',noteAr:'تصاريح مفتوحة أو خاصة (مثل الأزواج وبعض البرامج)؛ تُحدد الأهلية بعد مراجعة الحالة.',noteEn:'Open or special permits (e.g., spouses, specific programs); eligibility is set after case review.'}),
 P({id:'admission',category:'study',ar:'القبول الأكاديمي',en:'Academic Admission',service:'study',sections:['residence','language','education'],required:[R.nationality,R.country,R.education,R.language],intakeStatus:'open',engine:'office_review',sourceURL:`${IRCC}/study-canada/study-permit.html`,effectiveDate:'2026-04-24'}),
 P({id:'study_permit',category:'study',ar:'تصريح الدراسة',en:'Study Permit',service:'study',sections:['residence','language','education'],required:[R.nationality,R.country,R.education,R.language],intakeStatus:'open',engine:'program_rules',sourceURL:`${IRCC}/study-canada/study-permit.html`,effectiveDate:'2026-04-24',noteAr:'يتطلب خطاب قبول من مؤسسة تعليمية معتمدة (DLI).',noteEn:'Requires an acceptance letter from a designated learning institution (DLI).'}),
 P({id:'pgwp',category:'study',ar:'تصريح العمل بعد التخرج (PGWP)',en:'Post-Graduation Work Permit (PGWP)',service:'study',sections:['residence','language','education'],required:[R.nationality,R.country,R.education,R.language],intakeStatus:'open',engine:'program_rules',sourceURL:`${IRCC}/study-canada/work/after-graduation/about.html`,effectiveDate:'2026-03-09',noteAr:'التخرج من DLI لا يمنح الأهلية تلقائيًا؛ يلزم برنامج مؤهل، ونتيجة لغة لمعظم الطلبات المقدمة من 1 نوفمبر 2024.',noteEn:'Graduating from a DLI does not by itself make you eligible; an eligible program is required, and most applications since November 1, 2024 need language results.'}),
 P({id:'visitor_visa',category:'visit',ar:'تأشيرة زيارة',en:'Visitor Visa',service:'other',sections:['residence'],required:[R.nationality,R.country],intakeStatus:'open',engine:'program_rules',sourceURL:`${IRCC}/visit-canada.html`,effectiveDate:'2026-09-28',noteAr:'تأشيرة الزيارة أو eTA تُحدد حسب الجنسية ووثيقة السفر وطريقة الوصول.',noteEn:'Visitor visa or eTA depends on citizenship, travel document and how you arrive.'}),
 P({id:'super_visa',category:'visit',ar:'سوبر فيزا للوالدين والأجداد',en:'Parent & Grandparent Super Visa',service:'other',sections:['residence'],required:[R.nationality,R.country],intakeStatus:'open',engine:'program_rules',sourceURL:`${IRCC}/visit-canada/parent-grandparent-super-visa.html`,effectiveDate:'2026-07-06'}),
 P({id:'eta',category:'visit',ar:'تصريح السفر الإلكتروني (eTA)',en:'Electronic Travel Authorization (eTA)',service:'other',sections:['residence'],required:[R.nationality,R.country],intakeStatus:'open',engine:'program_rules',sourceURL:`${IRCC}/visit-canada/eta.html`,effectiveDate:'2026-06-05',noteAr:'eTA للمسافرين جوًا من الجنسيات المعفاة من التأشيرة؛ غيرهم يحتاج تأشيرة زيارة.',noteEn:'eTA is for visa-exempt travellers flying to Canada; others need a visitor visa.'}),
 P({id:'fstp',category:'trades',ar:'برنامج الحرفيين الفيدرالي (FSTP)',en:'Federal Skilled Trades Program (FSTP)',service:'immigration',sections:['residence','work','offer','language','education'],required:[R.nationality,R.country,R.occupation,R.noc,R.jobs,R.language,R.offer],intakeStatus:'open',engine:'express_entry',sourceURL:`${IRCC}/immigrate-canada/express-entry/who-can-apply/federal-skilled-trades.html`,effectiveDate:'2026-10-16',noteAr:'ضمن Express Entry: سنتان دوام كامل (3,120 ساعة) خلال 5 سنوات في مهنة حرفية مؤهلة، مع عرض عمل لسنة على الأقل أو شهادة تأهيل كندية.',noteEn:'Part of Express Entry: 2 years full-time (3,120 hours) within 5 years in an eligible trade, plus a 1-year job offer or a Canadian certificate of qualification.'}),
 P({id:'field_work',category:'trades',ar:'العمل الزراعي والميداني',en:'Agricultural & Field Work',service:'work',sections:['residence','work','offer','language'],required:[R.nationality,R.country,R.occupation,R.industry,R.jobs],intakeStatus:'open',engine:'job_matching',sourceURL:`${IRCC}/immigrate-canada/agri-food-pilot.html`,effectiveDate:'2026-04-27',noteAr:'برنامج Agri-Food Pilot مغلق منذ 14 مايو 2025 ولا يقبل طلبات جديدة؛ يُقيَّم العمل الميداني عبر عروض العمل وتصاريحها.',noteEn:'The Agri-Food Pilot closed on May 14, 2025 and takes no new applications; field work is assessed through job offers and work permits.'}),
 P({id:'regional_pr',category:'trades',ar:'مسارات الإقامة الدائمة الإقليمية',en:'Regional PR Pathways',service:'immigration',sections:['residence','work','offer','language','education','recommendation'],required:[R.nationality,R.country,R.occupation,R.jobs,R.offer],intakeStatus:'office_review',engine:'program_rules',sourceURL:`${IRCC}/immigrate-canada/rural-franco-pilots.html`,effectiveDate:'2026-11-09',noteAr:'تشمل الترشيح الإقليمي والهجرة الأطلسية والريفية والفرنكوفونية حسب المهنة وعرض العمل.',noteEn:'Covers PNP, Atlantic, rural and Francophone pathways depending on occupation and job offer.'}),
];
export const pathwayIds=pathways.map(p=>p.id) as [PathwayId,...PathwayId[]];
export const categoryIds=categories.map(c=>c.id) as [CategoryId,...CategoryId[]];
export const pathwayById=(id:string)=>pathways.find(p=>p.id===id);
export const pathwaysOf=(category:string)=>pathways.filter(p=>p.category===category);
// A chosen pathway must belong to its category ("not_sure" may resolve to any pathway).
export function pathwayConsistent(d:{category:string;pathway:string}){if(!d.pathway)return true;const p=pathwayById(d.pathway);return !!p&&(d.category===p.category||d.category==='not_sure');}
export function pathwayLabel(id:string,ar=true){const p=pathwayById(id);if(!p)return '';const c=categories.find(x=>x.id===p.category)!;return ar?`${c.ar} · ${p.ar}`:`${c.en} · ${p.en}`;}
// Program readiness, never a score: READY when the pathway's intake fields are present, else INCOMPLETE_DATA.
export function pathwayReadiness(id:string,profile:Profile,details:PathwayDetails,entry?:EntryInfo){
 const p=pathwayById(id);if(!p)return {status:'INCOMPLETE_DATA' as const,missing:[{key:'pathway',ar:'اختيار مسار الطلب',en:'Application pathway'}],notes:[] as {ar:string;en:string}[],rulesVersion:RULES_VERSION};
 const seen=new Set<string>(),missing=p.required.filter(r=>!r.test(profile,details)).filter(r=>!seen.has(r.ar)&&!!seen.add(r.ar)).map(({key,ar,en})=>({key,ar,en})),notes:{ar:string;en:string}[]=[];
 if(p.noteAr)notes.push({ar:p.noteAr,en:p.noteEn||''});
 if(p.id==='rcip'&&details.recommendationDate){notes.push(details.recommendationDate.startsWith('2026-')?{ar:'توصيتك مؤرخة في 2026: تصلح للبرنامج التجريبي فقط إذا اعتُمد الطلب للإرسال في 2026 بتوقيت تورونتو، ولا تُقبل في البرنامج الدائم.',en:'Your recommendation is dated in 2026: it serves the pilot only if the application is approved for submission in 2026 (Toronto time); the permanent program does not accept it.'}:{ar:'توصيتك مؤرخة في 2027 أو بعده: يُعالج الطلب ضمن البرنامج الدائم عند اعتماده للإرسال في 2027 أو بعده.',en:'Your recommendation is dated 2027 or later: the application falls under the permanent program when approved for submission in 2027 or later.'});}
 if(p.category==='visit'&&entry){if(entry.code==='INCOMPLETE_DATA'&&profile.nationality.trim())missing.push({key:'arrival',ar:'طريقة الوصول إلى كندا (جوًا أو برًا/بحرًا)',en:'How you will arrive (air, or land/sea)'});else if(entry.code!=='INCOMPLETE_DATA')notes.push({ar:'الوثيقة المطلوبة حسب جنسيتك: '+entry.ar,en:'Document required for your citizenship: '+entry.en});
  if(p.id==='eta'&&['visa'].includes(entry.code))notes.push({ar:'جنسيتك تتطلب تأشيرة زيارة وليس eTA؛ يُحوَّل طلبك إلى تأشيرة الزيارة.',en:'Your citizenship needs a visitor visa, not an eTA; your request is handled as a visitor visa.'});
  if(p.id==='visitor_visa'&&['eta','passport_only','none','citizen'].includes(entry.code))notes.push({ar:'جنسيتك لا تتطلب تأشيرة زيارة.',en:'Your citizenship does not need a visitor visa.'});}
 return {status:missing.length?'INCOMPLETE_DATA' as const:'READY' as const,missing,notes,rulesVersion:RULES_VERSION,engine:p.engine,intakeStatus:p.intakeStatus,sourceURL:p.sourceURL,effectiveDate:p.effectiveDate};
}
// "Not sure" guide: plain-language answers mapped by fixed rules to candidate pathways, each with its reason.
export type Guide={goal:''|'settle'|'work'|'study'|'visit';offer:''|'yes'|'no';trade:''|'yes'|'no';degree:''|'yes'|'no';french:''|'yes'|'no'};
export const blankGuide:Guide={goal:'',offer:'',trade:'',degree:'',french:''};
export function guideComplete(g:Guide){return !!g.goal&&(g.goal==='visit'||g.goal==='study'||(!!g.offer&&!!g.trade&&!!g.degree&&!!g.french));}
export function suggestPathways(g:Guide):{id:PathwayId;ar:string;en:string}[]{
 const out:{id:PathwayId;ar:string;en:string}[]=[],add=(id:PathwayId,ar:string,en:string)=>{if(!out.some(o=>o.id===id))out.push({id,ar,en});};
 if(g.goal==='visit'){add('visitor_visa','حسب جنسيتك: تأشيرة زيارة','Depending on citizenship: visitor visa');add('eta','أو eTA إن كانت جنسيتك معفاة ووصولك جوًا','Or an eTA if visa-exempt and flying');add('super_visa','لوالدي أو أجداد مواطن/مقيم دائم','For parents or grandparents of a citizen or PR');return out;}
 if(g.goal==='study'){add('admission','تبدأ الدراسة بالقبول من مؤسسة معتمدة','Study starts with admission to a designated school');add('study_permit','بعد القبول يُطلب تصريح الدراسة','After admission, apply for a study permit');return out;}
 if(g.offer==='yes'){add('work_offer','لديك عرض عمل كندي مكتوب','You hold a written Canadian job offer');if(g.goal==='settle'){add('aip','إن كان صاحب العمل معيّنًا في المقاطعات الأطلسية','If the employer is designated in Atlantic Canada');add('rcip','إن كان صاحب العمل معيّنًا في مجتمع ريفي مشارك','If the employer is designated in a participating rural community');}}
 if(g.french==='yes'&&g.goal==='settle')add('fcip','لديك فرنسية؛ مسار المجتمعات الفرنكوفونية','You speak French; Francophone community pathway');
 if(g.trade==='yes'){add('fstp','خبرة حرفية قد تؤهل لبرنامج الحرفيين ضمن Express Entry','Trade experience may qualify for FSTP within Express Entry');add('field_work','خبرة ميدانية أو زراعية','Field or agricultural experience');add('regional_pr','مسارات إقليمية لا تشترط شهادة جامعية دائمًا','Regional pathways that do not always require a degree');}
 if(g.degree==='yes'&&g.goal!=='work'){add('express_entry','لديك مؤهل بعد الثانوية؛ يُحسب CRS بعد استكمال اللغة','You have post-secondary education; CRS is calculated once language is provided');add('pnp','الترشيح الإقليمي حسب المهنة والمقاطعة','Provincial nomination by occupation and province');}
 if(g.goal==='work'&&g.offer!=='yes')add('job_search','تقييم خدمة التوظيف ومطابقة الفرص','Employment-service assessment and job matching');
 if(!out.length){add('express_entry','نقطة البداية الأشمل للإقامة الدائمة','The broadest starting point for permanent residence');add('job_search','تقييم فرص العمل','Job opportunity assessment');}
 return out.slice(0,5);
}

// ---- v2.2 Gate 3: generic obligation interpreter for sealed program payloads (05 "obligations"). Typed comparison,
// range, temporal comparison on real dates, set membership, ALL, ANY (sourced exemptions are ANY branches). No eval,
// SQL or JS strings. ALL: any FAIL => FAIL, else any UNKNOWN => UNKNOWN, else PASS. ANY: any PASS => PASS, else any
// UNKNOWN => UNKNOWN, else FAIL. A missing fact is UNKNOWN, never FAIL. The set of evaluated obligation IDs must equal
// the signed manifest; otherwise the program is blocked and cannot PASS.
export type DateBasis = 'PROFILE' | 'INVITATION' | 'APPLICATION' | 'RECOMMENDATION' | 'APPROVAL_TORONTO';
export type RuleLiteral = string | number | boolean | null | string[];
export type RuleExpression = { operator: 'ALL' | 'ANY'; nodeIds: string[] } | { operator: 'EQ' | 'NE' | 'IN' | 'GE' | 'GT' | 'LE' | 'LT' | 'PRESENT'; normalizedFactPath: string; expected: RuleLiteral; dateBasis: DateBasis };
export type Obligation = { obligationId: string; expression: RuleExpression; sourceIds: string[]; sourceLocator: string; scopeLimitations: string[] };
export type PredicateState = 'PASS' | 'FAIL' | 'UNKNOWN' | 'NOT_APPLICABLE';
export type SourceCitation = { sourceId: string; officialUrl: string; locator: string; sourceHash: string };
export type PredicateResult = { obligationId: string; state: PredicateState; reasonCode: string; ruleHash: string; factRevisionIds: string[]; evidenceRefs: string[]; citations: SourceCitation[]; dateBasis: DateBasis; evaluatedOn: string };
export type InterpreterFact = { value: string | number | boolean | null; state: 'VERIFIED' | 'REPORTED' | 'UNKNOWN'; origin: string };
export type ObligationInput = {
  obligations: readonly Obligation[]; rootObligationId: string; requiredObligationIds: readonly string[]; ruleHash: string;
  facts: Readonly<Record<string, InterpreterFact>>; supportedPaths: ReadonlySet<string>;
  dates: Partial<Record<DateBasis, string>>; defaultBasis: DateBasis;
  sources: ReadonlyMap<string, { officialUrl: string; sourceHash: string }>; purpose: 'RAPID_SCREENING' | 'VERIFIED_SCREENING';
};
export type ObligationOutcome = { eligibility: PredicateState; predicates: PredicateResult[]; reasonCodes: string[]; blocked: string | null };
const COMPARE = new Set(['EQ', 'NE', 'IN', 'GE', 'GT', 'LE', 'LT', 'PRESENT']);
const realDate = (v: unknown): v is string => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && new Date(v + 'T00:00:00Z').toISOString().slice(0, 10) === v;
class Blocked extends Error {}
export function evaluateObligations(i: ObligationInput): ObligationOutcome {
  const byId = new Map<string, Obligation>();
  for (const o of i.obligations) { if (byId.has(o.obligationId)) return { eligibility: 'UNKNOWN', predicates: [], reasonCodes: ['DUPLICATE_OBLIGATION'], blocked: 'DUPLICATE_OBLIGATION' }; byId.set(o.obligationId, o); }
  const results = new Map<string, PredicateResult>(), visiting = new Set<string>();
  const citations = (o: Obligation): SourceCitation[] => {
    if (!o.sourceIds.length) throw new Blocked('SOURCE_MISSING');
    return o.sourceIds.map(id => { const s = i.sources.get(id); if (!s) throw new Blocked('SOURCE_MISSING'); return { sourceId: id, officialUrl: s.officialUrl, locator: o.sourceLocator, sourceHash: s.sourceHash }; });
  };
  const visit = (id: string): PredicateResult => {
    const done = results.get(id); if (done) return done;
    const o = byId.get(id); if (!o) throw new Blocked('OBLIGATION_NODE_MISSING');
    if (visiting.has(id)) throw new Blocked('OBLIGATION_CYCLE');
    visiting.add(id);
    const e = o.expression, cites = citations(o);
    let r: PredicateResult;
    if ('nodeIds' in e) {
      if (!e.nodeIds.length) throw new Blocked('EMPTY_COMBINATOR');
      const kids = e.nodeIds.map(visit), states = kids.map(k => k.state).filter(s => s !== 'NOT_APPLICABLE');
      const state: PredicateState = e.operator === 'ALL'
        ? (states.includes('FAIL') ? 'FAIL' : states.includes('UNKNOWN') ? 'UNKNOWN' : 'PASS')
        : (states.includes('PASS') ? 'PASS' : states.includes('UNKNOWN') ? 'UNKNOWN' : 'FAIL');
      const date = i.dates[i.defaultBasis];
      r = { obligationId: id, state, reasonCode: e.operator + '_' + state, ruleHash: i.ruleHash, factRevisionIds: [...new Set(kids.flatMap(k => k.factRevisionIds))].sort(), evidenceRefs: [...new Set(kids.flatMap(k => k.evidenceRefs))].sort(), citations: cites, dateBasis: i.defaultBasis, evaluatedOn: date ?? '0000-01-01' };
      if (!date) r = { ...r, state: state === 'FAIL' ? 'FAIL' : 'UNKNOWN', reasonCode: 'CONTEXT_INCOMPLETE' };
    } else {
      if (!COMPARE.has(e.operator)) throw new Blocked('UNSUPPORTED_OPERATOR');
      if (!i.supportedPaths.has(e.normalizedFactPath)) throw new Blocked('UNSUPPORTED_FACT_PATH');
      const date = i.dates[e.dateBasis], f = i.facts[e.normalizedFactPath];
      const base = { obligationId: id, ruleHash: i.ruleHash, citations: cites, dateBasis: e.dateBasis, evaluatedOn: date ?? '0000-01-01' };
      const refs = f && f.state !== 'UNKNOWN' ? { factRevisionIds: [f.origin], evidenceRefs: f.origin.startsWith('documents.') ? [f.origin] : [] } : { factRevisionIds: [], evidenceRefs: [] };
      if (!date) r = { ...base, ...refs, state: 'UNKNOWN', reasonCode: 'CONTEXT_INCOMPLETE' };
      else if (!f || f.state === 'UNKNOWN') r = { ...base, ...refs, state: 'UNKNOWN', reasonCode: 'FACT_UNKNOWN' };
      else if (f.state === 'REPORTED' && i.purpose === 'VERIFIED_SCREENING') r = { ...base, ...refs, state: 'UNKNOWN', reasonCode: 'FACT_NOT_VERIFIED' };
      else r = { ...base, ...refs, ...compare(e.operator, f.value, e.expected) };
    }
    visiting.delete(id); results.set(id, r); return r;
  };
  try {
    if (!byId.has(i.rootObligationId)) throw new Blocked('ROOT_OBLIGATION_MISSING');
    const root = visit(i.rootObligationId), required = new Set(i.requiredObligationIds), visited = new Set(results.keys());
    if (required.size !== i.requiredObligationIds.length || visited.size !== required.size || [...visited].some(v => !required.has(v)) || byId.size !== required.size) throw new Blocked('OBLIGATION_COVERAGE_INCOMPLETE');
    const predicates = [...results.values()].sort((a, b) => a.obligationId.localeCompare(b.obligationId));
    const reasonCodes = [...new Set(predicates.filter(p => p.state !== 'PASS').map(p => p.obligationId + ':' + p.reasonCode))].sort();
    return { eligibility: root.state, predicates, reasonCodes, blocked: null };
  } catch (err) {
    if (err instanceof Blocked) return { eligibility: 'UNKNOWN', predicates: [], reasonCodes: [err.message], blocked: err.message };
    throw err;
  }
}
function compare(op: string, value: string | number | boolean | null, expected: RuleLiteral): { state: PredicateState; reasonCode: string } {
  const res = (ok: boolean) => ({ state: (ok ? 'PASS' : 'FAIL') as PredicateState, reasonCode: ok ? 'MET' : 'NOT_MET' });
  if (op === 'PRESENT') { if (typeof expected !== 'boolean') throw new Blocked('OPERAND_TYPE_MISMATCH'); return res(expected === (value !== null)); }
  if (op === 'IN') { if (!Array.isArray(expected) || typeof value !== 'string') throw new Blocked('OPERAND_TYPE_MISMATCH'); return res(expected.includes(value)); }
  if (op === 'EQ' || op === 'NE') { if (Array.isArray(expected) || (expected !== null && typeof expected !== typeof value)) throw new Blocked('OPERAND_TYPE_MISMATCH'); return res(op === 'EQ' ? value === expected : value !== expected); }
  const numeric = typeof value === 'number' && typeof expected === 'number', dates = realDate(value) && realDate(expected);
  if (!numeric && !dates) throw new Blocked('OPERAND_TYPE_MISMATCH');
  const a = value as number | string, b = expected as number | string;
  return res(op === 'GE' ? a >= b : op === 'GT' ? a > b : op === 'LE' ? a <= b : a < b);
}
