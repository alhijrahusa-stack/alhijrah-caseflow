import { staffSessionIdentity } from "./staff-auth";
import { getChatGPTUser } from "@/app/chatgpt-auth";
import { getDb } from "@/db";
import { candidates, events, officeSettings, officeMembers, operationLogs } from "@/db/schema";
import { and, eq, inArray, sql, type SQL } from "drizzle-orm";
import { loadAuthority, ensureStaffUser, staffUserId, requireCapability, requireManager, type Authority } from "./rbac";
import { z } from "zod";
import { env,waitUntil } from "cloudflare:workers";
export const PUBLIC_OWNER = "office:alhijrah-canada";
/**
 * Case scope. Office policy (owner decision, "flexibility and trust"): every active STAFF member and the MANAGER see
 * all office cases, documents and client-portal cases; case_access records assignment only and never filters reads.
 * Inactive or non-staff actors see nothing. SYSTEM scope is only for internal jobs and never comes from a request.
 */
export type Scope = { ownerId: string; authority: Authority | null; system?: true };
export function systemScope(ownerId: string): Scope { return { ownerId, authority: null, system: true }; }
export function owned(column:Parameters<typeof eq>[0], scope:Scope): SQL {
  const base = inArray(column as typeof candidates.ownerId,[scope.ownerId,PUBLIC_OWNER]);
  if (scope.system) return base;
  const a = scope.authority;
  if (!a || !a.actor.active || (a.actor.role !== "MANAGER" && a.actor.role !== "STAFF")) return sql`0`;
  return base;
}
import { ApiError } from './api-error';
export { ApiError };
export async function staff() {
 const user=await staffSessionIdentity()??await getChatGPTUser();if(!user)throw new ApiError(401,"يلزم تسجيل دخول الموظف");
 const admin=(env.OFFICE_ADMIN_EMAIL||"").trim().toLowerCase();
 if(!admin)throw new ApiError(503,"لم يكتمل إعداد مدير النظام");
 const db=getDb(),isAdmin=user.email.toLowerCase()===admin;
 const [settingsRows,memberRows]=await Promise.all([
  db.select().from(officeSettings).where(eq(officeSettings.id,"office")).limit(1),
  isAdmin?Promise.resolve([]):db.select().from(officeMembers).where(and(eq(officeMembers.email,user.email.toLowerCase()),eq(officeMembers.active,true))).limit(1),
 ]);
 if(!isAdmin&&!memberRows.length)throw new ApiError(403,"هذا الحساب غير مخوّل بدخول لوحة الموظفين");
 const settings=settingsRows[0];let primaryOwnerId=settings?.primaryOwnerId;
 if(isAdmin&&!settings?.primaryOwnerId){
  await db.insert(officeSettings).values({id:"office",primaryOwnerId:user.userId,updatedAt:new Date().toISOString()}).onConflictDoNothing();
  if(settings)await db.update(officeSettings).set({primaryOwnerId:user.userId}).where(and(eq(officeSettings.id,"office"),eq(officeSettings.primaryOwnerId,"")));
  primaryOwnerId=user.userId;
 }
 if(!primaryOwnerId)throw new ApiError(503,"يلزم دخول مدير المكتب أولًا لتفعيل مساحة الموظفين");
 const userId = isAdmin ? primaryOwnerId : staffUserId(user.email);
 await ensureStaffUser(isAdmin ? "MANAGER" : "STAFF", userId, user.email);
 const authority = await loadAuthority(userId);
 const expected = isAdmin ? "MANAGER" : "STAFF";
 if (!authority.actor.active || authority.actor.role !== expected) throw new ApiError(403,"هذا الحساب غير مخوّل بدخول لوحة الموظفين");
 if (!isAdmin) requireCapability(authority, "view_crm");
 const role = authority.actor.role as "MANAGER" | "STAFF";
 return {user,role,ownerId:primaryOwnerId,authority,scope:{ownerId:primaryOwnerId,authority} as Scope};
}
export async function owner(): Promise<Scope> {return (await staff()).scope;}
export async function admin(){const s=await staff();requireManager(s.authority);return s;}
/** Capability check against the D1 authority loaded for this request (fails closed). */
export async function staffWith(capability: string){const s=await staff();requireCapability(s.authority,capability);return s;}
export async function ownerWith(capability: string): Promise<Scope>{return (await staffWith(capability)).scope;}
export function sameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin) throw new ApiError(403,"الطلب غير مسموح");
  if (request.headers.get("sec-fetch-site") === "cross-site") throw new ApiError(403,"الطلب غير مسموح");
}
export async function candidateOwned(id: string, scope: Scope) {
  const [row] = await getDb().select().from(candidates).where(and(eq(candidates.id,id),owned(candidates.ownerId,scope))).limit(1);
  if (!row) throw new ApiError(404,"الملف غير موجود"); return row;
}
export function audit(ownerId: string, candidateId: string, action: string, note = "") {
  return getDb().insert(events).values({ id:crypto.randomUUID(),ownerId,candidateId,action,note,createdAt:new Date().toISOString() });
}
export function errorResponse(error: unknown) {
  if(!(error instanceof ApiError)||error.status>=500){try{waitUntil(getDb().insert(operationLogs).values({id:crypto.randomUUID(),operation:"api_error",actor:"system",result:"failed",code:error instanceof ApiError?"HTTP_"+error.status:error instanceof Error?error.name:"UNKNOWN",createdAt:new Date().toISOString()}).then(()=>{}).catch(()=>{}));}catch{}}
  if (error instanceof ApiError) return Response.json({error:error.message},{status:error.status,headers:{"Cache-Control":"private, no-store"}});
  if (error instanceof SyntaxError) return Response.json({error:"صيغة الطلب غير صحيحة"},{status:400});
  console.error("Canada Desk request failed", error instanceof Error ? error.name : "unknown");
  return Response.json({error:"تعذّر إتمام العملية. حاول مرة أخرى."},{status:500});
}

export async function readJson<T extends z.ZodTypeAny>(request:Request,schema:T,maxBytes=40000):Promise<z.infer<T>> {
  if(!request.headers.get("content-type")?.toLowerCase().includes("application/json")) throw new ApiError(415,"صيغة الطلب يجب أن تكون JSON");
  if(Number(request.headers.get("content-length"))>maxBytes) throw new ApiError(413,"الطلب أكبر من الحد المسموح");
  const reader=request.body?.getReader(); if(!reader) throw new ApiError(400,"الطلب فارغ");
  const decoder=new TextDecoder(); let size=0; let body="";
  try { while(true) {const {value,done}=await reader.read();if(done)break;size+=value.byteLength;if(size>maxBytes){await reader.cancel();throw new ApiError(413,"الطلب أكبر من الحد المسموح");}body+=decoder.decode(value,{stream:true});} body+=decoder.decode(); } finally {reader.releaseLock();}
  const parsed=schema.safeParse(JSON.parse(body));
  if(!parsed.success) throw new ApiError(400,parsed.error.issues[0].message);
  return parsed.data;
}
