// v2.2 Gate 2 — four roles and server-side permissions on top of the EXISTING authentication (no IdP, no parallel
// sessions). The verified identity from lib/server.ts staff() is mapped to a `users` row; authority (active, role,
// permission epoch, open-access state) is re-read from D1 before every protected access. KV only caches the STAFF role
// policy under a key that includes the current D1 epoch, so a stale entry can never restore a revoked permission.
import { env } from 'cloudflare:workers';
import { getDb } from '@/db';
import { users, officeMembers, caseAccess } from '@/db/schema';
import { and, eq } from 'drizzle-orm';
import { ApiError } from './api-error';
import { BASE_CATALOG, STAFF_CAPABILITIES, MANAGER_RESERVED_CAPABILITIES, effectivePermission, openAllActive, torontoDate, nextTorontoMidnightMs, type Catalog, type OpenState, type Role } from './v22-core';

export const SYSTEM_USER_ID = 'system:v2.2';
export const staffUserId = (email: string) => 'staff:' + email.trim().toLowerCase();

/** Server catalog: product + financial STAFF capabilities, MANAGER-reserved and SYSTEM task capabilities. */
export const CATALOG: Catalog = BASE_CATALOG;
for (const k of STAFF_CAPABILITIES) if (!Object.hasOwn(CATALOG, k)) throw new Error('CATALOG_INCOMPLETE:' + k);

export type Actor = { userId: string; role: Role; active: boolean; permissionVersion: number; custom: Record<string, boolean> };
export type Authority = { actor: Actor; epoch: number; rolePermissions: Record<string, boolean>; open: OpenState };

type Kv = { get(key: string): Promise<string | null>; put(key: string, value: string, opts?: { expirationTtl?: number }): Promise<void> };
function kv(): Kv | null { const b = (env as unknown as { PERMISSIONS_KV?: Kv }).PERMISSIONS_KV; return b && typeof b.get === 'function' ? b : null; }
function kvNamespace() { return ((env as unknown as { PERMISSIONS_KV_NAMESPACE?: string }).PERMISSIONS_KV_NAMESPACE || 'canada-desk') + ':perm:v1'; }
export const rolePolicyKey = (epoch: number) => `${kvNamespace()}:role:STAFF:e${epoch}`;

/** Primary-consistent D1 handle when the Sessions API exists; otherwise the binding (single-region D1 reads the primary). */
function primary(): D1Database {
  const db = env.DB; if (!db) throw new ApiError(503, 'قاعدة البيانات غير متاحة');
  const withSession = (db as unknown as { withSession?: (c: string) => D1Database }).withSession;
  return typeof withSession === 'function' ? withSession.call(db, 'first-primary') : db;
}
function parseBooleans(raw: unknown): Record<string, boolean> {
  const value = typeof raw === 'string' ? JSON.parse(raw) : raw;
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new ApiError(503, 'تعذر التحقق من الصلاحيات');
  const out: Record<string, boolean> = {};
  for (const [k, v] of Object.entries(value)) { if (typeof v !== 'boolean') throw new ApiError(503, 'تعذر التحقق من الصلاحيات'); out[k] = v; }
  return out;
}

/** Re-read authority from D1 (fail closed). The role policy may come from KV only under the current D1 epoch. */
export async function loadAuthority(userId: string): Promise<Authority> {
  let user: Record<string, unknown> | null, runtime: Record<string, unknown> | null;
  const db = primary();
  try {
    [user, runtime] = await Promise.all([
      db.prepare('SELECT user_id,role,active,permission_version,custom_permissions FROM users WHERE user_id=?').bind(userId).first(),
      db.prepare('SELECT version,open_all_enabled,open_all_local_date,open_until_ms FROM permission_runtime WHERE singleton=1').first(),
    ]);
  } catch { throw new ApiError(503, 'تعذر التحقق من الصلاحيات'); }
  if (!user || !runtime) throw new ApiError(403, 'هذا الحساب غير مخوّل');
  const epoch = Number(runtime.version);
  let policy: string | null = null; const cache = kv();
  if (cache) { try { policy = await cache.get(rolePolicyKey(epoch)); } catch { policy = null; } }
  if (policy === null) {
    const row = await db.prepare("SELECT permissions_json FROM role_permissions WHERE role='STAFF'").first<{ permissions_json: string }>().catch(() => null);
    if (!row) throw new ApiError(503, 'تعذر التحقق من الصلاحيات');
    policy = row.permissions_json;
    if (cache) { try { await cache.put(rolePolicyKey(epoch), policy, { expirationTtl: 300 }); } catch { /* cache is optional */ } }
  }
  return {
    actor: { userId: String(user.user_id), role: user.role as Role, active: Number(user.active) === 1, permissionVersion: Number(user.permission_version), custom: parseBooleans(user.custom_permissions) },
    epoch, rolePermissions: parseBooleans(policy),
    open: { enabled: Number(runtime.open_all_enabled) === 1, localDate: (runtime.open_all_local_date as string | null) ?? null, untilMs: Number(runtime.open_until_ms) },
  };
}

export function can(a: Authority, cap: string, now = Date.now()): boolean {
  return effectivePermission(a.actor, cap, a.rolePermissions, a.actor.custom, a.open, now, CATALOG);
}
export function requireCapability(a: Authority, cap: string, now = Date.now()) {
  if (!can(a, cap, now)) throw new ApiError(403, 'لا تملك صلاحية تنفيذ هذه العملية');
}
export function requireManager(a: Authority) {
  if (a.actor.role !== 'MANAGER' || !a.actor.active) throw new ApiError(403, 'هذه العملية للمدير فقط');
}

/**
 * Map the verified staff identity to its users row. Mapping sources are trusted server records only:
 * MANAGER = office_settings.primary_owner_id (set by the authenticated OFFICE_ADMIN_EMAIL session),
 * STAFF = an active office_members row (manager-maintained). Nothing from the request body is used.
 */
export async function ensureStaffUser(kind: 'MANAGER' | 'STAFF', userId: string, email: string) {
  const db = getDb(), now = new Date().toISOString();
  if (kind === 'MANAGER') {
    await db.insert(users).values({ userId, role: 'MANAGER', createdAt: now }).onConflictDoNothing();
    return;
  }
  const [member] = await db.select({ active: officeMembers.active }).from(officeMembers).where(eq(officeMembers.email, email.toLowerCase())).limit(1);
  if (!member?.active) throw new ApiError(403, 'هذا الحساب غير مخوّل بدخول لوحة الموظفين');
  await db.insert(users).values({ userId, role: 'STAFF', active: 1, createdAt: now }).onConflictDoNothing();
}

export async function hasCaseGrant(caseId: string, userId: string) {
  const [row] = await getDb().select({ c: caseAccess.caseId }).from(caseAccess).where(and(eq(caseAccess.caseId, caseId), eq(caseAccess.userId, userId))).limit(1);
  return !!row;
}

// ---- Permission mutations: one INSERT into permission_changes_audit; triggers apply value + version + epoch atomically.
function canonical(map: Record<string, boolean>) { return JSON.stringify(Object.fromEntries(Object.keys(map).sort().map(k => [k, map[k]]))); }
const reserved = new Set<string>(MANAGER_RESERVED_CAPABILITIES);
export function assertAssignable(key: string) {
  if (!Object.hasOwn(CATALOG, key) || CATALOG[key].staffAssignable !== true || reserved.has(key)) throw new ApiError(400, 'صلاحية غير موجودة في كتالوج الموظفين');
}
const conflictCodes = ['PERMISSION_EPOCH_CONFLICT', 'ROLE_PERMISSION_CONFLICT', 'INVALID_PERMISSION_TARGET', 'OPEN_ACCESS_SNAPSHOT_CONFLICT', 'OPEN_ACCESS_VERSION_CONFLICT', 'UNIQUE constraint failed'];
async function applyChange(stmt: D1PreparedStatement) {
  try { await stmt.run(); }
  catch (e) {
    const m = e instanceof Error ? e.message : '';
    if (conflictCodes.some(c => m.includes(c))) throw new ApiError(409, 'تغيّرت الصلاحيات قبل حفظ طلبك. حدّث الصفحة وأعد المحاولة.');
    if (m.includes('MANAGER_REQUIRED') || m.includes('ROOT_PERMISSIONS_IMMUTABLE')) throw new ApiError(403, 'هذه العملية للمدير فقط');
    if (m.includes('INVALID_PERMISSION_KEY_OR_TYPE')) throw new ApiError(400, 'صلاحية غير صالحة');
    throw e;
  }
}
const insertAudit = 'INSERT INTO permission_changes_audit(audit_id,change_kind,target_user_id,target_role,old_permissions,new_permissions,expected_version,expected_epoch,changed_by,changed_at) VALUES(?,?,?,?,?,?,?,?,?,?)';

export async function toggleStaffPermission(manager: Authority, input: { target: 'ROLE' | 'USER'; targetUserId?: string; key: string; value: boolean; expectedVersion: number; expectedEpoch: number; requestKey: string }) {
  requireManager(manager); assertAssignable(input.key);
  const db = primary(), now = new Date().toISOString();
  let old: Record<string, boolean>;
  if (input.target === 'ROLE') {
    const row = await db.prepare("SELECT permissions_json FROM role_permissions WHERE role='STAFF' AND version=?").bind(input.expectedVersion).first<{ permissions_json: string }>();
    if (!row) throw new ApiError(409, 'تغيّرت الصلاحيات قبل حفظ طلبك. حدّث الصفحة وأعد المحاولة.');
    old = parseBooleans(row.permissions_json);
    const next = canonical({ ...old, [input.key]: input.value });
    await applyChange(db.prepare(insertAudit).bind('perm:' + input.requestKey, 'ROLE', null, 'STAFF', row.permissions_json, next, input.expectedVersion, input.expectedEpoch, manager.actor.userId, now));
  } else {
    if (!input.targetUserId) throw new ApiError(400, 'حدد الموظف');
    const row = await db.prepare("SELECT custom_permissions FROM users WHERE user_id=? AND role='STAFF' AND permission_version=?").bind(input.targetUserId, input.expectedVersion).first<{ custom_permissions: string }>();
    if (!row) throw new ApiError(409, 'تغيّرت الصلاحيات قبل حفظ طلبك. حدّث الصفحة وأعد المحاولة.');
    old = parseBooleans(row.custom_permissions);
    const next = canonical({ ...old, [input.key]: input.value });
    await applyChange(db.prepare(insertAudit).bind('perm:' + input.requestKey, 'USER', input.targetUserId, null, row.custom_permissions, next, input.expectedVersion, input.expectedEpoch, manager.actor.userId, now));
  }
}

function openSnapshot(o: OpenState) { return JSON.stringify({ enabled: o.enabled, localDate: o.localDate, untilMs: o.untilMs }); }

/** One MANAGER switch: STAFF open until the next America/Toronto midnight computed on the server. */
export async function setOpenAll(manager: Authority, input: { enabled: boolean; expectedEpoch: number; requestKey: string }, now = Date.now()) {
  requireManager(manager);
  const next = input.enabled
    ? { enabled: true, localDate: torontoDate(now), untilMs: nextTorontoMidnightMs(now) }
    : { enabled: false, localDate: null, untilMs: 0 };
  await applyChange(primary().prepare(insertAudit).bind('open:' + input.requestKey, 'OPEN_ALL', null, 'STAFF', openSnapshot(manager.open), JSON.stringify(next), input.expectedEpoch, input.expectedEpoch, manager.actor.userId, new Date(now).toISOString()));
  return next;
}

/** SYSTEM can only close an expired switch; deterministic id dedupes repeated cron ticks. */
export async function autoKillExpired(now = Date.now()) {
  const db = primary();
  const r = await db.prepare('SELECT version,open_all_enabled,open_all_local_date,open_until_ms FROM permission_runtime WHERE singleton=1').first<{ version: number; open_all_enabled: number; open_all_local_date: string | null; open_until_ms: number }>();
  if (!r || r.open_all_enabled !== 1) return { closed: false };
  const state: OpenState = { enabled: true, localDate: r.open_all_local_date, untilMs: r.open_until_ms };
  if (openAllActive(state, now)) return { closed: false };
  try {
    await db.prepare(insertAudit).bind(`auto-kill:${r.open_all_local_date}:${r.version}`, 'AUTO_KILL', null, 'STAFF', openSnapshot(state), JSON.stringify({ enabled: false, localDate: null, untilMs: 0 }), r.version, r.version, SYSTEM_USER_ID, new Date(now).toISOString()).run();
  } catch (e) {
    const m = e instanceof Error ? e.message : '';
    if (conflictCodes.some(c => m.includes(c))) return { closed: false };
    throw e;
  }
  return { closed: true };
}

/** A case created by a STAFF member is granted to that member in the creation batch (granted by SYSTEM). */
export function creatorGrants(a: Authority | null, caseIds: string[]) {
  if (!a || a.actor.role !== 'STAFF' || !caseIds.length) return [];
  const db = getDb(), now = new Date().toISOString();
  return caseIds.map(caseId => db.insert(caseAccess).values({ caseId, userId: a.actor.userId, grantedBy: SYSTEM_USER_ID, createdAt: now }));
}

/**
 * Resolve a "follow-up owner" typed by any staff member: an active office member matched by email or by name
 * (case-insensitive, trimmed). One match -> that STAFF user; several members with the same name -> 409 (use the email);
 * no match -> null (the text is still saved as before, it just names nobody on the staff list).
 */
export async function resolveAssignee(text: string): Promise<{ userId: string; email: string } | null> {
  const value = text.trim().toLowerCase();
  if (!value) return null;
  const members = await getDb().select({ email: officeMembers.email, name: officeMembers.name }).from(officeMembers).where(eq(officeMembers.active, true));
  const hits = members.filter(m => m.email.toLowerCase() === value || m.name.trim().toLowerCase() === value);
  const unique = [...new Map(hits.map(m => [m.email.toLowerCase(), m])).values()];
  if (unique.length > 1) throw new ApiError(409, 'يوجد أكثر من موظف بهذا الاسم؛ اكتب البريد الإلكتروني للموظف.');
  if (!unique.length) return null;
  return { userId: staffUserId(unique[0].email), email: unique[0].email.toLowerCase() };
}
