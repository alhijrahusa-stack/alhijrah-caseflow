// v2.2 Gate 4 — account drafts and the fixed signature (10 §4–5). A draft is pre-submission input owned by the account
// key derived from the verified email session; it is not a second case store or a lead. Every write carries
// expectedRevision + a unique mutationId: the same mutation with the same payload replays the committed revision, a
// different payload under the same id is 409, and a stale revision is 409 with the current revision (no silent
// last-write-wins). Revisions are enforced by the 0024 triggers (draft_mutation_guard / draft_revision_guard).
import { env } from 'cloudflare:workers';
import { z } from 'zod';
import { getDb } from '@/db';
import { clientApplicationDrafts,clientDraftMutations } from '@/db/schema';
import { and,eq,desc } from 'drizzle-orm';
import { ApiError } from './api-error';
import { profileSchema,blankProfile } from './model';
import { detailsSchema } from './intake';
import { accountSession,accountKeyOf,accountProfile } from './client-account';
import { AUTHORIZATION_TEXT,LEGAL_VERSION } from './legal';
import { jcsHash,sha256Hex } from './v22-core';
import { inspectSignaturePng,signingPayloadHash } from './signature';

export const pathSelectionSchema=z.object({
 selectedPathId:z.enum(['work','immigration','study','other','unsure']).nullable(),focused:z.boolean(),needsGuidance:z.boolean(),
 subOptions:z.array(z.object({key:z.string().min(1).max(200),value:z.union([z.string().max(500),z.number().finite(),z.boolean(),z.null()])}).strict()).max(20),
}).strict().refine(v=>v.selectedPathId!=='unsure'||v.needsGuidance,'NEEDS_GUIDANCE_REQUIRED').refine(v=>v.selectedPathId!==null||!v.focused,'FOCUS_WITHOUT_SELECTION');
export type PathSelection=z.infer<typeof pathSelectionSchema>;
const draftProfileSchema=profileSchema.omit({consent:true}).extend({fullName:z.string().max(150),email:z.string().max(254),phone:z.string().max(40),noc:z.string().max(5)});
export const draftPayloadSchema=z.object({profile:draftProfileSchema,details:detailsSchema,pathSelection:pathSelectionSchema,step:z.number().int().min(1).max(4)}).strict();
export type DraftPayload=z.infer<typeof draftPayloadSchema>;
export const draftWriteSchema=z.object({expectedRevision:z.number().int().min(1),mutationId:z.string().uuid(),payload:z.unknown()}).strict();
export const signatureManifestSchema=z.object({expectedRevision:z.number().int().min(1),mutationId:z.string().uuid(),signedPayloadHash:z.string().regex(/^[0-9a-f]{64}$/),legalVersion:z.string().min(1).max(200)}).strict();
export const signatureClearSchema=z.object({expectedRevision:z.number().int().min(1),mutationId:z.string().uuid()}).strict();
export const blankPathSelection:PathSelection={selectedPathId:null,focused:false,needsGuidance:false,subOptions:[]};
type Row=typeof clientApplicationDrafts.$inferSelect;
export class DraftConflict extends Error{constructor(public code:string,public currentRevision:number|null){super(code);}}
const MAX_PAYLOAD=100_000;

export async function requireAccount(request:Request){const a=await accountSession(request);if(!a)throw new ApiError(401,'يلزم تأكيد البريد الإلكتروني.');return {email:a.email,accountKey:await accountKeyOf(a.email)};}
// RFC 4122 v4-shaped id derived from the account and the client request key, so a retried create is idempotent.
async function derivedId(accountKey:string,requestKey:string){const h=await sha256Hex('draft-create:v1:'+accountKey+':'+requestKey);return `${h.slice(0,8)}-${h.slice(8,12)}-4${h.slice(13,16)}-${'89ab'[parseInt(h[16],16)%4]}${h.slice(17,20)}-${h.slice(20,32)}`;}
const revisionOfKey=(key:string|null)=>{const m=key?/\/(\d+)-[0-9a-f-]{36}\.png$/.exec(key):null;return m?Number(m[1]):null;};
export function signatureRecord(r:Row){
 if(!r.signatureId||!r.signatureObjectKey||!r.signatureSha256||!r.signedPayloadHash||!r.signatureLegalVersion||!r.signatureSignedAt)return null;
 return {signatureId:r.signatureId,draftRevision:revisionOfKey(r.signatureObjectKey)??1,state:'SIGNED' as const,signedPayloadHash:r.signedPayloadHash,legalVersion:r.signatureLegalVersion,signedAt:r.signatureSignedAt,imageHash:r.signatureSha256};
}
export function draftResource(r:Row){return {draftId:r.draftId,revision:r.revision,state:r.state as 'DRAFT'|'SUBMITTED',payload:JSON.parse(r.payloadJson) as DraftPayload,signature:signatureRecord(r)};}
async function owned(accountKey:string,draftId:string){const [r]=await getDb().select().from(clientApplicationDrafts).where(and(eq(clientApplicationDrafts.accountKey,accountKey),eq(clientApplicationDrafts.draftId,draftId))).limit(1);if(!r)throw new ApiError(404,'المسودة غير موجودة في حسابك.');return r;}
export async function listDrafts(accountKey:string){return {items:(await getDb().select({draftId:clientApplicationDrafts.draftId,state:clientApplicationDrafts.state,updatedAt:clientApplicationDrafts.updatedAt}).from(clientApplicationDrafts).where(eq(clientApplicationDrafts.accountKey,accountKey)).orderBy(desc(clientApplicationDrafts.updatedAt)).limit(50)).map(r=>({...r,state:r.state as 'DRAFT'|'SUBMITTED'}))};}
export async function readDraft(accountKey:string,draftId:string){return draftResource(await owned(accountKey,draftId));}
function normalize(raw:unknown,email:string):DraftPayload{
 const p=draftPayloadSchema.safeParse(raw);if(!p.success)throw new ApiError(400,'بيانات المسودة غير صالحة: '+p.error.issues[0].path.join('.'));
 const payload={...p.data,profile:{...p.data.profile,email}};if(JSON.stringify(payload).length>MAX_PAYLOAD)throw new ApiError(413,'المسودة أكبر من الحد المسموح.');return payload;
}
export async function createDraft(account:{email:string;accountKey:string},requestKey:string){
 const profile=await accountProfile(account.email);if(!profile)throw new ApiError(428,'أدخل اسمك لإنشاء ملف الحساب قبل بدء المسودة.');
 const draftId=await derivedId(account.accountKey,requestKey),db=getDb(),[existing]=await db.select().from(clientApplicationDrafts).where(eq(clientApplicationDrafts.draftId,draftId)).limit(1);
 if(existing){if(existing.accountKey!==account.accountKey)throw new ApiError(409,'تعذّر إنشاء المسودة.');return {created:false,draft:draftResource(existing)};}
 const {consent:_c,...profileFields}=blankProfile;void _c;
 const payload=normalize({profile:{...profileFields,fullName:profile.displayName,email:account.email},details:detailsSchema.parse({}),pathSelection:blankPathSelection,step:1},account.email),now=new Date().toISOString();
 await db.insert(clientApplicationDrafts).values({draftId,accountKey:account.accountKey,revision:1,state:'DRAFT',payloadJson:JSON.stringify(payload),payloadHash:await jcsHash(payload),createdAt:now,updatedAt:now}).onConflictDoNothing();
 return {created:true,draft:draftResource(await owned(account.accountKey,draftId))};
}
const isConstraint=(e:unknown)=>{const m=e instanceof Error?e.message+String((e as {cause?:unknown}).cause??''):String(e);return /DRAFT_REVISION_CONFLICT|INVALID_DRAFT_UPDATE|DRAFT_MUTATION_REQUIRED|UNIQUE constraint failed|PRIMARY KEY/.test(m);};
async function replay(accountKey:string,draftId:string,mutationId:string,requestHash:string){
 const [m]=await getDb().select().from(clientDraftMutations).where(and(eq(clientDraftMutations.accountKey,accountKey),eq(clientDraftMutations.draftId,draftId),eq(clientDraftMutations.mutationId,mutationId))).limit(1);
 if(!m)return null;if(m.requestHash!==requestHash)throw new DraftConflict('MUTATION_REUSED',null);return m;
}
export async function saveDraft(account:{email:string;accountKey:string},draftId:string,input:z.infer<typeof draftWriteSchema>){
 const payload=normalize(input.payload,account.email),requestHash=await jcsHash({kind:'save',draftId,expectedRevision:input.expectedRevision,payload});
 const prior=await replay(account.accountKey,draftId,input.mutationId,requestHash);if(prior)return {draftId,revision:prior.expectedRevision+1,mutationId:input.mutationId,savedAt:prior.createdAt};
 const current=await owned(account.accountKey,draftId);if(current.state!=='DRAFT')throw new DraftConflict('DRAFT_SUBMITTED',current.revision);
 if(current.revision!==input.expectedRevision)throw new DraftConflict('DRAFT_REVISION_CONFLICT',current.revision);
 const db=getDb(),now=new Date().toISOString();
 try{await db.batch([
  db.insert(clientDraftMutations).values({accountKey:account.accountKey,draftId,mutationId:input.mutationId,expectedRevision:input.expectedRevision,requestHash,createdAt:now}),
  db.update(clientApplicationDrafts).set({revision:input.expectedRevision+1,payloadJson:JSON.stringify(payload),payloadHash:await jcsHash(payload),updatedAt:now}).where(and(eq(clientApplicationDrafts.accountKey,account.accountKey),eq(clientApplicationDrafts.draftId,draftId),eq(clientApplicationDrafts.revision,input.expectedRevision))),
 ]);}
 catch(e){const again=await replay(account.accountKey,draftId,input.mutationId,requestHash);if(again)return {draftId,revision:again.expectedRevision+1,mutationId:input.mutationId,savedAt:again.createdAt};if(isConstraint(e)){const [r]=await db.select({revision:clientApplicationDrafts.revision}).from(clientApplicationDrafts).where(eq(clientApplicationDrafts.draftId,draftId)).limit(1);throw new DraftConflict('DRAFT_REVISION_CONFLICT',r?.revision??null);}throw e;}
 return {draftId,revision:input.expectedRevision+1,mutationId:input.mutationId,savedAt:now};
}
const bucket=()=>{const b=(env as unknown as {BUCKET?:R2Bucket}).BUCKET;if(!b)throw new ApiError(503,'تخزين التوقيع غير متاح.');return b;};
export async function snapshotHash(accountKey:string,r:Row,legalVersion:string){const p=JSON.parse(r.payloadJson) as DraftPayload;return signingPayloadHash({accountKey,draftId:r.draftId,profile:p.profile,details:p.details,pathSelection:p.pathSelection,legalVersion,authorizationText:AUTHORIZATION_TEXT,mandatoryAcceptanceValues:{legalAuthorization:true}});}
// Save the signature: private PNG in R2, then one batch (mutation + revision + signature columns). The signing time is
// the server's; the browser supplies no time, object key or URL. An existing signature must be cleared explicitly first.
export async function saveSignature(account:{email:string;accountKey:string},draftId:string,manifest:z.infer<typeof signatureManifestSchema>,image:Uint8Array){
 if(manifest.legalVersion!==LEGAL_VERSION)throw new ApiError(409,'نسخة الإقرار تغيّرت؛ حدّث الصفحة.');
 const imageHash=await sha256Hex(image),requestHash=await jcsHash({kind:'signature',draftId,expectedRevision:manifest.expectedRevision,signedPayloadHash:manifest.signedPayloadHash,imageHash});
 const prior=await replay(account.accountKey,draftId,manifest.mutationId,requestHash);if(prior){const r=await owned(account.accountKey,draftId),rec=signatureRecord(r);if(rec)return rec;}
 const r=await owned(account.accountKey,draftId);
 if(r.state!=='DRAFT')throw new DraftConflict('DRAFT_SUBMITTED',r.revision);
 if(r.revision!==manifest.expectedRevision)throw new DraftConflict('DRAFT_REVISION_CONFLICT',r.revision);
 if(r.signatureId)throw new DraftConflict('SIGNATURE_EXISTS',r.revision);
 if(await snapshotHash(account.accountKey,r,manifest.legalVersion)!==manifest.signedPayloadHash)throw new DraftConflict('SIGNED_PAYLOAD_MISMATCH',r.revision);
 const png=await inspectSignaturePng(image);if(!png.ok)throw new ApiError(422,'التوقيع غير صالح ('+png.code+'). ارسم توقيعك ثم احفظه.');
 const signatureId=crypto.randomUUID(),revision=manifest.expectedRevision+1,key=`signatures/${account.accountKey}/${draftId}/${revision}-${signatureId}.png`,signedAt=new Date().toISOString(),db=getDb();
 await bucket().put(key,image,{httpMetadata:{contentType:'image/png'},customMetadata:{sha256:imageHash,draftId,signedPayloadHash:manifest.signedPayloadHash}});
 try{await db.batch([
  db.insert(clientDraftMutations).values({accountKey:account.accountKey,draftId,mutationId:manifest.mutationId,expectedRevision:manifest.expectedRevision,requestHash,createdAt:signedAt}),
  db.update(clientApplicationDrafts).set({revision,signatureId,signatureObjectKey:key,signatureSha256:imageHash,signedPayloadHash:manifest.signedPayloadHash,signatureLegalVersion:manifest.legalVersion,signatureSignedAt:signedAt,updatedAt:signedAt}).where(and(eq(clientApplicationDrafts.accountKey,account.accountKey),eq(clientApplicationDrafts.draftId,draftId),eq(clientApplicationDrafts.revision,manifest.expectedRevision))),
 ]);}
 catch(e){await bucket().delete(key).catch(()=>undefined);const again=await replay(account.accountKey,draftId,manifest.mutationId,requestHash);if(again){const rec=signatureRecord(await owned(account.accountKey,draftId));if(rec)return rec;}if(isConstraint(e))throw new DraftConflict('DRAFT_REVISION_CONFLICT',null);throw e;}
 return signatureRecord(await owned(account.accountKey,draftId))!;
}
// Explicit "clear signature" (user action): a new revision without a signature; the image is removed afterwards.
export async function clearSignature(account:{email:string;accountKey:string},draftId:string,input:z.infer<typeof signatureClearSchema>){
 const requestHash=await jcsHash({kind:'clear',draftId,expectedRevision:input.expectedRevision});
 const prior=await replay(account.accountKey,draftId,input.mutationId,requestHash);if(prior)return {draftId,revision:prior.expectedRevision+1,mutationId:input.mutationId,savedAt:prior.createdAt};
 const r=await owned(account.accountKey,draftId);
 if(r.state!=='DRAFT')throw new DraftConflict('DRAFT_SUBMITTED',r.revision);
 if(r.revision!==input.expectedRevision)throw new DraftConflict('DRAFT_REVISION_CONFLICT',r.revision);
 if(!r.signatureId)throw new DraftConflict('NO_SIGNATURE',r.revision);
 const db=getDb(),now=new Date().toISOString();
 try{await db.batch([
  db.insert(clientDraftMutations).values({accountKey:account.accountKey,draftId,mutationId:input.mutationId,expectedRevision:input.expectedRevision,requestHash,createdAt:now}),
  db.update(clientApplicationDrafts).set({revision:input.expectedRevision+1,signatureId:null,signatureObjectKey:null,signatureSha256:null,signedPayloadHash:null,signatureLegalVersion:null,signatureSignedAt:null,updatedAt:now}).where(and(eq(clientApplicationDrafts.accountKey,account.accountKey),eq(clientApplicationDrafts.draftId,draftId),eq(clientApplicationDrafts.revision,input.expectedRevision))),
 ]);}
 catch(e){if(isConstraint(e))throw new DraftConflict('DRAFT_REVISION_CONFLICT',null);throw e;}
 if(r.signatureObjectKey)await bucket().delete(r.signatureObjectKey).catch(()=>undefined);
 return {draftId,revision:input.expectedRevision+1,mutationId:input.mutationId,savedAt:now};
}
export async function signatureImage(accountKey:string,draftId:string){
 const r=await owned(accountKey,draftId);if(!r.signatureObjectKey)throw new ApiError(404,'لا يوجد توقيع محفوظ.');
 const obj=await bucket().get(r.signatureObjectKey);if(!obj)throw new ApiError(404,'لا يوجد توقيع محفوظ.');
 return new Response(obj.body,{headers:{'Content-Type':'image/png','Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'"}});
}
// Submission binding (used by /api/intake inside its own batch): the draft must be owned by the verified account, still
// DRAFT at the expected revision, and carry exactly the signature the request names with its original snapshot hash.
export async function submissionBinding(accountKey:string,input:{draftId:string;expectedDraftRevision:number;signatureId:string;signedPayloadHash:string}){
 const r=await owned(accountKey,input.draftId);
 if(r.state!=='DRAFT')throw new DraftConflict('DRAFT_SUBMITTED',r.revision);
 if(r.revision!==input.expectedDraftRevision)throw new DraftConflict('DRAFT_REVISION_CONFLICT',r.revision);
 if(!r.signatureId||r.signatureId!==input.signatureId||r.signedPayloadHash!==input.signedPayloadHash||!r.signatureObjectKey||!r.signatureSha256||!r.signatureSignedAt)throw new ApiError(422,'يلزم توقيع محفوظ لهذه المسودة قبل الإرسال.');
 return {row:r,signature:{signatureId:r.signatureId,signatureObjectKey:r.signatureObjectKey,signatureSha256:r.signatureSha256,signedPayloadHash:r.signedPayloadHash,signatureSignedAt:r.signatureSignedAt,signerAccountKey:accountKey}};
}
export function submissionStatements(accountKey:string,draftId:string,expectedRevision:number,requestId:string,candidateId:string,signedPayloadHash:string,now:string){
 const db=getDb();
 return [
  // The submit mutation's request hash is the signed snapshot hash it binds (the intake request has its own payload hash).
  db.insert(clientDraftMutations).values({accountKey,draftId,mutationId:requestId,expectedRevision,requestHash:signedPayloadHash,createdAt:now}),
  db.update(clientApplicationDrafts).set({revision:expectedRevision+1,state:'SUBMITTED',submittedCandidateId:candidateId,updatedAt:now}).where(and(eq(clientApplicationDrafts.accountKey,accountKey),eq(clientApplicationDrafts.draftId,draftId),eq(clientApplicationDrafts.revision,expectedRevision))),
 ] as const;
}
export function conflictResponse(e:DraftConflict){return Response.json({code:e.code,error:e.code==='DRAFT_REVISION_CONFLICT'?'تغيّرت المسودة من نافذة أخرى. راجع أحدث نسخة قبل المتابعة.':e.code==='SIGNATURE_EXISTS'?'يوجد توقيع محفوظ؛ امسحه صراحة قبل توقيع جديد.':e.code==='SIGNED_PAYLOAD_MISMATCH'?'تغيّرت بيانات المسودة قبل حفظ التوقيع؛ أعد المحاولة.':e.code==='DRAFT_SUBMITTED'?'أُرسلت هذه المسودة بالفعل.':e.code==='MUTATION_REUSED'?'معرّف الحفظ مستخدم لبيانات أخرى.':'تعارض في المسودة.',currentRevision:e.currentRevision},{status:409,headers:{'Cache-Control':'private, no-store'}});}
