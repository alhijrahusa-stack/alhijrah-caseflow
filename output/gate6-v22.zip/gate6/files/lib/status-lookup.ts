// v2.2 Gate 4 — status lookup without signing in (10 §7). One identifier (email, international phone or case number);
// the server never accepts a destination, candidate id or channel. Request and resend always answer the same 202
// envelope whether or not a file matches or delivery fails; the challenge row is stored with an encrypted delivery
// payload and dispatched afterwards (waitUntil plus the scheduled handler recovering leased/abandoned rows). Codes have
// purpose 'status_lookup' and cannot open account_login/case_login. Proof is short-lived and bound to the identifier;
// the result token is scope 'case_status' in client_sessions (5 minutes, its own cookie and path) and is rejected by
// clientCase() and every file/document/signature route. The answer is caseNumber, statusCode, updatedAt, nextAction.
import { z } from 'zod';
import { getDb } from '@/db';
import { authChallenges,candidates,clientCases,clientSessions } from '@/db/schema';
import { and,eq,gt,isNull,lt,lte,sql,inArray } from 'drizzle-orm';
import { ApiError } from './api-error';
import { accessCode,decrypt,encrypt,sha } from './security';
import { codeDigest,targetThrottle } from './otp';
import { deliverOtp,deliveryOptions,internationalPhone } from './otp-delivery';
import { readCookie } from './client-access';

export const LOOKUP_COOKIE='alh_status_lookup';
export const LOOKUP_SECONDS=5*60;
const PROOF_MS=10*60*1000;
export type IdentifierKind='EMAIL'|'PHONE'|'CASE_NUMBER';
const latin=(v:string)=>v.normalize('NFKC').replace(/[٠-٩]/g,c=>String(c.charCodeAt(0)-1632)).replace(/[۰-۹]/g,c=>String(c.charCodeAt(0)-1776)).trim();
// Classification only; no country code is guessed and an email keeps its dots and plus signs.
export function classifyIdentifier(raw:string):{kind:IdentifierKind;value:string}|null{
 const v=latin(raw);
 if(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)&&v.length<=254)return {kind:'EMAIL',value:v.toLowerCase()};
 const phone=internationalPhone(v);if(phone)return {kind:'PHONE',value:phone};
 if(/^ALH-[A-Z0-9-]{4,90}$/i.test(v))return {kind:'CASE_NUMBER',value:v.toUpperCase()};
 return null;
}
const phoneSql=sql`'+'||replace(replace(replace(replace(replace(replace(replace(json_extract(${candidates.profile},'$.phone'),' ',''),'-',''),'(',''),')',''),'.',''),'+',''),'00','')`;
// Matching files for an identifier (client files only). Same query shape for every outcome.
async function matches(kind:IdentifierKind,value:string){
 const db=getDb(),base=db.select({id:candidates.id,reference:candidates.reference,profile:candidates.profile}).from(candidates).innerJoin(clientCases,eq(clientCases.candidateId,candidates.id));
 const rows=kind==='EMAIL'?await base.where(sql`lower(trim(json_extract(${candidates.profile},'$.email')))=${value}`).limit(10)
  :kind==='CASE_NUMBER'?await base.where(eq(candidates.reference,value)).limit(10)
  :(await base.where(sql`${phoneSql}=${value} OR json_extract(${candidates.profile},'$.phone')=${value}`).limit(10));
 return rows.map(r=>({id:r.id,reference:r.reference,profile:JSON.parse(r.profile) as {email?:string;phone?:string}}));
}
const identifierHash=(kind:IdentifierKind,value:string)=>sha('status-lookup:v1:'+kind+':'+value);
function sixDigits(){let n:number;do{n=crypto.getRandomValues(new Uint32Array(1))[0];}while(n>=4294000000);return String(n%1000000).padStart(6,'0');}
const envelope=(requestId:string,expiresAt:number)=>({requestId,expiresAt,resendAfter:60,messageKey:'CHECK_REGISTERED_CONTACT_IF_MATCHED' as const});
export async function requestLookup(identifier:string,requestKey:string,locale:'ar'|'en'){
 const id=classifyIdentifier(identifier);if(!id)throw new ApiError(400,'أدخل بريدًا إلكترونيًا أو رقم هاتف دوليًا يبدأ بـ + أو رقم الملف.');
 const db=getDb(),hash=await identifierHash(id.kind,id.value),key=await sha('status-lookup-request:'+hash+':'+requestKey),[prior]=await db.select({id:authChallenges.id,expiresAt:authChallenges.expiresAt}).from(authChallenges).where(eq(authChallenges.requestKey,key)).limit(1);
 if(prior)return envelope(prior.id,prior.expiresAt);
 await targetThrottle('status-lookup:'+hash,5,3600);
 const now=Date.now(),cool=Math.floor(now/1000),rows=await db.all<{key:string}>(sql`INSERT INTO rate_limits (key,count,expires) VALUES (${await sha('status-lookup-cooldown:'+hash)},1,${cool+60}) ON CONFLICT(key) DO UPDATE SET expires=excluded.expires WHERE rate_limits.expires<=${cool} RETURNING key`);
 if(!rows.length)throw new ApiError(429,'انتظر 60 ثانية قبل طلب رمز جديد.');
 const found=await matches(id.kind,id.value),options=await deliveryOptions(),challengeId=crypto.randomUUID(),code=sixDigits(),expiresAt=now+600000;
 // Destination: only a contact already registered on a matching file. Email identifier -> that email; phone ->
 // WhatsApp when configured (no SMS is claimed); case number -> the file's email, else its WhatsApp.
 let channel:'email'|'whatsapp'='email',destination:string|null=null;
 if(found.length){
  if(id.kind==='EMAIL'&&options.email){destination=id.value;}
  else if(id.kind==='PHONE'&&options.whatsapp){channel='whatsapp';destination=id.value;}
  else if(id.kind==='CASE_NUMBER'){const p=found[0].profile;if(options.email&&p.email){destination=p.email;}else if(options.whatsapp&&p.phone&&internationalPhone(p.phone)){channel='whatsapp';destination=internationalPhone(p.phone);}}
 }
 await db.batch([
  db.update(authChallenges).set({expiresAt:now}).where(and(eq(authChallenges.purpose,'status_lookup'),eq(authChallenges.contactHash,hash),isNull(authChallenges.usedAt),gt(authChallenges.expiresAt,now))),
  db.insert(authChallenges).values({id:challengeId,candidateId:null,channel,purpose:'status_lookup',contactHash:hash,codeHash:await codeDigest(challengeId,code),requestKey:key,state:destination?'created':'unmatched',expiresAt,createdAt:now,deliveryPayloadEncrypted:await encrypt(JSON.stringify({kind:id.kind,value:id.value,...(destination?{delivery:{destination,code,locale,channel}}:{})}))}),
 ]);
 return envelope(challengeId,expiresAt);
}
// Durable dispatcher: lease one row at a time, deliver through the existing OTP service, clear the payload. Rows whose
// lease expired are retried (max 3 attempts); the payload is never logged.
type Seed={kind:IdentifierKind;value:string;delivery?:{destination:string;code:string;locale:'ar'|'en';channel:'email'|'whatsapp'}};
export async function dispatchLookupDeliveries(limit=10){
 const db=getDb(),now=Date.now(),due=await db.select({id:authChallenges.id}).from(authChallenges).where(and(eq(authChallenges.purpose,'status_lookup'),eq(authChallenges.state,'created'),lte(authChallenges.deliveryLeaseUntil,now),lt(authChallenges.deliveryAttemptCount,3),gt(authChallenges.expiresAt,now))).limit(limit);
 let delivered=0;
 for(const r of due){
  const [leased]=await db.update(authChallenges).set({deliveryLeaseUntil:now+60000,deliveryAttemptCount:sql`${authChallenges.deliveryAttemptCount}+1`}).where(and(eq(authChallenges.id,r.id),eq(authChallenges.state,'created'),lte(authChallenges.deliveryLeaseUntil,now))).returning({payload:authChallenges.deliveryPayloadEncrypted,attempts:authChallenges.deliveryAttemptCount});
  if(!leased?.payload)continue;
  let p:Seed;try{p=JSON.parse(await decrypt(leased.payload)) as Seed;}catch{await db.update(authChallenges).set({state:'failed',deliveryPayloadEncrypted:null}).where(eq(authChallenges.id,r.id));continue;}
  if(!p.delivery){await db.update(authChallenges).set({state:'unmatched'}).where(eq(authChallenges.id,r.id));continue;}
  const result=await deliverOtp(p.delivery.channel,p.delivery.destination,p.delivery.code,p.delivery.locale,r.id);
  const final=result.state==='accepted'||result.state==='failed'||leased.attempts>=3;
  // After a final outcome the code and destination are dropped; only the identifier stays for proof (until verify).
  await db.update(authChallenges).set({state:final?result.state:'created',providerId:result.providerId,...(final?{deliveryPayloadEncrypted:await encrypt(JSON.stringify({kind:p.kind,value:p.value}))}:{deliveryLeaseUntil:0})}).where(eq(authChallenges.id,r.id));
  if(result.state==='accepted')delivered++;
 }
 return delivered;
}
const proofSchema=z.object({kind:z.enum(['EMAIL','PHONE','CASE_NUMBER']),hash:z.string().regex(/^[a-f0-9]{64}$/),value:z.string().max(254),expiresAt:z.number(),challengeId:z.string().uuid()});
const invalid=()=>new ApiError(400,'الرمز غير صحيح أو انتهت صلاحيته. اطلب رمزًا جديدًا عند الحاجة.');
export async function verifyLookup(requestId:string,code:string){
 const db=getDb(),now=Date.now(),[c]=await db.select().from(authChallenges).where(eq(authChallenges.id,requestId)).limit(1);
 if(!c||c.purpose!=='status_lookup'||c.usedAt||c.expiresAt<=now||c.attempts>=5||!['accepted','unknown','created'].includes(c.state))throw invalid();
 const digest=await codeDigest(requestId,code);let diff=0;for(let i=0;i<digest.length;i++)diff|=digest.charCodeAt(i)^c.codeHash.charCodeAt(i);
 if(diff){await db.update(authChallenges).set({attempts:sql`${authChallenges.attempts}+1`}).where(and(eq(authChallenges.id,requestId),isNull(authChallenges.usedAt),lt(authChallenges.attempts,5)));throw invalid();}
 if(!c.deliveryPayloadEncrypted)throw invalid();
 let seed:Seed;try{seed=JSON.parse(await decrypt(c.deliveryPayloadEncrypted)) as Seed;}catch{throw invalid();}
 if(await identifierHash(seed.kind,seed.value)!==c.contactHash)throw invalid();
 const [claimed]=await db.update(authChallenges).set({usedAt:now,consumedBy:await sha('lookup-proof:'+requestId),deliveryPayloadEncrypted:null}).where(and(eq(authChallenges.id,requestId),eq(authChallenges.purpose,'status_lookup'),eq(authChallenges.codeHash,digest),isNull(authChallenges.usedAt),lt(authChallenges.attempts,5),gt(authChallenges.expiresAt,now))).returning({hash:authChallenges.contactHash});
 if(!claimed)throw invalid();
 const p={kind:seed.kind,value:seed.value},found=await matches(p.kind,p.value);if(!found.length)throw invalid();
 const expiresAt=now+PROOF_MS;
 return {proofTicket:await encrypt(JSON.stringify({kind:p.kind,hash:claimed.hash,value:p.value,expiresAt,challengeId:c.id})),expiresAt,caseOptions:found.map(f=>({caseNumber:f.reference}))};
}
export async function selectLookupCase(proofTicket:string,caseNumber:string){
 let p:z.infer<typeof proofSchema>;try{p=proofSchema.parse(JSON.parse(await decrypt(proofTicket)));}catch{throw invalid();}
 if(p.expiresAt<=Date.now()||await identifierHash(p.kind,p.value)!==p.hash)throw invalid();
 const own=(await matches(p.kind,p.value)).find(f=>f.reference===caseNumber.trim().toUpperCase());if(!own)throw new ApiError(404,'الملف غير متاح لهذا الإثبات.');
 const token=accessCode(),now=Date.now();
 await getDb().insert(clientSessions).values({tokenHash:await sha(token),candidateId:own.id,method:'status_lookup',createdAt:now,expiresAt:now+LOOKUP_SECONDS*1000,scope:'case_status'});
 return token;
}
export function lookupCookie(token:string,request:Request,seconds=LOOKUP_SECONDS){return `${LOOKUP_COOKIE}=${token}; HttpOnly; SameSite=Strict; Path=/api/client/status-lookup; Max-Age=${seconds}${new URL(request.url).protocol==='https:'?'; Secure':''}`;}
const NEXT:Record<string,{code:'NONE'|'COMPLETE_PROFILE'|'UPLOAD_REQUESTED_DOCUMENTS'|'CONTACT_OFFICE';ar:string;en:string}>={
 new:{code:'NONE',ar:'تم استلام الملف وهو بانتظار المراجعة.',en:'Your file was received and awaits review.'},
 reviewing:{code:'NONE',ar:'الملف قيد المراجعة لدى المكتب.',en:'The office is reviewing your file.'},
 documents:{code:'UPLOAD_REQUESTED_DOCUMENTS',ar:'يلزم رفع المستندات المطلوبة من حسابك.',en:'Please upload the requested documents from your account.'},
 shortlisted:{code:'NONE',ar:'الملف في مرحلة متقدمة لدى المكتب.',en:'Your file is at an advanced stage.'},
 referred:{code:'CONTACT_OFFICE',ar:'تواصل مع المكتب لمعرفة الخطوة التالية.',en:'Contact the office for the next step.'},
 hold:{code:'CONTACT_OFFICE',ar:'الملف معلّق مؤقتًا؛ تواصل مع المكتب.',en:'Your file is on hold; contact the office.'},
 archived:{code:'CONTACT_OFFICE',ar:'الملف مؤرشف؛ تواصل مع المكتب.',en:'Your file is archived; contact the office.'},
};
export async function lookupResult(request:Request,locale:'ar'|'en'){
 const token=readCookie(request,LOOKUP_COOKIE);if(!/^[a-f0-9]{64}$/.test(token))throw new ApiError(401,'انتهت صلاحية الاستعلام. أعد التحقق.');
 const [r]=await getDb().select({reference:candidates.reference,status:candidates.status,updatedAt:candidates.updatedAt}).from(clientSessions).innerJoin(candidates,eq(candidates.id,clientSessions.candidateId)).where(and(eq(clientSessions.tokenHash,await sha(token)),eq(clientSessions.scope,'case_status'),inArray(clientSessions.method,['status_lookup']),isNull(clientSessions.revokedAt),gt(clientSessions.expiresAt,Date.now()))).limit(1);
 if(!r)throw new ApiError(401,'انتهت صلاحية الاستعلام. أعد التحقق.');
 const next=NEXT[r.status]??NEXT.reviewing;
 return {caseNumber:r.reference,statusCode:(Object.hasOwn(NEXT,r.status)?r.status:'reviewing') as keyof typeof NEXT,updatedAt:new Date(r.updatedAt).toISOString(),nextAction:{code:next.code,label:locale==='ar'?next.ar:next.en}};
}
