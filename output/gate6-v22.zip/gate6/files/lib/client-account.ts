import { getDb } from '@/db';
import { authChallenges,candidates,clientCases,clientAccountProfiles } from '@/db/schema';
import { and,eq,gt,isNull,lt,sql } from 'drizzle-orm';
import { z } from 'zod';
import { accessCode,decrypt,encrypt,sha } from './security';
import { codeDigest,targetThrottle } from './otp';
import { deliverOtp,deliveryOptions } from './otp-delivery';
import { ApiError } from './server';
import { createClientSession,readCookie,SESSION_SECONDS } from './client-access';
export const ACCOUNT_COOKIE='alh_application_account';
// v2.2 Gate 4: the ticket also carries the entry intent and the name typed for START_NEW (encrypted, server-issued).
const ticketSchema=z.object({id:z.string().uuid(),email:z.string().email(),expiresAt:z.number(),intent:z.enum(['START_NEW','RETURN']).default('RETURN'),name:z.string().max(150).optional()});
const sessionSchema=ticketSchema.extend({token:z.string().regex(/^[a-f0-9]{64}$/)});
export type AccountIntent='START_NEW'|'RETURN';
// Opaque, stable account key: hash of the verified, normalized email (client_account_profiles.account_key).
export const accountKeyOf=(email:string)=>sha('client-account:v1:'+email.trim().toLowerCase());
function invalid(){return new ApiError(400,'الرمز غير صحيح أو انتهت صلاحيته.');}
async function decoded(value:string,session=false){try{return session?sessionSchema.parse(JSON.parse(await decrypt(value))):ticketSchema.parse(JSON.parse(await decrypt(value)));}catch{throw invalid();}}
export function accountCookie(value:string,request:Request,seconds=SESSION_SECONDS){return `${ACCOUNT_COOKIE}=${value}; HttpOnly; SameSite=Lax; Path=/api; Max-Age=${seconds}${new URL(request.url).protocol==='https:'?'; Secure':''}`;}
export async function accountSession(request:Request){const value=readCookie(request,ACCOUNT_COOKIE);if(!value)return null;try{const d=sessionSchema.parse(await decoded(value,true));if(d.expiresAt<=Date.now())return null;const [row]=await getDb().select().from(authChallenges).where(and(eq(authChallenges.id,d.id),eq(authChallenges.channel,'account_email'),eq(authChallenges.consumedBy,await sha(d.token)),gt(authChallenges.expiresAt,Date.now()))).limit(1);return row?.usedAt&&row.contactHash===await sha(d.email)&&(row.purpose==='account_login'||row.purpose==='account_password')?{...d,purpose:row.purpose as 'account_login'|'account_password',verifiedAt:row.usedAt,sessionExpiresAt:row.expiresAt}:null;}catch{return null;}}
// Account profile (display name only; no secret or permission). Created only after email ownership is proven; an
// existing profile is reused and never overwritten by a later typed name.
export async function accountProfile(email:string){const [row]=await getDb().select().from(clientAccountProfiles).where(eq(clientAccountProfiles.accountKey,await accountKeyOf(email))).limit(1);return row??null;}
export async function ensureAccountProfile(email:string,name:string){const accountKey=await accountKeyOf(email),now=new Date().toISOString(),displayName=name.normalize('NFKC').replace(/\s+/g,' ').trim();if(displayName.length<2||displayName.length>150)throw new ApiError(400,'أدخل الاسم الكامل (حرفان على الأقل).');await getDb().insert(clientAccountProfiles).values({accountKey,displayName,createdAt:now,updatedAt:now}).onConflictDoNothing();return (await accountProfile(email))!;}
// Email+password sign-in issues the same account session store as OTP (auth_challenges, purpose account_password).
export async function createPasswordAccountSession(email:string){const id=crypto.randomUUID(),token=accessCode(),now=Date.now(),expiresAt=now+SESSION_SECONDS*1000;await getDb().insert(authChallenges).values({id,channel:'account_email',purpose:'account_password',contactHash:await sha(email),codeHash:await codeDigest(id,accessCode()),requestKey:await sha('account-password-session:'+id),state:'accepted',usedAt:now,consumedBy:await sha(token),expiresAt,createdAt:now});return {id,value:await encrypt(JSON.stringify({id,email,expiresAt,intent:'RETURN',token}))};}
export async function accountCases(email:string){return getDb().select({id:candidates.id,reference:candidates.reference,name:sql<string>`json_extract(${candidates.profile},'$.fullName')`.as('name')}).from(candidates).innerJoin(clientCases,eq(clientCases.candidateId,candidates.id)).where(sql`lower(trim(json_extract(${candidates.profile},'$.email')))=${email}`);}
export async function requestAccountCode(emailInput:string,requestKey:string,locale:'ar'|'en',intent:AccountIntent='RETURN',name?:string){
 if(!(await deliveryOptions()).email)throw new ApiError(503,'الدخول بالبريد غير متاح حاليًا. تواصل مع المكتب.');
 const email=emailInput.trim().toLowerCase(),db=getDb(),key=await sha('account-request:'+email+':'+requestKey),[prior]=await db.select().from(authChallenges).where(eq(authChallenges.requestKey,key)).limit(1);
 if(prior)return {requestId:prior.id,expiresAt:prior.expiresAt,resendAfter:60,ticket:await encrypt(JSON.stringify({id:prior.id,email,expiresAt:prior.expiresAt,intent,...(name?{name}:{})})),messageKey:'CHECK_REGISTERED_CONTACT_IF_MATCHED' as const};
 await targetThrottle('account-email:'+email,6,3600);
 const rows=await db.all<{key:string}>(sql`INSERT INTO rate_limits (key,count,expires) VALUES (${await sha('account-cooldown:'+email)},1,${Math.floor(Date.now()/1000)+60}) ON CONFLICT(key) DO UPDATE SET expires=excluded.expires WHERE rate_limits.expires<=${Math.floor(Date.now()/1000)} RETURNING key`);if(!rows.length)throw new ApiError(429,'انتظر 60 ثانية قبل طلب رمز جديد.');
 const id=crypto.randomUUID(),now=Date.now(),expiresAt=now+600000;let n:number;do{n=crypto.getRandomValues(new Uint32Array(1))[0];}while(n>=4294000000);const code=String(n%1000000).padStart(6,'0'),hash=await sha(email);
 await db.batch([db.update(authChallenges).set({expiresAt:now}).where(and(eq(authChallenges.channel,'account_email'),eq(authChallenges.contactHash,hash),isNull(authChallenges.usedAt))),db.insert(authChallenges).values({id,channel:'account_email',purpose:'account_login',contactHash:hash,codeHash:await codeDigest(id,code),requestKey:key,state:'created',expiresAt,createdAt:now})]);
 const result=await deliverOtp('email',email,code,locale,id);await db.update(authChallenges).set(result).where(eq(authChallenges.id,id));
 return {requestId:id,expiresAt,resendAfter:60,ticket:await encrypt(JSON.stringify({id,email,expiresAt,intent,...(name?{name}:{})})),messageKey:'CHECK_REGISTERED_CONTACT_IF_MATCHED' as const};
}
export async function verifyAccountCode(ticket:string,code:string){
 const d=ticketSchema.parse(await decoded(ticket)),now=Date.now(),db=getDb(),[row]=await db.select().from(authChallenges).where(eq(authChallenges.id,d.id)).limit(1);
 if(d.expiresAt<=now||!row||row.channel!=='account_email'||row.purpose!=='account_login'||row.contactHash!==await sha(d.email)||row.usedAt||row.expiresAt<=now||row.attempts>=5||!['accepted','unknown'].includes(row.state))throw invalid();
 const digest=await codeDigest(d.id,code);let diff=0;for(let i=0;i<digest.length;i++)diff|=digest.charCodeAt(i)^row.codeHash.charCodeAt(i);
 if(diff){await db.update(authChallenges).set({attempts:sql`${authChallenges.attempts}+1`}).where(and(eq(authChallenges.id,d.id),isNull(authChallenges.usedAt),lt(authChallenges.attempts,5)));throw invalid();}
 const token=accessCode(),expiresAt=now+SESSION_SECONDS*1000;
 const [claimed]=await db.update(authChallenges).set({usedAt:now,consumedBy:await sha(token),expiresAt}).where(and(eq(authChallenges.id,d.id),isNull(authChallenges.usedAt),lt(authChallenges.attempts,5),gt(authChallenges.expiresAt,now),eq(authChallenges.codeHash,digest))).returning({id:authChallenges.id});if(!claimed)throw invalid();
  return {email:d.email,intent:d.intent,name:d.name,value:await encrypt(JSON.stringify({...d,expiresAt,token}))};
}
export async function openAccountCase(email:string,reference:string){const own=(await accountCases(email)).find(c=>c.reference===reference);if(!own)throw new ApiError(404,'الملف غير مرتبط بهذا الحساب.');return createClientSession(own.id,'otp_email');}
