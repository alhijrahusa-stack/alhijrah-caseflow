import type { Profile,DocumentRecord } from './model';
import type { IntakeDetails } from './intake';
import { screenIntake } from './screening';
export type ViewTask={key:string;labelAr:string;labelEn:string;action:'profile'|'documents'|'office';category?:string;state:'done'|'client'|'office';requested:boolean};
export function dashboardProgress(profile:Profile,details:IntakeDetails,files:Pick<DocumentRecord,'category'|'verified'>[],requested:string[],inbox:string){
 const items:ViewTask[]=[
 {key:'contact',labelAr:'بيانات التواصل',labelEn:'Contact details',action:'profile',state:profile.fullName&&profile.email&&profile.phone?'done':'client',requested:false},
 {key:'residence',labelAr:'الجنسية والإقامة',labelEn:'Citizenship & residence',action:'profile',state:profile.country&&profile.nationality?'done':'client',requested:false},
 {key:'occupation',labelAr:'البيانات المهنية',labelEn:'Occupation details',action:'profile',state:profile.occupation?'done':'client',requested:false},
 {key:'education',labelAr:'المؤهل الدراسي المسجّل',labelEn:'Education details',action:'profile',state:profile.education!=='unknown'?'done':'client',requested:false},
 {key:'experience',labelAr:'الخبرة المسجّلة',labelEn:'Work history details',action:'profile',state:details.jobs.some(j=>j.title&&j.employer&&j.start)&&details.jobs.every(j=>!j.start||(typeof j.weekly_hours==='number'&&j.weekly_hours>0))?'done':'client',requested:false},
 ];
 const screening=screenIntake(profile,details,files,requested);
 for(const doc of screening.documents)items.push({key:'document:'+doc.category,labelAr:doc.label,labelEn:doc.category,category:doc.category,action:'documents',state:doc.state==='reviewed'?'done':doc.state==='uploaded'?'office':'client',requested:requested.includes(doc.category)});
 if(inbox==='pending')items.push({key:'office-intake',labelAr:'مراجعة الاستقبال',labelEn:'Intake review',action:'office',state:'office',requested:false});
 const done=items.filter(i=>i.state==='done').length;
 return {items,done,total:items.length,percent:Math.round(done/items.length*100),clientCount:items.filter(i=>i.state==='client').length,officeCount:items.filter(i=>i.state==='office').length};
}
export function publicEvent(action:string):{ar:string;en:string}|null{
 if(action.startsWith('تم إنشاء الملف'))return {ar:'استلام الطلب',en:'Application received'};
 if(action==='رفع العميل مستندًا'||action==='تم رفع مستند')return {ar:'أُضيف مستند للملف',en:'Document added'};
 if(action.startsWith('تم اعتماد مراجعة مستند'))return {ar:'اكتملت مراجعة مستند',en:'Document review completed'};
 if(action.startsWith('ألغيت مراجعة مستند'))return {ar:'أُعيد مستند للمراجعة',en:'Document returned for review'};
 if(action==='استكمل العميل بيانات الطلب')return {ar:'تحديث بيانات الملف',en:'Case details updated'};
 if(action==='بدأ الموظف مراجعة طلب العميل')return {ar:'بدأت مراجعة المكتب',en:'Office review started'};
 if(action==='طلب الموظف استكمال الملف')return {ar:'طلب المكتب معلومات إضافية',en:'Office requested more information'};
 if(action==='اعتمد مراجع مستقل المراجعة الإدارية')return {ar:'اكتملت مراجعة الفريق الإدارية',en:'Administrative team review completed'};
 if(action.includes('الحالة:'))return {ar:'تحديث حالة المتابعة',en:'Case status updated'};
 if(action==='تمت مراجعة طلب تعديل التواصل')return {ar:'مراجعة طلب تعديل التواصل',en:'Contact update request reviewed'};
 return null;
}
export function caseStages(status:string,inbox:string,reviewed:boolean,offerReviewed:boolean){
 const current=status==='archived'?-1:inbox==='pending'?1:inbox==='needs_info'||status==='documents'?2:reviewed||status==='referred'?4:3;
 return [
 {key:'received',ar:'الاستلام',en:'Received',state:'done'},
 {key:'review',ar:'مراجعة المكتب',en:'Office review',state:current===1?'current':inbox!=='pending'?'done':'waiting'},
 {key:'completion',ar:'استكمال الملف',en:'Case completion',state:current===2?'current':reviewed?'done':'waiting'},
 {key:'team',ar:'مراجعة الفريق',en:'Team review',state:reviewed?'done':current===3?'current':'waiting'},
 {key:'offer',ar:offerReviewed?'عرض عمل مسجّل':'متابعة المسار',en:offerReviewed?'Offer recorded':'Pathway follow-up',state:offerReviewed?'done':current===4?'current':'waiting'},
 ];
}
// v2.2 Gate 5 — the client's own invoices (read-only): the same server figures staff see, without staff identities,
// audit data or receipt files. Amounts stay integer cents in the invoice currency.
export async function clientBilling(caseId:string){
 const { caseInvoices,invoiceDetail }=await import('./billing');
 const list=await caseInvoices(caseId);
 return Promise.all(list.map(async i=>{const d=await invoiceDetail(i.invoiceId);return {invoiceId:d.invoiceId,currency:d.currency,status:d.status,subtotalCents:d.subtotalCents,discountCents:d.discountCents,totalCents:d.totalCents,paidCents:d.paidCents,remainingCents:d.remainingCents,deadline:d.deadline,note:d.note,version:d.version,
  items:d.items.map(x=>({serviceName:x.serviceName,isFree:x.isFree,unitPriceCents:x.unitPriceCents,referencePriceCents:x.referencePriceCents})),payments:d.payments.map(p=>({amountCents:p.amountCents,method:p.method,paidAt:p.paidAt}))};}));
}
