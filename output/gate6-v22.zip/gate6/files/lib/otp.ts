import { getDb } from '@/db';
import { authChallenges,candidates,clientCases,clientSessions,events,rateLimits } from '@/db/schema';
import { eq,and,sql,isNull,lt,gt,inArray } from 'drizzle-orm';
import { accessCode,sha } from './security';
import { deliverOtp,deliveryOptions,internationalPhone } from './otp-delivery';
import type { DeliveryChannel } from './otp-delivery';
import { ApiError } from './server';
import { signingSecret } from './keys';
import { SESSION_SECONDS } from './client-access';
export async function codeDigest(id:string,code:string){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(signingSecret()),{name:'HMAC',hash:'SHA-256'},false,['sign']);return [...new Uint8Array(await crypto.subtle.sign('HMAC',key,new TextEncoder().encode('otp-v1:'+id+':'+code)))].map(n=>n.toString(16).padStart(2,'0')).join('');}
export async function targetThrottle(scope:string,max:number,seconds:number){const now=Math.floor(Date.now()/1000),window=Math.floor(now/seconds),db=getDb();const [r]=await db.insert(rateLimits).values({key:await sha(scope+'|'+window),count:1,expires:(window+1)*seconds}).onConflictDoUpdate({target:rateLimits.key,set:{count:sql`${rateLimits.count}+1`}}).returning({count:rateLimits.count});if(r.count>max)throw new ApiError(429,'طلبات كثيرة. حاول بعد قليل.');}
async function cooldown(scope:string){const now=Math.floor(Date.now()/1000);const rows=await getDb().all<{key:string}>(sql`INSERT INTO rate_limits (key,count,expires) VALUES (${await sha(scope)},1,${now+60}) ON CONFLICT(key) DO UPDATE SET expires = excluded.expires WHERE rate_limits.expires <= ${now} RETURNING key`);if(!rows.length)throw new ApiError(429,'انتظر 60 ثانية قبل طلب رمز جديد.');}
function sixDigits(){let n:number;do{n=crypto.getRandomValues(new Uint32Array(1))[0];}while(n>=4294000000);return String(n%1000000).padStart(6,'0');}
export async function requestOtp(reference:string,channel:DeliveryChannel,locale:'ar'|'en',requestKey:string){
 const options=await deliveryOptions();if(!options[channel])throw new ApiError(503,'قناة الإرسال غير مفعّلة. تواصل مع المكتب.');
 const normalized=reference.trim().toUpperCase(),scopedKey=await sha('otp-request:'+normalized+':'+channel+':'+requestKey),db=getDb(),[prior]=await db.select().from(authChallenges).where(eq(authChallenges.requestKey,scopedKey)).limit(1);
 if(prior)return {requestId:prior.id,expiresAt:prior.expiresAt,resendAfter:60};
 await cooldown('otp-cooldown:'+normalized+':'+channel);await targetThrottle('otp-target:'+normalized,6,3600);
 const [caseRow]=await db.select({candidate:candidates}).from(candidates).innerJoin(clientCases,eq(clientCases.candidateId,candidates.id)).where(eq(candidates.reference,normalized)).limit(1);
 const id=crypto.randomUUID(),now=Date.now(),code=sixDigits(),profile=caseRow?JSON.parse(caseRow.candidate.profile):null;
 const destination=channel==='email'?profile?.email:profile?internationalPhone(profile.phone):null;
 const candidateId=caseRow?.candidate.id??null;
 await db.batch([
  db.update(authChallenges).set({expiresAt:now}).where(and(eq(authChallenges.candidateId,candidateId??''),eq(authChallenges.channel,channel),isNull(authChallenges.usedAt))),
  db.insert(authChallenges).values({id,candidateId,channel,contactHash:profile?await sha(JSON.stringify([profile.email,profile.phone])):'',codeHash:await codeDigest(id,code),requestKey:scopedKey,state:'created',expiresAt:now+600000,createdAt:now}),
 ]);
 const result=destination?await deliverOtp(channel,destination,code,locale,id):{state:'unmatched',providerId:''};
 await db.update(authChallenges).set(result).where(eq(authChallenges.id,id));
 // Identical response for unmatched records and provider failures prevents case enumeration.
 return {requestId:id,expiresAt:now+600000,resendAfter:60};
}
export async function verifyOtp(id:string,code:string){
 const db=getDb(),now=Date.now(),[challenge]=await db.select().from(authChallenges).where(eq(authChallenges.id,id)).limit(1);
 const invalid=()=>new ApiError(400,'الرمز غير صحيح أو انتهت صلاحيته. اطلب رمزًا جديدًا عند الحاجة.');
 if(!challenge||challenge.purpose!=='case_login'||!challenge.candidateId||challenge.usedAt||challenge.expiresAt<=now||challenge.attempts>=5||!['accepted','unknown'].includes(challenge.state))throw invalid();
 const digest=await codeDigest(id,code);let diff=0;for(let i=0;i<digest.length;i++)diff|=digest.charCodeAt(i)^challenge.codeHash.charCodeAt(i);if(diff!==0){await db.update(authChallenges).set({attempts:sql`${authChallenges.attempts}+1`}).where(and(eq(authChallenges.id,id),isNull(authChallenges.usedAt),lt(authChallenges.attempts,5)));throw invalid();}
 const [person]=await db.select({profile:candidates.profile}).from(candidates).where(eq(candidates.id,challenge.candidateId)).limit(1);const profile=person?JSON.parse(person.profile):null;if(!profile||!challenge.contactHash||challenge.contactHash!==await sha(JSON.stringify([profile.email,profile.phone])))throw invalid();
 const token=accessCode(),tokenHash=await sha(token),method='otp_'+challenge.channel;
 const scope=and(eq(authChallenges.id,id),eq(authChallenges.purpose,'case_login'),eq(authChallenges.codeHash,digest),isNull(authChallenges.usedAt),lt(authChallenges.attempts,5),gt(authChallenges.expiresAt,now),eq(authChallenges.expiresAt,challenge.expiresAt),sql`EXISTS (SELECT 1 FROM candidates p WHERE p.id=${challenge.candidateId} AND json_extract(p.profile,'$.email')=${profile.email} AND json_extract(p.profile,'$.phone')=${profile.phone})`,inArray(authChallenges.state,['accepted','unknown']));
 const result=await db.batch([
  db.update(authChallenges).set({usedAt:now,consumedBy:tokenHash}).where(scope).returning({candidateId:authChallenges.candidateId}),
  db.insert(clientSessions).select(db.select({tokenHash:sql<string>`${tokenHash}`.as('token_hash'),candidateId:authChallenges.candidateId,method:sql<string>`${method}`.as('method'),createdAt:sql<number>`${now}`.as('created_at'),expiresAt:sql<number>`${now+SESSION_SECONDS*1000}`.as('expires_at'),revokedAt:sql<number|null>`NULL`.as('revoked_at'),scope:sql<string>`'full_case'`.as('scope')}).from(authChallenges).where(and(eq(authChallenges.id,id),eq(authChallenges.consumedBy,tokenHash)))),
  db.update(clientCases).set({otpOnly:true}).where(and(eq(clientCases.candidateId,challenge.candidateId),sql`EXISTS (SELECT 1 FROM auth_challenges a WHERE a.id = ${id} AND a.consumed_by = ${tokenHash})`)),
  db.insert(events).select(db.select({id:sql<string>`${crypto.randomUUID()}`.as('id'),ownerId:candidates.ownerId,candidateId:candidates.id,action:sql<string>`${challenge.channel==='email'?'تحقق العميل من البريد ودخل الملف':'تحقق العميل من WhatsApp ودخل الملف'}`.as('action'),note:sql<string>`''`.as('note'),createdAt:sql<string>`${new Date(now).toISOString()}`.as('created_at')}).from(candidates).where(and(eq(candidates.id,challenge.candidateId),sql`EXISTS (SELECT 1 FROM auth_challenges a WHERE a.id = ${id} AND a.consumed_by = ${tokenHash})`))),
 ]);
 if(!result[0].length)throw invalid();
 return token;
}
