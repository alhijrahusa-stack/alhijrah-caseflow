import { getDb } from "@/db";
import { candidates,events,tasks,officeSettings } from "@/db/schema";
import { and,eq,or,ne } from "drizzle-orm";
import { initialAssessment,evaluationDate } from "@/lib/case-engine";
import { assessmentHistory } from "@/db/schema";
import type { IntakeDetails } from "@/lib/intake";
import type { Profile } from "@/lib/model";
import { ApiError,owned,PUBLIC_OWNER,systemScope } from "@/lib/server";
import { contactKeys,identityMatches } from './contact-identity';
import type { ContactIdentity } from './contact-identity';
export { contactKeys } from './contact-identity';

export async function findDuplicate(ownerId:string,profile:ContactIdentity,exceptId?:string) {
  const db=getDb(); const keys=contactKeys(profile);
  const [office]=ownerId===PUBLIC_OWNER?await db.select({ownerId:officeSettings.primaryOwnerId}).from(officeSettings).where(eq(officeSettings.id,'office')).limit(1):[];
  const scopeOwner=office?.ownerId||ownerId;
  const clauses=[eq(candidates.dedupeKey,keys.dedupeKey)];if(keys.emailKey)clauses.push(eq(candidates.emailKey,keys.emailKey));
  if(keys.contactPairKey)clauses.push(eq(candidates.contactPairKey,keys.contactPairKey));
  const [exact]=await db.select({id:candidates.id,reference:candidates.reference}).from(candidates).where(and(owned(candidates.ownerId,systemScope(scopeOwner)),or(...clauses),exceptId?ne(candidates.id,exceptId):undefined)).limit(1);
  if(exact)return exact;
  const legacy=await db.select({id:candidates.id,reference:candidates.reference,profile:candidates.profile}).from(candidates).where(and(owned(candidates.ownerId,systemScope(scopeOwner)),eq(candidates.identityVersion,0),exceptId?ne(candidates.id,exceptId):undefined));
  return legacy.find(row=>identityMatches(JSON.parse(row.profile),profile));
}
export async function ensureUnique(ownerId:string,profile:Profile,exceptId?:string) {
  const duplicate=await findDuplicate(ownerId,profile,exceptId);
  if(duplicate)throw new ApiError(409,"يوجد ملف بالاسم ووسيلة التواصل نفسيهما: "+duplicate.reference);
}
// The first assessment comes from the case engine and is written with its assessment_history row in the same batch.
export async function newApplicant(ownerId:string,profile:Profile,source="staff",details:IntakeDetails|null=null) {
  const now=new Date().toISOString(),id=crypto.randomUUID();
  const {assessment,history}=await initialAssessment(id,{profile,details,verifiedCategories:[],asOf:evaluationDate(new Date(now)),facts:[],crsInput:null,eligibility:null});
  const row={id,ownerId,reference:"CA-"+now.slice(0,4)+"-"+id.slice(0,8).toUpperCase(),profile:JSON.stringify(profile),assessment:JSON.stringify(assessment),status:"new",version:1,createdAt:now,updatedAt:now,...contactKeys(profile),source,...(details?{pathway:details.pathway}:{})};
  const db=getDb();
  return {row,profile,assessment,history,queries:[
    db.insert(candidates).values(row),
    db.insert(events).values({id:crypto.randomUUID(),ownerId,candidateId:id,action:"تم إنشاء الملف والتقييم الأولي",note:source==="csv"?"استيراد CSV؛ موافقة حفظ البيانات مسجلة":"موافقة حفظ البيانات مسجلة",createdAt:now}),
    db.insert(tasks).values({id:crypto.randomUUID(),ownerId,candidateId:id,title:"مراجعة بيانات المتقدم وتحديد المسار",systemKey:"initial-review",createdAt:now,updatedAt:now}),
    // Appended last: callers read [candidate, event, task] by position (api/intake rebuilds the candidate insert).
    db.insert(assessmentHistory).values(history),
  ] as const};
}
export function isDuplicateConstraint(error:unknown) {
  const message=error instanceof Error?error.message+" "+String(error.cause):"";
  return /UNIQUE constraint failed: candidates\.(owner_id|dedupe_key|email_key|contact_pair_key)/.test(message);
}
