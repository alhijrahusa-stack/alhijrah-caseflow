// Shared API error (moved out of lib/server.ts so lib/rbac.ts can use it without a circular import).
export class ApiError extends Error { constructor(public status: number, message: string) { super(message); } }
