import type { IntakeDetails } from "./intake";
import type { Profile, Tri } from "./model";
import { normalizeCase, FACT_PATH_LIST, V22_ENGINE_VERSION } from "./normalization.ts";
import type { NormalizationInput, NormalizedFacts, WageRow } from "./normalization.ts";
import { crsFromPolicy } from "./crs.ts";
import type { CrsPolicyResult } from "./crs.ts";
import { evaluateObligations } from "./pathways.ts";
import type { PredicateResult, PredicateState, Obligation } from "./pathways.ts";
import { resolveRule, routeRcip, datesFor } from "./rule-resolver.ts";
import type { ActiveRelease, EventContext, LoadedBundle, Resolution } from "./rule-resolver.ts";
import { CRS_PROGRAM_ID, CRS_FAMILY, ELIGIBILITY_FAMILY } from "./rule-import.ts";
import { jcs, jcsHash } from "./v22-core.ts";
// Facts derived by lib/case-engine.ts (TEER from NOC, experience from the job list). Never entered by hand.
export type DerivedFacts = { teer: number | null; experience3: number | null; experience10: number | null };
export const RULE_VERSION = "2026-11-15.v4";
const base = "https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/";
export const sources = {
  lmia: "https://www.canada.ca/en/immigration-refugees-citizenship/services/work-canada/hire-temporary-foreign/find-need-labour-market-impact-assessment.html",
  workPermit: "https://www.canada.ca/en/immigration-refugees-citizenship/services/work-canada/permit/temporary/apply.html",
  rcip: base + "rural-franco-pilots/rural-immigration/eligibility.html",
  language: base + "rural-franco-pilots/rural-immigration/eligibility/language-test.html",
  experience: base + "rural-franco-pilots/rural-immigration/eligibility/work-experience.html",
  funds: base + "rural-franco-pilots/rural-immigration/eligibility/proof-funds.html",
  fsw: base + "express-entry/who-can-apply/federal-skilled-workers.html",
  french: base + "express-entry/rounds-invitations/category-based-selection.html",
  crs: base + "express-entry/changes.html",
};
export type Check = { label: string; state: "pass" | "fail" | "unknown"; source: string };
export type Pathway = { id: string; title: string; subtitle: string; state: "potential" | "incomplete" | "mismatch"; checks: Check[]; caveat: string };
export type Assessment = { ruleVersion: string; assessedAt: string; completeness: number; nextAction: string; pathways: Pathway[]; missingDocuments: string[]; };
const bool = (v: Tri) => v === "unknown" ? null : v === "yes";
function check(label: string, value: boolean | null, source: string): Check { return { label, state: value === null ? "unknown" : value ? "pass" : "fail", source }; }
function validTest(min: number | null, date: string, required: number, now: Date): boolean | null {
  if (min === null) return null;
  if (min < required) return false;
  if (!date) return null;
  const parsed = new Date(date + "T00:00:00Z");
  if (!Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0,10) !== date) return null;
  if (parsed > now) return false;
  const expiry = new Date(parsed); expiry.setUTCFullYear(expiry.getUTCFullYear() + 2);
  return expiry > now;
}
const either = (a: boolean | null, b: boolean | null): boolean | null => a === true || b === true ? true : a === null || b === null ? null : false;
function path(id: string, title: string, subtitle: string, checks: Check[], caveat: string): Pathway {
  return { id, title, subtitle, checks, caveat, state: checks.some(c => c.state === "fail") ? "mismatch" : checks.some(c => c.state === "unknown") ? "incomplete" : "potential" };
}
// Rule module for the preliminary screening. Called only by lib/case-engine.ts (the single writer of candidates.assessment).
export function assess(p: Profile, derived: DerivedFacts, now: Date, verifiedCategories: string[], details: IntakeDetails | null): Assessment {
  const teer=derived.teer;
  const offerTeer=details?details.offerTeer:teer;
  const rcipLevel = offerTeer === null ? null : offerTeer <= 1 ? 6 : offerTeer <= 3 ? 5 : 4;
  const english=(level:number)=>details&&details.englishTest==='unknown'?null:details&&!['ielts_general','celpip_general','pte_core'].includes(details.englishTest)?false:validTest(p.englishMin,p.englishDate,level,now);
  const frenchTest=(level:number)=>details&&details.frenchTest==='unknown'?null:details&&!['tef_canada','tcf_canada'].includes(details.frenchTest)?false:validTest(p.frenchMin,p.frenchDate,level,now);
  const rcipLanguage = rcipLevel === null ? null : either(english(rcipLevel),frenchTest(rcipLevel));
  const fswLanguage = either(english(7),frenchTest(7));
  const edu = p.education === "unknown" ? null : p.education !== "below_secondary";
  const rcip = path("rcip", "المجتمعات الريفية", "RCIP", [
    check("12 شهرًا من الخبرة خلال آخر 3 سنوات؛ تُراجع مطابقة المهنة وإعفاءات الخريجين", derived.experience3 === null ? null : derived.experience3 >= 12, sources.experience),
    check("خبرة مدفوعة لدى جهة عمل؛ ليست عملًا حرًا", bool(p.paidEmployee), sources.experience),
    check("الحد اللغوي المطلوب باختبار ساري في المهارات الأربع", rcipLanguage, sources.language),
    check("مؤهل يعادل الثانوية الكندية على الأقل", edu, sources.rcip),
    check("تقييم ECA ساري أو مؤهل كندي مؤهل", bool(p.eca), sources.rcip),
    check("عرض عمل من صاحب عمل معتمد داخل مجتمع مشارك", p.jobOffer === "no" || p.designated === "no" ? false : p.jobOffer === "yes" && p.designated === "yes" ? true : null, sources.rcip),
    check("عرض غير موسمي، بلا نهاية محددة، و30 ساعة مدفوعة أسبوعيًا على الأقل", bool(p.jobConditions), sources.rcip),
    check("توصية المجتمع المحلي", bool(p.recommendation), sources.rcip),
    check("مراجعة أموال الاستقرار أو إثبات الإعفاء", null, sources.funds),
  ], "فحص أولي فقط. تُراجع المهن ذات الأولوية، تطابق الخبرة، صحة المستندات، صلاحية التوصية، الأموال، ونية الاستقرار بالمجتمع قبل تحديد الأهلية.");
  const fsw = path("fsw", "العامل الماهر الفيدرالي", "Express Entry · FSW", [
    check("خبرة في TEER 0 أو 1 أو 2 أو 3", teer === null ? null : teer <= 3, sources.fsw),
    check("12 شهرًا من الخبرة خلال آخر 10 سنوات", derived.experience10 === null ? null : derived.experience10 >= 12, sources.fsw),
    check("سنة خبرة مؤهلة متصلة في المهنة الأساسية", bool(p.continuous12), sources.fsw),
    check("CLB/NCLC 7 على الأقل باختبار ساري", fswLanguage, sources.fsw),
    check("مؤهل يعادل الثانوية الكندية على الأقل", edu, sources.fsw),
    check("ECA ساري أو مؤهل كندي مؤهل", bool(p.eca), sources.fsw),
  ], "استيفاء هذه البنود لا يثبت الأهلية: يلزم تقييم شبكة 67 نقطة، الخبرة المدفوعة ومهام NOC، الأموال، المقبولية، وترتيب CRS بواسطة المختص.");
  const french = path("french", "أولوية اللغة الفرنسية", "Express Entry · French", [
    check("NCLC 7 على الأقل في المهارات الأربع باختبار ساري", frenchTest(7), sources.french),
  ], "اللغة الفرنسية فئة اختيار وليست برنامج إقامة مستقلًا. يجب التأهل لأحد برامج Express Entry واستيفاء تعليمات جولة الدعوة.");
  // v2.2: no RCIP transition branch, grace or screen here. The pilot/permanent routing is decided only by the
  // approval-for-submission date in Toronto through the sealed rules (lib/rule-resolver.ts routeRcip).
  const lmia=path('lmia','تصريح العمل المرتبط بصاحب عمل','LMIA · Employer-specific permit',[
    check('عرض عمل كندي مكتوب',bool(p.jobOffer),sources.lmia),
    check('قرار LMIA إيجابي صادر لصاحب العمل',details?.lmiaStatus==='positive'?true:details?.lmiaStatus==='negative'?false:null,sources.lmia),
    check('مطابقة اسم العامل والمهنة وصلاحية القرار وشروط عرض العمل',null,sources.lmia),
    check('فحص متطلبات تصريح العمل، أو الإعفاء المنطبق من LMIA',null,sources.workPermit),
  ],'LMIA إجراء لدى صاحب العمل، وليس عقدًا أو تأشيرة أو إقامة دائمة. غياب القرار لا يعني عدم أهلية العميل؛ تُراجع الحاجة إلى LMIA أو الإعفاء المنطبق قبل اختيار المسار.');
  const required = ["resume", "language", "education", "experience"];
  const missingDocuments = required.filter(c => !verifiedCategories.includes(c));
  const fields = [p.fullName,p.phone,p.country,p.occupation,p.noc,derived.teer,derived.experience3,derived.experience10,p.education === "unknown" ? null : p.education,p.englishMin ?? p.frenchMin,p.englishDate || p.frenchDate,p.eca === "unknown" ? null : p.eca,details && !details.familySizeProvided ? null : p.familySize,p.funds];
  const completeness = Math.round(fields.filter(v => v !== null && v !== "").length / fields.length * 100);
  const nextAction = !p.occupation ? "استكمال المهنة والخبرة" : !p.noc || teer === null ? "تحديد NOC وTEER حسب المهام الفعلية" : p.englishMin === null && p.frenchMin === null ? "طلب نتيجة اختبار لغة معتمد" : missingDocuments.length ? "استلام المستندات والتحقق منها" : "إحالة التقييم إلى المختص";
  return { ruleVersion: RULE_VERSION, assessedAt: now.toISOString(), completeness, nextAction, pathways: [rcip, lmia, fsw, french], missingDocuments };
}

// ---- v2.2 Gate 3: the unified assessment (same engine, same assessment_history). Pure apart from the injected
// bundle/source loaders. Eligibility, CRS and ranking stay separate; ranking is RANK_UNAVAILABLE until an approved
// rubric exists (I10). RAPID_SCREENING may use reported facts and is never final; VERIFIED_SCREENING treats reported
// facts as unverified. No missing rule or fact is replaced by a value.
export type ProgramRef = { programId: string; streamId: string | null; phase: "PROFILE" | "APPLICATION" | "PROCESSING" };
export type PathwayResultV22 = { program: ProgramRef; evaluationStatus: "EVALUATED" | "RULE_UNAVAILABLE" | "CONTEXT_INCOMPLETE"; intakeState: "OPEN" | "CLOSED_TO_NEW" | "FUTURE" | "UNKNOWN"; eligibility: PredicateState; predicates: PredicateResult[]; reasonCodes: string[] };
export type CrsResultV22 = Omit<Extract<CrsPolicyResult, { status: "COMPLETE" }>, "trace"> | Exclude<CrsPolicyResult, { status: "COMPLETE" }>;
export type Stage = "PRELIMINARY_ASSESSMENT" | "FINAL_VERIFIED_ASSESSMENT" | "BLOCKED_RULES" | "REVIEW_REQUIRED";
export type AssessmentStaffV22 = {
  schemaVersion: "2.0.0"; assessmentId: string; caseId: string; dataRevision: number; assessmentMode: "PRODUCTION" | "SHADOW";
  stage: Stage; fingerprint: string; ruleReleaseHash: string | null; engineVersion: string; eventContext: EventContext;
  pathways: PathwayResultV22[]; crs: CrsResultV22; ranking: { status: "RANK_UNAVAILABLE"; policyHash: null; entries: []; reasonCodes: string[] };
  missingEvidence: { factKey: string; reasonCode: string; program: ProgramRef }[]; scopeLimitations: string[]; reviewRefs: string[];
  internalDiagnosticCodes: string[]; assessmentPurpose: "RAPID_SCREENING" | "VERIFIED_SCREENING";
};
export type V22BuildInput = {
  caseId: string; dataRevision: number; mode: "PRODUCTION" | "SHADOW"; purpose: "RAPID_SCREENING" | "VERIFIED_SCREENING";
  eventContext: EventContext; selectedPrograms: readonly ProgramRef[]; normalization: Omit<NormalizationInput, "profileDate" | "wageRows">;
  active: ActiveRelease | null; loadBundle: (bundleId: string) => Promise<LoadedBundle | null>;
  sources: ReadonlyMap<string, { officialUrl: string; sourceHash: string }>;
};
export const SCOPE_LIMITATIONS: readonly string[] = Object.freeze([
  "Preparation screening by the office engine; it is not a decision by IRCC or a province and does not predict acceptance.",
  "A MANAGER seal is the office software authority over imported rule payloads, not a government or independent legal certification.",
  "RCIP pilot/permanent routing follows the approved office policy (approval-for-submission date in America/Toronto), not an independently verified IRCC change.",
]);
const RCIP_IDS = new Set(["RCIP", "RCIP_PILOT", "RCIP_PERMANENT"]);
export const NO_RELEASE_HASH_INPUT = { release: null, engineVersion: V22_ENGINE_VERSION };
const programKey = (p: ProgramRef) => jcs(p);
function unavailablePath(program: ProgramRef, r: Exclude<Resolution, { status: "RESOLVED" }> | { status: "RULE_UNAVAILABLE" | "CONTEXT_INCOMPLETE"; reason: string }): PathwayResultV22 {
  return { program, evaluationStatus: r.status === "CONTEXT_INCOMPLETE" ? "CONTEXT_INCOMPLETE" : "RULE_UNAVAILABLE", intakeState: "UNKNOWN", eligibility: "UNKNOWN", predicates: [], reasonCodes: [r.reason] };
}
export async function buildV22Assessment(i: V22BuildInput): Promise<{ output: Omit<AssessmentStaffV22, "assessmentId">; canonical: Record<string, unknown>; canonicalHash: string; ruleBundleHash: string; trace: Record<string, unknown> }> {
  const selected = [...new Map(i.selectedPrograms.map(p => [programKey(p), p])).values()].sort((a, b) => programKey(a).localeCompare(programKey(b)));
  const diagnostics: string[] = [], bundleHashes = new Set<string>();
  const needsCrs = selected.some(p => p.programId.startsWith("EE_"));
  let crsResolution: Resolution | null = null;
  if (needsCrs) crsResolution = await resolveRule(i.active, { programId: CRS_PROGRAM_ID, family: CRS_FAMILY, phase: "PROFILE" }, i.eventContext, i.loadBundle);
  let wageRows: WageRow[] | null = null;
  if (crsResolution?.status === "RESOLVED") {
    bundleHashes.add(crsResolution.bundleHash);
    const wage = crsResolution.bundle.dataSets.filter(d => d.kind === "HIGH_WAGE_BANDS");
    if (wage.length === 1 && wage[0].kind === "HIGH_WAGE_BANDS") wageRows = wage[0].rows; else if (wage.length > 1) diagnostics.push("CRS_WAGE_DATASET_AMBIGUOUS");
  }
  const facts: NormalizedFacts = normalizeCase({ ...i.normalization, profileDate: i.eventContext.profileDate, wageRows });
  const dates = datesFor(i.eventContext), supported = new Set<string>(FACT_PATH_LIST);
  const pathways: PathwayResultV22[] = [], missing: AssessmentStaffV22["missingEvidence"] = [];
  for (const sel of selected) {
    if (sel.programId === CRS_PROGRAM_ID) continue;
    let programId = sel.programId;
    if (RCIP_IDS.has(sel.programId)) {
      const route = routeRcip(i.active, ELIGIBILITY_FAMILY, sel.phase, { ...i.eventContext, recommendationIssuedOn: (facts["rcip.recommendationIssuedOn"].value as string | null) ?? i.eventContext.recommendationIssuedOn });
      if (route.status === "FAIL") { pathways.push({ program: { ...sel, programId: route.programId }, evaluationStatus: "EVALUATED", intakeState: "UNKNOWN", eligibility: "FAIL", predicates: [], reasonCodes: [route.code] }); continue; }
      if (route.status !== "RESOLVED") { pathways.push(unavailablePath({ ...sel, programId: "RCIP" }, route)); continue; }
      programId = route.programId;
    }
    const program = { ...sel, programId }, r = await resolveRule(i.active, { programId, family: ELIGIBILITY_FAMILY, phase: sel.phase }, i.eventContext, i.loadBundle);
    if (r.status !== "RESOLVED") { pathways.push(unavailablePath(program, r)); continue; }
    bundleHashes.add(r.bundleHash);
    const out = evaluateObligations({ obligations: r.bundle.obligations as Obligation[], rootObligationId: r.bundle.rootObligationId, requiredObligationIds: r.bundle.requiredObligationIds, ruleHash: r.bundleHash, facts, supportedPaths: supported, dates, defaultBasis: r.interval.dateBasis, sources: i.sources, purpose: i.purpose });
    if (out.blocked) { diagnostics.push(programId + ":" + out.blocked); pathways.push({ program, evaluationStatus: "RULE_UNAVAILABLE", intakeState: "UNKNOWN", eligibility: "UNKNOWN", predicates: [], reasonCodes: [out.blocked] }); continue; }
    const leaf = new Map(r.bundle.obligations.map(o => [o.obligationId, o.expression]));
    for (const p of out.predicates) {
      const e = leaf.get(p.obligationId);
      if (e && "normalizedFactPath" in e && (p.reasonCode === "FACT_UNKNOWN" || p.reasonCode === "FACT_NOT_VERIFIED")) missing.push({ factKey: e.normalizedFactPath, reasonCode: p.reasonCode, program });
    }
    pathways.push({ program, evaluationStatus: "EVALUATED", intakeState: "UNKNOWN", eligibility: out.eligibility, predicates: out.predicates, reasonCodes: out.reasonCodes });
  }
  let crsFull: CrsPolicyResult;
  if (!needsCrs) crsFull = { status: "NOT_APPLICABLE", total: null, maxTotal: null, components: null, rulePolicyHash: null, missingFields: [], reasonCodes: ["NO_EXPRESS_ENTRY_PROGRAM_SELECTED"] };
  else if (!crsResolution || crsResolution.status === "RULE_UNAVAILABLE") crsFull = { status: "RULE_UNAVAILABLE", total: null, maxTotal: null, components: null, rulePolicyHash: null, missingFields: [], reasonCodes: [crsResolution?.reason ?? "NO_ACTIVE_RELEASE"] };
  else if (crsResolution.status === "CONTEXT_INCOMPLETE") crsFull = { status: "INCOMPLETE", total: null, maxTotal: null, components: null, rulePolicyHash: null, missingFields: [crsResolution.reason], reasonCodes: ["CONTEXT_INCOMPLETE"] };
  else crsFull = crsFromPolicy({ tables: crsResolution.bundle.decisionTables, caps: crsResolution.bundle.caps, policyHash: crsResolution.bundleHash }, facts, i.purpose);
  const { trace: crsTrace, ...crs } = crsFull.status === "COMPLETE" ? crsFull : { ...crsFull, trace: null };
  if (crsFull.status === "INCOMPLETE") for (const f of crsFull.missingFields) missing.push({ factKey: f, reasonCode: crsFull.reasonCodes[0] ?? "FACT_UNKNOWN", program: { programId: CRS_PROGRAM_ID, streamId: null, phase: "PROFILE" } });
  const evaluated = pathways.filter(p => p.evaluationStatus === "EVALUATED");
  const crsBlocked = crs.status === "RULE_UNAVAILABLE" || crs.status === "NOT_APPLICABLE";
  const stage: Stage = !i.active || (!evaluated.length && crsBlocked) ? "BLOCKED_RULES"
    : diagnostics.length ? "REVIEW_REQUIRED"
    : i.purpose === "VERIFIED_SCREENING" && pathways.length > 0 && evaluated.length === pathways.length && evaluated.every(p => p.eligibility === "PASS" || p.eligibility === "FAIL") && !missing.length && (crs.status === "COMPLETE" || crs.status === "NOT_APPLICABLE") ? "FINAL_VERIFIED_ASSESSMENT"
    : "PRELIMINARY_ASSESSMENT";
  const ruleBundleHash = i.active ? i.active.manifestSha256 : await jcsHash(NO_RELEASE_HASH_INPUT);
  const canonical = { schemaVersion: "2.0.0", caseId: i.caseId, engineVersion: V22_ENGINE_VERSION, mode: i.mode, purpose: i.purpose, eventContext: i.eventContext, selectedPrograms: selected, facts, evidence: [...i.normalization.verifiedCategories].sort(), release: i.active ? { releaseId: i.active.releaseId, manifestSha256: i.active.manifestSha256 } : null, bundles: [...bundleHashes].sort() };
  const canonicalHash = await jcsHash(canonical);
  const output: Omit<AssessmentStaffV22, "assessmentId"> = {
    schemaVersion: "2.0.0", caseId: i.caseId, dataRevision: i.dataRevision, assessmentMode: i.mode, stage, fingerprint: canonicalHash,
    ruleReleaseHash: i.active ? i.active.manifestSha256 : null, engineVersion: V22_ENGINE_VERSION, eventContext: i.eventContext,
    pathways, crs, ranking: { status: "RANK_UNAVAILABLE", policyHash: null, entries: [], reasonCodes: ["RANKING_RUBRIC_NOT_APPROVED"] },
    missingEvidence: missing.sort((a, b) => (a.factKey + a.program.programId).localeCompare(b.factKey + b.program.programId)), scopeLimitations: [...SCOPE_LIMITATIONS], reviewRefs: [],
    internalDiagnosticCodes: diagnostics.sort(), assessmentPurpose: i.purpose,
  };
  return { output, canonical, canonicalHash, ruleBundleHash, trace: { engineVersion: V22_ENGINE_VERSION, crs: crsTrace, factOrigins: Object.fromEntries(Object.entries(facts).filter(([, f]) => f.state !== "UNKNOWN").map(([k, f]) => [k, f.origin + ":" + f.state])), bundles: [...bundleHashes].sort() } };
}
