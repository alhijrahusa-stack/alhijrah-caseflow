// v2.2 Gate 6 — privacy lifecycle (04_DATA_AND_ATOMICITY "Erasure"): access export, correction record, legal hold and a
// controlled erasure job, all recorded in the append-only privacy_requests ledger (0031). Erasure removes the personal
// bytes the application can delete — private R2 evidence objects, identity fields of the case profile and client
// details, open sessions and pending/encrypted notice payloads — and writes a non-identifying tombstone. Records that are
// immutable by design (financial ledger and receipts, the signed authorization snapshot and signature, append-only
// audit/events, the encrypted chat transcript, the draft mutation journal, fact revisions) are NOT silently altered:
// they are reported as RETAINED_PENDING_POLICY until an approved retention policy authorizes a retention migration.
// The ledger holds pseudonymous IDs only, so reapplyErasures() can re-run every completed erasure after a backup restore.
import { env } from 'cloudflare:workers';
import { z } from 'zod';
import { getDb } from '@/db';
import { privacyRequests,candidates,clientCases,documents,clientSessions,deliveryOutbox,events,invoices,caseChatMessages,casePurposeConsents,clientServiceRequests } from '@/db/schema';
import { and,eq,inArray,asc,isNull } from 'drizzle-orm';
import { ApiError } from './api-error';
import { encrypt } from './security';

export const PRIVACY_POLICY_APPROVED=false;
export const RETAINED_PENDING_POLICY=['financial_ledger_and_receipts','signed_authorization_snapshot_and_signature','append_only_audit_and_events','chat_transcript_immutable_encrypted','draft_mutation_journal','fact_revisions'] as const;
export const privacyRequestSchema=z.object({kind:z.enum(['ACCESS','CORRECTION','ERASURE','HOLD','RELEASE_HOLD']),reasonCode:z.string().trim().min(2).max(200),requestKey:z.string().min(8).max(200)}).strict();
const ERASED='[erased]';
const PROFILE_PII=['fullName','phone','email','community'] as const;
const DETAILS_PII=['passportNumber','birthDate','passportExpiry','issuingCountry','city','notes','additionalSkills','offerNoc'] as const;

export async function privacyLedger(caseId:string){
 const rows=await getDb().select().from(privacyRequests).where(eq(privacyRequests.caseId,caseId)).orderBy(asc(privacyRequests.createdAt),asc(privacyRequests.requestId));
 return rows.map(r=>({requestId:r.requestId,kind:r.kind,state:r.state,reasonCode:r.reasonCode,requestedBy:r.requestedBy,completedAt:r.completedAt,createdAt:r.createdAt,result:r.resultJson?JSON.parse(r.resultJson):null}));
}
/** A hold is active when the latest HOLD/RELEASE_HOLD completed entry is a HOLD. */
export async function holdActive(caseId:string){
 const rows=(await privacyLedger(caseId)).filter(r=>r.state==='COMPLETED'&&(r.kind==='HOLD'||r.kind==='RELEASE_HOLD'));
 return rows.at(-1)?.kind==='HOLD';
}
export async function isErased(caseId:string){const [c]=await getDb().select({profile:candidates.profile}).from(candidates).where(eq(candidates.id,caseId)).limit(1);return !!c&&(JSON.parse(c.profile) as {erased?:boolean}).erased===true;}
/** Subject access export: the client-relevant data the office holds for the case (decrypted chat texts included). */
export async function accessExport(caseId:string){
 const db=getDb(),[c]=await db.select().from(candidates).where(eq(candidates.id,caseId)).limit(1);if(!c)throw new ApiError(404,'الملف غير موجود.');
 const [cc]=await db.select({details:clientCases.details,submittedAt:clientCases.submittedAt}).from(clientCases).where(eq(clientCases.candidateId,caseId)).limit(1);
 const docs=await db.select({id:documents.id,name:documents.name,category:documents.category,size:documents.size,mime:documents.mime,createdAt:documents.createdAt,integrityState:documents.integrityState}).from(documents).where(eq(documents.candidateId,caseId));
 const inv=await db.select({invoiceId:invoices.invoiceId,currency:invoices.currency,status:invoices.status,totalCents:invoices.totalCents,paidCents:invoices.paidCents,remainingCents:invoices.remainingCents,createdAt:invoices.createdAt}).from(invoices).where(eq(invoices.caseId,caseId));
 const { decrypt }=await import('./security'),msgs=await db.select().from(caseChatMessages).where(eq(caseChatMessages.caseId,caseId)).orderBy(asc(caseChatMessages.sequence));
 const consents=await db.select({purpose:casePurposeConsents.purpose,granted:casePurposeConsents.granted,updatedAt:casePurposeConsents.updatedAt}).from(casePurposeConsents).where(eq(casePurposeConsents.caseId,caseId));
 const services=await db.select({serviceId:clientServiceRequests.serviceId,state:clientServiceRequests.state,createdAt:clientServiceRequests.createdAt}).from(clientServiceRequests).where(eq(clientServiceRequests.caseId,caseId));
 return {generatedAt:new Date().toISOString(),reference:c.reference,status:c.status,profile:JSON.parse(c.profile),details:cc?JSON.parse(cc.details):null,submittedAt:cc?.submittedAt??null,documents:docs,invoices:inv,consents,serviceRequests:services,
  chat:await Promise.all(msgs.map(async m=>({sequence:m.sequence,actorType:m.actorType,kind:m.kind,createdAt:m.createdAt,text:(JSON.parse(await decrypt(m.bodyEncrypted)) as {text:string|null}).text})))};
}
function bucket(){const b=(env as unknown as {BUCKET?:R2Bucket}).BUCKET;if(!b)throw new ApiError(503,'التخزين غير متاح.');return b;}
/** Idempotent erasure of the case's deletable personal data (see header). Returns non-identifying counts. */
export async function executeErasure(caseId:string){
 const db=getDb(),[c]=await db.select().from(candidates).where(eq(candidates.id,caseId)).limit(1);if(!c)return {caseFound:false};
 const docs=await db.select({id:documents.id,objectKey:documents.objectKey}).from(documents).where(eq(documents.candidateId,caseId));
 let objectsDeleted=0;for(const d of docs)if(d.objectKey){await bucket().delete(d.objectKey);objectsDeleted++;}
 const profile=JSON.parse(c.profile) as Record<string,unknown>;
 for(const k of PROFILE_PII)if(k in profile)profile[k]=k==='fullName'?ERASED:k==='phone'?'00000':'';
 profile.fullName=ERASED;profile.phone='00000';profile.jobs=[];profile.erased=true;
 const [cc]=await db.select({details:clientCases.details}).from(clientCases).where(eq(clientCases.candidateId,caseId)).limit(1);
 let details:Record<string,unknown>|null=null;if(cc){details=JSON.parse(cc.details) as Record<string,unknown>;for(const k of DETAILS_PII)if(k in details)details[k]='';details.jobs=[];details.companions=[];}
 const outbox=await db.select({eventId:deliveryOutbox.eventId,state:deliveryOutbox.state}).from(deliveryOutbox).where(eq(deliveryOutbox.caseId,caseId));
 const now=new Date().toISOString(),blank=await encrypt('{}');
 const stmts:unknown[]=[
  db.update(documents).set({name:ERASED,objectKey:'',preparation:'{}'}).where(eq(documents.candidateId,caseId)),
  db.update(candidates).set({profile:JSON.stringify(profile),emailKey:'',contactPairKey:'',dedupeKey:'',status:'archived',updatedAt:now}).where(eq(candidates.id,caseId)),
  db.update(clientSessions).set({revokedAt:Date.now()}).where(and(eq(clientSessions.candidateId,caseId),isNull(clientSessions.revokedAt))),
 ];
 if(details)stmts.push(db.update(clientCases).set({details:JSON.stringify(details)}).where(eq(clientCases.candidateId,caseId)));
 const open=outbox.filter(o=>['PENDING','RETRY','AMBIGUOUS','LEASED'].includes(o.state)).map(o=>o.eventId);
 if(open.length)stmts.push(db.update(deliveryOutbox).set({state:'CANCELLED',errorCode:'ERASED',leaseUntilMs:0}).where(inArray(deliveryOutbox.eventId,open)));
 if(outbox.length)stmts.push(db.update(deliveryOutbox).set({payloadEncrypted:blank}).where(eq(deliveryOutbox.caseId,caseId)));
 await db.batch(stmts as unknown as Parameters<typeof db.batch>[0]);
 return {caseFound:true,objectsDeleted,documentsTombstoned:docs.length,outboxCancelled:open.length,outboxPayloadsCleared:outbox.length,policyApproved:PRIVACY_POLICY_APPROVED,retainedPendingPolicy:[...RETAINED_PENDING_POLICY]};
}
/** One privacy request: recorded first (REQUESTED), executed, then COMPLETED or REFUSED. Replays by request key. */
export async function handlePrivacyRequest(caseId:string,actor:string,input:z.infer<typeof privacyRequestSchema>){
 const db=getDb(),[prior]=await db.select().from(privacyRequests).where(eq(privacyRequests.requestKey,input.requestKey)).limit(1);
 if(prior){if(prior.caseId!==caseId||prior.kind!==input.kind)throw new ApiError(409,'مفتاح الطلب مستخدم لطلب مختلف.');return {requestId:prior.requestId,state:prior.state,result:prior.resultJson?JSON.parse(prior.resultJson):null,replayed:true};}
 const requestId=crypto.randomUUID(),now=new Date().toISOString();
 await db.insert(privacyRequests).values({requestId,caseId,kind:input.kind,reasonCode:input.reasonCode,requestKey:input.requestKey,requestedBy:actor,createdAt:now});
 const finish=async(state:'COMPLETED'|'REFUSED',result:Record<string,unknown>)=>{const [c]=await db.select({o:candidates.ownerId}).from(candidates).where(eq(candidates.id,caseId)).limit(1);
  await db.batch([db.update(privacyRequests).set({state,completedBy:actor,completedAt:new Date().toISOString(),resultJson:JSON.stringify(result)}).where(eq(privacyRequests.requestId,requestId)),
   db.insert(events).values({id:crypto.randomUUID(),ownerId:c.o,candidateId:caseId,action:'طلب خصوصية: '+input.kind+' · '+state,note:requestId,createdAt:new Date().toISOString()})]);
  return {requestId,state,result,replayed:false};};
 if(input.kind==='ERASURE'){if(await holdActive(caseId))return finish('REFUSED',{reason:'LEGAL_HOLD_ACTIVE'});return finish('COMPLETED',await executeErasure(caseId));}
 if(input.kind==='ACCESS')return {...await finish('COMPLETED',{exported:true}),export:await accessExport(caseId)};
 if(input.kind==='RELEASE_HOLD'&&!await holdActive(caseId))return finish('REFUSED',{reason:'NO_ACTIVE_HOLD'});
 // HOLD / RELEASE_HOLD change the erasure eligibility; CORRECTION records that the correction was made through the
 // existing case edit flows (no second editing path).
 return finish('COMPLETED',{});
}
/** After a restore: re-run every completed erasure from the current ledger (or an external journal of the ledger). */
export async function reapplyErasures(journal?:{requestId:string;caseId:string;requestedBy:string;requestKey:string;reasonCode:string|null;createdAt:string;completedAt:string|null;resultJson:string|null}[]){
 const db=getDb(),entries=journal??(await db.select().from(privacyRequests).where(and(eq(privacyRequests.kind,'ERASURE'),eq(privacyRequests.state,'COMPLETED')))).map(r=>({...r}));
 let reapplied=0;
 for(const e of entries){
  // A restored database may predate the erasure: restore the ledger row itself first (same request id).
  await db.insert(privacyRequests).values({requestId:e.requestId,caseId:e.caseId,kind:'ERASURE',state:'COMPLETED',reasonCode:e.reasonCode,requestKey:e.requestKey,requestedBy:e.requestedBy,completedBy:e.requestedBy,resultJson:e.resultJson,createdAt:e.createdAt,completedAt:e.completedAt}).onConflictDoNothing();
  const r=await executeErasure(e.caseId);if(r.caseFound)reapplied++;
 }
 return {reapplied,entries:entries.length};
}
export async function erasureJournal(){return (await getDb().select().from(privacyRequests).where(and(eq(privacyRequests.kind,'ERASURE'),eq(privacyRequests.state,'COMPLETED')))).map(r=>({requestId:r.requestId,caseId:r.caseId,requestedBy:r.requestedBy,requestKey:r.requestKey,reasonCode:r.reasonCode,createdAt:r.createdAt,completedAt:r.completedAt,resultJson:r.resultJson}));}
