// v2.2 Gate 5 — Package 8 canonical case chat on D1 (+R2 evidence). One conversation per case; every message gets the
// next per-conversation sequence through the chat_message_guard trigger (last_sequence+1), so two concurrent writers
// cannot share a sequence: the loser re-reads and retries. (conversation, sender, clientMessageId) is unique: a retry with
// the same payload hash replays the committed message, a different payload under the same id is 409. State changes are
// append-only transitions with an expected revision (one claim wins); every transition bumps automation_generation, which
// fences any assistant output computed before it (ASSISTANT_FENCED). Bodies are encrypted at rest. Owner policy: every
// active staff member with the `chat` capability reads every conversation. The legacy support thread stays readable
// as history; new writes land here only.
import { getDb } from '@/db';
import { caseConversations,caseChatMessages,caseChatReceipts,caseChatTransitions,caseInAppNotifications,documents,users,candidates,durableJobs,deliveryOutbox,ruleActivation,casePurposeConsents,events } from '@/db/schema';
import { and,eq,gt,asc,inArray,sql } from 'drizzle-orm';
import { z } from 'zod';
import { ApiError } from './api-error';
import { encrypt,decrypt } from './security';
import { jcsHash } from './v22-core';
import { SYSTEM_USER_ID } from './rbac';
import { jobRow } from './jobs';
import { outboxRow,hasConsent } from './outbox';
import { integrityView } from './evidence-processing';
import { publish } from './chat-transport';
import { assistantAvailability } from './case-assistant';

export const PROTOCOL='2.0.0';
export type Principal={kind:'CLIENT';userId:string;caseId:string}|{kind:'STAFF';userId:string}|{kind:'ASSISTANT'|'SYSTEM';userId:string};
export const clientPrincipalId=(caseId:string)=>'client:'+caseId;
const Id=z.string().min(8).max(200);
export const messageCreateSchema=z.union([
 z.object({clientMessageId:Id,repliedToMessageId:Id.nullable(),kind:z.literal('TEXT'),text:z.string().trim().min(1).max(4000)}).strict(),
 z.object({clientMessageId:Id,repliedToMessageId:Id.nullable(),kind:z.literal('ATTACHMENT'),evidenceIds:z.array(Id).min(1).max(5)}).strict(),
 z.object({clientMessageId:Id,repliedToMessageId:Id.nullable(),kind:z.literal('VOICE_NOTE'),evidenceId:Id}).strict(),
]);
export type MessageCreate=z.infer<typeof messageCreateSchema>;
type Conversation=typeof caseConversations.$inferSelect;
type Row=typeof caseChatMessages.$inferSelect;
type Body={text:string|null;evidenceIds:string[];assessmentId:string|null;repliedToMessageId:string|null;sourceRefs:unknown[]};

export async function ensureClientUser(caseId:string){await getDb().insert(users).values({userId:clientPrincipalId(caseId),role:'CLIENT',createdAt:new Date().toISOString()}).onConflictDoNothing();return clientPrincipalId(caseId);}
export async function conversationOf(caseId:string):Promise<Conversation>{
 const db=getDb(),now=new Date().toISOString();
 await db.insert(caseConversations).values({conversationId:crypto.randomUUID(),caseId,createdAt:now,updatedAt:now}).onConflictDoNothing();
 const [c]=await db.select().from(caseConversations).where(eq(caseConversations.caseId,caseId)).limit(1);return c;
}
async function conversationById(id:string){const [c]=await getDb().select().from(caseConversations).where(eq(caseConversations.conversationId,id)).limit(1);return c??null;}
// forClient: the client sees that a staff member holds the conversation, never which one (no staff identities).
export async function conversationResource(c:Conversation,forClient=false){return {conversationId:c.conversationId,caseId:c.caseId,state:c.state as 'BOT_ACTIVE'|'HANDOFF_PENDING'|'HUMAN_ACTIVE'|'CLOSED',assignedStaffId:forClient?(c.assignedTo?'office':null):c.assignedTo,conversationRevision:c.revision,automationGeneration:c.automationGeneration,lastSequence:c.lastSequence,assistantAvailability:await assistantAvailability(c.caseId),presence:'UNKNOWN' as const};}
const KIND_VIEW:Record<string,'TEXT'|'ATTACHMENT'|'VOICE_NOTE'|'ASSESSMENT_LINK'|'SYSTEM'>={TEXT:'TEXT',ATTACHMENT:'ATTACHMENT',VOICE:'VOICE_NOTE',ASSESSMENT:'ASSESSMENT_LINK'};
async function view(rows:Row[],forClient:boolean){
 const bodies=await Promise.all(rows.map(async r=>JSON.parse(await decrypt(r.bodyEncrypted)) as Body));
 const ids=[...new Set(bodies.flatMap(b=>b.evidenceIds))];
 const docs=ids.length?await getDb().select({id:documents.id,objectKey:documents.objectKey,mime:documents.mime,size:documents.size,state:documents.integrityState,duration:documents.mediaDurationMs,category:documents.category}).from(documents).where(inArray(documents.id,ids)):[];
 const jobs=ids.length?await getDb().select({key:durableJobs.requestKey,state:durableJobs.state}).from(durableJobs).where(inArray(durableJobs.requestKey,ids.map(i=>'transcribe:'+i))):[];
 const { transcriptState }=await import('./transcription');
 return Promise.all(rows.map(async (r,i)=>{const b=bodies[i];return {messageId:r.messageId,conversationId:r.conversationId,caseId:r.caseId,sequence:r.sequence,clientMessageId:r.clientMessageId,
  senderDisplayRef:r.actorType==='STAFF'?(forClient?'office':r.senderId):r.actorType==='CLIENT'?'client':r.actorType==='ASSISTANT'?'assistant':'system',actorType:r.actorType,kind:KIND_VIEW[r.kind]??'SYSTEM',text:b.text,
  attachments:await Promise.all(b.evidenceIds.map(async id=>{const d=docs.find(x=>x.id===id),voice=d?.category==='chat_voice';return {evidenceId:id,mediaKind:voice?'VOICE_NOTE' as const:d?.mime.startsWith('image/')?'IMAGE' as const:'DOCUMENT' as const,state:d&&d.objectKey?integrityView(d.state):'ERASED' as const,mimeType:d?.mime??'application/octet-stream',byteLength:d?.size??null,durationMs:d?.duration??null,transcriptState:await transcriptState(r.caseId,voice,jobs.find(j=>j.key==='transcribe:'+id)??null)};})),
  assessmentId:b.assessmentId,repliedToMessageId:b.repliedToMessageId,sourceRefs:b.sourceRefs,createdAt:r.createdAt};}));
}
/** Keyset replay: messages after a sequence, at most 100 per page. */
export async function replay(caseId:string,afterSequence:number,limit:number,forClient:boolean){
 const c=await conversationOf(caseId),n=Math.min(100,Math.max(1,limit));
 const rows=await getDb().select().from(caseChatMessages).where(and(eq(caseChatMessages.conversationId,c.conversationId),gt(caseChatMessages.sequence,afterSequence))).orderBy(asc(caseChatMessages.sequence)).limit(n+1);
 const page=rows.slice(0,n);
 return {items:await view(page,forClient),nextAfterSequence:rows.length>n?page[page.length-1].sequence:null,lastSequence:c.lastSequence,conversation:await conversationResource(c,forClient)};
}
const actorType=(p:Principal)=>p.kind;
const conflict=(e:unknown)=>{const m=e instanceof Error?e.message+' '+String((e as {cause?:unknown}).cause??''):String(e);return m;};
async function existing(conversationId:string,senderId:string,clientMessageId:string){const [r]=await getDb().select().from(caseChatMessages).where(and(eq(caseChatMessages.conversationId,conversationId),eq(caseChatMessages.senderId,senderId),eq(caseChatMessages.clientMessageId,clientMessageId))).limit(1);return r??null;}
async function validateEvidence(caseId:string,m:MessageCreate){
 const ids=m.kind==='ATTACHMENT'?m.evidenceIds:m.kind==='VOICE_NOTE'?[m.evidenceId]:[];if(!ids.length)return ids;
 const rows=await getDb().select({id:documents.id,category:documents.category,state:documents.integrityState}).from(documents).where(and(eq(documents.candidateId,caseId),inArray(documents.id,ids)));
 if(rows.length!==new Set(ids).size)throw new ApiError(422,'المرفق غير موجود في هذا الملف.');
 if(rows.some(r=>r.state==='REJECTED'))throw new ApiError(422,'رُفض أحد المرفقات في الفحص.');
 if(m.kind==='VOICE_NOTE'&&rows[0].category!=='chat_voice')throw new ApiError(422,'الملف ليس رسالة صوتية.');
 if(m.kind==='ATTACHMENT'&&rows.some(r=>r.category==='chat_voice'))throw new ApiError(422,'أرسل الرسالة الصوتية بنوع VOICE_NOTE.');
 return ids;
}
type Extra=(c:Conversation,sequence:number)=>Promise<{before?:unknown[];after?:unknown[]}>;
/** The one write path: sequence allocation with retry, dedup by client id, extra statements in the same batch. */
export async function appendMessage(p:Principal,caseId:string,input:{clientMessageId:string;kind:'TEXT'|'ATTACHMENT'|'VOICE'|'ASSESSMENT';body:Body;fence?:{automationGeneration:number;inReplyToSequence:number;dataRevision:number;ruleGeneration:number}},extra?:Extra){
 const db=getDb(),payloadHash=await jcsHash({kind:input.kind,body:input.body});
 for(let attempt=0;attempt<16;attempt++){
  if(attempt)await new Promise(r=>setTimeout(r,Math.floor(Math.random()*15*Math.min(attempt,6))));
  const c=await conversationOf(caseId),prior=await existing(c.conversationId,p.userId,input.clientMessageId);
  if(prior){if(prior.payloadHash!==payloadHash)throw new ApiError(409,'معرّف الرسالة مستخدم لمحتوى مختلف.');return {message:prior,replayed:true,conversation:c};}
  const sequence=c.lastSequence+1,messageId=crypto.randomUUID(),now=new Date().toISOString();
  const more=extra?await extra(c,sequence):{};
  const stmts:unknown[]=[...(more.before??[]),db.insert(caseChatMessages).values({messageId,conversationId:c.conversationId,caseId,sequence,senderId:p.userId,actorType:actorType(p),clientMessageId:input.clientMessageId,payloadHash,kind:input.kind,bodyEncrypted:await encrypt(JSON.stringify(input.body)),evidenceId:input.body.evidenceIds[0]??null,automationGeneration:input.fence?.automationGeneration??null,contextDataRevision:input.fence?.dataRevision??null,contextRuleGeneration:input.fence?.ruleGeneration??null,inReplyToSequence:input.fence?.inReplyToSequence??null,createdAt:now})];
  stmts.push(...(more.after??[]));
  try{await db.batch(stmts as unknown as Parameters<typeof db.batch>[0]);}
  catch(e){const m=conflict(e);
   if(/ASSISTANT_FENCED/.test(m))throw new ApiError(409,'ASSISTANT_FENCED');
   if(/CHAT_SEQUENCE_CONFLICT|UNIQUE constraint failed: case_chat_messages|UNIQUE constraint failed: case_chat_transitions|CHAT_TRANSITION_CONFLICT/.test(m)){const again=await conversationById(c.conversationId);if(again?.state==='CLOSED'&&p.kind!=='CLIENT')throw new ApiError(409,'المحادثة مغلقة.');continue;}
   if(/CHAT_ATTACHMENT_SCOPE/.test(m))throw new ApiError(422,'المرفق غير موجود في هذا الملف.');
   throw e;}
  const [row]=await db.select().from(caseChatMessages).where(eq(caseChatMessages.messageId,messageId)).limit(1);
  const conv=(await conversationById(c.conversationId))!;
  void publish(caseId,{protocolVersion:PROTOCOL,type:'MESSAGE_COMMITTED',commandId:input.clientMessageId,message:(await view([row],false))[0]});
  return {message:row,replayed:false,conversation:conv};
 }
 throw new ApiError(409,'تعذّر حجز تسلسل الرسالة بسبب ضغط متزامن؛ أعد المحاولة.');
}
function transitionStmt(c:{conversationId:string;revision:number;state:string},to:string,assignedTo:string|null,actor:string,requestKey:string,requestHash:string,now:string){
 return getDb().insert(caseChatTransitions).values({transitionId:crypto.randomUUID(),conversationId:c.conversationId,requestKey,requestHash,expectedRevision:c.revision,oldState:c.state,newState:to,assignedTo,actorId:actor,createdAt:now});
}
async function assignedNotification(c:Conversation,sequence:number,now:string){return c.assignedTo?[getDb().insert(caseInAppNotifications).values({notificationId:crypto.randomUUID(),userId:c.assignedTo,caseId:c.caseId,kind:'CHAT_MESSAGE',resourceId:c.conversationId,businessKey:'chat:'+c.conversationId+':'+sequence,createdAt:now}).onConflictDoNothing()]:[];}
/** One external notice per unread window: keyed by the client's current read position, consent required. */
async function clientNotice(c:Conversation,now:number){
 if(!await hasConsent(c.caseId,'CHAT_NOTIFICATIONS'))return [];
 const [r]=await getDb().select({read:caseChatReceipts.readSequence}).from(caseChatReceipts).where(and(eq(caseChatReceipts.conversationId,c.conversationId),eq(caseChatReceipts.userId,clientPrincipalId(c.caseId)))).limit(1);
 const row=await outboxRow('CHAT_NOTICE',c.caseId,'chat-notice:'+c.conversationId+':'+(r?.read??0),{},now+2*60_000);
 return row?[getDb().insert(deliveryOutbox).values(row).onConflictDoNothing()]:[];
}
/** Client message. BOT_ACTIVE with a ready assistant queues one ASSISTANT job; without one the conversation is handed to
 * staff in the same batch. A message to a CLOSED conversation reopens it to the staff queue. */
export async function clientSend(caseId:string,m:MessageCreate,wantsHuman=false){
 const userId=await ensureClientUser(caseId),p:Principal={kind:'CLIENT',userId,caseId};
 const ids=await validateEvidence(caseId,m),kind=m.kind==='VOICE_NOTE'?'VOICE':m.kind;
 const body:Body={text:m.kind==='TEXT'?m.text:null,evidenceIds:ids,assessmentId:null,repliedToMessageId:m.repliedToMessageId,sourceRefs:[]};
 const availability=await assistantAvailability(caseId);
 const out=await appendMessage(p,caseId,{clientMessageId:m.clientMessageId,kind,body},async(c,sequence)=>{
  const now=new Date().toISOString(),extra:unknown[]=[],before:unknown[]=[];
  const hash=await jcsHash({conversationId:c.conversationId,sequence,auto:true});
  if(c.state==='CLOSED')before.push(transitionStmt(c,'HANDOFF_PENDING',null,userId,'auto-reopen:'+c.conversationId+':'+sequence,hash,now));
  else if(c.state==='BOT_ACTIVE'&&(wantsHuman||availability!=='READY'||m.kind!=='TEXT'))extra.push(transitionStmt(c,'HANDOFF_PENDING',null,userId,'auto-handoff:'+c.conversationId+':'+sequence,hash,now));
  else if(c.state==='BOT_ACTIVE'){const [act]=await getDb().select({g:ruleActivation.generation}).from(ruleActivation).where(eq(ruleActivation.singleton,1)).limit(1);const [cand]=await getDb().select({rev:candidates.dataRevision}).from(candidates).where(eq(candidates.id,caseId)).limit(1);
   extra.push(getDb().insert(durableJobs).values(await jobRow({kind:'ASSISTANT',caseId,requestKey:'assistant:'+c.conversationId+':'+sequence,payload:{conversationId:c.conversationId,inReplyToSequence:sequence,automationGeneration:c.automationGeneration,dataRevision:cand.rev,ruleGeneration:act?.g??0},actor:SYSTEM_USER_ID})));}
  extra.push(...await assignedNotification(c,sequence,now));
  // Voice notes are transcribed only with the AUDIO_TRANSCRIPTION consent (the job then reports the provider state).
  if(m.kind==='VOICE_NOTE'&&await hasConsent(caseId,'AUDIO_TRANSCRIPTION'))extra.push(getDb().insert(durableJobs).values(await jobRow({kind:'TRANSCRIPTION',caseId,requestKey:'transcribe:'+ids[0],payload:{documentId:ids[0]},actor:SYSTEM_USER_ID})).onConflictDoNothing());
  return {before,after:extra};
 });
 if(!out.replayed)void publish(caseId,{protocolVersion:PROTOCOL,type:'CONVERSATION_STATE',conversation:await conversationResource(out.conversation)});
 return out;
}
/** Staff message: the sender must hold the conversation (claimed in the same batch when it is unassigned). */
export async function staffSend(caseId:string,staffUserId:string,m:MessageCreate){
 const ids=await validateEvidence(caseId,m),kind=m.kind==='VOICE_NOTE'?'VOICE':m.kind;
 const body:Body={text:m.kind==='TEXT'?m.text:null,evidenceIds:ids,assessmentId:null,repliedToMessageId:m.repliedToMessageId,sourceRefs:[]};
 const out=await appendMessage({kind:'STAFF',userId:staffUserId},caseId,{clientMessageId:m.clientMessageId,kind,body},async(c)=>{
  const now=new Date().toISOString(),before:unknown[]=[];
  if(c.state==='HUMAN_ACTIVE'&&c.assignedTo!==staffUserId)throw new ApiError(409,'المحادثة مستلمة من موظف آخر.');
  if(c.state!=='HUMAN_ACTIVE'){
   const hash=await jcsHash({conversationId:c.conversationId,claim:staffUserId,revision:c.revision});let cur={conversationId:c.conversationId,revision:c.revision,state:c.state};
   if(c.state==='BOT_ACTIVE'||c.state==='CLOSED'){before.push(transitionStmt(cur,'HANDOFF_PENDING',null,staffUserId,'send-handoff:'+c.conversationId+':'+c.revision,hash,now));cur={...cur,revision:cur.revision+1,state:'HANDOFF_PENDING'};}
   before.push(transitionStmt(cur,'HUMAN_ACTIVE',staffUserId,staffUserId,'send-claim:'+c.conversationId+':'+cur.revision,hash,now));
  }
  return {before,after:await clientNotice(c,Date.now())};
 });
 return out;
}
export const transitionSchema=z.object({action:z.enum(['handoff','claim','release','resume_bot','close','reopen']),expectedRevision:z.number().int().min(0),requestKey:Id}).strict();
const TARGET:Record<z.infer<typeof transitionSchema>['action'],string>={handoff:'HANDOFF_PENDING',claim:'HUMAN_ACTIVE',release:'HANDOFF_PENDING',resume_bot:'BOT_ACTIVE',close:'CLOSED',reopen:'HANDOFF_PENDING'};
export async function transition(caseId:string,p:Principal,input:z.infer<typeof transitionSchema>){
 const c=await conversationOf(caseId),requestHash=await jcsHash({caseId,actor:p.userId,...input,requestKey:undefined}),db=getDb();
 const [prior]=await db.select().from(caseChatTransitions).where(eq(caseChatTransitions.requestKey,input.requestKey)).limit(1);
 if(prior){if(prior.requestHash!==requestHash)throw new ApiError(409,'مفتاح الطلب مستخدم لطلب مختلف.');return {replayed:true,conversation:await conversationResource((await conversationById(c.conversationId))!,p.kind==='CLIENT')};}
 if(p.kind==='CLIENT'&&!['handoff','reopen'].includes(input.action))throw new ApiError(403,'هذا الإجراء للمكتب.');
 if(c.revision!==input.expectedRevision)throw new ApiError(409,'تغيّرت حالة المحادثة؛ حدّث الصفحة.');
 if(input.action==='release'&&c.assignedTo!==p.userId)throw new ApiError(409,'لا تملك هذه المحادثة.');
 const to=TARGET[input.action],assigned=to==='HUMAN_ACTIVE'?p.userId:null,now=new Date().toISOString();
 try{await db.batch([transitionStmt(c,to,assigned,p.userId,input.requestKey,requestHash,now),db.insert(events).values({id:crypto.randomUUID(),ownerId:(await db.select({o:candidates.ownerId}).from(candidates).where(eq(candidates.id,caseId)).limit(1))[0].o,candidateId:caseId,action:'محادثة الملف: '+c.state+' → '+to,note:p.kind==='CLIENT'?'العميل':p.userId,createdAt:now})]);}
 catch(e){const m=conflict(e);if(/UNIQUE constraint failed: case_chat_transitions.request_key/.test(m))return transition(caseId,p,input);if(/CHAT_TRANSITION_CONFLICT|CHAT_OWNER_REQUIRED/.test(m))throw new ApiError(409,'تغيّرت حالة المحادثة أو استلمها موظف آخر.');throw e;}
 const fresh=(await conversationById(c.conversationId))!,conv=await conversationResource(fresh);
 void publish(caseId,{protocolVersion:PROTOCOL,type:'CONVERSATION_STATE',conversation:conv});
 return {replayed:false,conversation:p.kind==='CLIENT'?await conversationResource(fresh,true):conv};
}
/** Monotonic receipts (never above last_sequence; read ≤ delivered). */
export async function writeReceipt(caseId:string,userId:string,delivered:number,read:number){
 const c=await conversationOf(caseId),d=Math.min(Math.max(0,delivered),c.lastSequence),r=Math.min(Math.max(0,read),d),now=new Date().toISOString();
 await getDb().run(sql`INSERT INTO case_chat_receipts(conversation_id,user_id,delivered_sequence,read_sequence,updated_at) VALUES(${c.conversationId},${userId},${d},${r},${now})
  ON CONFLICT(conversation_id,user_id) DO UPDATE SET delivered_sequence=MAX(delivered_sequence,excluded.delivered_sequence),read_sequence=MIN(MAX(read_sequence,excluded.read_sequence),MAX(delivered_sequence,excluded.delivered_sequence)),updated_at=excluded.updated_at`);
 const [row]=await getDb().select().from(caseChatReceipts).where(and(eq(caseChatReceipts.conversationId,c.conversationId),eq(caseChatReceipts.userId,userId))).limit(1);
 const receipt={principalDisplayRef:userId.startsWith('client:')?'client':userId,deliveredSequence:row.deliveredSequence,readSequence:row.readSequence,updatedAt:row.updatedAt};
 void publish(caseId,{protocolVersion:PROTOCOL,type:'RECEIPT_UPDATED',receipt});
 return receipt;
}
export async function receipts(caseId:string,forClient=false){const c=await conversationOf(caseId);return (await getDb().select().from(caseChatReceipts).where(eq(caseChatReceipts.conversationId,c.conversationId))).map(r=>({principalDisplayRef:r.userId.startsWith('client:')?'client':forClient?'office':r.userId,deliveredSequence:r.deliveredSequence,readSequence:r.readSequence,updatedAt:r.updatedAt}));}
/** Staff triage: conversations waiting for a human first, then the rest by activity. */
export async function chatQueue(limit=100){
 const rows=await getDb().select({c:caseConversations,reference:candidates.reference,name:sql<string>`json_extract(${candidates.profile},'$.fullName')`}).from(caseConversations).innerJoin(candidates,eq(candidates.id,caseConversations.caseId)).orderBy(sql`case ${caseConversations.state} when 'HANDOFF_PENDING' then 0 when 'HUMAN_ACTIVE' then 1 when 'BOT_ACTIVE' then 2 else 3 end`,sql`${caseConversations.updatedAt} desc`).limit(limit);
 return rows.map(r=>({caseId:r.c.caseId,conversationId:r.c.conversationId,state:r.c.state,assignedStaffId:r.c.assignedTo,waitingSince:r.c.updatedAt,conversationRevision:r.c.revision,lastSequence:r.c.lastSequence,reference:r.reference,name:r.name}));
}
export const consentSchema=z.object({purpose:z.enum(['LLM_CHAT_ASSISTANT','AUDIO_TRANSCRIPTION','CHAT_NOTIFICATIONS','EXPIRY_NOTIFICATIONS']),granted:z.boolean(),noticeVersion:z.string().min(1).max(40)}).strict();
export const CONSENT_NOTICE_VERSION='2026-11-v1';
/** Client-owned purpose consents (each change audited as a case event). */
export async function setConsent(caseId:string,actor:string,input:z.infer<typeof consentSchema>){
 if(input.noticeVersion!==CONSENT_NOTICE_VERSION)throw new ApiError(409,'نص الموافقة تغيّر؛ حدّث الصفحة.');
 const db=getDb(),now=new Date().toISOString(),[c]=await db.select({o:candidates.ownerId}).from(candidates).where(eq(candidates.id,caseId)).limit(1);
 await db.batch([db.insert(casePurposeConsents).values({caseId,purpose:input.purpose,granted:input.granted,noticeVersion:input.noticeVersion,updatedBy:actor,updatedAt:now}).onConflictDoUpdate({target:[casePurposeConsents.caseId,casePurposeConsents.purpose],set:{granted:input.granted,noticeVersion:input.noticeVersion,updatedBy:actor,updatedAt:now}}),
  db.insert(events).values({id:crypto.randomUUID(),ownerId:c.o,candidateId:caseId,action:(input.granted?'منح موافقة: ':'سحب موافقة: ')+input.purpose,note:input.noticeVersion,createdAt:now})]);
 return consents(caseId);
}
export async function consents(caseId:string){const rows=await getDb().select().from(casePurposeConsents).where(eq(casePurposeConsents.caseId,caseId));return Object.fromEntries(['LLM_CHAT_ASSISTANT','AUDIO_TRANSCRIPTION','CHAT_NOTIFICATIONS','EXPIRY_NOTIFICATIONS'].map(p=>[p,rows.find(r=>r.purpose===p)?.granted===true]));}
/** Chat media (CLEAN only): attachments/voice of this case, streamed privately. */
export async function chatMedia(caseId:string,evidenceId:string){
 const [d]=await getDb().select().from(documents).where(and(eq(documents.id,evidenceId),eq(documents.candidateId,caseId))).limit(1);
 if(!d)throw new ApiError(404,'المرفق غير موجود.');if(!d.objectKey)throw new ApiError(410,'حُذف المرفق بطلب خصوصية.');if(d.integrityState!=='CLEAN')throw new ApiError(423,'المرفق قيد الفحص ولا يمكن تشغيله قبل اعتماده نظيفًا.');
 const { env }=await import('cloudflare:workers'),bucket=(env as unknown as {BUCKET?:R2Bucket}).BUCKET;if(!bucket)throw new ApiError(503,'التخزين غير متاح.');
 const o=await bucket.get(d.objectKey);if(!o)throw new ApiError(404,'المرفق غير موجود.');
 return new Response(o.body,{headers:{'Content-Type':d.mime,'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; media-src 'self'",'Content-Disposition':(d.mime.startsWith('audio/')||d.mime.startsWith('image/')?'inline':'attachment')+'; filename="evidence"'}});
}
/** Rapid Assessment from the chat: the same engine, release and Toronto date as every assessment, purpose
 * RAPID_SCREENING (moves only latest_rapid_assessment_id; the verified pointer and report are untouched; never FINAL).
 * Requires the client's explicit confirmation (the request itself, with its own key). */
export async function requestRapidAssessment(caseId:string,p:Principal,requestKey:string){
 const { autoPrograms,commitAssessment }=await import('./assessment-store'),{ torontoDate }=await import('./v22-core');
 const fullKey='rapid:'+caseId+':'+requestKey,[prior]=await getDb().select({resultRef:durableJobs.resultRef}).from(durableJobs).where(eq(durableJobs.requestKey,fullKey)).limit(1);
 if(prior?.resultRef){const msg=await appendMessage({kind:'SYSTEM',userId:SYSTEM_USER_ID},caseId,{clientMessageId:'rapid:'+requestKey+':'+p.userId,kind:'ASSESSMENT',body:{text:null,evidenceIds:[],assessmentId:prior.resultRef,repliedToMessageId:null,sourceRefs:[]}});return {assessmentId:prior.resultRef,status:'REPLAYED' as const,purpose:'RAPID_SCREENING' as const,messageSequence:msg.message.sequence};}
 const programs=await autoPrograms();if(!programs||!programs.length)throw new ApiError(409,'RULE_UNAVAILABLE: لا توجد قواعد مختومة مفعّلة للتقييم.');
 const [c]=await getDb().select({dataRevision:candidates.dataRevision,publicationRevision:candidates.publicationRevision}).from(candidates).where(eq(candidates.id,caseId)).limit(1);
 const today=torontoDate(Date.now());
 const out=await commitAssessment(caseId,SYSTEM_USER_ID,{requestKey:fullKey,expectedDataRevision:c.dataRevision,expectedPublicationRevision:c.publicationRevision,assessmentMode:'PRODUCTION',assessmentPurpose:'RAPID_SCREENING',selectedPrograms:programs,eventContext:{profileDate:today,invitationDate:null,applicationDate:null,recommendationIssuedOn:null}});
 const msg=await appendMessage({kind:'SYSTEM',userId:SYSTEM_USER_ID},caseId,{clientMessageId:'rapid:'+requestKey+':'+p.userId,kind:'ASSESSMENT',body:{text:null,evidenceIds:[],assessmentId:out.assessmentId,repliedToMessageId:null,sourceRefs:[]}});
 return {assessmentId:out.assessmentId,status:out.status,purpose:'RAPID_SCREENING' as const,messageSequence:msg.message.sequence};
}
