// v2.2 Gate 5 — Accounting & Billing core (09 §7, contracts/v2_2.schema.json). Case-linked invoices in the office's
// explicitly configured currency; catalog, custom and free items; integer cents only; totals always computed here (and
// re-checked by the 0025 triggers). Every write is one D1 batch: an append-only financial audit row (full before/after
// snapshot, expected version, permission epoch, authorization expiry, request hash, idempotency key) followed by the
// item/payment rows and the invoice update. A stale version, expired authorization, missing permission, locked
// (PENDING_APPROVAL) invoice, overpayment or mixed case/currency aborts the whole batch. No gateway, tax or assumed
// currency. PDF and the payment notice read the same server data; the notice goes through the existing outbox.
import { env } from 'cloudflare:workers';
import { z } from 'zod';
import { getDb } from '@/db';
import { invoices,invoiceItems,paymentsLedger,financialAuditLogs,officeBillingSettings,officeServiceCatalog,candidates,deliveryOutbox,permissionRuntime } from '@/db/schema';
import { and,eq,desc,lt,or,inArray,sql } from 'drizzle-orm';
import { ApiError } from './api-error';
import { invoiceTotals,invoiceStatus,parseCents,torontoDate,jcsHash,isRealDate,PAYMENT_METHODS } from './v22-core';
import type { InvoiceStatus } from './v22-core';
import { SYSTEM_USER_ID } from './rbac';
import type { Authority } from './rbac';
import { encrypt,sha } from './security';
import { clientRecipient } from './outbox';

export const AUTHZ_WINDOW_MS=60_000;
const Cents=z.number().int().min(0).max(Number.MAX_SAFE_INTEGER);
const Key=z.string().min(8).max(200);
export const itemInputSchema=z.union([
 z.object({kind:z.literal('CATALOG'),serviceId:z.string().min(1).max(200),isFree:z.boolean()}).strict(),
 z.object({kind:z.literal('CUSTOM'),serviceName:z.string().trim().min(1).max(300),unitPriceCents:Cents,isFree:z.boolean(),referencePriceCents:Cents.nullable()}).strict(),
]);
const Deadline=z.string().refine(isRealDate,'INVALID_DATE').nullable();
export const createInvoiceSchema=z.object({currency:z.string().regex(/^[A-Z]{3}$/),items:z.array(itemInputSchema).min(1).max(100),discountCents:Cents,deadline:Deadline,note:z.string().max(4000).nullable(),requestKey:Key}).strict();
export const editInvoiceSchema=z.object({action:z.literal('edit'),expectedVersion:Cents,items:z.array(itemInputSchema).min(1).max(100),discountCents:Cents,deadline:Deadline,note:z.string().max(4000).nullable(),requestKey:Key}).strict();
export const discountSchema=z.object({action:z.literal('discount'),expectedVersion:Cents,discountCents:Cents,requestKey:Key}).strict();
export const actionSchema=z.object({expectedVersion:Cents,requestKey:Key}).strict();
// Amount: integer cents, or an exact decimal text converted on the server (never a float).
export const paymentSchema=z.object({expectedVersion:Cents,amountCents:z.number().int().min(1).max(Number.MAX_SAFE_INTEGER).optional(),amountText:z.string().max(20).optional(),method:z.enum(PAYMENT_METHODS as unknown as [string,...string[]]),paidAt:z.string().datetime(),notes:z.string().max(4000).nullable(),notify:z.boolean().optional(),idempotencyKey:Key}).strict().refine(v=>(v.amountCents===undefined)!==(v.amountText===undefined),'AMOUNT_REQUIRED');
export const noticeSchema=z.object({expectedVersion:Cents,channel:z.enum(['EMAIL','SMS']),requestKey:Key}).strict();

type Invoice=typeof invoices.$inferSelect;
type Item={serviceId:string|null;serviceName:string;isCustom:boolean;isFree:boolean;unitPriceCents:number;referencePriceCents:number|null};
const snap=(i:Pick<Invoice,'subtotalCents'|'discountCents'|'totalCents'|'paidCents'|'remainingCents'|'version'|'status'|'deadline'|'note'>,items?:readonly Item[])=>({subtotal_cents:i.subtotalCents,discount_cents:i.discountCents,total_cents:i.totalCents,paid_cents:i.paidCents,remaining_cents:i.remainingCents,version:i.version,status:i.status,deadline:i.deadline,note:i.note,...(items?{items:items.map(x=>({service_id:x.serviceId,service_name:x.serviceName,is_custom:x.isCustom,is_free:x.isFree,unit_price_cents:x.unitPriceCents,reference_price_cents:x.referencePriceCents}))}:{})});
export function summary(i:Invoice){return {invoiceId:i.invoiceId,caseId:i.caseId,currency:i.currency,status:i.status as InvoiceStatus,subtotalCents:i.subtotalCents,discountCents:i.discountCents,totalCents:i.totalCents,paidCents:i.paidCents,remainingCents:i.remainingCents,deadline:i.deadline,version:i.version,updatedAt:i.updatedAt};}
export async function officeCurrency(){const [s]=await getDb().select({currency:officeBillingSettings.currency}).from(officeBillingSettings).where(eq(officeBillingSettings.singleton,1)).limit(1);return s?.currency??null;}
async function epoch(){const [r]=await getDb().select({v:permissionRuntime.version}).from(permissionRuntime).where(eq(permissionRuntime.singleton,1)).limit(1);return r?.v??1;}
const failMap:[RegExp,number,string][]=[
 [/INVOICE_REVISION_CONFLICT|AUDIT_OLD_SNAPSHOT_MISMATCH|INVALID_INVOICE_UPDATE|PERMISSION_EPOCH_CONFLICT/,409,'تغيّرت الفاتورة أو الصلاحيات أثناء العملية؛ حدّث الصفحة.'],
 [/AUTHORIZATION_EXPIRED|AUDITED_OPERATION_REQUIRED/,409,'انتهت صلاحية التفويض أثناء العملية؛ أعد المحاولة.'],
 [/INVOICE_LOCKED|APPROVE_WITHOUT_EDITING_LOCKED_INVOICE|INVOICE_ITEM_WRITE_DENIED/,423,'الفاتورة بانتظار اعتماد المدير ولا تقبل التعديل.'],
 [/DISCOUNT_PERMISSION_REQUIRED/,403,'تعديل الخصم يتطلب صلاحية الخصم.'],
 [/FINANCIAL_PERMISSION_REQUIRED|FINANCIAL_WRITE_DENIED/,403,'لا تملك صلاحية العملية المالية.'],
 [/MANAGER_APPROVAL_REQUIRED/,403,'الاعتماد للمدير وحده.'],
 [/PAYMENT_NOT_AUTHORIZED|CHECK constraint failed: paid_cents|OVERPAYMENT/,409,'المبلغ يتجاوز المتبقي أو لا يطابق الفاتورة.'],
 [/UNIQUE constraint failed: financial_audit_logs.idempotency_key|UNIQUE constraint failed: payments_ledger.idempotency_key/,409,'مفتاح العملية مستخدم.'],
];
function mapDb(e:unknown):never{const m=e instanceof Error?e.message+' '+String((e as {cause?:unknown}).cause??''):String(e);for(const [re,status,text] of failMap)if(re.test(m))throw new ApiError(status,text);throw e;}
async function invoice(invoiceId:string){const [i]=await getDb().select().from(invoices).where(eq(invoices.invoiceId,invoiceId)).limit(1);if(!i)throw new ApiError(404,'الفاتورة غير موجودة.');return i;}
export async function invoiceItemsOf(invoiceId:string){return getDb().select().from(invoiceItems).where(eq(invoiceItems.invoiceId,invoiceId)).orderBy(invoiceItems.itemId);}
export async function paymentsOf(invoiceId:string){return getDb().select({paymentId:paymentsLedger.paymentId,amountCents:paymentsLedger.amountCents,method:paymentsLedger.method,paidAt:paymentsLedger.paidAt,hasReceipt:sql<number>`receipt_r2_key IS NOT NULL`.as('has_receipt'),notes:paymentsLedger.notes,createdAt:paymentsLedger.createdAt}).from(paymentsLedger).where(eq(paymentsLedger.invoiceId,invoiceId)).orderBy(paymentsLedger.paidAt,paymentsLedger.paymentId);}
// Replay: the same idempotency key with the same request hash returns the committed result; another payload is 409.
async function replay(idempotencyKey:string,requestHash:string){const [a]=await getDb().select({hash:financialAuditLogs.requestHash,invoiceId:financialAuditLogs.invoiceId}).from(financialAuditLogs).where(eq(financialAuditLogs.idempotencyKey,idempotencyKey)).limit(1);if(!a)return null;if(a.hash!==requestHash)throw new ApiError(409,'مفتاح العملية مستخدم لطلب مختلف.');return a.invoiceId;}
async function resolveItems(inputs:z.infer<typeof itemInputSchema>[],currency:string):Promise<Item[]>{
 const ids=inputs.filter(i=>i.kind==='CATALOG').map(i=>(i as {serviceId:string}).serviceId),db=getDb();
 const catalog=ids.length?await db.select().from(officeServiceCatalog).where(inArray(officeServiceCatalog.serviceId,ids)):[];
 return inputs.map(i=>{
  if(i.kind==='CATALOG'){const c=catalog.find(x=>x.serviceId===i.serviceId);if(!c||!c.active)throw new ApiError(422,'خدمة غير موجودة في الكتالوج أو غير مفعّلة.');if(c.currency!==currency)throw new ApiError(422,'عملة الخدمة لا تطابق عملة الفاتورة.');return {serviceId:c.serviceId,serviceName:c.nameAr+' / '+c.nameEn,isCustom:false,isFree:i.isFree,unitPriceCents:i.isFree?0:c.priceCents,referencePriceCents:i.isFree?c.priceCents:null};}
  if(i.isFree&&i.unitPriceCents!==0)throw new ApiError(422,'البند المجاني سعره صفر؛ ضع السعر المرجعي في الحقل المخصص.');
  return {serviceId:null,serviceName:i.serviceName,isCustom:true,isFree:i.isFree,unitPriceCents:i.unitPriceCents,referencePriceCents:i.referencePriceCents};
 });
}
function totalsOf(items:readonly Item[],discount:number,payments:readonly number[]){try{return invoiceTotals(items.map(i=>({unitPriceCents:i.unitPriceCents,isFree:i.isFree})),discount,payments);}catch(e){const m=(e as Error).message;throw new ApiError(m==='OVERPAYMENT_NOT_SUPPORTED'?409:422,m==='INVALID_DISCOUNT_OR_TOTAL'?'الخصم أكبر من المجموع.':m==='OVERPAYMENT_NOT_SUPPORTED'?'المجموع الجديد أقل من المدفوع.':'مبالغ غير صالحة.');}}
const audit=(logId:string,invoiceId:string,actor:string,action:string,oldV:object,newV:object,expected:number,ep:number,requestHash:string,key:string,now:string)=>getDb().insert(financialAuditLogs).values({logId,invoiceId,modifiedBy:actor,actionType:action,oldValue:JSON.stringify(oldV),newValue:JSON.stringify(newV),expectedVersion:expected,permissionsEpoch:ep,authzExpiresAtMs:Date.now()+AUTHZ_WINDOW_MS,requestHash,idempotencyKey:key,timestamp:now});
const actorOf=(a:Authority)=>a.actor.userId;

export async function createInvoice(a:Authority,caseId:string,input:z.infer<typeof createInvoiceSchema>){
 const key='create:'+input.requestKey,requestHash=await jcsHash({caseId,...input});
 const prior=await replay(key,requestHash);if(prior)return summary(await invoice(prior));
 const currency=await officeCurrency();if(!currency)throw new ApiError(409,'لم يحدد المدير عملة الفوترة للمكتب بعد.');
 if(input.currency!==currency)throw new ApiError(422,'عملة الفاتورة يجب أن تطابق عملة المكتب المعتمدة ('+currency+').');
 const items=await resolveItems(input.items,currency),t=totalsOf(items,input.discountCents,[]),now=new Date().toISOString(),nowMs=Date.now();
 const status=invoiceStatus(t,input.deadline,false,nowMs),invoiceId=crypto.randomUUID(),logId=crypto.randomUUID(),ep=await epoch(),db=getDb();
 const zero={subtotalCents:0,discountCents:0,totalCents:0,paidCents:0,remainingCents:0,version:0,status:'DRAFT',deadline:input.deadline,note:input.note};
 const next={subtotalCents:t.subtotal_cents,discountCents:t.discount_cents,totalCents:t.total_cents,paidCents:0,remainingCents:t.remaining_cents,version:1,status,deadline:input.deadline,note:input.note};
 try{await db.batch([
  db.insert(invoices).values({invoiceId,caseId,currency,deadline:input.deadline,note:input.note,createdBy:actorOf(a),createdAt:now,updatedAt:now}),
  audit(logId,invoiceId,actorOf(a),'CREATE',snap(zero),snap(next,items),0,ep,requestHash,key,now),
  ...items.map(i=>db.insert(invoiceItems).values({itemId:crypto.randomUUID(),invoiceId,serviceId:i.serviceId,serviceName:i.serviceName,isCustom:i.isCustom?1:0,isFree:i.isFree?1:0,unitPriceCents:i.unitPriceCents,referencePriceCents:i.referencePriceCents,lastOperationId:logId})),
  db.update(invoices).set({...next,lastOperationId:logId,updatedAt:now}).where(eq(invoices.invoiceId,invoiceId)),
 ] as unknown as Parameters<typeof db.batch>[0]);}catch(e){const again=await replay(key,requestHash);if(again)return summary(await invoice(again));mapDb(e);}
 return summary(await invoice(invoiceId));
}
// EDIT replaces the items and terms; a changed discount needs edit_discount (enforced again by the audit trigger, so EDIT
// cannot be used to bypass the discount permission). Payments are kept; the new total may not fall below them.
export async function editInvoice(a:Authority,invoiceId:string,input:z.infer<typeof editInvoiceSchema>|z.infer<typeof discountSchema>){
 const key=input.action+':'+input.requestKey,requestHash=await jcsHash({invoiceId,...input});
 if(await replay(key,requestHash))return summary(await invoice(invoiceId));
 const cur=await invoice(invoiceId),db=getDb(),now=new Date().toISOString(),nowMs=Date.now(),logId=crypto.randomUUID();
 if(cur.version!==input.expectedVersion)throw new ApiError(409,'تغيّرت الفاتورة؛ حدّث الصفحة.');
 if(cur.status==='PENDING_APPROVAL')throw new ApiError(423,'الفاتورة بانتظار اعتماد المدير ولا تقبل التعديل.');
 const oldItems=(await invoiceItemsOf(invoiceId)).map(i=>({serviceId:i.serviceId,serviceName:i.serviceName,isCustom:!!i.isCustom,isFree:!!i.isFree,unitPriceCents:i.unitPriceCents,referencePriceCents:i.referencePriceCents}));
 const payments=(await paymentsOf(invoiceId)).map(p=>p.amountCents);
 const items=input.action==='edit'?await resolveItems(input.items,cur.currency):oldItems;
 const deadline=input.action==='edit'?input.deadline:cur.deadline,note=input.action==='edit'?input.note:cur.note;
 const t=totalsOf(items,input.discountCents,payments),status=invoiceStatus(t,deadline,false,nowMs);
 const next={subtotalCents:t.subtotal_cents,discountCents:t.discount_cents,totalCents:t.total_cents,paidCents:t.paid_cents,remainingCents:t.remaining_cents,version:cur.version+1,status,deadline,note};
 const stmts:unknown[]=[audit(logId,invoiceId,actorOf(a),input.action==='edit'?'EDIT':'DISCOUNT',snap(cur,oldItems),snap(next,items),cur.version,await epoch(),requestHash,key,now)];
 if(input.action==='edit'){stmts.push(db.delete(invoiceItems).where(eq(invoiceItems.invoiceId,invoiceId)));for(const i of items)stmts.push(db.insert(invoiceItems).values({itemId:crypto.randomUUID(),invoiceId,serviceId:i.serviceId,serviceName:i.serviceName,isCustom:i.isCustom?1:0,isFree:i.isFree?1:0,unitPriceCents:i.unitPriceCents,referencePriceCents:i.referencePriceCents,lastOperationId:logId}));}
 stmts.push(db.update(invoices).set({...next,lastOperationId:logId,updatedAt:now}).where(and(eq(invoices.invoiceId,invoiceId),eq(invoices.version,cur.version))));
 try{await db.batch(stmts as unknown as Parameters<typeof db.batch>[0]);}catch(e){if(await replay(key,requestHash).catch(()=>null))return summary(await invoice(invoiceId));mapDb(e);}
 return summary(await invoice(invoiceId));
}
const bucket=()=>{const b=(env as unknown as {BUCKET?:R2Bucket}).BUCKET;if(!b)throw new ApiError(503,'تخزين السندات غير متاح.');return b;};
const RECEIPT_MAX=10*1024*1024;
function receiptMime(b:Uint8Array){const h=new TextDecoder().decode(b.slice(0,5));if(h.startsWith('%PDF-'))return 'application/pdf';if(b[0]===0xff&&b[1]===0xd8&&b[2]===0xff)return 'image/jpeg';if(b[0]===0x89&&b[1]===0x50&&b[2]===0x4e&&b[3]===0x47)return 'image/png';return null;}
// Payment: the case and currency come from the invoice (never from the browser). Optional private receipt in R2 is
// stored before the batch and removed if the batch fails, so no committed payment points to a missing object.
export async function recordPayment(a:Authority,invoiceId:string,input:z.infer<typeof paymentSchema>,receipt:File|null,emailConfigured=false){
 let amount:number;if(input.amountCents!==undefined)amount=input.amountCents;else{try{amount=parseCents(input.amountText!);}catch{throw new ApiError(422,'المبلغ يجب أن يكون رقمًا موجبًا بخانتين عشريتين على الأكثر.');}if(amount<1)throw new ApiError(422,'المبلغ يجب أن يكون أكبر من صفر.');}
 const requestHash=await jcsHash({invoiceId,expectedVersion:input.expectedVersion,amount,method:input.method,paidAt:input.paidAt,notes:input.notes,receipt:receipt?{size:receipt.size,type:receipt.type}:null});
 const prior=await replay(input.idempotencyKey,requestHash);if(prior)return summary(await invoice(invoiceId));
 const cur=await invoice(invoiceId),db=getDb(),now=new Date().toISOString(),nowMs=Date.now(),logId=crypto.randomUUID(),paymentId=crypto.randomUUID();
 if(cur.version!==input.expectedVersion)throw new ApiError(409,'تغيّرت الفاتورة؛ حدّث الصفحة.');
 if(cur.status==='PENDING_APPROVAL')throw new ApiError(423,'الفاتورة بانتظار اعتماد المدير ولا تقبل دفعات.');
 if(amount>cur.remainingCents)throw new ApiError(409,'المبلغ يتجاوز المتبقي ('+cur.remainingCents+').');
 const paidAt=new Date(input.paidAt);if(paidAt.getTime()>nowMs+5*60_000)throw new ApiError(422,'تاريخ الدفع في المستقبل.');
 let receiptKey:string|null=null,receiptSha:string|null=null;
 if(receipt){if(receipt.size<1||receipt.size>RECEIPT_MAX)throw new ApiError(413,'السند حتى 10MB.');const bytes=new Uint8Array(await receipt.arrayBuffer()),mime=receiptMime(bytes);if(!mime)throw new ApiError(415,'السند يجب أن يكون PDF أو JPEG أو PNG.');receiptSha=await sha(bytes.buffer);receiptKey='finance/receipts/'+invoiceId+'/'+paymentId;await bucket().put(receiptKey,bytes,{httpMetadata:{contentType:mime},customMetadata:{sha256:receiptSha,invoiceId}});}
 const paid=cur.paidCents+amount,remaining=cur.totalCents-paid,t={subtotal_cents:cur.subtotalCents,discount_cents:cur.discountCents,total_cents:cur.totalCents,paid_cents:paid,remaining_cents:remaining};
 const next={...cur,paidCents:paid,remainingCents:remaining,version:cur.version+1,status:invoiceStatus(t,cur.deadline,false,nowMs)};
 if(input.notify&&!emailConfigured)throw new ApiError(409,'البريد الصادر غير مهيأ؛ سجّل الدفعة دون إخطار.');
 const notice=input.notify?await noticeRow(next,actorOf(a)):null;
 try{await db.batch([
  audit(logId,invoiceId,actorOf(a),'PAYMENT',snap(cur),{...snap(next),payment:{payment_id:paymentId,amount_cents:amount,method:input.method,paid_at:paidAt.toISOString(),receipt_sha256:receiptSha}},cur.version,await epoch(),requestHash,input.idempotencyKey,now),
  db.insert(paymentsLedger).values({paymentId,invoiceId,caseId:cur.caseId,currency:cur.currency,amountCents:amount,method:input.method,paidAt:paidAt.toISOString(),receiptR2Key:receiptKey,receiptSha256:receiptSha,notes:input.notes,idempotencyKey:input.idempotencyKey,operationId:logId,createdBy:actorOf(a),createdAt:now}),
  db.update(invoices).set({paidCents:paid,remainingCents:remaining,version:next.version,status:next.status,lastOperationId:logId,updatedAt:now}).where(and(eq(invoices.invoiceId,invoiceId),eq(invoices.version,cur.version))),
  ...(notice?[db.insert(deliveryOutbox).values(notice)]:[]),
 ] as unknown as Parameters<typeof db.batch>[0]);}catch(e){if(receiptKey)await bucket().delete(receiptKey).catch(()=>undefined);if(await replay(input.idempotencyKey,requestHash).catch(()=>null))return summary(await invoice(invoiceId));mapDb(e);}
 return summary(await invoice(invoiceId));
}
export async function receiptObject(invoiceId:string,paymentId:string){const [p]=await getDb().select({key:paymentsLedger.receiptR2Key}).from(paymentsLedger).where(and(eq(paymentsLedger.invoiceId,invoiceId),eq(paymentsLedger.paymentId,paymentId))).limit(1);if(!p?.key)throw new ApiError(404,'لا يوجد سند.');const o=await bucket().get(p.key);if(!o)throw new ApiError(404,'لا يوجد سند.');return new Response(o.body,{headers:{'Content-Type':o.httpMetadata?.contentType||'application/octet-stream','Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'"}});}
// Referral locks the invoice (PENDING_APPROVAL) until one MANAGER approves; approval restores the computed status.
export async function referInvoice(a:Authority,invoiceId:string,input:z.infer<typeof actionSchema>){return transition(a,invoiceId,input,'REFER');}
export async function approveInvoice(a:Authority,invoiceId:string,input:z.infer<typeof actionSchema>){return transition(a,invoiceId,input,'APPROVE');}
async function transition(a:Authority,invoiceId:string,input:z.infer<typeof actionSchema>,action:'REFER'|'APPROVE'){
 const key=action.toLowerCase()+':'+input.requestKey,requestHash=await jcsHash({invoiceId,action,...input});
 if(await replay(key,requestHash))return summary(await invoice(invoiceId));
 const cur=await invoice(invoiceId),db=getDb(),now=new Date().toISOString(),logId=crypto.randomUUID();
 if(cur.version!==input.expectedVersion)throw new ApiError(409,'تغيّرت الفاتورة؛ حدّث الصفحة.');
 if(action==='REFER'&&cur.status==='PENDING_APPROVAL')throw new ApiError(409,'الفاتورة محالة مسبقًا.');
 if(action==='APPROVE'&&cur.status!=='PENDING_APPROVAL')throw new ApiError(409,'لا توجد إحالة بانتظار الاعتماد.');
 const status=action==='REFER'?'PENDING_APPROVAL':invoiceStatus({subtotal_cents:cur.subtotalCents,discount_cents:cur.discountCents,total_cents:cur.totalCents,paid_cents:cur.paidCents,remaining_cents:cur.remainingCents},cur.deadline,false,Date.now());
 const next={...cur,version:cur.version+1,status};
 try{await db.batch([
  audit(logId,invoiceId,actorOf(a),action,snap(cur),snap(next),cur.version,await epoch(),requestHash,key,now),
  db.update(invoices).set({version:next.version,status,lastOperationId:logId,updatedAt:now,...(action==='REFER'?{approvalRequestedAt:now}:{approvedBy:actorOf(a),approvedAt:now})}).where(and(eq(invoices.invoiceId,invoiceId),eq(invoices.version,cur.version))),
 ]);}catch(e){if(await replay(key,requestHash).catch(()=>null))return summary(await invoice(invoiceId));mapDb(e);}
 return summary(await invoice(invoiceId));
}
// Daily SYSTEM refresh: unpaid invoices past their deadline (Toronto date) become OVERDUE through an audited operation.
export async function refreshOverdue(limit=100){
 const today=torontoDate(Date.now()),db=getDb(),due=await db.select().from(invoices).where(and(inArray(invoices.status,['DRAFT','PARTIAL']),lt(invoices.deadline,today),sql`remaining_cents>0`)).limit(limit);
 let changed=0;
 for(const cur of due){const now=new Date().toISOString(),logId=crypto.randomUUID(),next={...cur,version:cur.version+1,status:'OVERDUE'},key='overdue:'+cur.invoiceId+':'+cur.version;
  try{await db.batch([audit(logId,cur.invoiceId,SYSTEM_USER_ID,'OVERDUE_REFRESH',snap(cur),snap(next),cur.version,await epoch(),await jcsHash({key}),key,now),db.update(invoices).set({version:next.version,status:'OVERDUE',lastOperationId:logId,updatedAt:now}).where(and(eq(invoices.invoiceId,cur.invoiceId),eq(invoices.version,cur.version)))]);changed++;}catch{/* a concurrent change wins; the next run re-evaluates */}}
 return changed;
}
// Payment notice: server-composed limited text to the client's registered email through the outbox (no amount typed by
// staff, no other case data). SMS is not configured in this application, so it is refused instead of faked.
// The notice payload is composed on the server from the committed invoice row only: case number, remaining balance,
// currency and due date (AC-56). No items, notes, payments or other case data travel by email.
async function noticeRow(i:Pick<Invoice,'invoiceId'|'caseId'|'deadline'|'status'|'version'|'remainingCents'|'currency'>,actor:string){
 const recipient=await clientRecipient(i.caseId);if(!recipient)throw new ApiError(409,'لا يوجد بريد مسجّل للعميل.');
 // AC-56: limited content = remaining balance, currency and due date only (no items, notes, payments or identities).
 const payload={...recipient,status:i.status,deadline:i.deadline,remainingCents:i.remainingCents,currency:i.currency,requestedBy:actor};
 return {eventId:crypto.randomUUID(),caseId:i.caseId,kind:'PAYMENT_NOTICE',businessKey:'payment-notice:'+i.invoiceId+':'+i.version+':EMAIL',payloadEncrypted:await encrypt(JSON.stringify(payload)),nextAtMs:Date.now(),createdAt:new Date().toISOString()};
}
export async function queuePaymentNotice(a:Authority,invoiceId:string,input:z.infer<typeof noticeSchema>,emailConfigured:boolean){
 const cur=await invoice(invoiceId);if(cur.version!==input.expectedVersion)throw new ApiError(409,'تغيّرت الفاتورة؛ حدّث الصفحة.');
 if(input.channel==='SMS')throw new ApiError(409,'قناة SMS غير مهيأة في هذا النظام.');
 if(!emailConfigured)throw new ApiError(409,'البريد الصادر غير مهيأ.');
 const db=getDb(),row=await noticeRow(cur,actorOf(a));
 const [existing]=await db.select({eventId:deliveryOutbox.eventId,state:deliveryOutbox.state}).from(deliveryOutbox).where(eq(deliveryOutbox.businessKey,row.businessKey)).limit(1);
 if(existing)return {eventId:existing.eventId,state:existing.state,replayed:true};
 await db.insert(deliveryOutbox).values(row).onConflictDoNothing();
 const [stored]=await db.select({eventId:deliveryOutbox.eventId,state:deliveryOutbox.state}).from(deliveryOutbox).where(eq(deliveryOutbox.businessKey,row.businessKey)).limit(1);
 return {eventId:stored.eventId,state:stored.state,replayed:stored.eventId!==row.eventId};
}
export async function caseInvoices(caseId:string){return (await getDb().select().from(invoices).where(eq(invoices.caseId,caseId)).orderBy(desc(invoices.createdAt),invoices.invoiceId).limit(100)).map(summary);}
export async function invoiceDetail(invoiceId:string){const i=await invoice(invoiceId);return {...summary(i),note:i.note,approvalRequestedAt:i.approvalRequestedAt,approvedAt:i.approvedAt,items:(await invoiceItemsOf(invoiceId)).map(x=>({itemId:x.itemId,serviceId:x.serviceId,serviceName:x.serviceName,isCustom:!!x.isCustom,isFree:!!x.isFree,unitPriceCents:x.unitPriceCents,referencePriceCents:x.referencePriceCents})),payments:(await paymentsOf(invoiceId)).map(p=>({...p,hasReceipt:!!p.hasReceipt}))};}
// Office dashboard: per-currency aggregates from D1 (never summed across currencies) and a keyset-paged list.
export async function officeBilling(cursor:string|null,limit=25){
 const db=getDb(),today=torontoDate(Date.now());
 const collected=await db.select({currency:paymentsLedger.currency,cents:sql<number>`COALESCE(SUM(amount_cents),0)`.as('cents')}).from(paymentsLedger).groupBy(paymentsLedger.currency);
 const outstanding=await db.select({currency:invoices.currency,status:invoices.status,count:sql<number>`count(*)`.as('n'),remaining:sql<number>`COALESCE(SUM(remaining_cents),0)`.as('r')}).from(invoices).where(sql`status IN ('OVERDUE','PENDING_APPROVAL','PARTIAL','DRAFT') AND remaining_cents>0`).groupBy(invoices.currency,invoices.status);
 const [ca,id]=cursor?cursor.split('|'):[null,null];
 const rows=await db.select({i:invoices,reference:candidates.reference}).from(invoices).innerJoin(candidates,eq(candidates.id,invoices.caseId)).where(ca&&id?or(lt(invoices.createdAt,ca),and(eq(invoices.createdAt,ca),lt(invoices.invoiceId,id))):undefined).orderBy(desc(invoices.createdAt),desc(invoices.invoiceId)).limit(Math.min(100,Math.max(1,limit))+1);
 const page=rows.slice(0,limit);
 return {asOf:today,collected,outstanding,items:page.map(r=>({...summary(r.i),reference:r.reference})),nextCursor:rows.length>limit?page[page.length-1].i.createdAt+'|'+page[page.length-1].i.invoiceId:null};
}
export async function setOfficeCurrency(a:Authority,currency:string){await getDb().update(officeBillingSettings).set({currency,updatedBy:actorOf(a),updatedAt:new Date().toISOString()}).where(eq(officeBillingSettings.singleton,1));return currency;}
export async function upsertService(a:Authority,input:{serviceId:string;nameAr:string;nameEn:string;priceCents:number;currency:string;active:boolean;expectedVersion:number|null}){
 const db=getDb(),now=new Date().toISOString(),[cur]=await db.select().from(officeServiceCatalog).where(eq(officeServiceCatalog.serviceId,input.serviceId)).limit(1);
 if(!cur){if(input.expectedVersion!==null)throw new ApiError(409,'الخدمة غير موجودة.');await db.insert(officeServiceCatalog).values({serviceId:input.serviceId,nameAr:input.nameAr,nameEn:input.nameEn,priceCents:input.priceCents,currency:input.currency,active:input.active?1:0,version:1,updatedBy:actorOf(a),updatedAt:now});return;}
 const r=await db.update(officeServiceCatalog).set({nameAr:input.nameAr,nameEn:input.nameEn,priceCents:input.priceCents,currency:input.currency,active:input.active?1:0,version:cur.version+1,updatedBy:actorOf(a),updatedAt:now}).where(and(eq(officeServiceCatalog.serviceId,input.serviceId),eq(officeServiceCatalog.version,input.expectedVersion??-1))).returning({v:officeServiceCatalog.version});
 if(!r.length)throw new ApiError(409,'تغيّرت الخدمة؛ حدّث الصفحة.');
}
export async function catalog(activeOnly=false){const rows=await getDb().select().from(officeServiceCatalog).orderBy(officeServiceCatalog.serviceId);return rows.filter(r=>!activeOnly||r.active).map(r=>({serviceId:r.serviceId,nameAr:r.nameAr,nameEn:r.nameEn,priceCents:r.priceCents,currency:r.currency,active:!!r.active,version:r.version}));}
// PDF data: the committed invoice, its items and payments; the hash binds the rendered figures to this version.
export async function invoicePdfData(invoiceId:string){
 const d=await invoiceDetail(invoiceId),[c]=await getDb().select({reference:candidates.reference,profile:candidates.profile}).from(candidates).where(eq(candidates.id,d.caseId)).limit(1);
 const [created]=await getDb().select({createdAt:invoices.createdAt}).from(invoices).where(eq(invoices.invoiceId,invoiceId)).limit(1);
 const core={reference:c.reference,clientName:String((JSON.parse(c.profile) as {fullName?:string}).fullName||''),invoiceId,currency:d.currency,status:d.status,version:d.version,createdAt:created.createdAt,deadline:d.deadline,note:d.note,
  items:d.items.map(i=>({serviceName:i.serviceName,isFree:i.isFree,unitPriceCents:i.unitPriceCents,referencePriceCents:i.referencePriceCents})),subtotalCents:d.subtotalCents,discountCents:d.discountCents,totalCents:d.totalCents,paidCents:d.paidCents,remainingCents:d.remainingCents,
  payments:d.payments.map(p=>({amountCents:p.amountCents,method:p.method,paidAt:p.paidAt}))};
 return {...core,dataHash:await jcsHash(core)};
}
// Route guard: the actor's capability (view_financials plus the operation capability) and the invoice's case scope.
export async function invoiceCase(invoiceId:string){const [i]=await getDb().select({caseId:invoices.caseId}).from(invoices).where(eq(invoices.invoiceId,invoiceId)).limit(1);if(!i)throw new ApiError(404,'الفاتورة غير موجودة.');return i.caseId;}
