// v2.2 deterministic controls — section 10 of 09_CLAUDE_CODE_EXECUTION.md (V2_2_CONTROLS block), typed.
// Server/test layer only: invoice pricing never moves to the browser. The permission catalog is a trusted server
// parameter and is never built from a request body. Toronto day boundaries are computed without a fixed offset.

export type Role = 'CLIENT' | 'STAFF' | 'MANAGER' | 'SYSTEM';
export const ROLES: readonly Role[] = ['CLIENT', 'STAFF', 'MANAGER', 'SYSTEM'];
export type InvoiceStatus = 'DRAFT' | 'PENDING_APPROVAL' | 'PARTIAL' | 'PAID' | 'OVERDUE';
export type PaymentMethod = 'CASH' | 'CHEQUE' | 'ZELLE' | 'CASH_APP';
export const PAYMENT_METHODS: readonly PaymentMethod[] = ['CASH', 'CHEQUE', 'ZELLE', 'CASH_APP'];

const zone = 'America/Toronto';
const dayFormat = new Intl.DateTimeFormat('en-CA', { timeZone: zone, year: 'numeric', month: '2-digit', day: '2-digit' });

export function torontoDate(epochMs: number): string {
  if (!Number.isSafeInteger(epochMs)) throw new Error('INVALID_TIMESTAMP');
  const p = Object.fromEntries(dayFormat.formatToParts(new Date(epochMs)).map(x => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}`;
}

export function nextTorontoMidnightMs(epochMs: number): number {
  const day = torontoDate(epochMs);
  let lo = epochMs, hi = epochMs + 36 * 60 * 60 * 1000;
  while (hi - lo > 1) { const mid = lo + Math.floor((hi - lo) / 2); if (torontoDate(mid) === day) lo = mid; else hi = mid; }
  return hi;
}

export type OpenState = { enabled: boolean; localDate: string | null; untilMs: number };
export function openAllActive(state: OpenState, now: number): boolean {
  return state.enabled === true && torontoDate(now) === state.localDate && now < state.untilMs;
}

// Existing product capabilities (legacy STAFF policy recorded by migration 0026) stay in the server catalog next to the
// v2.2 financial minimum; they are Toggles too, never extra roles.
export const PRODUCT_CAPABILITIES = ['view_crm', 'edit_case', 'review_case', 'view_documents', 'upload_documents', 'chat', 'request_assessment'] as const;
export const FINANCIAL_CAPABILITIES = ['view_financials', 'create_invoice', 'edit_invoice', 'edit_discount', 'record_payment', 'send_payment_notice', 'export_invoice_pdf'] as const;
export const STAFF_CAPABILITIES = [...PRODUCT_CAPABILITIES, ...FINANCIAL_CAPABILITIES] as const;
export type Capability = typeof STAFF_CAPABILITIES[number] | typeof MANAGER_RESERVED_CAPABILITIES[number] | typeof SYSTEM_CAPABILITIES[number];
export const MANAGER_RESERVED_CAPABILITIES = ['manage_permissions', 'open_staff_access', 'seal_rules', 'approve_invoice'] as const;
export const SYSTEM_CAPABILITIES = ['process_ingestion', 'recompute_assessment', 'dispatch_outbox', 'refresh_overdue', 'expire_staff_access'] as const;
const staffCaps = new Set<string>(STAFF_CAPABILITIES);
const managerCaps = new Set<string>([...staffCaps, ...MANAGER_RESERVED_CAPABILITIES]);
const systemCaps = new Set<string>(SYSTEM_CAPABILITIES);
export type CatalogEntry = { staffAssignable: boolean; systemAssignable: boolean };
export type Catalog = Readonly<Record<string, CatalogEntry>>;
export const BASE_CATALOG: Catalog = Object.freeze(Object.fromEntries([...new Set([...managerCaps, ...systemCaps])]
  .map(k => [k, Object.freeze({ staffAssignable: staffCaps.has(k), systemAssignable: systemCaps.has(k) })])));

export type Actor = { role: Role; active: boolean };
export function effectivePermission(actor: Actor, cap: string, rolePermissions: Record<string, unknown>,
  customPermissions: Record<string, unknown>, openState: OpenState, now: number, catalog: Catalog = BASE_CATALOG): boolean {
  if (actor.active !== true || !Object.hasOwn(catalog, cap)) return false;
  if (actor.role === 'MANAGER') return true;
  if (actor.role === 'SYSTEM') return catalog[cap].systemAssignable === true;
  if (actor.role !== 'STAFF' || catalog[cap].staffAssignable !== true) return false;
  if (openAllActive(openState, now)) return true;
  if (Object.hasOwn(customPermissions, cap)) return customPermissions[cap] === true;
  return rolePermissions[cap] === true;
}

// BigInt() constructor instead of literals: the project targets below ES2020.
const MAX = BigInt('9007199254740991'), ZERO = BigInt(0), HUNDRED = BigInt(100);
function cents(value: number): bigint {
  if (!Number.isSafeInteger(value) || value < 0) throw new Error('INTEGER_CENTS_REQUIRED');
  return BigInt(value);
}

/** Exact decimal string (at most two fraction digits) to integer cents, without floating arithmetic. */
export function parseCents(value: string): number {
  if (typeof value !== 'string' || !/^\d+(\.\d{1,2})?$/.test(value)) throw new Error('INVALID_MONEY_INPUT');
  const [whole, fraction = ''] = value.split('.');
  const result = BigInt(whole) * HUNDRED + BigInt(fraction.padEnd(2, '0'));
  if (result > MAX) throw new Error('MONEY_LIMIT_EXCEEDED');
  return Number(result);
}

export type InvoiceItemInput = { unitPriceCents: number; isFree: boolean };
export type InvoiceTotals = { subtotal_cents: number; discount_cents: number; total_cents: number; paid_cents: number; remaining_cents: number };
export function invoiceTotals(items: readonly InvoiceItemInput[], discountCents: number, payments: readonly number[]): InvoiceTotals {
  const subtotal = items.reduce((n, item) => {
    const value = cents(item.unitPriceCents);
    if (item.isFree && value !== ZERO) throw new Error('FREE_ITEM_MUST_BE_ZERO');
    return n + value;
  }, ZERO);
  const discount = cents(discountCents), paid = payments.reduce((n, v) => n + cents(v), ZERO);
  if (subtotal > MAX || discount > subtotal) throw new Error('INVALID_DISCOUNT_OR_TOTAL');
  const total = subtotal - discount;
  if (paid > total) throw new Error('OVERPAYMENT_NOT_SUPPORTED');
  return { subtotal_cents: Number(subtotal), discount_cents: Number(discount), total_cents: Number(total), paid_cents: Number(paid), remaining_cents: Number(total - paid) };
}

export function invoiceStatus(totals: InvoiceTotals, deadline: string | null, pending: boolean, now: number): InvoiceStatus {
  if (pending) return 'PENDING_APPROVAL';
  if (totals.remaining_cents === 0) return 'PAID';
  if (deadline && deadline < torontoDate(now)) return 'OVERDUE';
  return totals.paid_cents > 0 ? 'PARTIAL' : 'DRAFT';
}

/** Signatures are fixed: there is no STALE state and no automatic invalidation when case data changes. */
export function signatureStatus(signature: unknown): 'SIGNED' | 'EMPTY' { return signature ? 'SIGNED' : 'EMPTY'; }

export type RcipRange = { from: string; to: string | null; program: 'RCIP_PILOT' | 'RCIP_PERMANENT'; ruleId: string };
export type RcipResult =
  | { status: 'RULE_UNAVAILABLE'; date: string }
  | { status: 'FAIL'; code: 'RECOMMENDATION_OUTSIDE_APPROVED_POLICY'; date: string; program: 'RCIP_PERMANENT' }
  | { status: 'RESOLVED'; date: string; program: 'RCIP_PILOT' | 'RCIP_PERMANENT'; ruleId: string };
export function rcipPolicy({ approvedAtMs, recommendationIssuedOn, ranges }: { approvedAtMs: number; recommendationIssuedOn?: string | null; ranges: readonly RcipRange[] }): RcipResult {
  const date = torontoDate(approvedAtMs), matches = ranges.filter(r => r.from <= date && (r.to === null || date < r.to));
  if (matches.length !== 1) return { status: 'RULE_UNAVAILABLE', date };
  const year = Number(date.slice(0, 4)), program = year === 2026 ? 'RCIP_PILOT' : year >= 2027 ? 'RCIP_PERMANENT' : null;
  if (!program || matches[0].program !== program) return { status: 'RULE_UNAVAILABLE', date };
  if (program === 'RCIP_PERMANENT' && recommendationIssuedOn?.startsWith('2026-')) return { status: 'FAIL', code: 'RECOMMENDATION_OUTSIDE_APPROVED_POLICY', date, program };
  return { status: 'RESOLVED', date, program, ruleId: matches[0].ruleId };
}

// v2.2 Gate 3 — canonical JSON (RFC 8785 JCS subset used by the engine: no non-finite numbers, no undefined members
// inside arrays) and SHA-256 over its UTF-8 bytes. Object members are ordered by UTF-16 code units, which is the
// default Array.prototype.sort order for strings. Used for payload, manifest, canonical_input_hash and request hashes.
export function jcs(value: unknown): string {
  if (value === null || typeof value === 'boolean' || typeof value === 'string') return JSON.stringify(value);
  if (typeof value === 'number') { if (!Number.isFinite(value)) throw new Error('JCS_NON_FINITE_NUMBER'); return JSON.stringify(value); }
  if (Array.isArray(value)) return '[' + value.map(v => { if (v === undefined) throw new Error('JCS_UNDEFINED_IN_ARRAY'); return jcs(v); }).join(',') + ']';
  if (typeof value === 'object') {
    const o = value as Record<string, unknown>;
    return '{' + Object.keys(o).filter(k => o[k] !== undefined).sort().map(k => JSON.stringify(k) + ':' + jcs(o[k])).join(',') + '}';
  }
  throw new Error('JCS_UNSUPPORTED_TYPE');
}
export async function sha256Hex(text: string | Uint8Array): Promise<string> {
  const bytes = typeof text === 'string' ? new TextEncoder().encode(text) : new Uint8Array(text);
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('');
}
export const jcsHash = (value: unknown): Promise<string> => sha256Hex(jcs(value));
// Real calendar date (YYYY-MM-DD that round-trips through UTC), not a regex alone.
export function isRealDate(value: unknown): value is string {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const t = Date.parse(value + 'T00:00:00Z');
  return Number.isFinite(t) && new Date(t).toISOString().slice(0, 10) === value;
}
