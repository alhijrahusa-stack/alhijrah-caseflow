// v2.2 Gate 5 — document validity milestones (90 / 30 / 0 days, America/Toronto dates). Sources are dates already on
// the case: the passport expiry entered/extracted for the client, and language-test dates with the two-year validity the
// existing assessment already applies (lib/assessment.ts validTest). Catch-up: when the scan runs late, only the most
// urgent milestone reached is queued (earlier, now-stale milestones are not sent). Dedup: business key per case, item,
// expiry date and milestone. Client notice requires EXPIRY_NOTIFICATIONS consent (re-checked at dispatch); a staff task
// is created idempotently either way so the office sees it.
import { getDb } from '@/db';
import { candidates,clientCases,tasks,deliveryOutbox } from '@/db/schema';
import { and,eq,ne } from 'drizzle-orm';
import { torontoDate,isRealDate } from './v22-core';
import { outboxRow,hasConsent } from './outbox';

export const MILESTONES=[90,30,0] as const;
export type ExpiryItem={key:'passport'|'english_test'|'french_test';expiresOn:string};
const plusYears=(d:string,n:number)=>{const [y,m,day]=d.split('-').map(Number),t=new Date(Date.UTC(y+n,m-1,day));if(t.getUTCMonth()!==m-1)t.setUTCDate(0);return t.toISOString().slice(0,10);};
export const daysBetween=(from:string,to:string)=>Math.round((Date.parse(to+'T00:00:00Z')-Date.parse(from+'T00:00:00Z'))/86400000);
/** The single most urgent milestone reached today (null if none yet). */
export function dueMilestone(expiresOn:string,today:string):number|null{const left=daysBetween(today,expiresOn);for(const m of [0,30,90])if(left<=m)return m;return null;}
export function expiryItems(profile:Record<string,unknown>,details:Record<string,unknown>):ExpiryItem[]{
 const out:ExpiryItem[]=[];
 if(isRealDate(details.passportExpiry))out.push({key:'passport',expiresOn:details.passportExpiry as string});
 if(isRealDate(profile.englishDate))out.push({key:'english_test',expiresOn:plusYears(profile.englishDate as string,2)});
 if(isRealDate(profile.frenchDate))out.push({key:'french_test',expiresOn:plusYears(profile.frenchDate as string,2)});
 return out;
}
const TITLE:Record<ExpiryItem['key'],string>={passport:'جواز السفر',english_test:'نتيجة اختبار الإنجليزية',french_test:'نتيجة اختبار الفرنسية'};
export async function scanExpiry(now=Date.now(),limit=500){
 const db=getDb(),today=torontoDate(now),stamp=new Date(now).toISOString();let queued=0,taskCount=0;
 const rows=await db.select({id:candidates.id,ownerId:candidates.ownerId,profile:candidates.profile,details:clientCases.details}).from(clientCases).innerJoin(candidates,eq(candidates.id,clientCases.candidateId)).where(ne(candidates.status,'archived')).limit(limit);
 for(const r of rows){
  let profile:Record<string,unknown>,details:Record<string,unknown>;try{profile=JSON.parse(r.profile);details=JSON.parse(r.details);}catch{continue;}
  for(const item of expiryItems(profile,details)){
   const m=dueMilestone(item.expiresOn,today);if(m===null)continue;
   const key='expiry:'+r.id+':'+item.key+':'+item.expiresOn+':'+m;
   // A more urgent milestone already queued means this one is stale; never send a less urgent notice after it.
   const urgent=MILESTONES.filter(x=>x<m).map(x=>'expiry:'+r.id+':'+item.key+':'+item.expiresOn+':'+x);
   const [later]=urgent.length?await db.select({k:deliveryOutbox.businessKey}).from(deliveryOutbox).where(and(eq(deliveryOutbox.caseId,r.id),eq(deliveryOutbox.kind,'EXPIRY_NOTICE'))).limit(50).then(x=>x.filter(y=>urgent.includes(y.k))):[];
   if(later)continue;
   if(item.key!=='passport'){const t=await db.insert(tasks).values({id:crypto.randomUUID(),ownerId:r.ownerId,candidateId:r.id,title:m===0?TITLE[item.key]+' انتهت صلاحيتها ('+item.expiresOn+')؛ اطلب نتيجة سارية':TITLE[item.key]+' تنتهي صلاحيتها في '+item.expiresOn,dueDate:m===0?today:item.expiresOn,priority:'high',systemKey:'doc-expiry:'+item.key+':'+item.expiresOn+':'+m,createdAt:stamp,updatedAt:stamp}).onConflictDoNothing().returning({id:tasks.id});taskCount+=t.length;}
   if(!await hasConsent(r.id,'EXPIRY_NOTIFICATIONS'))continue;
   const row=await outboxRow('EXPIRY_NOTICE',r.id,key,{milestoneDays:m,item:item.key},now);if(!row)continue;
   const ins=await db.insert(deliveryOutbox).values(row).onConflictDoNothing().returning({id:deliveryOutbox.eventId});queued+=ins.length;
  }
 }
 return {queued,tasks:taskCount,checked:rows.length};
}
