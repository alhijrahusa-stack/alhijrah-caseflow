import { env } from 'cloudflare:workers';
import { getDb } from '@/db';
import { applicationAuthorizations } from '@/db/schema';
import { eq } from 'drizzle-orm';
import { ApiError } from './server';
import { sha } from './security';
import type { AuthorizationSnapshot } from './application-pdf';
export async function authorizationFor(candidateId:string){const [row]=await getDb().select().from(applicationAuthorizations).where(eq(applicationAuthorizations.candidateId,candidateId)).limit(1);return row||null;}
export async function ensureAuthorizationPdf(candidateId:string){
 if(!env.BUCKET)throw new ApiError(503,'تخزين المستندات غير متاح.');const record=await authorizationFor(candidateId);if(!record)throw new ApiError(404,'لا يوجد إقرار مسجّل بهذه النسخة لهذا الملف.');
 if(record.pdfObjectKey){const stored=await env.BUCKET.get(record.pdfObjectKey);if(stored)return {object:stored,record};}
 if(await sha(record.snapshot)!==record.snapshotHash)throw new ApiError(409,'تعذّر التحقق من سلامة سجل الإقرار.');
 const snapshot=JSON.parse(record.snapshot) as Omit<AuthorizationSnapshot,'snapshotHash'>;let signaturePngBase64:string|null=null;if(record.signatureObjectKey){const img=await env.BUCKET.get(record.signatureObjectKey);if(!img)throw new ApiError(503,'تعذّر قراءة صورة التوقيع المحفوظة.');const bytes=new Uint8Array(await img.arrayBuffer());if(await sha(bytes.buffer)!==record.signatureSha256)throw new ApiError(409,'تعذّر التحقق من سلامة صورة التوقيع.');let bin='';for(let i=0;i<bytes.length;i+=0x8000)bin+=String.fromCharCode(...bytes.subarray(i,i+0x8000));signaturePngBase64=btoa(bin);}const {renderApplicationPdf}=await import('./application-pdf');const bytes=renderApplicationPdf({...snapshot,snapshotHash:record.snapshotHash,signaturePngBase64}),hash=await sha(bytes.buffer),key='system/authorizations/'+candidateId+'/'+record.snapshotHash+'.pdf',at=new Date().toISOString();
 await env.BUCKET.put(key,bytes,{httpMetadata:{contentType:'application/pdf'},customMetadata:{candidateId,version:record.version,snapshotHash:record.snapshotHash,sha256:hash}});
 await getDb().update(applicationAuthorizations).set({pdfObjectKey:key,pdfSha256:hash,pdfGeneratedAt:at}).where(eq(applicationAuthorizations.candidateId,candidateId));
 const object=await env.BUCKET.get(key);if(!object)throw new ApiError(503,'تعذّر حفظ نسخة PDF. أعد المحاولة من ملفك.');return {object,record:{...record,pdfObjectKey:key,pdfSha256:hash,pdfGeneratedAt:at}};
}
export async function authorizationPdfResponse(candidateId:string,reference:string){const {object}=await ensureAuthorizationPdf(candidateId);return new Response(object.body,{headers:{'Content-Type':'application/pdf','Content-Disposition':'attachment; filename="'+reference.replace(/[^A-Z0-9-]/gi,'')+'-application.pdf"','Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; frame-ancestors 'self'"}});}
export function authorizationSummary(record:Awaited<ReturnType<typeof authorizationFor>>){return record?{version:record.version,acceptedAt:record.acceptedAt,authorizationText:record.authorizationText,termsText:JSON.parse(record.termsText) as string[],snapshotHash:record.snapshotHash,pdfReady:!!record.pdfObjectKey,pdfSha256:record.pdfSha256,pdfGeneratedAt:record.pdfGeneratedAt}:null;}
