// v2.2 Gate 5/6 — the outbox lease and settle compare-and-set, isolated so it can be proven against a real SQLite engine
// with forced interleaving (tests/v22/outbox-cas.test.mjs). A lease succeeds only when the row is still in the state and
// fence the dispatcher observed; it bumps the fence. A settle succeeds only for the current fence while LEASED. A second
// dispatcher that observed the same row, or a stale dispatcher whose lease expired, therefore gets null/false.
import { and,eq,sql } from 'drizzle-orm';
import { deliveryOutbox } from '../db/schema.ts';

export type SettleOutcome={state:'DELIVERED'|'RETRY'|'DEAD_LETTER'|'AMBIGUOUS'|'CANCELLED';providerReference?:string|null;errorCode?:string|null;nextAtMs?:number};
// Structural type: the D1 drizzle client in the Worker, any drizzle SQLite client in tests.
type Updater={update:(t:typeof deliveryOutbox)=>{set:(v:Record<string,unknown>)=>{where:(c:unknown)=>{returning:(f:Record<string,unknown>)=>Promise<Record<string,unknown>[]>}}}};
export async function leaseOutboxRow(db:Updater,eventId:string,observedState:string,observedFence:number,now:number,leaseMs:number){
 const [r]=await db.update(deliveryOutbox).set({state:'LEASED',fence:observedFence+1,leaseUntilMs:now+leaseMs,attempts:sql`attempts+1`}).where(and(eq(deliveryOutbox.eventId,eventId),eq(deliveryOutbox.state,observedState),eq(deliveryOutbox.fence,observedFence))).returning({fence:deliveryOutbox.fence,attempts:deliveryOutbox.attempts});
 return r?{fence:Number(r.fence),attempts:Number(r.attempts)}:null;
}
export async function settleOutboxRow(db:Updater,eventId:string,fence:number,s:SettleOutcome){
 const r=await db.update(deliveryOutbox).set({state:s.state,leaseUntilMs:0,providerReference:s.providerReference??null,errorCode:s.errorCode??null,...(s.nextAtMs!==undefined?{nextAtMs:s.nextAtMs}:{})}).where(and(eq(deliveryOutbox.eventId,eventId),eq(deliveryOutbox.fence,fence),eq(deliveryOutbox.state,'LEASED'))).returning({id:deliveryOutbox.eventId});
 return r.length===1;
}
