import { getDb } from '@/db';
import { candidates,tasks,clientCases,events } from '@/db/schema';
import { owned,ApiError,type Scope } from './server';
import { and,eq,ne,lt,lte,desc,asc,sql,inArray } from 'drizzle-orm';
import { statusLabels,pathwayLabels,priorityLabels } from './model';
import { maskIdentifiers } from './faq-retrieval';
import { decrypt } from './security';
import { professionalConfig } from './professional-ai';
import { officeCounts } from './daily-briefing';
import { runCaseReview } from './case-review';
import { createCareerDraft } from './career-draft';
// Staff assistant data layer. Everything sent to an AI provider is pseudonymous: file references, statuses,
// tasks, dates and missing items. Names, contact details and document numbers stay inside the system.
type Cand={id:string;reference:string;name:string};
const nameOf=(profile:unknown)=>sql<string>`json_extract(${profile},'$.fullName')`;
function scrub(text:string,people:Cand[]){let t=text;for(const p of people)if(p.name&&p.name.length>2)t=t.split(p.name).join(p.reference);return maskIdentifiers(t);}
export async function workSnapshot(ownerId:Scope){
 const db=getDb(),now=Date.now(),today=new Date(now).toISOString().slice(0,10),week=new Date(now+7*86400000).toISOString().slice(0,10),stale=new Date(now-14*86400000).toISOString();
 const open=and(owned(tasks.ownerId,ownerId),eq(tasks.status,'open'));
 const [taskRows,pending,staleRows,groups]=await Promise.all([
  db.select({title:tasks.title,dueDate:tasks.dueDate,priority:tasks.priority,id:candidates.id,reference:candidates.reference,name:nameOf(candidates.profile),status:candidates.status}).from(tasks).innerJoin(candidates,eq(candidates.id,tasks.candidateId)).where(and(open,ne(tasks.dueDate,''),lte(tasks.dueDate,week))).orderBy(asc(tasks.dueDate)).limit(40),
  db.select({id:candidates.id,reference:candidates.reference,name:nameOf(candidates.profile),at:clientCases.submittedAt}).from(clientCases).innerJoin(candidates,eq(candidates.id,clientCases.candidateId)).where(and(owned(candidates.ownerId,ownerId),eq(clientCases.inbox,'pending'))).orderBy(asc(clientCases.submittedAt)).limit(20),
  db.select({id:candidates.id,reference:candidates.reference,name:nameOf(candidates.profile),status:candidates.status,updatedAt:candidates.updatedAt}).from(candidates).where(and(owned(candidates.ownerId,ownerId),ne(candidates.status,'archived'),lt(candidates.updatedAt,stale))).orderBy(asc(candidates.updatedAt)).limit(15),
  db.select({status:candidates.status,n:sql<number>`count(*)`}).from(candidates).where(owned(candidates.ownerId,ownerId)).groupBy(candidates.status),
 ]);
 const people:Cand[]=[...taskRows,...pending,...staleRows].map(r=>({id:r.id,reference:r.reference,name:r.name}));
 const refs=Object.fromEntries(people.map(p=>[p.reference,p.id]));
 const lines=[`تاريخ اليوم: ${today}`,`توزيع الملفات: ${groups.map(g=>`${statusLabels[g.status]||g.status} ${g.n}`).join('، ')||'لا ملفات'}`,
  'المهام المتأخرة أو المستحقة خلال 7 أيام:',...(taskRows.length?taskRows.map(t=>`- ${t.dueDate<today?'متأخرة':t.dueDate===today?'اليوم':t.dueDate} | ${t.reference} | ${scrub(t.title,people)} | أولوية ${priorityLabels[t.priority]||t.priority} | حالة الملف ${statusLabels[t.status]||t.status}`):['- لا يوجد']),
  'طلبات عملاء بانتظار الفرز:',...(pending.length?pending.map(p=>`- ${p.reference} | وصل ${p.at.slice(0,10)}`):['- لا يوجد']),
  'ملفات بلا تحديث منذ 14 يومًا أو أكثر:',...(staleRows.length?staleRows.map(s=>`- ${s.reference} | ${statusLabels[s.status]||s.status} | آخر تحديث ${s.updatedAt.slice(0,10)}`):['- لا يوجد'])];
 const health=await officeCounts(owned(candidates.ownerId,ownerId) as ReturnType<typeof eq>);
 lines.splice(2,0,`مؤشرات الضبط: ملفات بلا مسؤول ${health.unassigned}، ملفات بلا متابعة قادمة (لا مهمة مفتوحة) ${health.noFollowUp}`);
 return {text:lines.join('\n'),refs};
}
export async function caseDetails(ownerId:Scope,reference:string){
 const db=getDb(),raw=reference.trim().toUpperCase().replace(/^ALH-/,'');if(!/^CA-\d{4}-[0-9A-F]{6,12}$/.test(raw))return {error:'رقم ملف غير صالح.'};
 const [c]=await db.select({id:candidates.id,reference:candidates.reference,name:nameOf(candidates.profile),status:candidates.status,pathway:candidates.pathway,priority:candidates.priority,assessment:candidates.assessment,updatedAt:candidates.updatedAt,source:candidates.source}).from(candidates).where(and(owned(candidates.ownerId,ownerId),inArray(candidates.reference,[raw,'ALH-'+raw]))).limit(1);
 if(!c)return {error:'لا يوجد ملف بهذا الرقم.'};
 const [openTasks,recent,inbox]=await Promise.all([
  db.select({title:tasks.title,dueDate:tasks.dueDate,priority:tasks.priority}).from(tasks).where(and(eq(tasks.candidateId,c.id),eq(tasks.status,'open'))).orderBy(asc(tasks.dueDate)).limit(10),
  db.select({action:events.action,at:events.createdAt}).from(events).where(eq(events.candidateId,c.id)).orderBy(desc(events.createdAt)).limit(6),
  db.select({inbox:clientCases.inbox,followUp:clientCases.followUpDate}).from(clientCases).where(eq(clientCases.candidateId,c.id)).limit(1),
 ]);
 const people=[{id:c.id,reference:c.reference,name:c.name}];let a:{completeness?:number;nextAction?:string;missingDocuments?:string[];pathways?:{id:string;state:string;checks?:{label:string;state:string}[]}[]}={};try{a=JSON.parse(c.assessment);}catch{}
 return {reference:c.reference,candidateId:c.id,status:statusLabels[c.status]||c.status,pathway:pathwayLabels[c.pathway]||c.pathway,priority:priorityLabels[c.priority]||c.priority,source:c.source==='client'?'بوابة العميل':'المكتب',lastUpdate:c.updatedAt.slice(0,10),completeness:a.completeness??null,nextAction:a.nextAction?scrub(a.nextAction,people):'',missingDocuments:a.missingDocuments||[],
  pathways:(a.pathways||[]).map(p=>({id:p.id,state:p.state,unmet:(p.checks||[]).filter(k=>k.state!=='pass').map(k=>k.label)})),clientInbox:inbox[0]?.inbox||'',followUpDate:inbox[0]?.followUp||'',
  openTasks:openTasks.map(t=>({title:scrub(t.title,people),dueDate:t.dueDate,priority:t.priority})),recentActivity:recent.map(e=>({action:scrub(e.action,people),date:e.at.slice(0,10)}))};
}
export async function resolveReferences(ownerId:Scope,refs:string[]){const base=Array.from(new Set(refs.map(r=>r.trim().toUpperCase().replace(/^ALH-/,'')))).filter(r=>/^CA-\d{4}-[0-9A-F]{6,12}$/.test(r)).slice(0,20);if(!base.length)return {} as Record<string,string>;const rows=await getDb().select({id:candidates.id,reference:candidates.reference}).from(candidates).where(and(owned(candidates.ownerId,ownerId),inArray(candidates.reference,[...base,...base.map(r=>'ALH-'+r)])));const out:Record<string,string>={};for(const r of rows){out[r.reference]=r.id;out[r.reference.replace(/^ALH-/,'')]=r.id;out['ALH-'+r.reference.replace(/^ALH-/,'')]=r.id;}return out;}

type Msg={role:'user'|'assistant';content:string};
export type Proposal={reference:string;title:string;dueDate:string;priority:'normal'|'high'|'urgent'};
type OutItem={type:string;call_id?:string;name?:string;arguments?:string;content?:{type:string;text?:string;annotations?:{type:string;url?:string;title?:string}[]}[]};
const TOOLS=[
 {type:'function',name:'get_case',description:'تفاصيل ملف واحد برقمه (الحالة، المسار، النواقص، المهام المفتوحة، آخر النشاط). لا تحتوي بيانات شخصية.',strict:true,parameters:{type:'object',properties:{reference:{type:'string',description:'رقم الملف كما هو، مثل ALH-CA-2026-9098A2F68D6E أو CA-2026-1A2B3C4D'}},required:['reference'],additionalProperties:false}},
 {type:'function',name:'review_case',description:'تشغيل مراجعة شاملة لملف برقمه: أقوى 3 مسارات كندية، ما يلزم من العميل، والخطوات التالية. تُحفظ في الملف كملاحظة. تستغرق حتى دقيقة.',strict:true,parameters:{type:'object',properties:{reference:{type:'string'}},required:['reference'],additionalProperties:false}},
 {type:'function',name:'generate_document',description:'تجهيز مسودة CV كندية (ATS) أو Cover Letter لملف برقمه من بيانات العميل وسيرته المرفوعة. تُحفظ كمسودة في تبويب المستندات وتحتاج مراجعة الموظف. تتطلب تفويض العميل المسجّل.',strict:true,parameters:{type:'object',properties:{reference:{type:'string'},kind:{type:'string',enum:['cv','cover_letter']}},required:['reference','kind'],additionalProperties:false}},
 {type:'function',name:'propose_tasks',description:'اقتراح مهام متابعة للموظف. لا تُنشأ إلا بعد ضغط الموظف «إنشاء».',strict:true,parameters:{type:'object',properties:{tasks:{type:'array',maxItems:8,items:{type:'object',properties:{reference:{type:'string'},title:{type:'string'},due_date:{type:'string',description:'YYYY-MM-DD أو فارغ'},priority:{type:'string',enum:['normal','high','urgent']}},required:['reference','title','due_date','priority'],additionalProperties:false}}},required:['tasks'],additionalProperties:false}},
];
// OpenAI Responses API loop: built-in web search plus the two office tools. Stateless (store:false).
export type ChatFile={name:string;mime:string;data:string};
export async function runOpenAI(ownerId:Scope,instructions:string,history:Msg[],actor='staff',files:ChatFile[]=[]){
 const c=await professionalConfig();if(!c.configured||c.provider!=='openai')return null;
 const key=await decrypt(c.key),lastUser=history.map(m=>m.role).lastIndexOf('user'),input:unknown[]=history.map((m,i)=>i===lastUser&&files.length?{role:'user',content:[{type:'input_text',text:m.content},...files.map(f=>f.mime.startsWith('image/')?{type:'input_image',image_url:`data:${f.mime};base64,${f.data}`}:{type:'input_file',filename:f.name,file_data:`data:${f.mime};base64,${f.data}`})]}:{role:m.role,content:m.content}),proposals:Proposal[]=[],sources:{title:string;url:string}[]=[];
 let webSearch=true,includeReasoning=true,effort=true;
 for(let round=0;round<5;round++){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),90000);let response:Response;
  try{response=await fetch('https://api.openai.com/v1/responses',{method:'POST',signal:controller.signal,headers:{'Content-Type':'application/json',Authorization:'Bearer '+key},body:JSON.stringify({model:c.model,store:false,instructions,input,max_output_tokens:4000,...(effort?{reasoning:{effort:'low'}}:{}),tools:webSearch?[{type:'web_search'},...TOOLS]:TOOLS,...(includeReasoning?{include:['reasoning.encrypted_content']}:{})})});}
  catch(e){throw new ApiError(502,(e as Error).name==='AbortError'?'انتهت مهلة الاتصال بـ OpenAI (60 ثانية).':'تعذّر الوصول إلى خادم OpenAI.');}finally{clearTimeout(timer);}
  if(!response.ok){const body=await response.json().catch(()=>null) as {error?:{message?:string}}|null;const msg=(body?.error?.message||'').replace(/sk-[A-Za-z0-9_-]+/g,'[key]').slice(0,220);
   if(response.status===400&&effort&&/effort/i.test(msg)){effort=false;round--;continue;}
   if(response.status===400&&includeReasoning&&/include|encrypted|reasoning/i.test(msg)){if(effort){effort=false;round--;continue;}includeReasoning=false;round--;continue;}
   if(response.status===400&&webSearch&&/web_search|tool/i.test(msg)){webSearch=false;round--;continue;}
   const reason=response.status===401?'مفتاح OpenAI مرفوض (401).':response.status===403?'OpenAI رفض الطلب (403): صلاحيات الحساب أو النموذج.':response.status===404?`النموذج ${c.model} غير متاح لحساب OpenAI (404). اختر نموذجًا من قائمة حسابك.`:response.status===429?'تجاوزت حد الاستخدام أو الرصيد في OpenAI (429).':`رفض OpenAI الطلب (${response.status}).`;
   throw new ApiError(response.status===429?429:502,msg?`${reason} رسالة المزود: ${msg}`:reason);}
  const r=await response.json() as {status?:string;output?:OutItem[]};const output=r.output||[];
  const calls=output.filter(o=>o.type==='function_call');
  for(const m of output.filter(o=>o.type==='message'))for(const part of m.content||[])for(const an of part.annotations||[])if(an.type==='url_citation'&&an.url&&!sources.some(s=>s.url===an.url))sources.push({title:an.title||an.url,url:an.url});
  if(!calls.length){const text=output.filter(o=>o.type==='message').flatMap(o=>o.content||[]).filter(p=>p.type==='output_text').map(p=>p.text||'').join('\n').trim();if(!text)throw new ApiError(502,r.status==='incomplete'?'توقفت إجابة OpenAI عند حد الطول. أعد صياغة السؤال بشكل أضيق.':'وصلت إجابة فارغة من OpenAI.');return {text,model:c.model,sources:sources.slice(0,8),proposals,webSearch};}
  input.push(...output.filter(o=>includeReasoning||o.type!=='reasoning'));
  for(const call of calls){let result:unknown;try{const args=JSON.parse(call.arguments||'{}');
   if(call.name==='get_case')result=await caseDetails(ownerId,String(args.reference||''));
   else if(call.name==='propose_tasks'){for(const t of (args.tasks||[]) as {reference:string;title:string;due_date:string;priority:string}[]){const title=String(t.title||'').trim().slice(0,200);if(title.length>=3&&proposals.length<8)proposals.push({reference:String(t.reference||'').trim().toUpperCase(),title,dueDate:/^\d{4}-\d{2}-\d{2}$/.test(t.due_date)?t.due_date:'',priority:['high','urgent'].includes(t.priority)?t.priority as Proposal['priority']:'normal'});}result={shown_to_staff:true,note:'عُرضت المقترحات على الموظف للتأكيد.'};}
   else if(call.name==='review_case'||call.name==='generate_document'){const ref=String(args.reference||'');const map=await resolveReferences(ownerId,[ref]);const candidateId=map[ref.trim().toUpperCase()];
    if(!candidateId)result={error:'لا يوجد ملف بهذا الرقم.'};
    else if(call.name==='review_case'){try{const r=await runCaseReview(candidateId,actor);result={saved:true,summary:r.review.summary,pathways:r.review.pathways.map(p=>({name:p.name,fit:p.fit,why:p.why,client_requirements:p.client_requirements,office_next_steps:p.office_next_steps,official_url:p.official_url})),questions_for_client:r.review.questions_for_client,documents_to_request:r.review.documents_to_request,note:'حُفظت المراجعة في الملف (التقييم الأولي) وسُجّلت كملاحظة.'};}catch(e){result={error:(e as Error).message};}}
    else{try{const r=await createCareerDraft(candidateId,args.kind==='cover_letter'?'cover_letter':'cv',actor);result={saved:true,state:r.state,warningsCount:(r.warnings||[]).length,note:'المسودة في تبويب المستندات داخل الملف، وتحتاج مراجعة الموظف واعتماده قبل الاستخدام.'};}catch(e){result={error:(e as Error).message};}}}
   else result={error:'أداة غير معروفة.'};}catch{result={error:'وسائط غير صالحة.'};}
   input.push({type:'function_call_output',call_id:call.call_id,output:JSON.stringify(result)});}
 }
 throw new ApiError(502,'تجاوز المساعد عدد خطوات المعالجة. أعد صياغة الطلب.');
}
