import { z } from 'zod';
// NOC 2021 five-digit codes: the 1st digit is the broad occupational category, the 2nd digit is the TEER.
// Example: 21231 -> TEER 1.
export function teerFromNoc(noc:string):number|null{return /^\d{5}$/.test(noc)?Number(noc.charAt(1)):null;}

// ---- v2.2 Gate 3: NOC suggestion adapter (09 §1.5, contracts NocSuggestionRequest). No consent or approval gate:
// there is no consentId/approvedConsent field and no refusal for a missing consent. What stays: authenticated case
// capability and scope, the configured provider, the sealed official NOC catalog (exact hash), and citations that must
// match that catalog and the episode's own words. A suggestion is PROVISIONAL and never becomes a professional fact;
// a staff member decides. Any forged citation rejects the whole response (no partial acceptance).
export type NocCatalogRow={nocCode:string;teer:number;officialTitle:string;leadStatement:string;mainDuties:{dutyId:string;text:string}[];exclusions:string[]};
const Id=z.string().regex(/^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/);
export const nocSuggestionRequestSchema=z.object({action:z.literal('noc_suggestion'),expectedDataRevision:z.number().int().min(0),workEpisodeId:Id,targetNocCodes:z.array(z.string().regex(/^[0-9]{5}$/)).min(1).max(5).refine(v=>new Set(v).size===v.length,'DUPLICATE_NOC')}).strict();
export const nocProviderSchema=z.object({suggestions:z.array(z.object({nocCode:z.string().regex(/^[0-9]{5}$/),leadStatementSupported:z.boolean(),dutyMatches:z.array(z.object({officialDutyId:Id,evidenceQuote:z.string().min(3).max(600),reason:z.string().min(1).max(600)}).strict()).max(20),exclusionNotes:z.array(z.string().min(1).max(600)).max(5)}).strict()).max(5),warnings:z.array(z.string().min(1).max(400)).max(6)}).strict();
export type NocProviderOutput=z.infer<typeof nocProviderSchema>;
export const nocProviderJsonSchema={type:'object',additionalProperties:false,required:['suggestions','warnings'],properties:{suggestions:{type:'array',items:{type:'object',additionalProperties:false,required:['nocCode','leadStatementSupported','dutyMatches','exclusionNotes'],properties:{nocCode:{type:'string'},leadStatementSupported:{type:'boolean'},dutyMatches:{type:'array',items:{type:'object',additionalProperties:false,required:['officialDutyId','evidenceQuote','reason'],properties:{officialDutyId:{type:'string'},evidenceQuote:{type:'string'},reason:{type:'string'}}}},exclusionNotes:{type:'array',items:{type:'string'}}}}},warnings:{type:'array',items:{type:'string'}}}} as const;
export const NOC_SYSTEM_PROMPT='You compare one work episode with official NOC 2021 occupations supplied by the office. Use only the supplied catalog rows and the episode text. For each target NOC, say whether the lead statement is supported and list main duties matched. Every officialDutyId must be one of that row\'s dutyId values and every evidenceQuote must be copied verbatim from the episode text. Do not invent duties, codes, titles, wages or eligibility. This is a provisional suggestion for a professional reviewer, not a decision.';
const norm=(s:string)=>s.normalize('NFC').replace(/\s+/g,' ').trim();
export function validateNocSuggestion(raw:unknown,ctx:{episodeText:string;targets:readonly string[];catalog:readonly NocCatalogRow[]}):{ok:true;output:NocProviderOutput}|{ok:false;code:string}{
 const parsed=nocProviderSchema.safeParse(raw);if(!parsed.success)return {ok:false,code:'NOC_RESPONSE_SCHEMA'};
 const text=norm(ctx.episodeText),seen=new Set<string>();
 for(const s of parsed.data.suggestions){
  if(!ctx.targets.includes(s.nocCode)||seen.has(s.nocCode))return {ok:false,code:'NOC_CITATION_FORGED:code'};seen.add(s.nocCode);
  const row=ctx.catalog.find(r=>r.nocCode===s.nocCode);if(!row)return {ok:false,code:'NOC_CITATION_FORGED:catalog'};
  for(const m of s.dutyMatches){
   if(!row.mainDuties.some(d=>d.dutyId===m.officialDutyId))return {ok:false,code:'NOC_CITATION_FORGED:duty'};
   if(!text.includes(norm(m.evidenceQuote)))return {ok:false,code:'NOC_CITATION_FORGED:quote'};
  }
 }
 return {ok:true,output:parsed.data};
}
