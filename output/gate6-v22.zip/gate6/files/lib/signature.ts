// v2.2 Gate 4 — fixed electronic signature (09 §1.3, 10 §5). Pure helpers, usable on the server and in tests.
// The signature is a private PNG bound to the ORIGINAL signing snapshot: signedPayloadHash = SHA-256 of the JCS of
// {accountKey,draftId,profile,details,pathSelection,legalVersion,authorizationText,mandatoryAcceptanceValues} at the
// signed draft revision. Later edits never invalidate it, never mark it STALE and never ask for a new signature.
// The server checks the image itself: PNG signature, IHDR bounds, 8-bit RGBA non-interlaced, decoded ink present.
import { jcsHash } from './v22-core.ts';

export const SIGNATURE_MAX_BYTES = 256 * 1024;
export const SIGNATURE_MAX_WIDTH = 2048;
export const SIGNATURE_MAX_HEIGHT = 1024;
export const SIGNATURE_MIN_INK_PIXELS = 24;
export type SignatureState = 'EMPTY' | 'DRAWING' | 'SAVING' | 'SIGNED' | 'ERROR';
export type SigningSnapshot = { accountKey: string; draftId: string; profile: unknown; details: unknown; pathSelection: unknown; legalVersion: string; authorizationText: string; mandatoryAcceptanceValues: { legalAuthorization: true } };
export const signingPayloadHash = (s: SigningSnapshot) => jcsHash(s);

const PNG_MAGIC = [137, 80, 78, 71, 13, 10, 26, 10];
const u32 = (b: Uint8Array, o: number) => ((b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]) >>> 0;
async function inflate(data: Uint8Array): Promise<Uint8Array> {
  const stream = new Blob([new Uint8Array(data)]).stream().pipeThrough(new DecompressionStream('deflate'));
  const out = new Uint8Array(await new Response(stream).arrayBuffer());
  return out;
}
export type PngCheck = { ok: true; width: number; height: number; inkPixels: number } | { ok: false; code: string };
// Decode enough of the PNG to prove real ink: unfilter every scanline (filters 0–4) and count pixels with alpha > 0.
export async function inspectSignaturePng(bytes: Uint8Array): Promise<PngCheck> {
  if (bytes.length < 57 || bytes.length > SIGNATURE_MAX_BYTES) return { ok: false, code: 'SIGNATURE_SIZE' };
  if (!PNG_MAGIC.every((v, i) => bytes[i] === v)) return { ok: false, code: 'SIGNATURE_NOT_PNG' };
  let pos = 8, width = 0, height = 0, sawHeader = false, ended = false;
  const idat: Uint8Array[] = [];
  while (pos + 12 <= bytes.length) {
    const len = u32(bytes, pos), type = String.fromCharCode(...bytes.subarray(pos + 4, pos + 8)), body = bytes.subarray(pos + 8, pos + 8 + len);
    if (pos + 12 + len > bytes.length) return { ok: false, code: 'SIGNATURE_TRUNCATED' };
    if (type === 'IHDR') {
      if (len !== 13) return { ok: false, code: 'SIGNATURE_HEADER' };
      width = u32(body, 0); height = u32(body, 4);
      const [depth, color, compression, filter, interlace] = [body[8], body[9], body[10], body[11], body[12]];
      if (!width || !height || width > SIGNATURE_MAX_WIDTH || height > SIGNATURE_MAX_HEIGHT) return { ok: false, code: 'SIGNATURE_DIMENSIONS' };
      if (depth !== 8 || color !== 6 || compression !== 0 || filter !== 0 || interlace !== 0) return { ok: false, code: 'SIGNATURE_FORMAT' };
      sawHeader = true;
    } else if (type === 'IDAT') idat.push(body);
    else if (type === 'IEND') { ended = true; break; }
    pos += 12 + len;
  }
  if (!sawHeader || !ended || !idat.length) return { ok: false, code: 'SIGNATURE_STRUCTURE' };
  const joined = new Uint8Array(idat.reduce((n, c) => n + c.length, 0));
  let off = 0; for (const c of idat) { joined.set(c, off); off += c.length; }
  let raw: Uint8Array;
  try { raw = await inflate(joined); } catch { return { ok: false, code: 'SIGNATURE_DATA' }; }
  const stride = width * 4;
  if (raw.length !== height * (stride + 1)) return { ok: false, code: 'SIGNATURE_DATA' };
  let prev = new Uint8Array(stride), ink = 0;
  for (let y = 0; y < height; y++) {
    const f = raw[y * (stride + 1)], line = raw.subarray(y * (stride + 1) + 1, (y + 1) * (stride + 1)), cur = new Uint8Array(stride);
    for (let x = 0; x < stride; x++) {
      const a = x >= 4 ? cur[x - 4] : 0, b = prev[x], c = x >= 4 ? prev[x - 4] : 0;
      let v: number;
      switch (f) {
        case 0: v = line[x]; break;
        case 1: v = line[x] + a; break;
        case 2: v = line[x] + b; break;
        case 3: v = line[x] + ((a + b) >> 1); break;
        case 4: { const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c); v = line[x] + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c); break; }
        default: return { ok: false, code: 'SIGNATURE_DATA' };
      }
      cur[x] = v & 255;
    }
    for (let x = 3; x < stride; x += 4) if (cur[x] > 0) ink++;
    prev = cur;
  }
  if (ink < SIGNATURE_MIN_INK_PIXELS) return { ok: false, code: 'SIGNATURE_EMPTY' };
  return { ok: true, width, height, inkPixels: ink };
}
