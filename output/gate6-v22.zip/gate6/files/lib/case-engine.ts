import { getDb } from '@/db';
import { candidates,clientCases,documents,assessmentHistory,operationLogs,caseCrs,eligibilityRuns } from '@/db/schema';
import { and,eq,desc } from 'drizzle-orm';
import { latestFacts } from './facts';
import type { FactView } from './facts';
import { crsSchema } from './crs';
import type { CrsInput } from './crs';
import { buildPreliminary } from './preliminary.ts';
import type { Preliminary,EligibilityResult } from './preliminary.ts';
import { assess,RULE_VERSION } from './assessment';
import type { Assessment,DerivedFacts } from './assessment';
import { deriveExperience,EXPERIENCE_RULE } from './experience';
import type { ExperienceJob } from './experience';
import { teerFromNoc } from './noc';
import { profileSchema } from './model';
import type { Profile } from './model';
import { detailsSchema } from './intake';
import type { IntakeDetails } from './intake';
import { computeLead } from './lead-score';
import { owned,systemScope } from './server';
import { shadowOnly } from './engine-mode';
import { sha } from './security';
import { autoRecompute } from './assessment-store';
import { SYSTEM_USER_ID } from './rbac';
// Case engine (contract step 1): the single writer of candidates.assessment. Inputs are the stored profile, the
// client details (when a client request exists), the categories of documents a staff member verified, and the
// evaluation date. Same inputs + same rules version = same output, recorded in assessment_history by inputs_hash.
export const ENGINE_VERSION='case-engine-1.1.0';
export type EngineDerived={teer:number|null;experience3:number|null;experience10:number|null;canadianMonths10:number|null;jobsMissingHours:number;experienceRule:string};
export type EngineAssessment=Assessment&{derived:EngineDerived;engineVersion:string;inputsHash:string;preliminary:Preliminary};
export type TraceEntry={rule_id:string;rule_version:string;source_url:string;inputs:Record<string,unknown>;computation:string;output:string|number|null};
// facts: latest version of each case fact; crsInput: the CRS inputs a staff member saved; eligibility: the latest staff
// eligibility run (FSW/CEC/FSTP). All of them are part of the hashed inputs.
export type CaseInputs={profile:Profile;details:IntakeDetails|null;verifiedCategories:string[];asOf:string;facts:FactView[];crsInput:CrsInput|null;eligibility:EligibilityResult|null};

export { computeInputsHash } from './inputs-hash';
import { computeInputsHash } from './inputs-hash';
export const evaluationDate=(now=new Date())=>now.toISOString().slice(0,10);
// Exactly one job source per file: the client request's jobs when it exists, otherwise the office-entered jobs.
export function jobsOf(profile:Profile,details:IntakeDetails|null):ExperienceJob[]{return (details?details.jobs:profile.jobs).map(j=>({start:j.start,end:j.end,weekly_hours:j.weekly_hours,country:j.country}));}
export function deriveFacts(inputs:CaseInputs):EngineDerived{
 const exp=deriveExperience(jobsOf(inputs.profile,inputs.details),inputs.asOf.slice(0,7));
 return {teer:teerFromNoc(inputs.profile.noc),experience3:exp.months3,experience10:exp.months10,canadianMonths10:exp.canadianMonths10,jobsMissingHours:exp.jobsMissingHours,experienceRule:EXPERIENCE_RULE};
}
// The hashed "details" object carries every non-profile input of the computation (client details, verified
// document categories, evaluation date), so the hash covers all inputs that can change the output.
export function hashedDetails(inputs:CaseInputs):Record<string,unknown>{return {client_details:inputs.details,verified_documents:[...inputs.verifiedCategories].sort(),as_of:inputs.asOf,facts:inputs.facts.map(f=>({key:f.key,version:f.version,status:f.status,value:f.value,evidence:f.evidenceDocumentId})),crs_inputs:inputs.crsInput,eligibility:inputs.eligibility};}
export async function evaluateCase(inputs:CaseInputs):Promise<{assessment:EngineAssessment;trace:TraceEntry[];inputsHash:string}>{
 const derived=deriveFacts(inputs),facts:DerivedFacts={teer:derived.teer,experience3:derived.experience3,experience10:derived.experience10};
 const base=assess(inputs.profile,facts,new Date(inputs.asOf+'T00:00:00Z'),[...inputs.verifiedCategories].sort(),inputs.details);
 const inputsHash=await computeInputsHash(inputs.profile as unknown as Record<string,unknown>,hashedDetails(inputs),RULE_VERSION);
 const trace:TraceEntry[]=[
  {rule_id:'derived_teer',rule_version:ENGINE_VERSION,source_url:'https://noc.esdc.gc.ca/',inputs:{noc:inputs.profile.noc},computation:'TEER = second digit of the 5-digit NOC 2021 code',output:derived.teer},
  {rule_id:'derived_experience_36m',rule_version:EXPERIENCE_RULE,source_url:'https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/express-entry/who-can-apply/federal-skilled-trades.html',inputs:{jobs:jobsOf(inputs.profile,inputs.details),as_of:inputs.asOf},computation:'full-time-equivalent months in the 36 months ending at as_of; weekly hours capped at 30 across jobs',output:derived.experience3},
  {rule_id:'derived_experience_120m',rule_version:EXPERIENCE_RULE,source_url:'https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/express-entry/who-can-apply/federal-skilled-trades.html',inputs:{jobs:jobsOf(inputs.profile,inputs.details),as_of:inputs.asOf},computation:'full-time-equivalent months in the 120 months ending at as_of; weekly hours capped at 30 across jobs',output:derived.experience10},
  ...base.pathways.flatMap(p=>p.checks.map((c,i)=>({rule_id:`${p.id}_check_${i+1}`,rule_version:RULE_VERSION,source_url:c.source,inputs:{pathway:p.id},computation:c.label,output:c.state}))),
  {rule_id:'completeness',rule_version:RULE_VERSION,source_url:'',inputs:{},computation:'share of filled screening fields',output:base.completeness},
 ];
 const preliminary=buildPreliminary({asOf:inputs.asOf,profile:inputs.profile,details:inputs.details,facts:inputs.facts,crsInput:inputs.crsInput,eligibility:inputs.eligibility,verifiedCategories:[...inputs.verifiedCategories].sort(),nocCatalog:null});
 trace.push({rule_id:'preliminary',rule_version:preliminary.version,source_url:'',inputs:{facts:inputs.facts.length,crs_inputs:inputs.crsInput!==null,eligibility:inputs.eligibility?.version??null},computation:'evidence-aware preliminary assessment: CRS (MI 2026-11-03) where applicable, FSW/CEC/FSTP from the staff eligibility run, provisional NOC, rule availability',output:preliminary.pathways.items.map(p=>p.programId+':'+p.legalStatus).join(',')||'none'});
 return {assessment:{...base,derived,engineVersion:ENGINE_VERSION,inputsHash,preliminary},trace,inputsHash};
}
type CandidateRow=typeof candidates.$inferSelect;
export async function loadInputs(candidate:CandidateRow,asOf:string):Promise<CaseInputs>{
 const db=getDb(),[cc]=await db.select({details:clientCases.details}).from(clientCases).where(eq(clientCases.candidateId,candidate.id)).limit(1);
 const verified=await db.select({category:documents.category}).from(documents).where(and(eq(documents.candidateId,candidate.id),eq(documents.verified,true)));
 const [crsRow]=await db.select({inputs:caseCrs.inputs}).from(caseCrs).where(eq(caseCrs.candidateId,candidate.id)).limit(1);
 const [elig]=await db.select({result:eligibilityRuns.result}).from(eligibilityRuns).where(eq(eligibilityRuns.candidateId,candidate.id)).orderBy(desc(eligibilityRuns.createdAt)).limit(1);
 const crsParsed=crsRow?crsSchema.safeParse(JSON.parse(crsRow.inputs)):null;
 return {profile:profileSchema.parse({...JSON.parse(candidate.profile),consent:true}),details:cc?detailsSchema.parse(JSON.parse(cc.details)):null,verifiedCategories:[...new Set(verified.map(v=>v.category))].sort(),asOf,facts:await latestFacts(candidate.id),crsInput:crsParsed&&crsParsed.success?crsParsed.data:null,eligibility:elig?JSON.parse(elig.result) as EligibilityResult:null};
}
// Write mode: candidates.assessment (+ the pathway projection for client files) and assessment_history in one
// batch, then lead_scores. Shadow mode: assessment_history only.
export async function recomputeCase(candidateId:string,opts:{mode:'write'|'shadow';asOf?:string}):Promise<{assessment:EngineAssessment;inputsHash:string;historyId:string;mode:'write'|'shadow'}>{
 const mode=opts.mode==='write'&&shadowOnly()?'shadow':opts.mode;
 const db=getDb(),[candidate]=await db.select().from(candidates).where(eq(candidates.id,candidateId)).limit(1);
 if(!candidate)throw new Error('candidate_not_found');
 const inputs=await loadInputs(candidate,opts.asOf??evaluationDate()),{assessment,trace,inputsHash}=await evaluateCase(inputs),historyId=crypto.randomUUID(),at=new Date().toISOString();
 // Event-driven recomputes (write mode, also when downgraded by SHADOW_ONLY) do not record the same evaluation twice:
 // identical inputs hash, engine version and rules version as the latest history row = no new row. Explicit shadow
 // runs always record (they are audit runs).
 if(opts.mode==='write'){
  const [last]=await db.select({id:assessmentHistory.id,inputsHash:assessmentHistory.inputsHash,engineVersion:assessmentHistory.engineVersion,rulesVersion:assessmentHistory.rulesVersion}).from(assessmentHistory).where(eq(assessmentHistory.candidateId,candidateId)).orderBy(desc(assessmentHistory.computedAt)).limit(1);
  if(last&&last.inputsHash===inputsHash&&last.engineVersion===ENGINE_VERSION&&last.rulesVersion===RULE_VERSION)return {assessment,inputsHash,historyId:last.id,mode};
 }
 const history=db.insert(assessmentHistory).values({id:historyId,candidateId,computedAt:at,inputsHash,engineVersion:ENGINE_VERSION,rulesVersion:RULE_VERSION,outputJson:JSON.stringify(assessment),explanationTraceJson:JSON.stringify(trace)});
 if(mode==='shadow'){await history;return {assessment,inputsHash,historyId,mode};}
 await db.batch([db.update(candidates).set({assessment:JSON.stringify(assessment),...(inputs.details?{pathway:inputs.details.pathway}:{})}).where(eq(candidates.id,candidateId)),history]);
 await computeLead(candidateId);
 // v2.2 Gate 3: the same recompute also publishes the sealed-rules assessment (VERIFIED_SCREENING) when a release is
 // active; it is a no-op without one, and a concurrent change leaves it to the next recompute.
 await autoRecompute(candidateId,SYSTEM_USER_ID);
 return {assessment,inputsHash,historyId,mode};
}
// Initial assessment for a row that is about to be inserted (intake, office create, import): same evaluation,
// returned together with its history row so the caller writes both in its own batch.
export async function initialAssessment(candidateId:string,inputs:CaseInputs){
 const {assessment,trace,inputsHash}=await evaluateCase(inputs);
 return {assessment,history:{id:crypto.randomUUID(),candidateId,computedAt:new Date().toISOString(),inputsHash,engineVersion:ENGINE_VERSION,rulesVersion:RULE_VERSION,outputJson:JSON.stringify(assessment),explanationTraceJson:JSON.stringify(trace)}};
}

// Labels of the checks each screening pathway runs (for the pathways guide), from the same rule module.
export function ruleCatalog(asOf=evaluationDate()):Record<string,string[]>{
 const empty=profileSchema.parse({fullName:'--',phone:'00000',consent:true});
 return Object.fromEntries(assess(empty,{teer:null,experience3:null,experience10:null},new Date(asOf+'T00:00:00Z'),[],null).pathways.map(p=>[p.id,p.checks.map(c=>c.label)]));
}
// ---- Shadow calculation (contract 1.6): new engine vs the stored legacy assessment, every difference explained.
type Comparable={completeness:number;nextAction:string;missingDocuments:string[];pathways:{id:string;state:string;checks:string[]}[]};
const comparable=(a:Pick<Assessment,'completeness'|'nextAction'|'missingDocuments'|'pathways'>):Comparable=>({completeness:a.completeness,nextAction:a.nextAction,missingDocuments:[...a.missingDocuments].sort(),pathways:a.pathways.map(p=>({id:p.id,state:p.state,checks:p.checks.map(c=>c.state)}))});
const same=(x:Comparable,y:Comparable)=>JSON.stringify(x)===JSON.stringify(y);
function diffFields(stored:Comparable,next:Comparable){const out:string[]=[];if(stored.completeness!==next.completeness)out.push(`completeness ${stored.completeness} -> ${next.completeness}`);if(stored.nextAction!==next.nextAction)out.push('nextAction');if(JSON.stringify(stored.missingDocuments)!==JSON.stringify(next.missingDocuments))out.push(`missingDocuments [${stored.missingDocuments.join(',')}] -> [${next.missingDocuments.join(',')}]`);
 for(const p of next.pathways){const o=stored.pathways.find(q=>q.id===p.id);if(!o){out.push(`pathway ${p.id} added`);continue;}if(o.state!==p.state)out.push(`pathway ${p.id}: ${o.state} -> ${p.state}`);p.checks.forEach((c,i)=>{if(o.checks[i]!==c)out.push(`${p.id} check ${i+1}: ${o.checks[i]??'—'} -> ${c}`);});}
 return out;}
export type ShadowCause='legacy_manual_experience_teer'|'legacy_unverified_documents'|'legacy_no_verified_documents'|'legacy_without_client_details'|'legacy_household_size_counted'|'evaluation_date'|'rules_version_changed';
export const SHADOW_CAUSES:Record<ShadowCause,string>={
 legacy_manual_experience_teer:'المحفوظ استخدم أشهر الخبرة وTEER المُدخلة يدويًا (ونسبة الاكتمال كانت تعدّ حقل TEER اليدوي)؛ المحرك يشتقها من الوظائف وNOC',
 legacy_unverified_documents:'المحفوظ عدّ المستندات المرفوعة غير المعتمدة (api/client PATCH القديم)؛ المحرك يعدّ المعتمدة فقط',
 legacy_no_verified_documents:'المحفوظ حُسب قبل مستندات اعتمدها الموظف لاحقًا (الاعتماد في v15.22 لم يكن يعيد الحساب)؛ المحرك يعدّها',
 legacy_without_client_details:'المحفوظ حُسب دون تفاصيل طلب العميل (قائمة/تعديل الموظف القديم)؛ المحرك يضمّنها',
 legacy_household_size_counted:'المحفوظ عدّ حجم الأسرة الافتراضي في نسبة الاكتمال (قبل v15.21)',
 evaluation_date:'تاريخ التقييم مختلف (صلاحية اختبار اللغة أو تواريخ البرامج تتغير بالتاريخ)',
 rules_version_changed:'نسخة القواعد المحفوظة تختلف عن النسخة الحالية',
};
export type ShadowRow={candidateId:string;reference:string;historyId:string;inputsHash:string;asOf:string;status:'identical'|'explained'|'unexplained';causes:ShadowCause[];differences:string[];derived:EngineDerived;legacy:{teer:number|null;experience3:number|null;experience10:number|null}};
// Byte-level fingerprint of every stored assessment in scope (SHA-256 of the exact column text).
async function assessmentFingerprints(ownerId:string|null):Promise<Record<string,string>>{
 const db=getDb(),q=db.select({id:candidates.id,assessment:candidates.assessment}).from(candidates),list=ownerId===null?await q:await q.where(owned(candidates.ownerId,systemScope(ownerId))),out:Record<string,string>={};
 for(const r of list)out[r.id]=await sha(r.assessment);return out;
}
export type ShadowIntegrity={filesBefore:number;filesAfter:number;assessmentUnchanged:boolean;changedIds:string[];digestBefore:string;digestAfter:string};
// ownerId null = every file (used by the scheduled production shadow).
export async function shadowAll(ownerId:string|null,asOf=evaluationDate()):Promise<{rows:ShadowRow[];summary:Record<string,number>;integrity:ShadowIntegrity}>{
 const before=await assessmentFingerprints(ownerId);
 const db=getDb(),base=db.select().from(candidates),list=ownerId===null?await base:await base.where(owned(candidates.ownerId,systemScope(ownerId))),rows:ShadowRow[]=[];
 for(const c of list){
  const raw=JSON.parse(c.profile) as Record<string,unknown>,stored=JSON.parse(c.assessment) as Assessment,inputs=await loadInputs(c,asOf);
  const {historyId,assessment}=await recomputeCase(c.id,{mode:'shadow',asOf});
  const num=(v:unknown)=>typeof v==='number'?v:null;
  // v15.22 legacy semantics: checks used teerFromNoc(noc) ?? the manual TEER, while completeness counted the manual
  // TEER field itself; experience months were the manual fields.
  const legacy={teer:teerFromNoc(inputs.profile.noc)??num(raw.teer),experience3:num(raw.experience3),experience10:num(raw.experience10)},legacyCompletenessTeer=num(raw.teer);
  const storedC=comparable(stored),nextC=comparable(assessment);
  const row:ShadowRow={candidateId:c.id,reference:c.reference,historyId,inputsHash:assessment.inputsHash,asOf,status:'identical',causes:[],differences:[],derived:assessment.derived,legacy};
  if(!same(storedC,nextC)){
   row.differences=diffFields(storedC,nextC);
   const allDocs=(await db.select({category:documents.category}).from(documents).where(eq(documents.candidateId,c.id))).map(d=>d.category);
   const storedDate=typeof stored.assessedAt==='string'?stored.assessedAt.slice(0,10):asOf;
   let found:ShadowCause[]|null=null;
   // Search the legacy computation variants; the first that reproduces the stored output names the causes.
   for(const manual of [false,true])for(const docs of ['verified','all','none'] as const)for(const withDetails of [true,false])for(const household of [false,true])for(const date of [asOf,storedDate]){
    if(found)break;
    const facts:DerivedFacts=manual?legacy:{teer:assessment.derived.teer,experience3:assessment.derived.experience3,experience10:assessment.derived.experience10};
    const cats=docs==='verified'?inputs.verifiedCategories:docs==='all'?[...new Set(allDocs)]:[];
    const det=withDetails&&inputs.details?(household?{...inputs.details,familySizeProvided:true}:inputs.details):null;
    if(household&&!(withDetails&&inputs.details))continue;
    const at=new Date(date+'T00:00:00Z'),sorted=[...cats].sort(),checks=assess(inputs.profile,facts,at,sorted,det);
    const variant=manual?{...checks,completeness:assess(inputs.profile,{...facts,teer:legacyCompletenessTeer},at,sorted,det).completeness}:checks;
    if(same(storedC,comparable(variant))){const causes:ShadowCause[]=[];if(manual&&(JSON.stringify(legacy)!==JSON.stringify({teer:assessment.derived.teer,experience3:assessment.derived.experience3,experience10:assessment.derived.experience10})||legacyCompletenessTeer!==assessment.derived.teer))causes.push('legacy_manual_experience_teer');if(docs==='all')causes.push('legacy_unverified_documents');if(docs==='none'&&inputs.verifiedCategories.length)causes.push('legacy_no_verified_documents');if(!withDetails&&inputs.details)causes.push('legacy_without_client_details');if(household)causes.push('legacy_household_size_counted');if(date!==asOf)causes.push('evaluation_date');found=causes;}
   }
   if(found&&found.length){row.status='explained';row.causes=found;}
   else if(stored.ruleVersion!==RULE_VERSION){row.status='explained';row.causes=['rules_version_changed'];}
   else row.status='unexplained';
  }
  rows.push(row);
 }
 const summary={files:rows.length,identical:rows.filter(r=>r.status==='identical').length,explained:rows.filter(r=>r.status==='explained').length,unexplained:rows.filter(r=>r.status==='unexplained').length};
 const after=await assessmentFingerprints(ownerId),ids=[...new Set([...Object.keys(before),...Object.keys(after)])].sort();
 const changedIds=ids.filter(id=>before[id]!==after[id]),digest=async(m:Record<string,string>)=>sha(Object.keys(m).sort().map(k=>k+':'+m[k]).join('|'));
 const integrity:ShadowIntegrity={filesBefore:Object.keys(before).length,filesAfter:Object.keys(after).length,assessmentUnchanged:changedIds.length===0,changedIds,digestBefore:await digest(before),digestAfter:await digest(after)};
 // One log row per file (status, causes, field differences, before/after assessment SHA-256) and one summary row.
 // Differences hold only numbers and pathway/check identifiers, no personal data.
 const at=new Date().toISOString(),runId=crypto.randomUUID();
 const caseLogs=rows.map(r=>db.insert(operationLogs).values({id:crypto.randomUUID(),candidateId:r.candidateId,operation:'engine_shadow_case',actor:'system',result:r.status,code:JSON.stringify({run:runId,history:r.historyId,causes:r.causes,differences:r.differences,before:before[r.candidateId]??'',after:after[r.candidateId]??''}),createdAt:at}));
 const summaryLog=db.insert(operationLogs).values({id:runId,operation:'engine_shadow',actor:'system',result:summary.unexplained?'unexplained_differences':integrity.assessmentUnchanged?'completed':'assessment_changed',code:[`engine=${ENGINE_VERSION}`,`rules=${RULE_VERSION}`,...Object.entries(summary).map(([k,v])=>k+'='+v),`assessment_unchanged=${integrity.assessmentUnchanged}`,`digest_before=${integrity.digestBefore}`,`digest_after=${integrity.digestAfter}`].join(';'),createdAt:at});
 await db.batch([summaryLog,...caseLogs]);
 return {rows,summary,integrity};
}

// Scheduled production shadow: runs once per engine + rules version, only while SHADOW_ONLY is on.
export async function shadowOnce():Promise<'skipped'|'already_done'|'completed'>{
 if(!shadowOnly())return 'skipped';
 const db=getDb(),marker=`engine=${ENGINE_VERSION};rules=${RULE_VERSION};`,done=await db.select({code:operationLogs.code}).from(operationLogs).where(eq(operationLogs.operation,'engine_shadow'));
 if(done.some(r=>r.code.startsWith(marker)))return 'already_done';
 await shadowAll(null);return 'completed';
}
