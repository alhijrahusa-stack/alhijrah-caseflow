import { jsPDF } from 'jspdf';
import { PDF_FONT_BASE64 } from './pdf-font';
import { OFFICE } from './branding';
import { PRIVACY_TITLE,TERMS_TITLE } from './legal';
import { educationLabels } from './model';
import { teerFromNoc } from './noc';
import { serviceOptions,industryOptions,triOptions,maritalOptions,employmentOptions,englishTestOptions,frenchTestOptions,lmiaOptions,relationshipOptions,ageOptions,scheduleOptions } from './intake-options';
import type { Choice } from './intake-options';
import type { Profile } from './model';
import type { IntakeDetails } from './intake';
// v2.2 Gate 4: signature = the fixed original signature bound at submission (image read from private R2). Records
// created before signature capture have none and are rendered as LEGACY_NOT_CAPTURED; nothing is back-filled.
export type SignatureSnapshot={signatureId:string;imageHash:string;signedAt:string;signedPayloadHash:string;legalVersion?:string|null};
export type AuthorizationSnapshot={reference:string;acceptedAt:string;version:string;authorizationText:string;termsText:readonly string[];profile:Profile;details:IntakeDetails;snapshotHash:string;signature?:SignatureSnapshot;signaturePngBase64?:string|null};
export function renderApplicationPdf(s:AuthorizationSnapshot){
 const doc=new jsPDF({unit:'mm',format:'a4',compress:true,putOnlyUsedFonts:true});
 doc.addFileToVFS('ALHArabic.ttf',PDF_FONT_BASE64);doc.addFont('ALHArabic.ttf','ALHArabic','normal');doc.setFont('ALHArabic');doc.setCreationDate(new Date(s.acceptedAt));doc.setFileId(s.snapshotHash.slice(0,32));doc.setProperties({title:'Application authorization | '+s.reference,author:OFFICE.name,subject:'Application and recorded data authorization',creator:OFFICE.name});
 const rtl={align:'right' as const,isInputVisual:false,isOutputVisual:true,isInputRtl:true,isOutputRtl:false};
 const ltr={isInputVisual:true,isOutputVisual:true,isInputRtl:false,isOutputRtl:false};let y=45;
 function page(){doc.setDrawColor(193,161,79);doc.setLineWidth(.4);doc.line(18,32,192,32);doc.setFont('helvetica','bold');doc.setFontSize(15);doc.setTextColor(18,43,68);doc.text('ALHIJRAH SERVICES',18,20);doc.setFont('helvetica','normal');doc.setFontSize(9);doc.text('CANADA APPLICATION & ASSESSMENT',18,26);doc.setFont('ALHArabic','normal');doc.setFontSize(12);doc.text('طلب التقييم والتفويض',192,24,rtl);}
 function need(height:number){if(y+height>270){doc.addPage();page();y=44;}}
 function wrap(value:string,max=171){const out:string[]=[];for(const raw of value.split('\n')){let line='';for(const word of raw.split(/\s+/)){const trial=line?line+' '+word:word;if(doc.getTextWidth(doc.processArabic(trial))>max&&line){out.push(line);line=word;}else line=trial;}out.push(line);}return out;}
 function text(value:string,size=11,color:[number,number,number]=[37,55,72]){doc.setFont('ALHArabic','normal');doc.setFontSize(size);doc.setTextColor(...color);for(const line of wrap(value)){need(7);doc.text(line,191,y,rtl);y+=6.7;}y+=3;}
 function heading(value:string){need(36);y+=5;doc.setFillColor(242,246,248);doc.roundedRect(18,y-5,174,12,2,2,'F');doc.setFontSize(12);doc.setTextColor(15,58,77);doc.text(value,188,y+2,rtl);y+=18;}
 function fact(label:string,value:string){
  if(!value)return;
  doc.setFont('ALHArabic','normal');doc.setFontSize(10.5);
  const arabic=/[\u0600-\u06ff]/.test(value);
  const lines=arabic?wrap(value,108):doc.splitTextToSize(value,108) as string[];
  need(Math.max(12,lines.length*6.7+3));doc.setTextColor(37,55,72);
  doc.text(label,191,y,rtl);
  for(const line of lines){doc.text(line,arabic?128:18,y,arabic?rtl:ltr);y+=6.7;}
  y+=3;
 }
 page();doc.setFont('helvetica','bold');doc.setFontSize(11);doc.setTextColor(18,43,68);doc.text(s.reference,18,y);doc.setFont('ALHArabic','normal');doc.setFontSize(11);doc.text('رقم الملف',192,y,rtl);y+=13;
 fact('الاسم الكامل',s.profile.fullName);fact('الهاتف',s.profile.phone);fact('البريد الإلكتروني',s.profile.email);fact('وقت الموافقة المسجّل',s.acceptedAt);fact('نسخة الإقرار',s.version);
 heading(PRIVACY_TITLE);text(s.authorizationText);
 heading(TERMS_TITLE);for(const [i,term] of s.termsText.entries())text(String(i+1)+' - '+term,10.5);
 heading('سجل الموافقة الإلكترونية');need(12);doc.setDrawColor(40,119,106);doc.rect(184,y-4,5,5);doc.line(184.8,y-1.3,186.1,y);doc.line(186.1,y,188.4,y-3);doc.setFontSize(11);doc.text('تم تحديد مربع الموافقة عند تقديم الطلب',180,y,rtl);y+=13;
 const p=s.profile,d=s.details;
 const choice=(label:string,value:string,options:Choice[])=>fact(label,options.find(option=>option[0]===value)?.[1]||'');
 const number=(label:string,value:number|null)=>{if(value!==null)fact(label,String(value));};
 heading('بيانات الطلب عند تقديم الإقرار');choice('الخدمة المطلوبة',d.service,serviceOptions);fact('الجنسية',p.nationality);fact('بلد الإقامة',p.country);fact('المدينة',d.city);choice('الحالة الاجتماعية',d.marital,maritalOptions);if(d.familySizeProvided)number('عدد أفراد الأسرة',p.familySize);fact('انتهاء جواز السفر',d.passportExpiry);choice('رفض سابق لطلب هجرة أو تأشيرة',d.previousRefusal,triOptions);
 heading('المؤهلات والخبرة');fact('المهنة',p.occupation);choice('قطاع العمل',d.industry,industryOptions);choice('الحالة الوظيفية',d.employment,employmentOptions);if(p.education!=='unknown')fact('المؤهل الدراسي',educationLabels[p.education]);choice('معادلة المؤهل الدراسي',p.eca,triOptions);fact('التصنيف المهني NOC',p.noc);number('المستوى المهني TEER (من NOC)',teerFromNoc(p.noc));choice('خبرة متصلة لمدة 12 شهرًا',p.continuous12,triOptions);choice('خبرة وظيفية مدفوعة الأجر',p.paidEmployee,triOptions);
 choice('عرض عمل',p.jobOffer,triOptions);fact('تصنيف عرض العمل NOC',d.offerNoc);number('مستوى عرض العمل TEER',d.offerTeer);choice('صاحب عمل معتمد',p.designated,triOptions);choice('شروط عرض العمل',p.jobConditions,triOptions);choice('توصية المجتمع',p.recommendation,triOptions);fact('المجتمع',p.community);choice('حالة LMIA',d.lmiaStatus,lmiaOptions);number('الأموال المتاحة بالدولار الكندي',p.funds);
 choice('اختبار الإنجليزية',d.englishTest,englishTestOptions);number('أدنى مستوى CLB للإنجليزية',p.englishMin);fact('تاريخ اختبار الإنجليزية',p.englishDate);choice('اختبار الفرنسية',d.frenchTest,frenchTestOptions);number('أدنى مستوى NCLC للفرنسية',p.frenchMin);fact('تاريخ اختبار الفرنسية',p.frenchDate);
 for(const [i,job] of d.jobs.entries()){if(!job.title&&!job.employer&&!job.duties&&!job.country&&!job.start&&!job.end&&job.schedule==='unknown'&&!job.fullTime)continue;heading('الخبرة المهنية '+(i+1));fact('المسمى',job.title);fact('جهة العمل',job.employer);fact('بلد العمل',job.country);number('ساعات العمل الأسبوعية',job.weekly_hours);fact('بداية العمل',job.start);fact('نهاية العمل',job.end);choice('نوع الدوام',job.schedule,scheduleOptions);if(job.schedule==='unknown'&&job.fullTime)fact('نوع الدوام','دوام كامل');if(job.duties)text(job.duties,10);}
 for(const [i,companion] of d.companions.entries()){if(!companion.name&&companion.relationship==='unknown'&&companion.ageGroup==='unknown'&&companion.accompany==='unknown')continue;heading('المرافق '+(i+1));fact('الاسم',companion.name);choice('صلة القرابة',companion.relationship,relationshipOptions);choice('الفئة العمرية',companion.ageGroup,ageOptions);choice('المرافقة',companion.accompany,triOptions);}
 if(s.details.notes){heading('ملاحظات المتقدم');text(s.details.notes,10);}
 heading('التوقيع الإلكتروني');
 if(s.signature&&s.signaturePngBase64){need(40);doc.setDrawColor(193,161,79);doc.rect(118,y-4,74,30);doc.addImage('data:image/png;base64,'+s.signaturePngBase64,'PNG',120,y-2,70,26,undefined,'FAST');y+=32;fact('وقت التوقيع (UTC)',s.signature.signedAt);need(14);doc.setFont('helvetica','normal');doc.setFontSize(7);doc.setTextColor(100,113,124);doc.text('Signature image SHA-256: '+s.signature.imageHash,18,y,ltr);y+=4;doc.text('Signed snapshot SHA-256: '+s.signature.signedPayloadHash,18,y,ltr);y+=7;text('التوقيع والإقرار قرينة قبول داخل خدمة المكتب، وليسا توقيعًا حكوميًا معتمدًا أو دليل هوية منفردًا.',9);}
 else{need(12);doc.setFont('helvetica','normal');doc.setFontSize(9);doc.setTextColor(100,113,124);doc.text('LEGACY_NOT_CAPTURED',18,y,ltr);y+=5;text('لم يُلتقط توقيع مرسوم لهذا الطلب عند تقديمه؛ لا يُضاف توقيع بأثر رجعي.',9);}
 need(18);doc.setFont('helvetica','normal');doc.setFontSize(7);doc.setTextColor(100,113,124);doc.text('SHA-256: '+s.snapshotHash,18,y+6,ltr);y+=13;
 const pages=doc.getNumberOfPages();for(let i=1;i<=pages;i++){doc.setPage(i);doc.setDrawColor(214,220,225);doc.line(18,279,192,279);doc.setFont('helvetica','normal');doc.setFontSize(8);doc.setTextColor(90,109,123);doc.text(OFFICE.email,18,286,ltr);doc.text(String(i)+' / '+String(pages),192,286,{...ltr,align:'right'});}
 return new Uint8Array(doc.output('arraybuffer'));
}
