// v2.2 Gate 5 — client-facing service catalog and explicit service requests. The catalog shows active services in the
// office's explicitly configured currency only (no assumed price or currency). A CRM event and a staff task are created
// ONLY by an explicit client request (client_service_requests, idempotent per request key), in the same batch.
import { z } from 'zod';
import { getDb } from '@/db';
import { officeServiceCatalog,clientServiceRequests,events,tasks,candidates } from '@/db/schema';
import { and,eq,desc } from 'drizzle-orm';
import { ApiError } from './api-error';
import { jcsHash } from './v22-core';
import { officeCurrency } from './billing';

export const serviceRequestSchema=z.object({serviceId:z.string().min(2).max(64),serviceVersion:z.number().int().min(1),note:z.string().trim().max(2000).nullable(),requestKey:z.string().min(8).max(200)}).strict();
/** Public/client catalog: active services in the office currency; null currency → empty (nothing is assumed). */
export async function publicCatalog(){
 const currency=await officeCurrency();if(!currency)return {currency:null,services:[]};
 const rows=await getDb().select().from(officeServiceCatalog).where(and(eq(officeServiceCatalog.active,1),eq(officeServiceCatalog.currency,currency))).orderBy(officeServiceCatalog.serviceId);
 return {currency,services:rows.map(r=>({serviceId:r.serviceId,nameAr:r.nameAr,nameEn:r.nameEn,priceCents:r.priceCents,currency:r.currency,version:r.version}))};
}
export async function requestService(caseId:string,input:z.infer<typeof serviceRequestSchema>){
 const db=getDb(),requestHash=await jcsHash({caseId,serviceId:input.serviceId,serviceVersion:input.serviceVersion,note:input.note});
 const prior=async()=>{const [r]=await db.select().from(clientServiceRequests).where(eq(clientServiceRequests.requestKey,input.requestKey)).limit(1);if(!r)return null;if(r.requestHash!==requestHash||r.caseId!==caseId)throw new ApiError(409,'مفتاح الطلب مستخدم لطلب مختلف.');return r;};
 const p=await prior();if(p)return {requestId:p.requestId,state:p.state,replayed:true};
 const [svc]=await db.select().from(officeServiceCatalog).where(eq(officeServiceCatalog.serviceId,input.serviceId)).limit(1);
 if(!svc||!svc.active)throw new ApiError(422,'الخدمة غير متاحة.');if(svc.version!==input.serviceVersion)throw new ApiError(409,'تغيّرت بيانات الخدمة؛ حدّث الصفحة.');
 const [c]=await db.select({ownerId:candidates.ownerId,reference:candidates.reference}).from(candidates).where(eq(candidates.id,caseId)).limit(1);
 const requestId=crypto.randomUUID(),now=new Date().toISOString();
 try{await db.batch([
  db.insert(clientServiceRequests).values({requestId,caseId,serviceId:svc.serviceId,serviceVersion:svc.version,requestKey:input.requestKey,requestHash,note:input.note,createdAt:now,updatedAt:now}),
  db.insert(events).values({id:crypto.randomUUID(),ownerId:c.ownerId,candidateId:caseId,action:'طلب العميل خدمة: '+svc.nameAr,note:input.note?input.note.slice(0,300):'',createdAt:now}),
  db.insert(tasks).values({id:crypto.randomUUID(),ownerId:c.ownerId,candidateId:caseId,title:'طلب خدمة من العميل: '+svc.nameAr,dueDate:now.slice(0,10),priority:'normal',systemKey:'service-request:'+requestId,createdAt:now,updatedAt:now}),
 ]);}catch(e){const again=await prior().catch(()=>null);if(again)return {requestId:again.requestId,state:again.state,replayed:true};throw e;}
 return {requestId,state:'REQUESTED',replayed:false};
}
export async function caseServiceRequests(caseId:string){return getDb().select({requestId:clientServiceRequests.requestId,serviceId:clientServiceRequests.serviceId,nameAr:officeServiceCatalog.nameAr,nameEn:officeServiceCatalog.nameEn,state:clientServiceRequests.state,note:clientServiceRequests.note,createdAt:clientServiceRequests.createdAt}).from(clientServiceRequests).innerJoin(officeServiceCatalog,eq(officeServiceCatalog.serviceId,clientServiceRequests.serviceId)).where(eq(clientServiceRequests.caseId,caseId)).orderBy(desc(clientServiceRequests.createdAt)).limit(50);}
