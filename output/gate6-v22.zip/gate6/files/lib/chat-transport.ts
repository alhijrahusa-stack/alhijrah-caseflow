// v2.2 Gate 5 — chat transport. D1 is the only source of truth; the CaseChatRoom Durable Object (binding CHAT_ROOMS)
// only fans committed frames out to open WebSockets of one case. Without the binding, or if a publish fails, clients
// still converge through HTTP replay (afterSequence keyset), so a lost push or an evicted room never loses a message.
// Each socket carries the principal it was opened for; the room re-validates it against D1 on every inbound frame and
// before relaying (at most 30 s old), so a revoked session or a deactivated staff member is disconnected (code 4401).
import { env } from 'cloudflare:workers';
import { getDb } from '@/db';
import { clientSessions,users } from '@/db/schema';
import { and,eq,gt,isNull } from 'drizzle-orm';
import { sha } from './security';

export type SocketPrincipal={kind:'CLIENT';caseId:string;sessionHash:string}|{kind:'STAFF';caseId:string;userId:string};
function rooms(){const n=(env as unknown as {CHAT_ROOMS?:DurableObjectNamespace}).CHAT_ROOMS;return n&&typeof n.idFromName==='function'?n:null;}
export const transportMode=()=>rooms()?'WEBSOCKET':'HTTP_POLL';
/** Best-effort fan-out of a committed frame (never the commit itself). */
export async function publish(caseId:string,frame:unknown){
 const ns=rooms();if(!ns)return false;
 try{const r=await ns.get(ns.idFromName(caseId)).fetch('https://chat-room/broadcast',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(frame)});return r.ok;}catch{return false;}
}
/** Forward an authenticated WebSocket upgrade to the case room with the server-derived principal. */
export async function connect(request:Request,principal:SocketPrincipal){
 const ns=rooms();if(!ns)return Response.json({error:'WEBSOCKET_UNAVAILABLE',transport:'HTTP_POLL'},{status:426});
 if(request.headers.get('upgrade')?.toLowerCase()!=='websocket')return Response.json({error:'UPGRADE_REQUIRED'},{status:426});
 // AC-32: browsers always send Origin on a WebSocket handshake; a missing or foreign Origin is refused (the session
 // travels in the HttpOnly cookie, never in the URL).
 if(request.headers.get('origin')!==new URL(request.url).origin)return Response.json({error:'ORIGIN_REJECTED'},{status:403});
 const headers=new Headers(request.headers);headers.set('X-Chat-Principal',JSON.stringify(principal));
 const r=await ns.get(ns.idFromName(principal.caseId)).fetch(new Request('https://chat-room/connect',{headers}));
 // A fresh response (mutable headers) carrying the socket, so the framework can finish the request normally.
 return r.status===101&&r.webSocket?new Response(null,{status:101,webSocket:r.webSocket}):r;
}
/** D1 re-validation of a socket principal (used by the room). */
export async function stillAuthorized(p:SocketPrincipal,now=Date.now()){
 const db=getDb();
 if(p.kind==='CLIENT'){const [s]=await db.select({id:clientSessions.candidateId}).from(clientSessions).where(and(eq(clientSessions.tokenHash,p.sessionHash),eq(clientSessions.candidateId,p.caseId),eq(clientSessions.scope,'full_case'),isNull(clientSessions.revokedAt),gt(clientSessions.expiresAt,now))).limit(1);return !!s;}
 const [u]=await db.select({active:users.active,role:users.role}).from(users).where(eq(users.userId,p.userId)).limit(1);if(!u||u.active!==1||(u.role!=='STAFF'&&u.role!=='MANAGER'))return false;
 if(u.role==='MANAGER')return true;
 const { loadAuthority,can }=await import('./rbac');return can(await loadAuthority(p.userId),'chat',now);
}
export const sessionHashOf=(token:string)=>sha(token);
