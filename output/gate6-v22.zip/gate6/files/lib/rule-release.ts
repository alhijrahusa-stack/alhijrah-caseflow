// v2.2 Gate 3 — Single-Authority Manager Seal (09 §4) on D1 + R2. One active MANAGER imports sources and payloads
// and creates+seals a release in one UI operation; the author may seal his own payload, no second account or approval.
// Internally: validate (schema, sources and their stored bytes, totality, obligations, bounds, overlap) -> one D1 batch
// that inserts the release as BUILDING, its intervals, the SEALED transition, and optionally the CAS activation. A
// failed statement rolls back the whole batch. SEALED is never inserted directly (trigger release_insert_guard) and the
// browser never supplies state, actor or validation report. AI and SYSTEM never publish a legal rule.
import { env } from 'cloudflare:workers';
import { getDb } from '@/db';
import { sourceSnapshots, ruleBundles, releaseSets, releaseIntervals, ruleActivation, operationLogs, users } from '@/db/schema';
import { eq, inArray, desc } from 'drizzle-orm';
import { ApiError } from './api-error';
import { requireManager } from './rbac';
import type { Authority } from './rbac';
import { jcs, jcsHash, sha256Hex } from './v22-core';
import { validateBundle, validateRelease, allowedSourceUrl, SOURCE_HOSTS } from './rule-import';
import type { ReleaseInterval, SourceFacts, StoredBundle } from './rule-import';
import type { ActiveRelease, LoadedBundle } from './rule-resolver';
import type { DateBasis } from './pathways';

const MAX_SOURCE_BYTES = 5 * 1024 * 1024;
const bucket = () => { const b = (env as unknown as { BUCKET?: R2Bucket }).BUCKET; if (!b) throw new ApiError(503, 'تخزين المصادر غير متاح.'); return b; };
const managerId = (a: Authority) => { requireManager(a); return a.actor.userId; };
const triggerCode = (e: unknown) => { const m = e instanceof Error ? e.message + ' ' + String((e as { cause?: unknown }).cause ?? '') : String(e); return /SEALED_MUST_BE_EARNED|SEALED_RELEASE|RULE_INTERVAL_OVERLAP|INVALID_RELEASE_TRANSITION|MANAGER_REQUIRED|EMPTY_RELEASE|INVALID_RULE_ACTIVATION|UNIQUE constraint failed/.exec(m)?.[0] ?? null; };

// Source snapshot: the manager uploads the exact bytes of an official page/file; the server hashes and stores them.
// Change detection and allowlisted live fetching create drafts only; nothing here fetches the web.
export async function importSource(a: Authority, input: { sourceId: string; officialUrl: string; authority: string; contentBase64: string }) {
  const actor = managerId(a);
  if (!allowedSourceUrl(input.officialUrl)) throw new ApiError(422, 'رابط المصدر يجب أن يكون HTTPS لجهة حكومية كندية رسمية: ' + SOURCE_HOSTS.join('، '));
  let bytes: Uint8Array;
  try { bytes = Uint8Array.from(atob(input.contentBase64), c => c.charCodeAt(0)); } catch { throw new ApiError(422, 'محتوى المصدر غير صالح (base64).'); }
  if (!bytes.length || bytes.length > MAX_SOURCE_BYTES) throw new ApiError(422, 'حجم المصدر يجب أن يكون بين 1 بايت و5MB.');
  const sha = await sha256Hex(bytes), key = 'rules/sources/' + sha, db = getDb();
  const [existing] = await db.select().from(sourceSnapshots).where(eq(sourceSnapshots.sourceId, input.sourceId)).limit(1);
  if (existing) { if (existing.contentSha256 === sha && existing.officialUrl === input.officialUrl) return { sourceId: existing.sourceId, contentSha256: sha, replayed: true }; throw new ApiError(409, 'معرّف المصدر مستخدم لمحتوى آخر؛ المصادر غير قابلة للتعديل.'); }
  await bucket().put(key, bytes, { customMetadata: { sha256: sha, officialUrl: input.officialUrl, authority: input.authority.slice(0, 200) } });
  const now = new Date().toISOString();
  try {
    await db.batch([
      db.insert(sourceSnapshots).values({ sourceId: input.sourceId, officialUrl: input.officialUrl, objectKey: key + ':' + input.sourceId, contentSha256: sha, fetchedAt: now }),
      db.insert(operationLogs).values({ id: crypto.randomUUID(), operation: 'rule_source_import', actor, result: 'stored', code: jcs({ sourceId: input.sourceId, sha256: sha, url: input.officialUrl, authority: input.authority.slice(0, 200) }), createdAt: now }),
    ]);
  } catch (e) { if (triggerCode(e)) throw new ApiError(409, 'المصدر مسجل مسبقًا.'); throw e; }
  return { sourceId: input.sourceId, contentSha256: sha, replayed: false };
}
const objectKeyOf = (stored: string) => stored.slice(0, stored.lastIndexOf(':'));
// Rehash the stored R2 bytes of each source: a missing or altered object blocks validation.
async function sourceFacts(ids: readonly string[]): Promise<SourceFacts> {
  const out = new Map<string, { contentSha256: string; storedSha256: string | null }>();
  if (!ids.length) return out;
  const rows = await getDb().select().from(sourceSnapshots).where(inArray(sourceSnapshots.sourceId, [...new Set(ids)]));
  for (const r of rows) { const obj = await bucket().get(objectKeyOf(r.objectKey)); out.set(r.sourceId, { contentSha256: r.contentSha256, storedSha256: obj ? await sha256Hex(new Uint8Array(await obj.arrayBuffer())) : null }); }
  return out;
}
export async function importBundle(a: Authority, input: { payload: unknown; payloadHash: string; bundleId?: string }) {
  const actor = managerId(a), ids = Array.isArray((input.payload as { sourceIds?: unknown })?.sourceIds) ? ((input.payload as { sourceIds: unknown[] }).sourceIds.filter(x => typeof x === 'string') as string[]) : [];
  const v = await validateBundle(input.payload, input.payloadHash, await sourceFacts(ids));
  if (!v.ok) throw new ApiError(422, 'الحمولة غير مكتملة أو غير مطابقة: ' + v.codes.slice(0, 12).join(' | '));
  const db = getDb(), [dup] = await db.select({ bundleId: ruleBundles.bundleId }).from(ruleBundles).where(eq(ruleBundles.payloadSha256, v.payloadHash)).limit(1);
  if (dup) return { bundleId: dup.bundleId, payloadHash: v.payloadHash, replayed: true };
  const bundleId = input.bundleId ?? 'bundle:' + v.payloadHash.slice(0, 32), now = new Date().toISOString();
  try {
    await db.batch([
      db.insert(ruleBundles).values({ bundleId, payload: v.canonical, payloadSha256: v.payloadHash, sourceId: v.bundle.sourceIds[0], createdBy: actor, createdAt: now }),
      db.insert(operationLogs).values({ id: crypto.randomUUID(), operation: 'rule_bundle_import', actor, result: 'stored', code: jcs({ bundleId, payloadSha256: v.payloadHash, program: v.bundle.program, family: v.bundle.family }), createdAt: now }),
    ]);
  } catch (e) { if (triggerCode(e)) throw new ApiError(409, 'معرّف الحزمة مستخدم مسبقًا.'); throw e; }
  return { bundleId, payloadHash: v.payloadHash, replayed: false };
}
async function storedBundles(ids: readonly string[]): Promise<Map<string, StoredBundle>> {
  const rows = ids.length ? await getDb().select().from(ruleBundles).where(inArray(ruleBundles.bundleId, [...new Set(ids)])) : [];
  return new Map(rows.map(r => [r.bundleId, { bundleId: r.bundleId, payload: r.payload, payloadSha256: r.payloadSha256 }]));
}
async function sourcesOfBundles(bundles: ReadonlyMap<string, StoredBundle>) {
  const ids = [...bundles.values()].flatMap(b => { try { const p = JSON.parse(b.payload) as { sourceIds?: unknown }; return Array.isArray(p.sourceIds) ? p.sourceIds.filter((x): x is string => typeof x === 'string') : []; } catch { return []; } });
  return sourceFacts(ids);
}
// Preview: the exact manifest the manager seals (shown in the UI before the single seal action).
export async function previewRelease(a: Authority, intervals: readonly ReleaseInterval[]) {
  managerId(a);
  const bundles = await storedBundles(intervals.map(i => i.bundleId));
  return validateRelease(intervals, bundles, await sourcesOfBundles(bundles));
}
export async function createAndSealRelease(a: Authority, input: { intervals: ReleaseInterval[]; manifestHash: string; activate: { expectedGeneration: number; reasonCode: string } | null }) {
  const actor = managerId(a), bundles = await storedBundles(input.intervals.map(i => i.bundleId));
  const v = await validateRelease(input.intervals, bundles, await sourcesOfBundles(bundles));
  if (v.codes.length) throw new ApiError(422, 'لا يمكن الختم: ' + v.codes.slice(0, 12).join(' | '));
  if (v.manifestHash !== input.manifestHash) throw new ApiError(409, 'بصمة البيان تغيّرت منذ المعاينة؛ راجع المعاينة ثم اختم.');
  const db = getDb(), [existing] = await db.select().from(releaseSets).where(eq(releaseSets.manifestSha256, v.manifestHash)).limit(1);
  if (existing && !input.activate) return { releaseId: existing.releaseId, manifestHash: v.manifestHash, state: existing.state, validationCodes: [] as string[], replayed: true };
  const releaseId = existing?.releaseId ?? 'release:' + v.manifestHash.slice(0, 32), now = new Date().toISOString(), reportHash = await jcsHash(v.report);
  const statements = [];
  if (!existing) {
    statements.push(db.insert(releaseSets).values({ releaseId, manifestSha256: v.manifestHash, state: 'BUILDING', createdBy: actor }));
    for (const i of input.intervals) statements.push(db.insert(releaseIntervals).values({ releaseId, programId: i.programId, family: i.family, phase: i.phase, dateBasis: i.dateBasis, effectiveFrom: i.effectiveFrom, effectiveToExclusive: i.effectiveToExclusive, bundleId: i.bundleId }));
    statements.push(db.update(releaseSets).set({ state: 'SEALED', sealedBy: actor, sealedAt: now, validationReportHash: reportHash }).where(eq(releaseSets.releaseId, releaseId)));
  }
  // Activation CAS: activation_guard requires generation = OLD + 1 and a SEALED release, so a stale expectedGeneration
  // aborts the whole batch (release included) rather than publishing a partial state.
  if (input.activate) statements.push(db.update(ruleActivation).set({ releaseId, generation: input.activate.expectedGeneration + 1, changedBy: actor, changedAt: now }).where(eq(ruleActivation.singleton, 1)));
  statements.push(db.insert(operationLogs).values({ id: crypto.randomUUID(), operation: 'rule_release_seal', actor, result: input.activate ? 'sealed_activated' : 'sealed', code: jcs({ releaseId, manifestSha256: v.manifestHash, validationReportHash: reportHash, reasonCode: input.activate?.reasonCode ?? null }), createdAt: now }));
  try { await db.batch(statements as [typeof statements[number], ...typeof statements]); }
  catch (e) { const c = triggerCode(e); if (c === 'INVALID_RULE_ACTIVATION') throw new ApiError(409, 'تغيّر جيل التفعيل؛ أعد التحميل ثم حاول.'); if (c) throw new ApiError(409, 'رُفض الختم: ' + c); throw e; }
  return { releaseId, manifestHash: v.manifestHash, state: 'SEALED' as const, validationCodes: [] as string[], replayed: false };
}
export async function activateRelease(a: Authority, input: { expectedGeneration: number; releaseId: string | null; reasonCode: string }) {
  const actor = managerId(a), db = getDb(), now = new Date().toISOString();
  if (input.releaseId) { const [r] = await db.select({ state: releaseSets.state }).from(releaseSets).where(eq(releaseSets.releaseId, input.releaseId)).limit(1); if (!r || r.state !== 'SEALED') throw new ApiError(422, 'لا يُفعّل إلا إصدار مختوم.'); }
  try {
    await db.batch([
      db.update(ruleActivation).set({ releaseId: input.releaseId, generation: input.expectedGeneration + 1, changedBy: actor, changedAt: now }).where(eq(ruleActivation.singleton, 1)),
      db.insert(operationLogs).values({ id: crypto.randomUUID(), operation: 'rule_activation', actor, result: input.releaseId ? 'activated' : 'deactivated', code: jcs({ releaseId: input.releaseId, generation: input.expectedGeneration + 1, reasonCode: input.reasonCode }), createdAt: now }),
    ]);
  } catch (e) { if (triggerCode(e) === 'INVALID_RULE_ACTIVATION') throw new ApiError(409, 'تغيّر جيل التفعيل؛ أعد التحميل ثم حاول.'); throw e; }
  const [row] = await db.select().from(ruleActivation).where(eq(ruleActivation.singleton, 1)).limit(1);
  return { releaseId: row.releaseId, generation: row.generation, activatedAt: row.changedAt };
}

// ---- Read side used by the resolver and the engine (D1 is the authority; payload bytes rehashed by the resolver).
export async function loadActiveRelease(): Promise<ActiveRelease | null> {
  const db = getDb(), [act] = await db.select().from(ruleActivation).where(eq(ruleActivation.singleton, 1)).limit(1);
  if (!act?.releaseId) return null;
  const [rel] = await db.select().from(releaseSets).where(eq(releaseSets.releaseId, act.releaseId)).limit(1);
  if (!rel || rel.state !== 'SEALED' || !rel.sealedBy || !rel.validationReportHash) return null;
  const [sealer] = await db.select({ role: users.role }).from(users).where(eq(users.userId, rel.sealedBy)).limit(1);
  if (sealer?.role !== 'MANAGER') return null;
  const intervals = await db.select().from(releaseIntervals).where(eq(releaseIntervals.releaseId, rel.releaseId));
  return { releaseId: rel.releaseId, manifestSha256: rel.manifestSha256, generation: act.generation, intervals: intervals.map(i => ({ programId: i.programId, family: i.family, phase: i.phase, dateBasis: i.dateBasis as DateBasis, effectiveFrom: i.effectiveFrom, effectiveToExclusive: i.effectiveToExclusive, bundleId: i.bundleId })) };
}
export async function loadBundleRow(bundleId: string): Promise<LoadedBundle | null> {
  const [r] = await getDb().select().from(ruleBundles).where(eq(ruleBundles.bundleId, bundleId)).limit(1);
  return r ? { bundleId: r.bundleId, payload: r.payload, payloadSha256: r.payloadSha256 } : null;
}
export async function citationSources(): Promise<Map<string, { officialUrl: string; sourceHash: string }>> {
  return new Map((await getDb().select().from(sourceSnapshots)).map(r => [r.sourceId, { officialUrl: r.officialUrl, sourceHash: r.contentSha256 }]));
}
// Program identities from 05 "Program coverage contract": visible to staff as NOT_CONFIGURED until an active sealed
// interval exists. PNP streams are listed only once the owner names them (I06); no generic province program.
export const PROGRAM_IDENTITIES = ['EE_FSWP', 'EE_FSTP', 'EE_CEC', 'EE_CRS', 'AIP', 'RCIP_PILOT', 'RCIP_PERMANENT', 'FCIP', 'NOC_2021'] as const;
export async function rulesState() {
  const db = getDb(), active = await loadActiveRelease(), [act] = await db.select().from(ruleActivation).where(eq(ruleActivation.singleton, 1)).limit(1);
  const releases = await db.select({ releaseId: releaseSets.releaseId, manifestSha256: releaseSets.manifestSha256, state: releaseSets.state, sealedBy: releaseSets.sealedBy, sealedAt: releaseSets.sealedAt, createdBy: releaseSets.createdBy }).from(releaseSets).orderBy(desc(releaseSets.sealedAt)).limit(50);
  const bundles = await db.select({ bundleId: ruleBundles.bundleId, payloadSha256: ruleBundles.payloadSha256, createdAt: ruleBundles.createdAt, createdBy: ruleBundles.createdBy }).from(ruleBundles).orderBy(desc(ruleBundles.createdAt)).limit(100);
  const sources = await db.select({ sourceId: sourceSnapshots.sourceId, officialUrl: sourceSnapshots.officialUrl, contentSha256: sourceSnapshots.contentSha256, fetchedAt: sourceSnapshots.fetchedAt }).from(sourceSnapshots).orderBy(desc(sourceSnapshots.fetchedAt)).limit(200);
  const configured = new Set(active?.intervals.map(i => i.programId) ?? []);
  return {
    activation: { releaseId: act?.releaseId ?? null, generation: act?.generation ?? 0, activatedAt: act?.changedAt ?? null, effective: !!active },
    activeIntervals: active?.intervals ?? [], releases, bundles, sources,
    readiness: PROGRAM_IDENTITIES.map(programId => ({ programId, status: configured.has(programId) ? 'CONFIGURED' : 'NOT_CONFIGURED' })),
  };
}
