// v2.2 Gate 3 — assessment commit for the single engine (09 §3.5–3.7, 05). The same assessment_history table holds
// every result (append-only, triggers in 0025). canonical_input_hash = SHA-256 of the JCS of facts, evidence, programs,
// event context, release manifest, bundle hashes, engine, purpose and mode (no run time, locale or headers).
// - Identical canonical input => the existing row is returned; no new row (unique index assessment_canonical_unique).
// - Request idempotency: durable_jobs(kind ASSESSMENT) keeps request_key + request_hash; the same key with a different
//   payload => 409; a replay returns the recorded assessment.
// - CAS: the history insert, the pointer move and publication_revision+1 commit in one D1 batch whose candidates update
//   aborts (CHECK publication_revision>=0) unless data_revision, publication_revision and the rule activation
//   generation are still the ones the result was computed from. A failed batch leaves no partial row.
// - SHADOW writes history only and never moves a pointer or the publication revision.
import { getDb } from '@/db';
import { candidates, clientCases, documents, caseCrs, eligibilityRuns, assessmentHistory, durableJobs, ruleActivation } from '@/db/schema';
import { and, eq, desc, sql } from 'drizzle-orm';
import { ApiError } from './api-error';
import { profileSchema } from './model';
import { detailsSchema } from './intake';
import { crsSchema } from './crs';
import { eligibilitySchema } from './eligibility';
import { buildV22Assessment } from './assessment';
import type { ProgramRef, AssessmentStaffV22 } from './assessment';
import { V22_ENGINE_VERSION } from './normalization';
import { loadActiveRelease, loadBundleRow, citationSources } from './rule-release';
import type { EventContext } from './rule-resolver';
import { ELIGIBILITY_FAMILY } from './rule-import';
import { jcsHash, torontoDate, isRealDate } from './v22-core';

export type RecomputeRequest = { requestKey: string; expectedDataRevision: number; expectedPublicationRevision: number; assessmentMode: 'PRODUCTION' | 'SHADOW'; selectedPrograms: ProgramRef[]; eventContext: Omit<EventContext, 'approvalForSubmissionAt'> & { approvalForSubmissionAt?: string | null }; assessmentPurpose: 'RAPID_SCREENING' | 'VERIFIED_SCREENING' };
export type CommitOutcome = { status: 'CREATED' | 'DEDUPLICATED' | 'REPLAYED'; assessmentId: string; assessment: AssessmentStaffV22 };
type CandidateRow = typeof candidates.$inferSelect;

async function engineInputs(c: CandidateRow) {
  const db = getDb();
  const [cc] = await db.select({ details: clientCases.details }).from(clientCases).where(eq(clientCases.candidateId, c.id)).limit(1);
  const verified = await db.select({ category: documents.category }).from(documents).where(and(eq(documents.candidateId, c.id), eq(documents.verified, true)));
  const [crsRow] = await db.select({ inputs: caseCrs.inputs }).from(caseCrs).where(eq(caseCrs.candidateId, c.id)).limit(1);
  const [elig] = await db.select({ inputs: eligibilityRuns.inputs, result: eligibilityRuns.result }).from(eligibilityRuns).where(eq(eligibilityRuns.candidateId, c.id)).orderBy(desc(eligibilityRuns.createdAt)).limit(1);
  const crs = crsRow ? crsSchema.safeParse(JSON.parse(crsRow.inputs)) : null, e = elig ? eligibilitySchema.safeParse(JSON.parse(elig.inputs)) : null;
  return {
    profile: profileSchema.parse({ ...JSON.parse(c.profile), consent: true }), details: cc ? detailsSchema.parse(JSON.parse(cc.details)) : null,
    crsInput: crs?.success ? crs.data : null, eligibility: e?.success ? { inputs: e.data, asOf: (JSON.parse(elig!.result) as { asOf?: string }).asOf ?? e.data.asOf } : null,
    verifiedCategories: [...new Set(verified.map(v => v.category))].sort(),
  };
}
// Server-authoritative context: approvalForSubmissionAt always comes from candidates (client timestamps are no
// authority); dates must be real calendar dates and the profile date cannot be in the future (Toronto).
export function serverEventContext(c: CandidateRow, ctx: RecomputeRequest['eventContext'], now = Date.now()): EventContext {
  const today = torontoDate(now);
  if (!isRealDate(ctx.profileDate) || ctx.profileDate > today) throw new ApiError(422, 'تاريخ الملف يجب أن يكون تاريخًا حقيقيًا لا يتجاوز اليوم.');
  for (const k of ['invitationDate', 'applicationDate', 'recommendationIssuedOn'] as const) if (ctx[k] !== null && !isRealDate(ctx[k])) throw new ApiError(422, 'تاريخ غير صالح: ' + k);
  return { profileDate: ctx.profileDate, invitationDate: ctx.invitationDate, applicationDate: ctx.applicationDate, recommendationIssuedOn: ctx.recommendationIssuedOn, approvalForSubmissionAt: c.approvalForSubmissionAt ?? null };
}
const findCanonical = async (caseId: string, canonicalHash: string, ruleHash: string, mode: string, purpose: string) => {
  const [row] = await getDb().select({ id: assessmentHistory.id, outputJson: assessmentHistory.outputJson }).from(assessmentHistory).where(and(eq(assessmentHistory.candidateId, caseId), eq(assessmentHistory.canonicalInputHash, canonicalHash), eq(assessmentHistory.ruleBundleHash, ruleHash), eq(assessmentHistory.engineVersion, V22_ENGINE_VERSION), eq(assessmentHistory.assessmentMode, mode), eq(assessmentHistory.assessmentPurpose, purpose))).limit(1);
  return row ? { id: row.id, assessment: JSON.parse(row.outputJson) as AssessmentStaffV22 } : null;
};
const byId = async (id: string) => { const [row] = await getDb().select({ outputJson: assessmentHistory.outputJson }).from(assessmentHistory).where(eq(assessmentHistory.id, id)).limit(1); return row ? JSON.parse(row.outputJson) as AssessmentStaffV22 : null; };
const jobRow = (caseId: string, actor: string, requestKey: string, requestHash: string, payload: unknown, resultRef: string, now: string) => ({ jobId: 'assessment:' + requestKey, caseId, kind: 'ASSESSMENT', requestKey, requestHash, payload: JSON.stringify(payload), state: 'SUCCEEDED', attempts: 1, nextAtMs: Date.parse(now), createdBy: actor, createdAt: now, updatedAt: now, resultRef });

export async function commitAssessment(caseId: string, actorUserId: string, req: RecomputeRequest): Promise<CommitOutcome> {
  const db = getDb(), { requestKey, ...body } = req, requestHash = await jcsHash({ caseId, ...body });
  const replay = async (): Promise<CommitOutcome | null> => {
    const [job] = await db.select().from(durableJobs).where(eq(durableJobs.requestKey, requestKey)).limit(1);
    if (!job) return null;
    if (job.requestHash !== requestHash || job.caseId !== caseId || job.kind !== 'ASSESSMENT') throw new ApiError(409, 'مفتاح الطلب مستخدم لطلب مختلف.');
    const a = job.resultRef ? await byId(job.resultRef) : null;
    if (!a) throw new ApiError(409, 'الطلب السابق بهذا المفتاح لم يكتمل.');
    return { status: 'REPLAYED', assessmentId: job.resultRef!, assessment: a };
  };
  const prior = await replay(); if (prior) return prior;
  const [c] = await db.select().from(candidates).where(eq(candidates.id, caseId)).limit(1);
  if (!c) throw new ApiError(404, 'الملف غير موجود.');
  const [act] = await db.select({ generation: ruleActivation.generation }).from(ruleActivation).where(eq(ruleActivation.singleton, 1)).limit(1);
  const active = await loadActiveRelease(), eventContext = serverEventContext(c, req.eventContext);
  const built = await buildV22Assessment({ caseId, dataRevision: c.dataRevision, mode: req.assessmentMode, purpose: req.assessmentPurpose, eventContext, selectedPrograms: req.selectedPrograms, normalization: await engineInputs(c), active, loadBundle: loadBundleRow, sources: await citationSources() });
  const now = new Date().toISOString();
  const generation = act?.generation ?? 0;
  const guardOn = (publicationRevision: number) => sql`data_revision = ${c.dataRevision} AND publication_revision = ${publicationRevision} AND (SELECT generation FROM rule_activation WHERE singleton = 1) = ${generation}`;
  const pointerField = req.assessmentPurpose === 'VERIFIED_SCREENING' ? 'latestVerifiedAssessmentId' : 'latestRapidAssessmentId';
  const dedupe = async (): Promise<CommitOutcome | null> => {
    const hit = await findCanonical(caseId, built.canonicalHash, built.ruleBundleHash, req.assessmentMode, req.assessmentPurpose);
    if (!hit) return null;
    const job = db.insert(durableJobs).values(jobRow(caseId, actorUserId, requestKey, requestHash, body, hit.id, now)).onConflictDoNothing();
    const [cur] = await db.select({ publicationRevision: candidates.publicationRevision, verified: candidates.latestVerifiedAssessmentId, rapid: candidates.latestRapidAssessmentId }).from(candidates).where(eq(candidates.id, caseId)).limit(1);
    const pointer = req.assessmentPurpose === 'VERIFIED_SCREENING' ? cur?.verified : cur?.rapid;
    // The same content was published before but the pointer moved on (data changed and came back): republish the
    // existing row under the same CAS guard instead of inserting a duplicate.
    if (req.assessmentMode === 'PRODUCTION' && cur && pointer !== hit.id) {
      try { await db.batch([db.update(candidates).set({ publicationRevision: sql`CASE WHEN ${guardOn(cur.publicationRevision)} THEN publication_revision + 1 ELSE -1 END`, [pointerField]: hit.id }).where(eq(candidates.id, caseId)), job]); }
      catch { throw new ApiError(409, 'تغيّرت بيانات الملف أو القواعد أثناء الحساب؛ لم يُنشر أي جزء. أعد المحاولة.'); }
    } else await job;
    const again = await replay(); if (again && again.assessmentId !== hit.id) return again;
    return { status: 'DEDUPLICATED', assessmentId: hit.id, assessment: hit.assessment };
  };
  const dup = await dedupe(); if (dup) return dup;
  if (c.dataRevision !== req.expectedDataRevision || c.publicationRevision !== req.expectedPublicationRevision) throw new ApiError(409, 'تغيّرت بيانات الملف أو نتيجته المنشورة؛ أعد التحميل ثم أعد الحساب.');
  const id = crypto.randomUUID(), assessment: AssessmentStaffV22 = { ...built.output, assessmentId: id };
  const history = db.insert(assessmentHistory).values({ id, candidateId: caseId, computedAt: now, inputsHash: built.canonicalHash, engineVersion: V22_ENGINE_VERSION, rulesVersion: active ? active.releaseId : 'NO_ACTIVE_RELEASE', outputJson: JSON.stringify(assessment), explanationTraceJson: JSON.stringify(built.trace), caseRevision: c.dataRevision, canonicalInputHash: built.canonicalHash, ruleBundleHash: built.ruleBundleHash, assessmentMode: req.assessmentMode, assessmentPurpose: req.assessmentPurpose, createdBy: actorUserId });
  const guard = guardOn(c.publicationRevision);
  const move = req.assessmentMode === 'SHADOW'
    ? db.update(candidates).set({ dataRevision: sql`CASE WHEN ${guard} THEN data_revision ELSE -1 END` }).where(eq(candidates.id, caseId))
    : db.update(candidates).set({ publicationRevision: sql`CASE WHEN ${guard} THEN publication_revision + 1 ELSE -1 END`, [pointerField]: id }).where(eq(candidates.id, caseId));
  try { await db.batch([history, move, db.insert(durableJobs).values(jobRow(caseId, actorUserId, requestKey, requestHash, body, id, now))]); }
  catch (e) {
    // A concurrent identical request or a changed input/rule: the batch rolled back. Converge or report stale.
    const again = await replay(); if (again) return again;
    const d2 = await dedupe(); if (d2) return d2;
    const m = e instanceof Error ? e.message + String((e as { cause?: unknown }).cause ?? '') : String(e);
    if (/CHECK constraint failed|UNIQUE constraint failed/i.test(m)) throw new ApiError(409, 'تغيّرت بيانات الملف أو القواعد أثناء الحساب؛ لم يُنشر أي جزء. أعد المحاولة.');
    throw e;
  }
  return { status: 'CREATED', assessmentId: id, assessment };
}

// Programs evaluated by the automatic recompute: every eligibility program in the active release (RCIP routed by
// policy), plus CRS when an Express Entry program is present. Nothing runs without an active sealed release.
export async function autoPrograms(): Promise<ProgramRef[] | null> {
  const active = await loadActiveRelease(); if (!active) return null;
  const seen = new Map<string, ProgramRef>();
  for (const i of active.intervals) {
    if (i.family !== ELIGIBILITY_FAMILY) continue;
    const programId = i.programId === 'RCIP_PILOT' || i.programId === 'RCIP_PERMANENT' ? 'RCIP' : i.programId;
    const ref: ProgramRef = { programId, streamId: null, phase: i.phase as ProgramRef['phase'] };
    seen.set(programId + '|' + i.phase, ref);
  }
  return [...seen.values()];
}
// Automatic recompute after a data change (same engine; staff can also run it from the case). Uses the current
// revisions; a concurrent change makes it a no-op (the next change triggers it again).
export async function autoRecompute(caseId: string, actorUserId: string): Promise<CommitOutcome | null> {
  const programs = await autoPrograms(); if (!programs || !programs.length) return null;
  const [c] = await getDb().select({ dataRevision: candidates.dataRevision, publicationRevision: candidates.publicationRevision }).from(candidates).where(eq(candidates.id, caseId)).limit(1);
  if (!c) return null;
  const [cc] = await getDb().select({ details: clientCases.details }).from(clientCases).where(eq(clientCases.candidateId, caseId)).limit(1);
  const rec = cc ? detailsSchema.parse(JSON.parse(cc.details)).recommendationDate : '';
  const today = torontoDate(Date.now());
  try {
    return await commitAssessment(caseId, actorUserId, { requestKey: 'auto:' + caseId + ':' + c.dataRevision + ':' + c.publicationRevision + ':' + today, expectedDataRevision: c.dataRevision, expectedPublicationRevision: c.publicationRevision, assessmentMode: 'PRODUCTION', assessmentPurpose: 'VERIFIED_SCREENING', selectedPrograms: programs, eventContext: { profileDate: today, invitationDate: null, applicationDate: null, recommendationIssuedOn: isRealDate(rec) ? rec : null } });
  } catch (e) { if (e instanceof ApiError && e.status === 409) return null; throw e; }
}
export async function latestV22(caseId: string) {
  const [c] = await getDb().select({ dataRevision: candidates.dataRevision, publicationRevision: candidates.publicationRevision, verified: candidates.latestVerifiedAssessmentId, rapid: candidates.latestRapidAssessmentId, approvalForSubmissionAt: candidates.approvalForSubmissionAt }).from(candidates).where(eq(candidates.id, caseId)).limit(1);
  if (!c) throw new ApiError(404, 'الملف غير موجود.');
  return { dataRevision: c.dataRevision, publicationRevision: c.publicationRevision, approvalForSubmissionAt: c.approvalForSubmissionAt, verified: c.verified ? await byId(c.verified) : null, rapid: c.rapid ? await byId(c.rapid) : null };
}
