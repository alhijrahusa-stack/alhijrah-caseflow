// v2.2 Gate 5 — the one delivery outbox (delivery_outbox). Writers insert a row in the same D1 batch as the business
// change (business_key UNIQUE dedupes repeats); cron/requests dispatch it. A row is leased with a fence (fence+1) and only
// the holder of the current fence may settle it, so a slow or evicted worker cannot overwrite a newer attempt. A lease
// that expires while LEASED means the provider call may or may not have happened: the row becomes AMBIGUOUS and is
// re-sent ONLY with the same provider Idempotency-Key (the event id), so the provider deduplicates instead of the client
// receiving two messages. 429/5xx/network → RETRY with backoff; permanent 4xx or too many attempts → DEAD_LETTER. Purpose
// consents (chat/expiry notices) are re-read at dispatch: a revoked consent cancels the row. waitUntil only speeds things
// up; durability is the row itself plus the scheduled dispatch.
import { getDb } from '@/db';
import { deliveryOutbox,officeSettings,candidates,clientCases,casePurposeConsents } from '@/db/schema';
import { and,eq,inArray,lte,lt } from 'drizzle-orm';
import { decrypt,encrypt } from './security';
import { leaseOutboxRow,settleOutboxRow,type SettleOutcome } from './outbox-lease';
import { OFFICE,PORTAL_ORIGIN } from './branding';

export const OUTBOX_LEASE_MS=60_000,OUTBOX_MAX_ATTEMPTS=6;
export type OutboxKind='PAYMENT_NOTICE'|'CHAT_NOTICE'|'PROGRESS_NOTICE'|'EXPIRY_NOTICE';
export type Recipient={to:string;reference:string;locale:'ar'|'en'};
export const backoffMs=(attempts:number)=>Math.min(6*60*60_000,60_000*2**Math.max(0,attempts-1));
const CONSENT:Partial<Record<OutboxKind,string>>={CHAT_NOTICE:'CHAT_NOTIFICATIONS',EXPIRY_NOTICE:'EXPIRY_NOTIFICATIONS'};

/** The client's registered email and preferred language (server records only). */
export async function clientRecipient(caseId:string):Promise<Recipient|null>{
 const db=getDb(),[c]=await db.select({reference:candidates.reference,profile:candidates.profile}).from(candidates).where(eq(candidates.id,caseId)).limit(1);if(!c)return null;
 const email=(JSON.parse(c.profile) as {email?:string}).email;if(!email)return null;
 const [cc]=await db.select({details:clientCases.details}).from(clientCases).where(eq(clientCases.candidateId,caseId)).limit(1);
 let locale:'ar'|'en'='ar';try{if(cc&&(JSON.parse(cc.details) as {preferredLanguage?:string}).preferredLanguage==='en')locale='en';}catch{/* legacy details */}
 return {to:email,reference:c.reference,locale};
}
export async function hasConsent(caseId:string,purpose:string){const [r]=await getDb().select({g:casePurposeConsents.granted}).from(casePurposeConsents).where(and(eq(casePurposeConsents.caseId,caseId),eq(casePurposeConsents.purpose,purpose))).limit(1);return r?.g===true;}
/** Outbox row for a business change; the caller puts it in the same batch. Returns null when no recipient exists. */
export async function outboxRow(kind:OutboxKind,caseId:string,businessKey:string,extra:Record<string,string|number|null>,nextAtMs=Date.now()){
 const recipient=await clientRecipient(caseId);if(!recipient)return null;
 return {eventId:crypto.randomUUID(),caseId,kind,businessKey,payloadEncrypted:await encrypt(JSON.stringify({...recipient,...extra})),nextAtMs,createdAt:new Date().toISOString()};
}
// Limited text only: never message bodies, document names, line items or assessment content. A payment notice carries
// only the remaining balance, currency and due date (AC-56).
/** Integer cents → "1,234.56 CAD" (string arithmetic; only the remaining balance is ever shown in a notice). */
const money=(p:Record<string,unknown>)=>{const c=Number(p.remainingCents);if(!Number.isSafeInteger(c)||c<0||typeof p.currency!=='string')return '—';const s=String(c).padStart(3,'0');return s.slice(0,-2).replace(/\B(?=(\d{3})+(?!\d))/g,',')+'.'+s.slice(-2)+' '+p.currency;};
export function composeNotice(kind:OutboxKind,p:Recipient&Record<string,unknown>){
 const ar=p.locale!=='en',link=PORTAL_ORIGIN+'/client/account',ref=p.reference;
 const map:Record<OutboxKind,[string,string,string,string]>={
  PAYMENT_NOTICE:['تحديث على فاتورة ملفك '+ref,'المبلغ المتبقي على فاتورة ملفك: '+money(p)+(p.deadline?' — تاريخ الاستحقاق: '+p.deadline:'')+'. التفاصيل بعد تسجيل الدخول.','Invoice update for file '+ref,'Remaining balance on your file invoice: '+money(p)+(p.deadline?' — due date: '+p.deadline:'')+'. Sign in for the details.'],
  CHAT_NOTICE:['رسالة جديدة في ملفك '+ref,'وصلتك رسالة جديدة في محادثة ملفك. اقرأها بعد تسجيل الدخول.','New message on file '+ref,'You have a new message in your file conversation. Sign in to read it.'],
  PROGRESS_NOTICE:['تحديث على ملفك '+ref,'يوجد تحديث على حالة ملفك. اطّلع عليه بعد تسجيل الدخول.','Update on file '+ref,'There is an update on your file. Sign in to see it.'],
  EXPIRY_NOTICE:['مستند يقترب انتهاؤه في ملفك '+ref,typeof p.milestoneDays==='number'&&p.milestoneDays>0?'أحد مستندات ملفك ينتهي خلال '+p.milestoneDays+' يومًا. راجع ملفك بعد تسجيل الدخول.':'أحد مستندات ملفك انتهت صلاحيته. راجع ملفك بعد تسجيل الدخول.','A document on file '+ref+' is expiring',typeof p.milestoneDays==='number'&&p.milestoneDays>0?'A document on your file expires within '+p.milestoneDays+' days. Sign in to review your file.':'A document on your file has expired. Sign in to review your file.'],
 };
 const [sa,ba,se,be]=map[kind];
 return {subject:ar?sa:se,text:(ar?ba:be)+'\n\n'+link+'\n\n'+OFFICE.name};
}
type Settle=SettleOutcome;
const settle=(eventId:string,fence:number,x:Settle)=>settleOutboxRow(getDb() as never,eventId,fence,x);
/** Expired leases: the attempt's outcome is unknown, so the row is AMBIGUOUS (re-sent only with the same key). */
export async function reclaimExpired(now=Date.now()){
 return (await getDb().update(deliveryOutbox).set({state:'AMBIGUOUS',errorCode:'LEASE_EXPIRED',leaseUntilMs:0,nextAtMs:now}).where(and(eq(deliveryOutbox.state,'LEASED'),lt(deliveryOutbox.leaseUntilMs,now))).returning({id:deliveryOutbox.eventId})).length;
}
const lease=(eventId:string,state:string,fence:number,now:number)=>leaseOutboxRow(getDb() as never,eventId,state,fence,now,OUTBOX_LEASE_MS);
type Provider=(input:{key:string;from:string;apiKey:string;to:string;subject:string;text:string;idempotencyKey:string})=>Promise<{status:number;id:string|null}|'NETWORK_UNKNOWN'>;
export const resendProvider:Provider=async m=>{
 const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),12_000);
 try{const r=await fetch('https://api.resend.com/emails',{method:'POST',signal:controller.signal,headers:{Authorization:'Bearer '+m.apiKey,'Content-Type':'application/json','Idempotency-Key':m.idempotencyKey},body:JSON.stringify({from:m.from,to:[m.to],subject:m.subject,text:m.text,reply_to:OFFICE.email})});const body=await r.json().catch(()=>null) as {id?:string}|null;return {status:r.status,id:body?.id??null};}
 catch{return 'NETWORK_UNKNOWN';}finally{clearTimeout(timeout);}
};
/** Dispatch due rows (PENDING/RETRY/AMBIGUOUS whose time has come). Returns per-state counts. */
export async function dispatchOutbox(limit=20,provider:Provider=resendProvider,now=Date.now()){
 const db=getDb(),counts:Record<string,number>={};await reclaimExpired(now);
 const due=await db.select().from(deliveryOutbox).where(and(inArray(deliveryOutbox.state,['PENDING','RETRY','AMBIGUOUS']),lte(deliveryOutbox.nextAtMs,now))).orderBy(deliveryOutbox.nextAtMs,deliveryOutbox.eventId).limit(limit);
 if(!due.length)return counts;
 const [s]=await db.select({key:officeSettings.mailKey,from:officeSettings.mailFrom}).from(officeSettings).where(eq(officeSettings.id,'office')).limit(1);
 for(const row of due){
  const held=await lease(row.eventId,row.state,row.fence,now);if(!held)continue;
  const done=(x:Settle)=>settle(row.eventId,held.fence,x).then(ok=>{if(ok)counts[x.state]=(counts[x.state]||0)+1;});
  const purpose=CONSENT[row.kind as OutboxKind];if(purpose&&!await hasConsent(row.caseId,purpose)){await done({state:'CANCELLED',errorCode:'CONSENT_REQUIRED'});continue;}
  if(!s?.key||!s.from){await done({state:'RETRY',errorCode:'EMAIL_NOT_CONFIGURED',nextAtMs:now+backoffMs(held.attempts)});continue;}
  let payload:Recipient&Record<string,unknown>;try{payload=JSON.parse(await decrypt(row.payloadEncrypted));}catch{await done({state:'DEAD_LETTER',errorCode:'PAYLOAD_UNREADABLE'});continue;}
  const message=composeNotice(row.kind as OutboxKind,payload);
  const r=await provider({key:row.eventId,from:s.from,apiKey:await decrypt(s.key),to:payload.to,subject:message.subject,text:message.text,idempotencyKey:'outbox/'+row.eventId});
  if(r==='NETWORK_UNKNOWN'){await done({state:held.attempts>=OUTBOX_MAX_ATTEMPTS?'DEAD_LETTER':'AMBIGUOUS',errorCode:'PROVIDER_OUTCOME_UNKNOWN',nextAtMs:now+backoffMs(held.attempts)});continue;}
  if(r.status>=200&&r.status<300&&r.id){await done({state:'DELIVERED',providerReference:r.id});continue;}
  // 409 = the provider is still processing the same idempotency key; 2xx without an id is unconfirmed: both are
  // AMBIGUOUS and are retried only with the same key.
  if(r.status===409||(r.status>=200&&r.status<300)){await done({state:held.attempts>=OUTBOX_MAX_ATTEMPTS?'DEAD_LETTER':'AMBIGUOUS',errorCode:'PROVIDER_IDEMPOTENCY_IN_PROGRESS',nextAtMs:now+backoffMs(held.attempts)});continue;}
  const retryable=r.status===408||r.status===429||r.status>=500;
  if(retryable&&held.attempts<OUTBOX_MAX_ATTEMPTS){await done({state:'RETRY',errorCode:'PROVIDER_'+r.status,nextAtMs:now+backoffMs(held.attempts)});continue;}
  await done({state:'DEAD_LETTER',errorCode:'PROVIDER_'+r.status});
 }
 return counts;
}
/** Staff view of one case's outbox (state only; payloads stay encrypted). */
export async function caseOutbox(caseId:string){return getDb().select({eventId:deliveryOutbox.eventId,kind:deliveryOutbox.kind,state:deliveryOutbox.state,attempts:deliveryOutbox.attempts,errorCode:deliveryOutbox.errorCode,createdAt:deliveryOutbox.createdAt}).from(deliveryOutbox).where(eq(deliveryOutbox.caseId,caseId)).orderBy(deliveryOutbox.createdAt).limit(100);}
/** MANAGER re-queues a dead-lettered row (same event id → same provider idempotency key). */
export async function requeueDeadLetter(eventId:string,now=Date.now()){return (await getDb().update(deliveryOutbox).set({state:'RETRY',nextAtMs:now,errorCode:null}).where(and(eq(deliveryOutbox.eventId,eventId),eq(deliveryOutbox.state,'DEAD_LETTER'))).returning({id:deliveryOutbox.eventId})).length===1;}
