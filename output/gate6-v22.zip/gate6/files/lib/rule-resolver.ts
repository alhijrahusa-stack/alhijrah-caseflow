// v2.2 Gate 3 — dated rule resolver (pure). Input: the active sealed release, program/family/phase and the event
// context. The date is selected by the interval's declared dateBasis (absent => CONTEXT_INCOMPLETE); exactly one
// approved interval must contain it (zero, more than one, or more than one dateBasis => RULE_UNAVAILABLE). The payload
// bytes are rehashed against the stored hash and checked for engine compatibility before use. An expired interval
// means "find a successor or block", never PROGRAM_CLOSED. RCIP follows the office policy in v22-core rcipPolicy:
// approval-for-submission timestamp (server-recorded) converted to America/Toronto; no transition, grace or state.
import { torontoDate, rcipPolicy, isRealDate, sha256Hex } from './v22-core.ts';
import type { RcipRange } from './v22-core.ts';
import { V22_ENGINE_VERSION } from './normalization.ts';
import type { RuleBundle } from './rule-import.ts';
import type { DateBasis } from './pathways.ts';

export type EventContext = { profileDate: string; invitationDate: string | null; applicationDate: string | null; recommendationIssuedOn: string | null; approvalForSubmissionAt?: string | null };
export type ActiveInterval = { programId: string; family: string; phase: string; dateBasis: DateBasis; effectiveFrom: string; effectiveToExclusive: string | null; bundleId: string };
export type ActiveRelease = { releaseId: string; manifestSha256: string; generation: number; intervals: readonly ActiveInterval[] };
export type LoadedBundle = { bundleId: string; payload: string; payloadSha256: string };
export type Resolution =
  | { status: 'RESOLVED'; interval: ActiveInterval; bundle: RuleBundle; bundleHash: string; date: string }
  | { status: 'RULE_UNAVAILABLE'; reason: string; date: string | null }
  | { status: 'CONTEXT_INCOMPLETE'; reason: string };

export function datesFor(ctx: EventContext): Partial<Record<DateBasis, string>> {
  const out: Partial<Record<DateBasis, string>> = {};
  if (isRealDate(ctx.profileDate)) out.PROFILE = ctx.profileDate;
  if (isRealDate(ctx.invitationDate)) out.INVITATION = ctx.invitationDate;
  if (isRealDate(ctx.applicationDate)) out.APPLICATION = ctx.applicationDate;
  if (isRealDate(ctx.recommendationIssuedOn)) out.RECOMMENDATION = ctx.recommendationIssuedOn;
  const t = ctx.approvalForSubmissionAt ? Date.parse(ctx.approvalForSubmissionAt) : NaN;
  if (Number.isSafeInteger(t)) out.APPROVAL_TORONTO = torontoDate(t);
  return out;
}
export function dateForBasis(basis: DateBasis, ctx: EventContext): { date: string } | { error: 'CONTEXT_INCOMPLETE' } {
  const d = datesFor(ctx)[basis];
  return d ? { date: d } : { error: 'CONTEXT_INCOMPLETE' };
}
// Verified immutable payloads cached by hash: invalidation changes the current activation, never historic bytes.
const verified = new Map<string, RuleBundle>();
export async function verifyBundle(b: LoadedBundle): Promise<{ ok: true; bundle: RuleBundle } | { ok: false; reason: string }> {
  const hit = verified.get(b.payloadSha256);
  if (hit) return { ok: true, bundle: hit };
  if (await sha256Hex(b.payload) !== b.payloadSha256) return { ok: false, reason: 'PAYLOAD_HASH_MISMATCH' };
  let parsed: RuleBundle; try { parsed = JSON.parse(b.payload) as RuleBundle; } catch { return { ok: false, reason: 'PAYLOAD_CORRUPT' }; }
  if (!Array.isArray(parsed.engineCompatibility) || !parsed.engineCompatibility.includes(V22_ENGINE_VERSION)) return { ok: false, reason: 'ENGINE_INCOMPATIBLE' };
  verified.set(b.payloadSha256, parsed);
  return { ok: true, bundle: parsed };
}
const contains = (i: { effectiveFrom: string; effectiveToExclusive: string | null }, d: string) => i.effectiveFrom <= d && (i.effectiveToExclusive === null || d < i.effectiveToExclusive);

export async function resolveRule(active: ActiveRelease | null, q: { programId: string; family: string; phase: string }, ctx: EventContext, load: (bundleId: string) => Promise<LoadedBundle | null>): Promise<Resolution> {
  if (!active) return { status: 'RULE_UNAVAILABLE', reason: 'NO_ACTIVE_RELEASE', date: null };
  const scoped = active.intervals.filter(i => i.programId === q.programId && i.family === q.family && i.phase === q.phase);
  if (!scoped.length) return { status: 'RULE_UNAVAILABLE', reason: 'NOT_CONFIGURED', date: null };
  const bases = [...new Set(scoped.map(i => i.dateBasis))];
  if (bases.length !== 1) return { status: 'RULE_UNAVAILABLE', reason: 'AMBIGUOUS_DATE_BASIS', date: null };
  const d = dateForBasis(bases[0], ctx);
  if ('error' in d) return { status: 'CONTEXT_INCOMPLETE', reason: 'DATE_REQUIRED:' + bases[0] };
  const hits = scoped.filter(i => contains(i, d.date));
  if (hits.length !== 1) return { status: 'RULE_UNAVAILABLE', reason: hits.length ? 'OVERLAPPING_INTERVALS' : 'NO_INTERVAL_FOR_DATE', date: d.date };
  const stored = await load(hits[0].bundleId);
  if (!stored) return { status: 'RULE_UNAVAILABLE', reason: 'BUNDLE_MISSING', date: d.date };
  const v = await verifyBundle(stored);
  if (!v.ok) return { status: 'RULE_UNAVAILABLE', reason: v.reason, date: d.date };
  if (v.bundle.program?.programId !== q.programId || v.bundle.family !== q.family) return { status: 'RULE_UNAVAILABLE', reason: 'BUNDLE_IDENTITY_MISMATCH', date: d.date };
  return { status: 'RESOLVED', interval: hits[0], bundle: v.bundle, bundleHash: stored.payloadSha256, date: d.date };
}

export type RcipRouting =
  | { status: 'RESOLVED'; programId: 'RCIP_PILOT' | 'RCIP_PERMANENT'; date: string }
  | { status: 'FAIL'; programId: 'RCIP_PERMANENT'; code: 'RECOMMENDATION_OUTSIDE_APPROVED_POLICY'; date: string }
  | { status: 'RULE_UNAVAILABLE'; reason: string; date: string | null }
  | { status: 'CONTEXT_INCOMPLETE'; reason: string };
// Ranges come from the active release's RCIP intervals for the requested family/phase only.
export function routeRcip(active: ActiveRelease | null, family: string, phase: string, ctx: EventContext): RcipRouting {
  if (!active) return { status: 'RULE_UNAVAILABLE', reason: 'NO_ACTIVE_RELEASE', date: null };
  const t = ctx.approvalForSubmissionAt ? Date.parse(ctx.approvalForSubmissionAt) : NaN;
  if (!Number.isSafeInteger(t)) return { status: 'CONTEXT_INCOMPLETE', reason: 'APPROVAL_FOR_SUBMISSION_REQUIRED' };
  const ranges: RcipRange[] = active.intervals.filter(i => (i.programId === 'RCIP_PILOT' || i.programId === 'RCIP_PERMANENT') && i.family === family && i.phase === phase && i.dateBasis === 'APPROVAL_TORONTO')
    .map(i => ({ from: i.effectiveFrom, to: i.effectiveToExclusive, program: i.programId as RcipRange['program'], ruleId: i.bundleId }));
  const r = rcipPolicy({ approvedAtMs: t, recommendationIssuedOn: ctx.recommendationIssuedOn, ranges });
  if (r.status === 'RULE_UNAVAILABLE') return { status: 'RULE_UNAVAILABLE', reason: ranges.length ? 'NO_APPROVED_RANGE_FOR_DATE' : 'NOT_CONFIGURED', date: r.date };
  if (r.status === 'FAIL') return { status: 'FAIL', programId: 'RCIP_PERMANENT', code: r.code, date: r.date };
  return { status: 'RESOLVED', programId: r.program, date: r.date };
}
