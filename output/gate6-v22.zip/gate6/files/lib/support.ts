import { getDb } from '@/db';
import { supportThreads,supportMessages,supportTransitions,documents,candidates,clientCases } from '@/db/schema';
import { env } from 'cloudflare:workers';
import { ApiError } from './server';
import { boundedForm } from './upload';
import { eq,desc,asc,sql,and,gt,lt,ne } from 'drizzle-orm';
import { professionalConfig } from './professional-ai';
import { decrypt } from './security';
import { faqAnswer } from './faq';
import { rankFaq,maskIdentifiers } from './faq-retrieval';
import { detailsSchema } from './intake';
import { screenIntake } from './screening';
import { statusLabels } from './model';
// Client support chat: the office's AI agent answers routine questions from the office reference and the
// client's own case facts; sensitive or unresolved topics are handed to staff, after which the AI stays silent.
type Candidate=typeof candidates.$inferSelect;type Client=typeof clientCases.$inferSelect;
export const HANDOFF_NOTE='تم تحويل محادثتك إلى أحد موظفي المكتب، وسيرد عليك هنا في أقرب وقت.';
const SENSITIVE=/شكو|استرد|استرجاع|تعويض|محام|قضي|رفض|مرفوض|مستعجل|عاجل|طارئ|موعد نهائي|إلغاء|ألغي|احتيال|نصب|دفع|دفعت|فاتور|سعر|أسعار|تكلف|رسوم المكتب|complain|refund|lawyer|refus|urgent|emergency|deadline|cancel|fraud|scam|payment|invoice|price|cost/i;
const nowIso=()=>new Date().toISOString();
async function ensureThread(candidateId:string){const at=nowIso();await getDb().insert(supportThreads).values({candidateId,status:'ai',lastMessageAt:at,updatedAt:at}).onConflictDoNothing();const [t]=await getDb().select().from(supportThreads).where(eq(supportThreads.candidateId,candidateId)).limit(1);return t;}
export async function threadMessages(candidateId:string,limit=80){return (await getDb().select({id:supportMessages.id,sender:supportMessages.sender,body:supportMessages.body,createdAt:supportMessages.createdAt,attachmentType:supportMessages.attachmentType,attachmentName:supportMessages.attachmentName}).from(supportMessages).where(eq(supportMessages.candidateId,candidateId)).orderBy(desc(supportMessages.createdAt)).limit(limit)).reverse();}
async function add(candidateId:string,sender:'client'|'ai'|'staff',body:string,author='',staffUnread=0,clientUnread=0,status?:string,reason?:string){const at=nowIso(),db=getDb();
 await db.batch([db.insert(supportMessages).values({id:crypto.randomUUID(),candidateId,sender,author,body,createdAt:at}),
  db.update(supportThreads).set({lastMessageAt:at,updatedAt:at,staffUnread:sql`${supportThreads.staffUnread}+${staffUnread}`,clientUnread:sql`${supportThreads.clientUnread}+${clientUnread}`,...(status?{status}:{}),...(reason!==undefined?{handoffReason:reason}:{})}).where(eq(supportThreads.candidateId,candidateId))]);}
export async function caseFacts(candidate:Candidate,client:Client){const db=getDb(),profile=JSON.parse(candidate.profile),details=detailsSchema.parse(JSON.parse(client.details));const files=await db.select({category:documents.category,verified:documents.verified}).from(documents).where(eq(documents.candidateId,candidate.id));const screen=screenIntake(profile,details,files,JSON.parse(client.requestedDocuments));
 return {status:statusLabels[candidate.status]||candidate.status,missingDocuments:screen.documents.filter(f=>f.state==='missing').map(f=>f.label),uploadedFiles:files.length,reviewedFiles:files.filter(f=>f.verified).length,officeFollowUpDate:client.followUpDate||null,officeInstructions:client.instructions?maskIdentifiers(client.instructions).slice(0,600):''};}
async function aiReply(candidate:Candidate,client:Client,history:{sender:string;body:string}[]):Promise<{reply:string;handoff:boolean;reason:string}|null>{
 const cfg=await professionalConfig();if(!cfg.configured||cfg.provider!=='openai')return null;
 const profile=JSON.parse(candidate.profile),scrub=(t:string)=>{let x=t;for(const v of [profile.fullName,profile.email,profile.phone])if(v&&v.length>2)x=x.split(v).join('[private]');return maskIdentifiers(x);};
 const last=history.filter(m=>m.sender==='client').at(-1)?.body||'',faq=rankFaq(last,3);
 const instructions=`You are Karem, the digital client-support assistant of ALHIJRAH Services (مكتب الهجرة – عبدالله المريسي), an administrative office preparing Canada immigration and work files. Reply in the client's language (Arabic by default), politely, in at most 90 words, as plain text without technical notes.
Answer only routine questions: how to use the portal, which documents are still missing, the current status, the recorded follow-up date, and general information from the office reference.
Never assess eligibility, promise approval, visas, jobs or timelines, give legal advice, quote prices or fees, or ask for passwords or codes.
Set handoff=true when the question needs a staff member: payments or prices, complaints, refusals, legal matters, urgent deadlines, changes to the file, anything not answered by the supplied facts, or when the client asks for a person. When handing off, reply with one short reassuring sentence only.
Case facts: ${JSON.stringify(await caseFacts(candidate,client))}
Office reference: ${faq.map(e=>`${e.question}: ${faqAnswer(e).slice(0,700)}`).join('\n')||'none'}`;
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),45000);
 try{let effort=true;for(let i=0;i<2;i++){const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',signal:controller.signal,headers:{'Content-Type':'application/json',Authorization:'Bearer '+await decrypt(cfg.key)},body:JSON.stringify({model:cfg.model,store:false,instructions,input:history.slice(-10).map(m=>({role:m.sender==='client'?'user':'assistant',content:scrub(m.body)})),max_output_tokens:1500,...(effort?{reasoning:{effort:'low'}}:{}),text:{format:{type:'json_schema',name:'support_reply',strict:true,schema:{type:'object',additionalProperties:false,required:['reply','handoff','reason'],properties:{reply:{type:'string'},handoff:{type:'boolean'},reason:{type:'string'}}}}}})});
  if(!r.ok){const b=await r.text();if(r.status===400&&effort&&/effort|reasoning/i.test(b)){effort=false;continue;}return null;}
  const body=await r.json() as {output?:{type:string;content?:{type:string;text?:string}[]}[]};const text=(body.output||[]).filter(o=>o.type==='message').flatMap(o=>o.content||[]).filter(p=>p.type==='output_text').map(p=>p.text||'').join('');
  const parsed=JSON.parse(text) as {reply?:string;handoff?:boolean;reason?:string};if(typeof parsed.reply!=='string'||!parsed.reply.trim())return null;return {reply:parsed.reply.trim().slice(0,1500),handoff:!!parsed.handoff,reason:String(parsed.reason||'').slice(0,200)};}return null;}
 catch{return null;}finally{clearTimeout(timer);}
}
export async function clientPost(candidate:Candidate,client:Client,body:string,wantsHuman:boolean){
 const thread=await ensureThread(candidate.id);await add(candidate.id,'client',body,'',1,0);
 if(thread.status==='human'||thread.status==='closed'&&wantsHuman){if(thread.status==='closed')await getDb().update(supportThreads).set({status:'human'}).where(eq(supportThreads.candidateId,candidate.id));return;}
 if(wantsHuman||SENSITIVE.test(body)){await toQueue(candidate.id);await add(candidate.id,'ai',HANDOFF_NOTE,'',0,1,'human',wantsHuman?'طلب العميل التحدث مع موظف':'موضوع يحتاج موظفًا');return;}
 const history=(await threadMessages(candidate.id,12)).map(m=>({sender:m.sender,body:m.body}));const r=await aiReply(candidate,client,history);
 if(!r){await toQueue(candidate.id);await add(candidate.id,'ai',HANDOFF_NOTE,'',0,1,'human','الرد الآلي غير متاح');return;}
 if(r.handoff){await toQueue(candidate.id);await add(candidate.id,'ai',r.reply||HANDOFF_NOTE,'',0,1,'human',r.reason||'تحويل من المساعد');return;}
 await add(candidate.id,'ai',r.reply,'',0,1,'ai');
}
export async function staffPost(candidateId:string,body:string,author:string){await ensureThread(candidateId);await claim(candidateId,author);const before=await threadOf(candidateId);await add(candidateId,'staff',body,author,0,1,'human');if(before&&!(await getDb().select({id:supportMessages.id}).from(supportMessages).where(and(eq(supportMessages.candidateId,candidateId),eq(supportMessages.sender,'staff'))).limit(2)).slice(1).length)await logTransition(candidateId,'ASSIGNED','HUMAN_ACTIVE',author);await getDb().update(supportThreads).set({staffUnread:0}).where(eq(supportThreads.candidateId,candidateId));}
export async function markRead(candidateId:string,side:'staff'|'client'){await getDb().update(supportThreads).set(side==='staff'?{staffUnread:0}:{clientUnread:0}).where(eq(supportThreads.candidateId,candidateId));}
export async function threadOf(candidateId:string){const [t]=await getDb().select().from(supportThreads).where(eq(supportThreads.candidateId,candidateId)).limit(1);return t||null;}
void asc;
// State machine: AI_ACTIVE → PENDING_HUMAN → QUEUED → ASSIGNED → HUMAN_ACTIVE → CLOSED. Stored as status
// (ai|human|closed) plus assigned_to; every change is written to support_transitions.
export type ChatState='AI_ACTIVE'|'QUEUED'|'HUMAN_ACTIVE'|'CLOSED';
export function chatState(t:{status:string;assignedTo:string}|null):ChatState{if(!t||t.status==='ai')return 'AI_ACTIVE';if(t.status==='closed')return 'CLOSED';return t.assignedTo?'HUMAN_ACTIVE':'QUEUED';}
export async function logTransition(candidateId:string,from:string,to:string,actor:string){await getDb().insert(supportTransitions).values({id:crypto.randomUUID(),candidateId,fromState:from,toState:to,actor,at:nowIso()});}
async function toQueue(candidateId:string){const t=await threadOf(candidateId);if(t?.status==='human')return;await logTransition(candidateId,chatState(t),'PENDING_HUMAN','system');await logTransition(candidateId,'PENDING_HUMAN','QUEUED','system');}
// Atomic claim: only succeeds while the thread is unassigned or already held by the same staff member.
export async function claim(candidateId:string,email:string){const at=nowIso();const r=await getDb().update(supportThreads).set({assignedTo:email,assignedAt:at,status:'human',updatedAt:at}).where(and(eq(supportThreads.candidateId,candidateId),sql`(${supportThreads.assignedTo}='' or ${supportThreads.assignedTo}=${email})`)).returning({prev:supportThreads.assignedAt});
 if(!r.length){const t=await threadOf(candidateId);throw new ApiError(409,'المحادثة مستلمة من موظف آخر: '+(t?.assignedTo||''));}
 if(r[0].prev===at){/* newly assigned or re-stamped */}
 const log=await getDb().select({to:supportTransitions.toState,actor:supportTransitions.actor}).from(supportTransitions).where(eq(supportTransitions.candidateId,candidateId)).orderBy(desc(supportTransitions.at)).limit(1);if(!log.length||log[0].to!=='ASSIGNED'&&log[0].to!=='HUMAN_ACTIVE'||log[0].actor!==email)await logTransition(candidateId,'QUEUED','ASSIGNED',email);}
export async function setStatus(candidateId:string,status:'ai'|'human'|'closed',actor:string){const t=await threadOf(candidateId);if(!t)throw new ApiError(404,'لا توجد محادثة.');if(status==='human'){await claim(candidateId,actor);return;}
 await getDb().update(supportThreads).set({status,assignedTo:'',assignedAt:'',handoffReason:'',updatedAt:nowIso()}).where(eq(supportThreads.candidateId,candidateId));await logTransition(candidateId,chatState(t),status==='ai'?'AI_ACTIVE':'CLOSED',actor);}
export async function transitions(candidateId:string){return getDb().select({from:supportTransitions.fromState,to:supportTransitions.toState,actor:supportTransitions.actor,at:supportTransitions.at}).from(supportTransitions).where(eq(supportTransitions.candidateId,candidateId)).orderBy(asc(supportTransitions.at)).limit(100);}
// Attachments (voice notes, PDF, JPG, PNG): type checked by content signature, stored in R2 under the client's id.
const SIGS:[string,(b:Uint8Array)=>boolean][]=[['application/pdf',b=>b[0]===0x25&&b[1]===0x50&&b[2]===0x44&&b[3]===0x46],['image/jpeg',b=>b[0]===0xff&&b[1]===0xd8&&b[2]===0xff],['image/png',b=>b[0]===0x89&&b[1]===0x50&&b[2]===0x4e&&b[3]===0x47],['audio/webm',b=>b[0]===0x1a&&b[1]===0x45&&b[2]===0xdf&&b[3]===0xa3],['audio/ogg',b=>b[0]===0x4f&&b[1]===0x67&&b[2]===0x67&&b[3]===0x53],['audio/mp4',b=>b[4]===0x66&&b[5]===0x74&&b[6]===0x79&&b[7]===0x70]];
export async function postAttachment(request:Request,candidate:Candidate|{id:string},sender:'client'|'staff',author=''){
 if(!env.BUCKET)throw new ApiError(503,'تخزين الملفات غير متاح.');const max=10*1024*1024;
 if(!request.headers.get('content-type')?.startsWith('multipart/form-data'))throw new ApiError(415,'أرسل الملف من نموذج الرفع.');
 const form=await boundedForm(request,max+1024*1024),file=form.get('file');if(!(file instanceof File)||!file.size||file.size>max)throw new ApiError(400,'اختر ملفًا حتى 10 MB.');
 const bytes=new Uint8Array(await file.arrayBuffer()),sig=SIGS.find(([,t])=>t(bytes));if(!sig)throw new ApiError(415,'الأنواع المسموحة: رسالة صوتية، PDF، JPG، PNG.');
 const type=sig[0],voice=type.startsWith('audio/'),name=voice?'':String(file.name||'file').replace(/[^\p{L}\p{N}._ -]/gu,'').slice(0,120)||'file',id=crypto.randomUUID(),key=`support/${candidate.id}/${id}`;
 await env.BUCKET.put(key,bytes,{httpMetadata:{contentType:type},customMetadata:{candidateId:candidate.id,sender}});
 const thread=await ensureThread(candidate.id),at=nowIso(),db=getDb(),label=voice?(sender==='client'?'رسالة صوتية':'رسالة صوتية من المكتب'):name;
 if(sender==='staff')await claim(candidate.id,author);
 const toStaff=sender==='client',handoff=toStaff&&thread.status!=='human';if(handoff)await toQueue(candidate.id);
 await db.batch([db.insert(supportMessages).values({id,candidateId:candidate.id,sender,author,body:label,createdAt:at,attachmentKey:key,attachmentType:type,attachmentName:name}),
  db.update(supportThreads).set({lastMessageAt:at,updatedAt:at,staffUnread:sql`${supportThreads.staffUnread}+${toStaff?1:0}`,clientUnread:sql`${supportThreads.clientUnread}+${toStaff?0:1}`,...(handoff?{status:'human',handoffReason:voice?'رسالة صوتية من العميل':'مرفق من العميل'}:{}),...(sender==='staff'?{status:'human'}:{})}).where(eq(supportThreads.candidateId,candidate.id))]);
 if(handoff)await add(candidate.id,'ai',HANDOFF_NOTE,'',0,1);
 return id;}
export async function attachmentOf(candidateId:string,messageId:string){if(!env.BUCKET)throw new ApiError(503,'تخزين الملفات غير متاح.');const [m]=await getDb().select({key:supportMessages.attachmentKey,type:supportMessages.attachmentType,name:supportMessages.attachmentName}).from(supportMessages).where(and(eq(supportMessages.id,messageId),eq(supportMessages.candidateId,candidateId))).limit(1);
 if(!m||!m.key)throw new ApiError(404,'المرفق غير موجود.');const obj=await env.BUCKET.get(m.key);if(!obj)throw new ApiError(404,'المرفق غير موجود.');
 return new Response(obj.body,{headers:{'Content-Type':m.type,'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Content-Disposition':(m.type.startsWith('audio/')||m.type.startsWith('image/')?'inline':'attachment')+'; filename="'+(m.name||'voice').replace(/[^A-Za-z0-9._-]/g,'_')+'"'}});}
// Waiting line: handed-off threads with unanswered client messages, ordered by their last activity.
export async function queuePosition(candidateId:string){const t=await threadOf(candidateId);if(!t||t.status!=='human'||t.assignedTo||t.staffUnread===0)return 0;
 const [row]=await getDb().select({n:sql<number>`count(*)`}).from(supportThreads).where(and(eq(supportThreads.status,'human'),eq(supportThreads.assignedTo,''),gt(supportThreads.staffUnread,0),ne(supportThreads.candidateId,candidateId),lt(supportThreads.lastMessageAt,t.lastMessageAt)));return Number(row?.n||0)+1;}
export async function resumeAi(candidateId:string){const t=await threadOf(candidateId);await getDb().update(supportThreads).set({status:'ai',handoffReason:'',staffUnread:0,assignedTo:'',assignedAt:'',updatedAt:nowIso()}).where(eq(supportThreads.candidateId,candidateId));if(t&&t.status!=='ai')await logTransition(candidateId,chatState(t),'AI_ACTIVE','client');}
// v2.2 Gate 5 — the canonical case chat (lib/case-chat.ts) now receives every new message. The legacy support thread is
// kept read-only as history, and the legacy endpoints are adapters: their writes go to the canonical chat and their
// reads return legacy history followed by the canonical messages in the legacy shape.
export async function unifiedMessages(candidateId:string,forClient:boolean){
 const chat=await import('./case-chat'),legacy=await threadMessages(candidateId,200),page=await chat.replay(candidateId,0,100,forClient);
 const mapped=page.items.map(m=>({id:m.messageId,sender:m.actorType==='CLIENT'?'client':m.actorType==='STAFF'?'staff':'ai',body:m.text??(m.kind==='ASSESSMENT_LINK'?'تقييم سريع':m.kind==='VOICE_NOTE'?'رسالة صوتية':'مرفق'),createdAt:m.createdAt,attachmentType:null as string|null,attachmentName:null as string|null}));
 return {messages:[...legacy,...mapped],conversation:page.conversation};
}
export const legacyStatus=(state:string)=>state==='BOT_ACTIVE'?'ai':state==='CLOSED'?'closed':'human';
