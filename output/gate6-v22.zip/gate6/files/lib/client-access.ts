import { getDb } from '@/db';
import { candidates,clientCases,clientSessions } from '@/db/schema';
import { eq,and,isNull,gt } from 'drizzle-orm';
import { ApiError } from './server';
import { sha,clientHeaders,accessCode } from './security';
import { deliveryOptions } from './otp-delivery';
export const CLIENT_COOKIE='alh_client_access';
export const SESSION_COOKIE='alh_client_session';
export const SESSION_SECONDS=8*60*60;
export function cookieFor(code:string,request:Request){return `${CLIENT_COOKIE}=${code}; HttpOnly; SameSite=Lax; Path=/api/client; Max-Age=2592000${new URL(request.url).protocol==='https:'?'; Secure':''}`;}
export function sessionCookie(token:string,request:Request){return `${SESSION_COOKIE}=${token}; HttpOnly; SameSite=Lax; Path=/api/client; Max-Age=${SESSION_SECONDS}${new URL(request.url).protocol==='https:'?'; Secure':''}`;}
export function readCookie(request:Request,name:string){return request.headers.get('cookie')?.split(';').map(v=>v.trim()).find(v=>v.startsWith(name+'='))?.slice(name.length+1)||'';}
export async function createClientSession(candidateId:string,method:string){const token=accessCode(),now=Date.now();await getDb().insert(clientSessions).values({tokenHash:await sha(token),candidateId,method,createdAt:now,expiresAt:now+SESSION_SECONDS*1000});return token;}
export async function clientCase(request:Request){
 const db=getDb(),token=readCookie(request,SESSION_COOKIE);
 if(/^[a-f0-9]{64}$/.test(token)){
  const [r]=await db.select({candidate:candidates,client:clientCases,session:clientSessions}).from(clientSessions).innerJoin(candidates,eq(candidates.id,clientSessions.candidateId)).innerJoin(clientCases,eq(clientCases.candidateId,candidates.id)).where(and(eq(clientSessions.tokenHash,await sha(token)),eq(clientSessions.scope,'full_case'),isNull(clientSessions.revokedAt),gt(clientSessions.expiresAt,Date.now()))).limit(1);
  // v2.2 Gate 4: only a full_case session opens the file; a case_status lookup token is rejected here even if copied.
  if(r)return {...r,authentication:{method:r.session.method,createdAt:r.session.createdAt,expiresAt:r.session.expiresAt}};
  throw new ApiError(401,'انتهت الجلسة. اطلب رمز تحقق جديدًا.');
 }
 // Existing signed receipt links remain usable until an actual delivery channel is configured.
 const raw=readCookie(request,CLIENT_COOKIE),options=await deliveryOptions();
 if(!options.email&&!options.whatsapp&&/^[a-f0-9]{64}$/.test(raw)){
  const [row]=await db.select({candidate:candidates,client:clientCases}).from(clientCases).innerJoin(candidates,eq(candidates.id,clientCases.candidateId)).where(eq(clientCases.accessHash,await sha(raw))).limit(1);
  if(row&&!row.client.otpOnly)return {...row,authentication:{method:'legacy',createdAt:0,expiresAt:0}};
 }
 throw new ApiError(401,'اطلب رمز تحقق لفتح ملفك');
}
export function clientResponse(data:unknown,status=200,extra:Record<string,string>={}){return Response.json(data,{status,headers:{...clientHeaders,...extra}});}
