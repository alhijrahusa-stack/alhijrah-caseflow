// v2.2 Gate 5 — employers, vacancies and ATS stages entered by staff from real sources: every employer and vacancy has
// an https source URL and the date staff checked it (enforced in SQL). Nothing is generated: no vacancy, acceptance rate,
// reference salary or progress is invented. Ranking needs an approved ranking policy, none is configured, so every list
// reports rank RANK_UNAVAILABLE (the exact-NOC filter is a filter, not a score). Private contacts are encrypted.
import { z } from 'zod';
import { getDb } from '@/db';
import { officeEmployers,officeVacancies,vacancyApplications,candidates,events } from '@/db/schema';
import { and,eq,desc } from 'drizzle-orm';
import { ApiError } from './api-error';
import { encrypt,decrypt } from './security';
import { isRealDate,torontoDate } from './v22-core';

export const RANK_STATUS='RANK_UNAVAILABLE' as const;
const Https=z.string().url().max(500).refine(v=>new URL(v).protocol==='https:','HTTPS_SOURCE_REQUIRED');
const Day=z.string().refine(isRealDate,'INVALID_DATE');
export const employerSchema=z.object({action:z.literal('employer'),employerId:z.string().uuid().nullable(),expectedVersion:z.number().int().min(1).nullable(),name:z.string().trim().min(2).max(200),sourceUrl:Https,sourceCheckedOn:Day,contact:z.string().trim().max(500).nullable()}).strict();
export const vacancySchema=z.object({action:z.literal('vacancy'),vacancyId:z.string().uuid().nullable(),expectedVersion:z.number().int().min(1).nullable(),employerId:z.string().uuid(),title:z.string().trim().min(2).max(200),noc:z.string().regex(/^\d{5}$/).nullable(),sourceUrl:Https,postedOn:Day,validUntil:Day.nullable(),status:z.enum(['OPEN','CLOSED'])}).strict();
export const stageSchema=z.object({action:z.literal('stage'),caseId:z.string().min(8).max(200),vacancyId:z.string().uuid(),stage:z.enum(['SHORTLISTED','SUBMITTED','INTERVIEW','OFFER','REJECTED','WITHDRAWN']),expectedVersion:z.number().int().min(1).nullable()}).strict();
const notFuture=(d:string)=>{if(d>torontoDate(Date.now()))throw new ApiError(422,'تاريخ التحقق أو النشر لا يكون في المستقبل.');};
export async function saveEmployer(actor:string,d:z.infer<typeof employerSchema>){
 notFuture(d.sourceCheckedOn);const db=getDb(),now=new Date().toISOString(),contact=d.contact?await encrypt(d.contact):null;
 if(!d.employerId){const employerId=crypto.randomUUID();await db.insert(officeEmployers).values({employerId,name:d.name,sourceUrl:d.sourceUrl,sourceCheckedOn:d.sourceCheckedOn,contactEncrypted:contact,createdBy:actor,createdAt:now,updatedAt:now});return employerId;}
 const r=await db.update(officeEmployers).set({name:d.name,sourceUrl:d.sourceUrl,sourceCheckedOn:d.sourceCheckedOn,contactEncrypted:contact,version:(d.expectedVersion??0)+1,updatedAt:now}).where(and(eq(officeEmployers.employerId,d.employerId),eq(officeEmployers.version,d.expectedVersion??-1))).returning({id:officeEmployers.employerId});
 if(!r.length)throw new ApiError(409,'تغيّرت بيانات جهة العمل؛ حدّث الصفحة.');return d.employerId;
}
export async function saveVacancy(actor:string,d:z.infer<typeof vacancySchema>){
 notFuture(d.postedOn);if(d.validUntil&&d.validUntil<=d.postedOn)throw new ApiError(422,'تاريخ الانتهاء بعد تاريخ النشر.');
 const db=getDb(),now=new Date().toISOString(),[e]=await db.select({id:officeEmployers.employerId}).from(officeEmployers).where(eq(officeEmployers.employerId,d.employerId)).limit(1);if(!e)throw new ApiError(422,'جهة العمل غير موجودة.');
 const values={employerId:d.employerId,title:d.title,noc:d.noc,sourceUrl:d.sourceUrl,postedOn:d.postedOn,validUntil:d.validUntil,status:d.status};
 if(!d.vacancyId){const vacancyId=crypto.randomUUID();await db.insert(officeVacancies).values({vacancyId,...values,createdBy:actor,createdAt:now,updatedAt:now});return vacancyId;}
 const r=await db.update(officeVacancies).set({...values,version:(d.expectedVersion??0)+1,updatedAt:now}).where(and(eq(officeVacancies.vacancyId,d.vacancyId),eq(officeVacancies.version,d.expectedVersion??-1))).returning({id:officeVacancies.vacancyId});
 if(!r.length)throw new ApiError(409,'تغيّر الشاغر؛ حدّث الصفحة.');return d.vacancyId;
}
export async function setStage(actor:string,d:z.infer<typeof stageSchema>){
 const db=getDb(),now=new Date().toISOString(),[c]=await db.select({ownerId:candidates.ownerId}).from(candidates).where(eq(candidates.id,d.caseId)).limit(1);if(!c)throw new ApiError(404,'الملف غير موجود.');
 const [v]=await db.select({title:officeVacancies.title,status:officeVacancies.status}).from(officeVacancies).where(eq(officeVacancies.vacancyId,d.vacancyId)).limit(1);if(!v)throw new ApiError(422,'الشاغر غير موجود.');
 const [cur]=await db.select().from(vacancyApplications).where(and(eq(vacancyApplications.caseId,d.caseId),eq(vacancyApplications.vacancyId,d.vacancyId))).limit(1);
 const audit=db.insert(events).values({id:crypto.randomUUID(),ownerId:c.ownerId,candidateId:d.caseId,action:'مرحلة شاغر: '+d.stage,note:v.title,createdAt:now});
 if(!cur){if(d.expectedVersion!==null)throw new ApiError(409,'تغيّرت المرحلة؛ حدّث الصفحة.');if(v.status!=='OPEN')throw new ApiError(409,'الشاغر مغلق.');await db.batch([db.insert(vacancyApplications).values({caseId:d.caseId,vacancyId:d.vacancyId,stage:d.stage,updatedBy:actor,updatedAt:now}),audit]);return 1;}
 if(cur.version!==d.expectedVersion)throw new ApiError(409,'تغيّرت المرحلة؛ حدّث الصفحة.');
 await db.batch([db.update(vacancyApplications).set({stage:d.stage,version:cur.version+1,updatedBy:actor,updatedAt:now}).where(and(eq(vacancyApplications.caseId,d.caseId),eq(vacancyApplications.vacancyId,d.vacancyId),eq(vacancyApplications.version,cur.version))),audit]);
 const [after]=await db.select({v:vacancyApplications.version}).from(vacancyApplications).where(and(eq(vacancyApplications.caseId,d.caseId),eq(vacancyApplications.vacancyId,d.vacancyId))).limit(1);if(after.v!==cur.version+1)throw new ApiError(409,'تغيّرت المرحلة؛ حدّث الصفحة.');return after.v;
}
export async function employersBoard(caseId:string|null){
 const db=getDb(),emps=await db.select().from(officeEmployers).orderBy(officeEmployers.name).limit(200),vacs=await db.select().from(officeVacancies).orderBy(desc(officeVacancies.postedOn)).limit(300);
 const apps=caseId?await db.select().from(vacancyApplications).where(eq(vacancyApplications.caseId,caseId)):await db.select().from(vacancyApplications).limit(1000);
 return {rank:RANK_STATUS,employers:await Promise.all(emps.map(async e=>({employerId:e.employerId,name:e.name,sourceUrl:e.sourceUrl,sourceCheckedOn:e.sourceCheckedOn,contact:e.contactEncrypted?await decrypt(e.contactEncrypted).catch(()=>null):null,version:e.version}))),
  vacancies:vacs.map(v=>({vacancyId:v.vacancyId,employerId:v.employerId,title:v.title,noc:v.noc,sourceUrl:v.sourceUrl,postedOn:v.postedOn,validUntil:v.validUntil,status:v.status,version:v.version,rank:RANK_STATUS})),
  applications:apps.map(a=>({caseId:a.caseId,vacancyId:a.vacancyId,stage:a.stage,version:a.version,updatedAt:a.updatedAt}))};
}
