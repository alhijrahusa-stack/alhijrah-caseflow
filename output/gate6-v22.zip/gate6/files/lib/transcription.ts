// v2.2 Gate 5 — voice-note transcription (TRANSCRIPTION job). Requires the AUDIO_TRANSCRIPTION purpose consent, a CLEAN
// file and a configured speech-to-text provider. No provider is configured in this application, so requests end as
// FAILED/TRANSCRIPTION_NOT_CONFIGURED; a transcript is never stored as VERIFIED (at most EXTRACTED_UNVERIFIED).
import type { JobContext,JobOutcome } from './jobs';
import { hasConsent } from './outbox';
export const TRANSCRIPTION_CONFIGURED=false;
export type TranscriptState='NOT_REQUESTED'|'CONSENT_REQUIRED'|'PROCESSING'|'EXTRACTED_UNVERIFIED'|'FAILED'|'NOT_APPLICABLE';
export async function transcriptState(caseId:string,isVoice:boolean,job:{state:string}|null):Promise<TranscriptState>{
 if(!isVoice)return 'NOT_APPLICABLE';if(!await hasConsent(caseId,'AUDIO_TRANSCRIPTION'))return 'CONSENT_REQUIRED';
 if(!job)return 'NOT_REQUESTED';if(job.state==='FAILED'||job.state==='DEAD_LETTER'||job.state==='CANCELLED')return 'FAILED';
 return job.state==='SUCCEEDED'?'EXTRACTED_UNVERIFIED':'PROCESSING';
}
export async function processTranscription({job}:JobContext):Promise<JobOutcome>{
 if(!job.caseId)return {state:'FAILED',errorCode:'CASE_REQUIRED'};
 if(!await hasConsent(job.caseId,'AUDIO_TRANSCRIPTION'))return {state:'CANCELLED',errorCode:'CONSENT_REQUIRED'};
 return {state:'FAILED',errorCode:'TRANSCRIPTION_NOT_CONFIGURED'};
}
