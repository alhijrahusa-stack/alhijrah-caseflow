// v2.2 Gate 5 — durable jobs (durable_jobs): ASSESSMENT / INGESTION / TRANSCRIPTION / ASSISTANT. A job is a D1 row
// (request_key UNIQUE + request_hash: the same key with another payload is a conflict, the same payload is a replay).
// Workers lease a due row by bumping its fence; only the current fence may heartbeat or settle it, so an evicted worker
// that wakes up late cannot overwrite a newer attempt. A lease that expires while RUNNING returns the job to RETRY (job
// handlers are idempotent: they commit through their own CAS/fence). Thrown errors → RETRY with backoff, then
// DEAD_LETTER; a handler can end a job as FAILED (permanent, e.g. a capability that is not configured). waitUntil only
// starts work sooner; the scheduled dispatch is what guarantees progress.
import { getDb } from '@/db';
import { durableJobs } from '@/db/schema';
import { and,eq,inArray,lte,lt,sql } from 'drizzle-orm';
import { ApiError } from './api-error';
import { jcsHash } from './v22-core';
import { backoffMs } from './outbox';

export type JobKind='ASSESSMENT'|'INGESTION'|'TRANSCRIPTION'|'ASSISTANT';
export const JOB_LEASE_MS=120_000,JOB_MAX_ATTEMPTS=5;
export type Job=typeof durableJobs.$inferSelect;
export type JobOutcome={state:'SUCCEEDED';resultRef?:string|null}|{state:'FAILED'|'CANCELLED';errorCode:string};
export type JobContext={job:Job;fence:number;heartbeat:()=>Promise<boolean>};
export type JobHandler=(ctx:JobContext)=>Promise<JobOutcome>;

/** Row for the caller's batch (so the job exists iff the business change committed). */
export async function jobRow(input:{kind:JobKind;caseId:string|null;requestKey:string;payload:Record<string,unknown>;actor:string;nextAtMs?:number}){
 const now=new Date().toISOString(),requestHash=await jcsHash({kind:input.kind,caseId:input.caseId,payload:input.payload});
 return {jobId:crypto.randomUUID(),caseId:input.caseId,kind:input.kind,requestKey:input.requestKey,requestHash,payload:JSON.stringify(input.payload),nextAtMs:input.nextAtMs??Date.now(),createdBy:input.actor,createdAt:now,updatedAt:now};
}
/** Enqueue outside a batch: idempotent by request key; a different payload under the same key is a 409. */
export async function enqueueJob(input:Parameters<typeof jobRow>[0]){
 const row=await jobRow(input),db=getDb();
 await db.insert(durableJobs).values(row).onConflictDoNothing();
 const [stored]=await db.select().from(durableJobs).where(eq(durableJobs.requestKey,input.requestKey)).limit(1);
 if(stored.requestHash!==row.requestHash)throw new ApiError(409,'مفتاح المهمة مستخدم لطلب مختلف.');
 return stored;
}
async function lease(job:Job,now:number){
 const [r]=await getDb().update(durableJobs).set({state:'RUNNING',fence:job.fence+1,leaseUntilMs:now+JOB_LEASE_MS,attempts:sql`attempts+1`,updatedAt:new Date(now).toISOString()}).where(and(eq(durableJobs.jobId,job.jobId),eq(durableJobs.state,job.state),eq(durableJobs.fence,job.fence))).returning();
 return r??null;
}
export async function settleJob(jobId:string,fence:number,outcome:{state:'SUCCEEDED'|'FAILED'|'CANCELLED'|'RETRY'|'DEAD_LETTER';resultRef?:string|null;errorCode?:string|null;nextAtMs?:number}){
 const r=await getDb().update(durableJobs).set({state:outcome.state,leaseUntilMs:0,resultRef:outcome.resultRef??null,errorCode:outcome.errorCode??null,updatedAt:new Date().toISOString(),...(outcome.nextAtMs!==undefined?{nextAtMs:outcome.nextAtMs}:{})}).where(and(eq(durableJobs.jobId,jobId),eq(durableJobs.fence,fence),eq(durableJobs.state,'RUNNING'))).returning({id:durableJobs.jobId});
 return r.length===1;
}
async function heartbeat(jobId:string,fence:number){return (await getDb().update(durableJobs).set({leaseUntilMs:Date.now()+JOB_LEASE_MS}).where(and(eq(durableJobs.jobId,jobId),eq(durableJobs.fence,fence),eq(durableJobs.state,'RUNNING'))).returning({id:durableJobs.jobId})).length===1;}
/** Expired RUNNING leases go back to RETRY (or DEAD_LETTER after the attempt budget). */
export async function reclaimJobs(now=Date.now()){
 const db=getDb();
 const dead=await db.update(durableJobs).set({state:'DEAD_LETTER',errorCode:'LEASE_EXPIRED',leaseUntilMs:0,updatedAt:new Date(now).toISOString()}).where(and(eq(durableJobs.state,'RUNNING'),lt(durableJobs.leaseUntilMs,now),sql`attempts>=${JOB_MAX_ATTEMPTS}`)).returning({id:durableJobs.jobId});
 const back=await db.update(durableJobs).set({state:'RETRY',errorCode:'LEASE_EXPIRED',leaseUntilMs:0,nextAtMs:now,updatedAt:new Date(now).toISOString()}).where(and(eq(durableJobs.state,'RUNNING'),lt(durableJobs.leaseUntilMs,now))).returning({id:durableJobs.jobId});
 return {retried:back.length,dead:dead.length};
}
/** Run due jobs with the given handlers (kinds without a handler are left untouched). */
export async function runJobs(handlers:Partial<Record<JobKind,JobHandler>>,limit=10,now=Date.now()){
 const db=getDb(),kinds=Object.keys(handlers) as JobKind[],counts:Record<string,number>={};if(!kinds.length)return counts;
 await reclaimJobs(now);
 const due=await db.select().from(durableJobs).where(and(inArray(durableJobs.state,['PENDING','RETRY']),inArray(durableJobs.kind,kinds),lte(durableJobs.nextAtMs,now))).orderBy(durableJobs.nextAtMs,durableJobs.jobId).limit(limit);
 for(const job of due){
  const held=await lease(job,now);if(!held)continue;
  const fence=held.fence,bump=(s:string)=>{counts[s]=(counts[s]||0)+1;};
  try{const out=await handlers[job.kind as JobKind]!({job:held,fence,heartbeat:()=>heartbeat(job.jobId,fence)});
   if(await settleJob(job.jobId,fence,out.state==='SUCCEEDED'?{state:'SUCCEEDED',resultRef:out.resultRef??null}:{state:out.state,errorCode:out.errorCode}))bump(out.state);}
  catch(e){const code=(e instanceof ApiError?'HTTP_'+e.status:e instanceof Error?e.name:'UNKNOWN').slice(0,80);
   const state=held.attempts>=JOB_MAX_ATTEMPTS?'DEAD_LETTER':'RETRY';
   if(await settleJob(job.jobId,fence,{state,errorCode:code,nextAtMs:now+backoffMs(held.attempts)}))bump(state);}
 }
 return counts;
}
/** Case progress from real job rows (no invented percentages). */
export async function caseJobs(caseId:string){return getDb().select({jobId:durableJobs.jobId,kind:durableJobs.kind,state:durableJobs.state,attempts:durableJobs.attempts,errorCode:durableJobs.errorCode,createdAt:durableJobs.createdAt,updatedAt:durableJobs.updatedAt}).from(durableJobs).where(eq(durableJobs.caseId,caseId)).orderBy(durableJobs.createdAt).limit(100);}
export async function requeueDeadJob(jobId:string,now=Date.now()){return (await getDb().update(durableJobs).set({state:'RETRY',attempts:0,nextAtMs:now,errorCode:null,updatedAt:new Date(now).toISOString()}).where(and(eq(durableJobs.jobId,jobId),eq(durableJobs.state,'DEAD_LETTER'))).returning({id:durableJobs.jobId})).length===1;}
// The application's handlers (lazy imports keep the job core free of module cycles).
export function defaultHandlers():Partial<Record<JobKind,JobHandler>>{return {
 ASSESSMENT:async({job})=>{const { autoRecompute }=await import('./assessment-store');const { SYSTEM_USER_ID }=await import('./rbac');if(!job.caseId)return {state:'FAILED',errorCode:'CASE_REQUIRED'};const r=await autoRecompute(job.caseId,SYSTEM_USER_ID);return r?{state:'SUCCEEDED',resultRef:r.assessmentId}:{state:'SUCCEEDED',resultRef:null};},
 INGESTION:async ctx=>{const { processIngestion }=await import('./evidence-processing');return processIngestion(ctx);},
 TRANSCRIPTION:async ctx=>{const { processTranscription }=await import('./transcription');return processTranscription(ctx);},
 ASSISTANT:async ctx=>{const { processAssistant }=await import('./case-assistant');return processAssistant(ctx);},
};}
