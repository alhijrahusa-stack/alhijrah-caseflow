import { getDb } from '@/db';
import { caseFactRevisions, caseFactHeads, documents } from '@/db/schema';
import { and, eq, ne, asc, desc, sql } from 'drizzle-orm';
import { ApiError } from './api-error';
import { SYSTEM_USER_ID } from './rbac';
import { jcsHash } from './v22-core';
// Case facts with provenance and full history. v2.2 Gate 3 cutover (docs/v22/FACTS_COEXISTENCE.md, Phase C): the
// source of truth is case_fact_revisions (append-only) + case_fact_heads (current pointer per case/subject/key). This
// module is the only reader and writer; the legacy facts table is a frozen archive (0029) never consulted here.
// New facts are recorded under an explicit subject (the principal applicant). Legacy rows copied at cutover sit under
// the reserved subject 'UNKNOWN', have no head and therefore never count; attribution needs a new audited revision.
// View states keep the existing contract: REPORTED = stated by the client, not yet checked; VERIFIED = an authorized
// staff member matched it to a verified document of the same file; CONFLICTED = that document contradicts it
// (canonical REJECTED, evidence kept); UNKNOWN = withdrawn (an empty reported value). Free text is stored as written.
export type FactStatus='UNKNOWN'|'REPORTED'|'VERIFIED'|'CONFIRMED_ABSENT'|'CONFLICTED';
export const SKILLS_FACT='additional_skills';
export const PRINCIPAL_SUBJECT='PRINCIPAL';
export type FactView={key:string;subjectId:string;version:number;status:FactStatus;value:{text:string};source:string;evidenceDocumentId:string|null;recordedBy:string;recordedAt:string};
type Row=typeof caseFactRevisions.$inferSelect;
type Note={v?:number;source?:string;recordedBy?:string;legacy?:{status?:string;source?:string;recordedBy?:string;version?:number}};
const note=(r:Row):Note=>{try{return JSON.parse(r.reviewNote||'{}') as Note;}catch{return {};}};
const textOf=(r:Row)=>{try{const v=JSON.parse(r.valueJson) as {text?:unknown};return typeof v.text==='string'?v.text:'';}catch{return '';}};
function view(r:Row):FactView{
 const n=note(r),text=textOf(r),legacy=n.legacy;
 const status:FactStatus=legacy?.status&&['REPORTED','VERIFIED'].includes(legacy.status)?legacy.status as FactStatus:r.state==='VERIFIED'?'VERIFIED':r.state==='REJECTED'?'CONFLICTED':text===''?'UNKNOWN':'REPORTED';
 const evidence=(()=>{try{const e=JSON.parse(r.evidenceIds) as unknown[];return typeof e[0]==='string'?e[0]:null;}catch{return null;}})();
 return {key:r.factKey,subjectId:r.subjectId,version:n.v??legacy?.version??0,status,value:{text},source:n.source??legacy?.source??'',evidenceDocumentId:evidence,recordedBy:n.recordedBy??legacy?.recordedBy??r.createdBy,recordedAt:r.createdAt};
}
// Every revision of the file (attributed and legacy UNKNOWN), newest version first per key.
export async function factHistory(candidateId:string):Promise<FactView[]>{
 const rows=await getDb().select().from(caseFactRevisions).where(eq(caseFactRevisions.caseId,candidateId)).orderBy(asc(caseFactRevisions.factKey),asc(caseFactRevisions.subjectId),desc(caseFactRevisions.createdAt));
 return rows.map(view).sort((a,b)=>a.key.localeCompare(b.key)||a.subjectId.localeCompare(b.subjectId)||b.version-a.version);
}
// Current value per key = the head revision of an attributed subject, sorted by key (deterministic for the inputs hash).
export async function latestFacts(candidateId:string):Promise<FactView[]>{
 const rows=await getDb().select({r:caseFactRevisions}).from(caseFactHeads).innerJoin(caseFactRevisions,and(eq(caseFactRevisions.caseId,caseFactHeads.caseId),eq(caseFactRevisions.factId,caseFactHeads.factId))).where(and(eq(caseFactHeads.caseId,candidateId),ne(caseFactHeads.subjectId,'UNKNOWN')));
 return rows.map(x=>view(x.r)).sort((a,b)=>a.key.localeCompare(b.key)||a.subjectId.localeCompare(b.subjectId));
}
async function head(candidateId:string,key:string):Promise<Row|undefined>{
 const [x]=await getDb().select({r:caseFactRevisions}).from(caseFactHeads).innerJoin(caseFactRevisions,and(eq(caseFactRevisions.caseId,caseFactHeads.caseId),eq(caseFactRevisions.factId,caseFactHeads.factId))).where(and(eq(caseFactHeads.caseId,candidateId),eq(caseFactHeads.subjectId,PRINCIPAL_SUBJECT),eq(caseFactHeads.factKey,key))).limit(1);
 return x?.r;
}
// One revision + head move in one batch. The head move is a compare-and-swap on the previous head: a concurrent
// writer makes the CASE write a non-revision id, which the 0027 scope guard rejects, rolling the batch back.
async function append(candidateId:string,key:string,prev:Row|undefined,state:'REPORTED'|'VERIFIED'|'REJECTED',text:string,source:string,createdBy:string,recordedBy:string,evidenceIds:string[]):Promise<Row>{
 const db=getDb(),factId=crypto.randomUUID(),value={text},n:Note={v:(prev?note(prev).v??0:0)+1,source,recordedBy},now=new Date().toISOString();
 const row={factId,caseId:candidateId,factKey:key,subjectId:PRINCIPAL_SUBJECT,valueJson:JSON.stringify(value),state,evidenceIds:JSON.stringify(evidenceIds),sourceHash:await jcsHash({caseId:candidateId,key,subject:PRINCIPAL_SUBJECT,value,evidenceIds,source}),createdBy,reviewNote:JSON.stringify(n),createdAt:now};
 const move=prev?db.update(caseFactHeads).set({factId:sql`CASE WHEN fact_id = ${prev.factId} THEN ${factId} ELSE 'HEAD_CHANGED' END`}).where(and(eq(caseFactHeads.caseId,candidateId),eq(caseFactHeads.subjectId,PRINCIPAL_SUBJECT),eq(caseFactHeads.factKey,key))):db.insert(caseFactHeads).values({caseId:candidateId,subjectId:PRINCIPAL_SUBJECT,factKey:key,factId});
 try{await db.batch([db.insert(caseFactRevisions).values(row),move]);}
 catch(e){const m=e instanceof Error?e.message+String((e as {cause?:unknown}).cause??''):String(e);if(/UNIQUE|PRIMARY KEY|FOREIGN KEY|FACT_HEAD_SCOPE_MISMATCH/i.test(m))throw new ApiError(409,'تغيّرت المعلومة في الوقت نفسه؛ أعد المحاولة.');throw e;}
 return row as Row;
}
// Client skills card (portal/intake, processed by the server as SYSTEM). Same text again = no new revision
// (idempotent). Clearing the text after a note records an empty reported value, shown as UNKNOWN.
export async function recordSkillsNote(candidateId:string,text:string,actor:string):Promise<'unchanged'|'recorded'>{
 const value=text.trim(),prev=await head(candidateId,SKILLS_FACT);
 if(!prev&&!value)return 'unchanged';
 const prevView=prev?view(prev):null;
 if(prevView&&prevView.value.text===value&&(value?prevView.status!=='UNKNOWN':prevView.status==='UNKNOWN'))return 'unchanged';
 await append(candidateId,SKILLS_FACT,prev,'REPORTED',value,'client_skills_card',SYSTEM_USER_ID,actor,[]);
 return 'recorded';
}
// Authorized evidence workflow: only a document of this file that a staff member already verified can back the outcome.
export async function reviewFact(candidateId:string,key:string,documentId:string,outcome:'verified'|'conflicted',actor:{userId:string;label:string}):Promise<FactView>{
 const prev=await head(candidateId,key);
 if(!prev)throw new ApiError(404,'لا توجد معلومة بهذا المفتاح في الملف.');
 const status=view(prev).status;
 if(status!=='REPORTED'&&status!=='CONFLICTED')throw new ApiError(409,'المعلومة ليست بحالة «مصرّح بها» حتى تُراجع.');
 const [doc]=await getDb().select({id:documents.id,candidateId:documents.candidateId,verified:documents.verified}).from(documents).where(eq(documents.id,documentId)).limit(1);
 if(!doc||doc.candidateId!==candidateId)throw new ApiError(404,'المستند غير موجود في هذا الملف.');
 if(!doc.verified)throw new ApiError(409,'وثّق المستند أولًا قبل ربطه بالمعلومة.');
 const saved=await append(candidateId,key,prev,outcome==='verified'?'VERIFIED':'REJECTED',textOf(prev),'staff_evidence_review',actor.userId,actor.label,[documentId]);
 return view(saved);
}
