// v2.2 Gate 3 — fact normalization for the single assessment engine. Pure: every input is passed in.
// Each normalized fact carries its evidence state. VERIFIED = an authorized staff member entered or confirmed it in a
// verified-evidence form (the saved CRS calculator input and the eligibility run both require `verified:true`) or a
// verified document backs it. REPORTED = stated by the client, not yet checked. UNKNOWN = absent or ambiguous.
// No value is guessed: an unmapped option stays UNKNOWN. A submitted high-wage tier is never proof: the tier is derived
// from the sealed wage dataset for the occupation the staff verified.
import type { Profile } from './model';
import type { IntakeDetails } from './intake';
import type { CrsInput } from './crs';
import type { EligibilityInput } from './eligibility';
import { isRealDate } from './v22-core.ts';

export const V22_ENGINE_VERSION = 'v22-engine-1.0.0';

export type FactState = 'VERIFIED' | 'REPORTED' | 'UNKNOWN';
export type FactValue = string | number | boolean | null;
export type NormalizedFact = { value: FactValue; state: FactState; origin: string };
type Kind = { type: 'int'; min: number; max: number } | { type: 'bool' } | { type: 'date' } | { type: 'noc' } | { type: 'enum'; values: readonly string[] };

const CLB: Kind = { type: 'int', min: 0, max: 12 };
const BOOL: Kind = { type: 'bool' };
export const EDUCATION_LEVELS = ['LESS_THAN_SECONDARY', 'SECONDARY', 'ONE_YEAR', 'TWO_YEAR', 'BACHELOR', 'TWO_OR_MORE', 'MASTERS_OR_PROFESSIONAL', 'DOCTORATE'] as const;
export const WAGE_TIERS = ['NONE', 'TIER_130', 'TIER_150', 'TIER_200'] as const;
export const ABILITIES = ['speaking', 'listening', 'reading', 'writing'] as const;
export type Ability = typeof ABILITIES[number];

// Engine contract v1: the only normalized fact paths a rule payload may reference. An obligation or decision table that
// names any other path is rejected at import (UNSUPPORTED_FACT_PATH) and blocks the program at evaluation.
export const FACT_PATHS = {
  'person.ageYears': { type: 'int', min: 0, max: 120 },
  'family.spouseClassification': { type: 'enum', values: ['WITH_SPOUSE', 'WITHOUT_SPOUSE'] },
  'education.level': { type: 'enum', values: EDUCATION_LEVELS },
  'education.recognized': BOOL,
  'language.first.language': { type: 'enum', values: ['ENGLISH', 'FRENCH'] },
  'language.first.speaking': CLB, 'language.first.listening': CLB, 'language.first.reading': CLB, 'language.first.writing': CLB,
  'language.first.min': CLB,
  'language.first.testValid': BOOL,
  'language.second.state': { type: 'enum', values: ['TESTED', 'NOT_TESTED'] },
  'language.second.speaking': CLB, 'language.second.listening': CLB, 'language.second.reading': CLB, 'language.second.writing': CLB,
  'language.second.min': CLB,
  'language.english.min': CLB,
  'language.french.min': CLB,
  'work.primaryNoc': { type: 'noc' },
  'work.primaryTeer': { type: 'int', min: 0, max: 5 },
  'work.dutiesMatched': BOOL,
  'work.canadianYears': { type: 'int', min: 0, max: 60 },
  'work.foreignYears': { type: 'int', min: 0, max: 60 },
  'work.highWageTier': { type: 'enum', values: WAGE_TIERS },
  'work.fswContinuousMonths10': { type: 'int', min: 0, max: 120 },
  'work.fswHours10': { type: 'int', min: 0, max: 50000 },
  'work.paidPrimary': BOOL,
  'work.cecMonths3': { type: 'int', min: 0, max: 36 },
  'work.cecHours3': { type: 'int', min: 0, max: 10000 },
  'work.cecAuthorized': BOOL,
  'work.fstMonths5': { type: 'int', min: 0, max: 60 },
  'work.fstHours5': { type: 'int', min: 0, max: 20000 },
  'work.fstQualifiedSameNoc': BOOL,
  'offer.present': BOOL,
  'offer.noc': { type: 'noc' },
  'offer.highWageTier': { type: 'enum', values: WAGE_TIERS },
  'offer.employerDesignated': BOOL,
  'offer.conditionsMet': BOOL,
  'spouse.education.level': { type: 'enum', values: EDUCATION_LEVELS },
  'spouse.language.state': { type: 'enum', values: ['TESTED', 'NOT_TESTED'] },
  'spouse.language.speaking': CLB, 'spouse.language.listening': CLB, 'spouse.language.reading': CLB, 'spouse.language.writing': CLB,
  'spouse.canadianWorkYears': { type: 'int', min: 0, max: 60 },
  'additional.tradeCertificate': BOOL,
  'additional.canadianEducation': { type: 'enum', values: ['NONE', 'ONE_TWO', 'THREE_PLUS'] },
  'additional.sibling': BOOL,
  'additional.eeNomination': BOOL,
  'funds.satisfied': BOOL,
  'intent.outsideQuebec': BOOL,
  'rcip.recommendationPresent': BOOL,
  'rcip.recommendationIssuedOn': { type: 'date' },
} as const satisfies Record<string, Kind>;
export type FactPath = keyof typeof FACT_PATHS;
export const FACT_PATH_LIST = Object.keys(FACT_PATHS).sort() as FactPath[];
export const isFactPath = (p: string): p is FactPath => Object.hasOwn(FACT_PATHS, p);
export type NormalizedFacts = Record<FactPath, NormalizedFact>;

export function validFactValue(path: FactPath, value: FactValue): boolean {
  if (value === null) return true;
  const k = FACT_PATHS[path] as Kind;
  switch (k.type) {
    case 'int': return Number.isSafeInteger(value) && (value as number) >= k.min && (value as number) <= k.max;
    case 'bool': return typeof value === 'boolean';
    case 'date': return isRealDate(value);
    case 'noc': return typeof value === 'string' && /^\d{5}$/.test(value);
    case 'enum': return typeof value === 'string' && k.values.includes(value);
  }
}

export type WageRow = { nocCode: string; tier: 'TIER_130' | 'TIER_150' | 'TIER_200' };
export type NormalizationInput = {
  profileDate: string;
  profile: Profile;
  details: IntakeDetails | null;
  crsInput: CrsInput | null;
  eligibility: { inputs: EligibilityInput; asOf: string } | null;
  verifiedCategories: readonly string[];
  wageRows: readonly WageRow[] | null;
};

const CRS_EDU: Record<CrsInput['education'], typeof EDUCATION_LEVELS[number]> = { below_secondary: 'LESS_THAN_SECONDARY', secondary: 'SECONDARY', one_year: 'ONE_YEAR', two_year: 'TWO_YEAR', bachelor: 'BACHELOR', two_or_more: 'TWO_OR_MORE', master: 'MASTERS_OR_PROFESSIONAL', doctorate: 'DOCTORATE' };
// Profile option 'diploma' does not say one or two years: it stays UNKNOWN rather than being guessed.
const PROFILE_EDU: Partial<Record<Profile['education'], typeof EDUCATION_LEVELS[number]>> = { below_secondary: 'LESS_THAN_SECONDARY', secondary: 'SECONDARY', bachelor: 'BACHELOR', master: 'MASTERS_OR_PROFESSIONAL', doctorate: 'DOCTORATE' };
const ELIG_EDU: Partial<Record<EligibilityInput['education'], typeof EDUCATION_LEVELS[number]>> = { none: 'LESS_THAN_SECONDARY', secondary: 'SECONDARY', one_year: 'ONE_YEAR', two_year: 'TWO_YEAR', bachelor: 'BACHELOR', two_credentials: 'TWO_OR_MORE', master: 'MASTERS_OR_PROFESSIONAL', doctorate: 'DOCTORATE' };
// CRS calculator tuples are entered in the order listening, speaking, reading, writing (components/operations/crs.tsx).
const CRS_TUPLE: readonly Ability[] = ['listening', 'speaking', 'reading', 'writing'];

function ageAt(birth: string, on: string): number | null {
  if (!isRealDate(birth) || !isRealDate(on) || birth > on) return null;
  const [by, bm, bd] = birth.split('-').map(Number), [y, m, d] = on.split('-').map(Number);
  return y - by - ((m < bm || (m === bm && d < bd)) ? 1 : 0);
}
function testValidOn(date: string, on: string): boolean | null {
  if (!isRealDate(date) || !isRealDate(on)) return null;
  if (date > on) return false;
  const [y, m, d] = date.split('-').map(Number), expiry = `${String(y + 2).padStart(4, '0')}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  return on < expiry;
}
const tri = (v: string | undefined): boolean | null => v === 'yes' ? true : v === 'no' ? false : null;

export function normalizeCase(i: NormalizationInput): NormalizedFacts {
  if (!isRealDate(i.profileDate)) throw new Error('PROFILE_DATE_INVALID');
  const out = Object.fromEntries(FACT_PATH_LIST.map(p => [p, { value: null, state: 'UNKNOWN', origin: 'none' }])) as NormalizedFacts;
  const set = (p: FactPath, value: FactValue, state: Exclude<FactState, 'UNKNOWN'>, origin: string) => {
    if (value === null) return;
    if (!validFactValue(p, value)) throw new Error('NORMALIZED_VALUE_OUT_OF_DOMAIN:' + p);
    out[p] = { value, state, origin };
  };
  const c = i.crsInput, e = i.eligibility?.inputs ?? null, d = i.details, verifiedDoc = (k: string) => i.verifiedCategories.includes(k);

  // Age at the profile date: date of birth backed by the verified passport, else the staff-verified CRS input.
  const age = d ? ageAt(d.birthDate, i.profileDate) : null;
  if (age !== null) set('person.ageYears', age, verifiedDoc('passport') && d?.passportConfirmed ? 'VERIFIED' : 'REPORTED', 'details.birthDate');
  else if (c) set('person.ageYears', c.age, 'VERIFIED', 'case_crs.age');
  else if (e && e.age !== null) set('person.ageYears', e.age, 'VERIFIED', 'eligibility.age');

  if (c) set('family.spouseClassification', c.withSpouse ? 'WITH_SPOUSE' : 'WITHOUT_SPOUSE', 'VERIFIED', 'case_crs.withSpouse');
  else if (d && ['single', 'divorced', 'separated', 'widowed'].includes(d.marital)) set('family.spouseClassification', 'WITHOUT_SPOUSE', 'REPORTED', 'details.marital');
  else if (d && ['married', 'common_law'].includes(d.marital)) {
    const sp = d.companions.filter(x => x.relationship === 'spouse' || x.relationship === 'partner');
    if (sp.some(x => x.accompany === 'yes')) set('family.spouseClassification', 'WITH_SPOUSE', 'REPORTED', 'details.companions');
    else if (sp.length && sp.every(x => x.accompany === 'no')) set('family.spouseClassification', 'WITHOUT_SPOUSE', 'REPORTED', 'details.companions');
  }

  if (c) set('education.level', CRS_EDU[c.education], 'VERIFIED', 'case_crs.education');
  else if (e && e.educationValid === 'yes' && ELIG_EDU[e.education]) set('education.level', ELIG_EDU[e.education] ?? null, 'VERIFIED', 'eligibility.education');
  else if (PROFILE_EDU[i.profile.education]) set('education.level', PROFILE_EDU[i.profile.education] ?? null, 'REPORTED', 'profile.education');
  if (e && tri(e.educationValid) !== null) set('education.recognized', tri(e.educationValid), 'VERIFIED', 'eligibility.educationValid');
  else if (tri(i.profile.eca) !== null) set('education.recognized', tri(i.profile.eca), 'REPORTED', 'profile.eca');

  // Language: the staff-verified CRS input holds CLB/NCLC per ability and the test dates.
  if (c) {
    const first = c.firstLanguage, second = first === 'english' ? 'french' : 'english';
    const firstDate = first === 'english' ? c.englishDate : c.frenchDate, secondDate = second === 'english' ? c.englishDate : c.frenchDate;
    set('language.first.language', first === 'english' ? 'ENGLISH' : 'FRENCH', 'VERIFIED', 'case_crs.firstLanguage');
    CRS_TUPLE.forEach((a, k) => set(`language.first.${a}` as FactPath, c[first][k], 'VERIFIED', 'case_crs.' + first));
    set('language.first.min', Math.min(...c[first]), 'VERIFIED', 'case_crs.' + first);
    set('language.first.testValid', testValidOn(firstDate, i.profileDate), 'VERIFIED', 'case_crs.' + first + 'Date');
    const tested = c[second].some(v => v > 0);
    set('language.second.state', tested ? 'TESTED' : 'NOT_TESTED', 'VERIFIED', 'case_crs.' + second);
    if (tested && testValidOn(secondDate, i.profileDate) === true) {
      CRS_TUPLE.forEach((a, k) => set(`language.second.${a}` as FactPath, c[second][k], 'VERIFIED', 'case_crs.' + second));
      set('language.second.min', Math.min(...c[second]), 'VERIFIED', 'case_crs.' + second);
    }
    const englishValid = c.english.some(v => v > 0) ? testValidOn(c.englishDate, i.profileDate) : null, frenchValid = c.french.some(v => v > 0) ? testValidOn(c.frenchDate, i.profileDate) : null;
    if (englishValid === true) set('language.english.min', Math.min(...c.english), 'VERIFIED', 'case_crs.english');
    if (frenchValid === true) set('language.french.min', Math.min(...c.french), 'VERIFIED', 'case_crs.french');
    if (!c.english.some(v => v > 0)) set('language.english.min', 0, 'VERIFIED', 'case_crs.english');
    if (!c.french.some(v => v > 0)) set('language.french.min', 0, 'VERIFIED', 'case_crs.french');
  }

  // Occupation and work: the eligibility run is the staff-verified source; the profile NOC alone is REPORTED.
  if (e && /^\d{5}$/.test(e.noc)) { set('work.primaryNoc', e.noc, 'VERIFIED', 'eligibility.noc'); set('work.primaryTeer', Number(e.noc[1]), 'VERIFIED', 'eligibility.noc'); }
  else if (/^\d{5}$/.test(i.profile.noc)) { set('work.primaryNoc', i.profile.noc, 'REPORTED', 'profile.noc'); set('work.primaryTeer', Number(i.profile.noc[1]), 'REPORTED', 'profile.noc'); }
  if (e) {
    set('work.dutiesMatched', tri(e.dutiesMatched), 'VERIFIED', 'eligibility.dutiesMatched');
    set('work.fswContinuousMonths10', e.fswContinuousMonths10, 'VERIFIED', 'eligibility.fswContinuousMonths10');
    set('work.fswHours10', e.fswHours10, 'VERIFIED', 'eligibility.fswHours10');
    set('work.paidPrimary', tri(e.fswPaidPrimary), 'VERIFIED', 'eligibility.fswPaidPrimary');
    set('work.cecMonths3', e.cecMonths3, 'VERIFIED', 'eligibility.cecMonths3');
    set('work.cecHours3', e.cecHours3, 'VERIFIED', 'eligibility.cecHours3');
    const cecAuthorized = e.cecAuthorizedEmployee === 'no' || e.cecStudentWork === 'yes' ? false : e.cecAuthorizedEmployee === 'yes' && e.cecStudentWork === 'no' && e.cecSelfEmployment === 'no' ? true : null;
    set('work.cecAuthorized', cecAuthorized, 'VERIFIED', 'eligibility.cecAuthorizedEmployee');
    set('work.fstMonths5', e.fstMonths5, 'VERIFIED', 'eligibility.fstMonths5');
    set('work.fstHours5', e.fstHours5, 'VERIFIED', 'eligibility.fstHours5');
    set('work.fstQualifiedSameNoc', tri(e.fstQualifiedPaidSameNoc), 'VERIFIED', 'eligibility.fstQualifiedPaidSameNoc');
    set('funds.satisfied', tri(e.fundsSatisfied), 'VERIFIED', 'eligibility.fundsSatisfied');
    set('intent.outsideQuebec', tri(e.outsideQuebec), 'VERIFIED', 'eligibility.outsideQuebec');
    set('additional.tradeCertificate', tri(e.tradeCertificate), 'VERIFIED', 'eligibility.tradeCertificate');
  }
  if (c) {
    set('work.canadianYears', c.canadianYears, 'VERIFIED', 'case_crs.canadianYears');
    set('work.foreignYears', c.foreignYears, 'VERIFIED', 'case_crs.foreignYears');
    if (out['additional.tradeCertificate'].state === 'UNKNOWN') set('additional.tradeCertificate', c.tradeCertificate, 'VERIFIED', 'case_crs.tradeCertificate');
    set('additional.canadianEducation', c.canadianEducation === 'three_plus' ? 'THREE_PLUS' : c.canadianEducation === 'one_two' ? 'ONE_TWO' : 'NONE', 'VERIFIED', 'case_crs.canadianEducation');
    set('additional.sibling', c.sibling, 'VERIFIED', 'case_crs.sibling');
    set('additional.eeNomination', c.nomination, 'VERIFIED', 'case_crs.nomination');
    if (c.withSpouse) {
      set('spouse.education.level', CRS_EDU[c.spouseEducation], 'VERIFIED', 'case_crs.spouseEducation');
      const tested = c.spouseLanguage.some(v => v > 0);
      if (!tested) set('spouse.language.state', 'NOT_TESTED', 'VERIFIED', 'case_crs.spouseLanguage');
      else if (testValidOn(c.spouseLanguageDate, i.profileDate) === true) {
        set('spouse.language.state', 'TESTED', 'VERIFIED', 'case_crs.spouseLanguage');
        CRS_TUPLE.forEach((a, k) => set(`spouse.language.${a}` as FactPath, c.spouseLanguage[k], 'VERIFIED', 'case_crs.spouseLanguage'));
      }
      set('spouse.canadianWorkYears', c.spouseCanadianYears, 'VERIFIED', 'case_crs.spouseCanadianYears');
    }
  }

  // High-wage tiers come only from the sealed wage dataset for a verified occupation; no dataset => UNKNOWN.
  if (i.wageRows) {
    const tierOf = (noc: FactValue) => (typeof noc === 'string' ? i.wageRows!.find(r => r.nocCode === noc)?.tier : undefined) ?? 'NONE';
    const primary = out['work.primaryNoc'];
    if (primary.state === 'VERIFIED' && out['work.canadianYears'].state === 'VERIFIED') set('work.highWageTier', (out['work.canadianYears'].value as number) >= 1 ? tierOf(primary.value) : 'NONE', 'VERIFIED', 'wage_dataset:eligibility.noc');
  }
  const offerReported = d?.guide.offer === 'yes' ? true : d?.guide.offer === 'no' ? false : null;
  if (verifiedDoc('offer')) set('offer.present', true, 'VERIFIED', 'documents.offer');
  else if (offerReported !== null) set('offer.present', offerReported, 'REPORTED', 'details.guide.offer');
  else if (tri(i.profile.jobOffer) !== null) set('offer.present', tri(i.profile.jobOffer), 'REPORTED', 'profile.jobOffer');
  if (d && /^\d{5}$/.test(d.offerNoc)) {
    set('offer.noc', d.offerNoc, verifiedDoc('offer') ? 'VERIFIED' : 'REPORTED', 'details.offerNoc');
    if (i.wageRows && verifiedDoc('offer')) set('offer.highWageTier', i.wageRows.find(r => r.nocCode === d.offerNoc)?.tier ?? 'NONE', 'VERIFIED', 'wage_dataset:documents.offer');
  } else if (out['offer.present'].value === false && out['offer.present'].state === 'VERIFIED') set('offer.highWageTier', 'NONE', 'VERIFIED', 'documents.offer');
  // A staff-verified "no qualifying offer" can only lower points, so it is accepted; a claimed tier still needs the
  // verified offer document and the sealed wage dataset above.
  if (out['offer.highWageTier'].state === 'UNKNOWN' && c && c.highWageOffer === 'none') set('offer.highWageTier', 'NONE', 'VERIFIED', 'case_crs.highWageOffer');
  if (tri(i.profile.designated) !== null) set('offer.employerDesignated', tri(i.profile.designated), 'REPORTED', 'profile.designated');
  if (tri(i.profile.jobConditions) !== null) set('offer.conditionsMet', tri(i.profile.jobConditions), 'REPORTED', 'profile.jobConditions');
  if (verifiedDoc('recommendation')) set('rcip.recommendationPresent', true, 'VERIFIED', 'documents.recommendation');
  else if (tri(i.profile.recommendation) !== null) set('rcip.recommendationPresent', tri(i.profile.recommendation), 'REPORTED', 'profile.recommendation');
  if (d && isRealDate(d.recommendationDate)) set('rcip.recommendationIssuedOn', d.recommendationDate, verifiedDoc('recommendation') ? 'VERIFIED' : 'REPORTED', 'details.recommendationDate');
  return out;
}
