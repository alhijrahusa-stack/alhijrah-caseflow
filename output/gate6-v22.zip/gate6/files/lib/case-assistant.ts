// v2.2 Gate 5 — the single case assistant (ASSISTANT job). Runs only when the conversation is BOT_ACTIVE, the client
// granted LLM_CHAT_ASSISTANT and a professional provider is configured. Its tools are the authorized read set only: the
// client's own limited case context, the office FAQ and the latest published assessment projection — it never writes
// facts or decisions. The reply is committed with the automationGeneration, the client sequence it answers, the case
// data revision and the rule generation it read; the chat_message_guard trigger rejects it (ASSISTANT_FENCED) if a
// handoff/claim, a newer client message, a data change or a rule activation happened meanwhile — the late output is
// discarded, never published. A recommended handoff is committed in the same batch as the reply.
import { z } from 'zod';
import { getDb } from '@/db';
import { candidates,clientCases,caseConversations,caseChatMessages } from '@/db/schema';
import { eq,desc } from 'drizzle-orm';
import type { JobContext,JobOutcome } from './jobs';
import { hasConsent } from './outbox';
import { professionalConfig,professionalJson } from './professional-ai';
import { caseFacts } from './support';
import { rankFaq,maskIdentifiers } from './faq-retrieval';
import { faqAnswer } from './faq';
import { decrypt } from './security';
import { SYSTEM_USER_ID } from './rbac';
import { ApiError } from './api-error';
import { jcsHash } from './v22-core';

export type Availability='READY'|'UNCONFIGURED'|'CONSENT_REQUIRED'|'UNAVAILABLE';
export async function assistantAvailability(caseId:string):Promise<Availability>{
 try{const cfg=await professionalConfig();if(!cfg.configured)return 'UNCONFIGURED';return await hasConsent(caseId,'LLM_CHAT_ASSISTANT')?'READY':'CONSENT_REQUIRED';}catch{return 'UNAVAILABLE';}
}
const draftSchema=z.object({text:z.string().min(1).max(4000),handoffRecommended:z.boolean()}).strict();
const draftJson={type:'object',additionalProperties:false,required:['text','handoffRecommended'],properties:{text:{type:'string'},handoffRecommended:{type:'boolean'}}};
const SYSTEM=`You are the digital assistant of ALHIJRAH Services, an administrative office preparing Canada immigration files.
Reply in the client's language (Arabic by default), politely, in at most 120 words, plain text.
Use ONLY the supplied case context, published assessment summary and office reference. Never assess eligibility beyond the published summary, promise approval, visas, jobs or timelines, give legal advice, quote prices, or ask for passwords or codes.
Set handoffRecommended=true for payments, complaints, refusals, legal matters, urgent deadlines, file changes, anything the context does not answer, or when the client asks for a person; then reply with one short reassuring sentence.`;
export async function processAssistant({job}:JobContext):Promise<JobOutcome>{
 const p=JSON.parse(job.payload) as {conversationId:string;inReplyToSequence:number;automationGeneration:number;dataRevision:number;ruleGeneration:number};
 if(!job.caseId)return {state:'FAILED',errorCode:'CASE_REQUIRED'};
 const db=getDb(),[c]=await db.select().from(caseConversations).where(eq(caseConversations.conversationId,p.conversationId)).limit(1);
 // Cheap pre-checks; the trigger is the authority at commit time.
 if(!c||c.state!=='BOT_ACTIVE'||c.automationGeneration!==p.automationGeneration||c.lastClientSequence!==p.inReplyToSequence)return {state:'CANCELLED',errorCode:'ASSISTANT_STALE'};
 const availability=await assistantAvailability(job.caseId);if(availability!=='READY')return {state:'CANCELLED',errorCode:'ASSISTANT_'+availability};
 const [cand]=await db.select().from(candidates).where(eq(candidates.id,job.caseId)).limit(1),[client]=await db.select().from(clientCases).where(eq(clientCases.candidateId,job.caseId)).limit(1);
 if(!cand||!client)return {state:'FAILED',errorCode:'CASE_CONTEXT_MISSING'};
 const history=await db.select().from(caseChatMessages).where(eq(caseChatMessages.conversationId,c.conversationId)).orderBy(desc(caseChatMessages.sequence)).limit(12);
 const profile=JSON.parse(cand.profile) as Record<string,string>,scrub=(t:string)=>{let x=t;for(const v of [profile.fullName,profile.email,profile.phone])if(v&&v.length>2)x=x.split(v).join('[private]');return maskIdentifiers(x);};
 const turns=(await Promise.all(history.reverse().map(async m=>({role:m.actorType==='CLIENT'?'client':'office',text:(JSON.parse(await decrypt(m.bodyEncrypted)) as {text:string|null}).text})))).filter(t=>t.text).map(t=>({role:t.role,text:scrub(t.text!).slice(0,1500)}));
 const last=turns.filter(t=>t.role==='client').at(-1)?.text||'',faq=rankFaq(last,3).map(e=>({q:e.question,a:faqAnswer(e).slice(0,700)}));
 const { latestV22 }=await import('./assessment-store');const published=await latestV22(job.caseId).catch(()=>null);
 const projection=published?{note:'Published screening summary (not a final decision).',summary:JSON.stringify(published).slice(0,1500)}:null;
 let draft:z.infer<typeof draftSchema>;
 try{draft=(await professionalJson(SYSTEM,{caseContext:await caseFacts(cand,client),assessment:projection,officeReference:faq,conversation:turns},draftSchema,draftJson,1200)).data as z.infer<typeof draftSchema>;}
 catch(e){if(e instanceof ApiError&&e.status===503)return {state:'CANCELLED',errorCode:'ASSISTANT_UNCONFIGURED'};throw e;}
 const { appendMessage }=await import('./case-chat');
 try{
  const out=await appendMessage({kind:'ASSISTANT',userId:SYSTEM_USER_ID},job.caseId,{clientMessageId:'assistant:'+p.conversationId+':'+p.inReplyToSequence,kind:'TEXT',body:{text:draft.text,evidenceIds:[],assessmentId:null,repliedToMessageId:null,sourceRefs:[]},fence:{automationGeneration:p.automationGeneration,inReplyToSequence:p.inReplyToSequence,dataRevision:p.dataRevision,ruleGeneration:p.ruleGeneration}},
   async conv=>draft.handoffRecommended?{after:[db.insert((await import('@/db/schema')).caseChatTransitions).values({transitionId:crypto.randomUUID(),conversationId:conv.conversationId,requestKey:'assistant-handoff:'+conv.conversationId+':'+p.inReplyToSequence,requestHash:await jcsHash({conv:conv.conversationId,seq:p.inReplyToSequence}),expectedRevision:conv.revision,oldState:'BOT_ACTIVE',newState:'HANDOFF_PENDING',assignedTo:null,actorId:SYSTEM_USER_ID,createdAt:new Date().toISOString()})]}:{});
  return {state:'SUCCEEDED',resultRef:out.message.messageId};
 }catch(e){if(e instanceof ApiError&&e.message==='ASSISTANT_FENCED')return {state:'CANCELLED',errorCode:'ASSISTANT_FENCED_DISCARDED'};throw e;}
}
