import { z } from 'zod';
import { profileSchema,dateSchema,jobSchema } from './model';
export { jobSchema } from './model';
import { latinDigits } from './contact-identity';
import { pathwayIds,categoryIds } from './pathways';
export { pathwayConsistent } from './pathways';
export { LEGAL_VERSION as CONSENT_VERSION,AUTHORIZATION_TEXT as CONSENT_TEXT,AUTHORIZATION_TEXT as CONSENT_EN } from './legal';
import { LEGAL_VERSION } from './legal';
export const companionSchema=z.object({
  name:z.string().trim().max(150).default(''),relationship:z.enum(['unknown','spouse','partner','child','parent','other']).default('unknown'),
  ageGroup:z.enum(['unknown','under18','18to21','22plus']).default('unknown'),accompany:z.enum(['unknown','yes','no']).default('unknown'),
});
export const detailsSchema=z.object({
 offerTeer:z.number().int().min(0).max(5).nullable().default(null),offerNoc:z.string().regex(/^$|^\d{5}$/).default(''),
 aiConsent:z.boolean().default(false),
 city:z.string().trim().max(100).default(''),service:z.enum(['unknown','work','immigration','study','other']).default('unknown'),
 passportExpiry:dateSchema.default(''),passportNumber:z.string().trim().regex(/^$|^[A-Z0-9]{5,9}$/).default(''),birthDate:dateSchema.default(''),sex:z.enum(['','M','F','X']).default(''),issuingCountry:z.string().regex(/^$|^[A-Z]{3}$/).default(''),passportConfirmed:z.boolean().default(false),notes:z.string().trim().max(3000).default(''),additionalSkills:z.string().trim().max(4000).default(''),jobs:z.array(jobSchema).max(10).default([]),
 companions:z.array(companionSchema).max(15).default([]),preferredLanguage:z.enum(['ar','en']).default('ar'),
 industry:z.enum(['unknown','agriculture','food','hospitality','construction','transport','technology','health','office','other']).default('unknown'),
 marital:z.enum(['unknown','single','married','common_law','divorced','separated','widowed']).default('unknown'),
 employment:z.enum(['unknown','employed','self_employed','unemployed','student','retired']).default('unknown'),
 englishTest:z.enum(['unknown','none','ielts_general','celpip_general','pte_core','other']).default('unknown'),
 frenchTest:z.enum(['unknown','none','tef_canada','tcf_canada','other']).default('unknown'),
 previousRefusal:z.enum(['unknown','yes','no']).default('unknown'),
 lmiaStatus:z.enum(['unknown','not_available','in_progress','positive','negative']).default('unknown'),
 familySizeProvided:z.boolean().default(false),
 category:z.union([z.literal(''),z.literal('not_sure'),z.enum(categoryIds)]).default(''),pathway:z.union([z.literal(''),z.enum(pathwayIds)]).default(''),recommendationDate:dateSchema.default(''),arrival:z.enum(['unknown','air','land_sea']).default('unknown'),
 guide:z.object({goal:z.enum(['','settle','work','study','visit']).default(''),offer:z.enum(['','yes','no']).default(''),trade:z.enum(['','yes','no']).default(''),degree:z.enum(['','yes','no']).default(''),french:z.enum(['','yes','no']).default('')}).default({}),
});

export type IntakeDetails=z.infer<typeof detailsSchema>;
export const publicProfileSchema=profileSchema.extend({phone:z.string().trim().max(40).transform(latinDigits).refine(v=>/^[+\d\s().-]+$/.test(v)&&v.replace(/\D/g,'').replace(/^00/,'').length>=7&&v.replace(/\D/g,'').replace(/^00/,'').length<=15,'أدخل رقم تواصل صحيحًا، ويفضل مع رمز الدولة'),email:z.string().trim().email('أدخل بريدًا صحيحًا').max(254)});
export const intakeSchema=z.object({requestId:z.string().uuid(),profile:publicProfileSchema,details:detailsSchema.default({}),consentVersion:z.enum(['intake-2026-11-v1','intake-2026-11-v2','intake-2026-11-v3',LEGAL_VERSION]),legalAuthorization:z.boolean().optional(),website:z.string().max(0).optional(),captchaToken:z.string().max(2048).optional(),
 // v2.2 Gate 4: account draft + fixed signature binding (required for every new submission; enforced by /api/intake).
 draftId:z.string().uuid().optional(),expectedDraftRevision:z.number().int().min(1).optional(),signatureId:z.string().uuid().optional(),signedPayloadHash:z.string().regex(/^[0-9a-f]{64}$/).optional()}).strict();
export const categoryKeys=['passport','photo','resume','education','experience','language','eca','offer','recommendation','funds','lmia','other'] as const;
export const publicSupplementSchema=z.object({version:z.number().int().positive(),profile:profileSchema.omit({fullName:true,phone:true,email:true,consent:true,jobs:true}).partial().strict(),details:detailsSchema}).strict();
