import { z } from 'zod';
import { env } from 'cloudflare:workers';
import { getDb } from '@/db';
import { documents,events,candidates,durableJobs } from '@/db/schema';
import { eq,and,count } from 'drizzle-orm';
import { documentLabels } from './model';
import { ApiError } from './server';
import { sha } from './security';
import { jobRow } from './jobs';
import { SYSTEM_USER_ID } from './rbac';
// v2.2 Gate 5: every new upload starts QUARANTINED with an INGESTION job in the same batch (scan → CLEAN only through a
// configured scanner). opts.voice accepts audio voice notes for the case chat (same storage, scan and job pipeline).
export async function uploadDocument(request:Request,candidate:{id:string;ownerId:string},byClient=false,opts:{voice?:boolean}={}){
 if(!env.BUCKET)throw new ApiError(503,'تخزين المستندات غير متاح');const max=(byClient?10:20)*1024*1024;
 if(Number(request.headers.get('content-length'))>max+1024*1024)throw new ApiError(413,`الحد الأقصى ${byClient?10:20} MB للملف`);
 if(!request.headers.get('content-type')?.startsWith('multipart/form-data'))throw new ApiError(415,'اختر الملف من نموذج الرفع');
 const db=getDb(),[{total}]=await db.select({total:count()}).from(documents).where(eq(documents.candidateId,candidate.id));if(total>=40)throw new ApiError(400,'الحد الأقصى 40 مستندًا لكل ملف');
 const form=await boundedForm(request,max+1024*1024),file=form.get('file'),category=opts.voice?'chat_voice':String(form.get('category')||'other');if(!(file instanceof File)||!file.size||file.size>max)throw new ApiError(400,`اختر ملفًا حتى ${byClient?10:20} MB`);if(!opts.voice&&!Object.hasOwn(documentLabels,category))throw new ApiError(400,'تصنيف المستند غير صحيح');
 const rawPreparation=form.get('preparation');let preparation='{}';if(typeof rawPreparation==='string'){if(rawPreparation.length>5000)throw new ApiError(400,'بيانات تجهيز المستند غير صحيحة');let value;try{value=JSON.parse(rawPreparation);}catch{throw new ApiError(400,'بيانات تجهيز المستند غير صحيحة');}const parsed=z.object({version:z.literal('2026-11-v1'),sourceName:z.string().max(180),sourceSize:z.number().int().min(1).max(30*1024*1024),outputSize:z.number().int().min(1).max(max),converted:z.boolean(),width:z.number().int().positive().max(40000).optional(),height:z.number().int().positive().max(40000).optional(),warnings:z.array(z.string().max(300)).max(8)}).strict().safeParse(value);if(!parsed.success||parsed.data.outputSize!==file.size)throw new ApiError(400,'بيانات تجهيز المستند غير صحيحة');preparation=JSON.stringify(parsed.data);}
 const bytes=await file.arrayBuffer(),b=new Uint8Array(bytes),text=new TextDecoder().decode(b.slice(0,16));let mime='';
 if(opts.voice){if(b[0]===0x1a&&b[1]===0x45&&b[2]===0xdf&&b[3]===0xa3)mime='audio/webm';else if(text.startsWith('OggS'))mime='audio/ogg';else if(text.slice(4,8)==='ftyp')mime='audio/mp4';if(!mime)throw new ApiError(415,'الرسالة الصوتية يجب أن تكون WebM أو Ogg أو MP4.');}
 else if(text.startsWith('%PDF-'))mime='application/pdf';else if(b[0]===255&&b[1]===216&&b[2]===255)mime='image/jpeg';else if([137,80,78,71,13,10,26,10].every((v,i)=>b[i]===v))mime='image/png';else if(text.startsWith('RIFF')&&text.slice(8,12)==='WEBP')mime='image/webp';else if(!byClient&&text.slice(4,8)==='ftyp')mime='video/mp4';
 if(!mime)throw new ApiError(400,'ارفع PDF أو JPG أو PNG أو WebP');const hash=await sha(bytes);
 const [duplicate]=await db.select({id:documents.id}).from(documents).where(and(eq(documents.candidateId,candidate.id),eq(documents.category,category),eq(documents.sha256,hash))).limit(1);
 if(duplicate)return {ok:true,duplicate:true,id:duplicate.id};
 const id=crypto.randomUUID(),objectKey=candidate.ownerId+'/'+candidate.id+'/'+id,name=file.name.replace(/[\x00-\x1f]/g,'').slice(0,180)||'document',now=new Date().toISOString();
 await env.BUCKET.put(objectKey,bytes,{httpMetadata:{contentType:mime}});
 const job=await jobRow({kind:'INGESTION',caseId:candidate.id,requestKey:'ingest:'+id,payload:{documentId:id},actor:SYSTEM_USER_ID});
 try{await db.batch([db.insert(documents).values({id,ownerId:candidate.ownerId,candidateId:candidate.id,name,objectKey,preparation,size:file.size,mime,category,sha256:hash,verified:false,createdAt:now,integrityState:'QUARANTINED'}),db.insert(durableJobs).values(job),db.insert(events).values({id:crypto.randomUUID(),ownerId:candidate.ownerId,candidateId:candidate.id,action:opts.voice?'رسالة صوتية في محادثة الملف':byClient?'رفع العميل مستندًا':'تم رفع مستند',note:opts.voice?'—':documentLabels[category]+': '+name,createdAt:now}),db.update(candidates).set({updatedAt:now,version:sqlIncrement()}).where(eq(candidates.id,candidate.id))]);}catch(e){await env.BUCKET.delete(objectKey).catch(()=>{});throw e;}return {ok:true,id};
}
import { sql } from 'drizzle-orm';
function sqlIncrement(){return sql`${candidates.version}+1`;}

export async function boundedForm(request:Request,max:number){
 const reader=request.body?.getReader();if(!reader)throw new ApiError(400,'لم يصل الملف');let size=0,tooLarge=false;
 const limited=new ReadableStream<Uint8Array>({async pull(controller){try{const {done,value}=await reader.read();if(done){controller.close();reader.releaseLock();return;}size+=value.byteLength;if(size>max){tooLarge=true;await reader.cancel();controller.error(new Error('limit'));return;}controller.enqueue(value);}catch(e){controller.error(e);}},async cancel(){await reader.cancel();}});
 try{return await new Response(limited,{headers:{'Content-Type':request.headers.get('content-type')!}}).formData();}catch{throw new ApiError(tooLarge?413:400,tooLarge?'الملف أكبر من الحد المسموح':'تعذّر قراءة المرفق');}
}
