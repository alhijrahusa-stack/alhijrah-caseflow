// v2.2 Gate 5 — Zero-Touch ingestion (INGESTION job). QUARANTINED → SCANNING → CLEAN | REJECTED | ERROR through the
// configured scanner adapter only (service binding EVIDENCE_SCANNER). Without a scanner the job ends FAILED with
// SCANNER_NOT_CONFIGURED and the file stays QUARANTINED: nothing is marked clean, played in chat or turned into a fact.
// The SHA-256 proves the bytes are intact; it never makes an extracted value a verified fact. Extraction (I15) has no
// configured adapter either, so no claim proposals are created; staff review of uploaded documents works as before.
import { env } from 'cloudflare:workers';
import { getDb } from '@/db';
import { documents } from '@/db/schema';
import { and,eq } from 'drizzle-orm';
import type { JobContext,JobOutcome } from './jobs';
import { sha } from './security';

type Scanner={fetch(input:RequestInfo,init?:RequestInit):Promise<Response>};
export function scannerConfigured(){const s=(env as unknown as {EVIDENCE_SCANNER?:Scanner}).EVIDENCE_SCANNER;return s&&typeof s.fetch==='function'?s:null;}
export type IntegrityView='PROCESSING'|'AVAILABLE'|'REJECTED';
/** Chat/UI view of a document's integrity: only CLEAN is AVAILABLE for playback/download in chat. */
export const integrityView=(state:string):IntegrityView=>state==='CLEAN'?'AVAILABLE':state==='REJECTED'?'REJECTED':'PROCESSING';
async function move(id:string,from:string,to:string,extra:Partial<typeof documents.$inferInsert>={}){return (await getDb().update(documents).set({integrityState:to,...extra}).where(and(eq(documents.id,id),eq(documents.integrityState,from))).returning({id:documents.id})).length===1;}
export async function processIngestion({job,heartbeat}:JobContext):Promise<JobOutcome>{
 const documentId=String((JSON.parse(job.payload) as {documentId?:string}).documentId||'');
 const [d]=await getDb().select().from(documents).where(eq(documents.id,documentId)).limit(1);
 if(!d||d.candidateId!==job.caseId)return {state:'FAILED',errorCode:'DOCUMENT_NOT_FOUND'};
 if(d.integrityState==='CLEAN'||d.integrityState==='REJECTED'||d.integrityState==='LEGACY_UNSCANNED')return {state:'SUCCEEDED',resultRef:d.integrityState};
 const scanner=scannerConfigured();if(!scanner)return {state:'FAILED',errorCode:'SCANNER_NOT_CONFIGURED'};
 const bucket=(env as unknown as {BUCKET?:R2Bucket}).BUCKET;if(!bucket)throw new Error('BUCKET_UNAVAILABLE');
 if(d.integrityState!=='SCANNING'&&!await move(d.id,d.integrityState,'SCANNING'))return {state:'SUCCEEDED',resultRef:'CONCURRENT'};
 const obj=await bucket.get(d.objectKey);if(!obj){await move(d.id,'SCANNING','ERROR');return {state:'FAILED',errorCode:'OBJECT_MISSING'};}
 const bytes=await obj.arrayBuffer();if(await sha(bytes)!==d.sha256){await move(d.id,'SCANNING','REJECTED',{integrityCheckedAt:new Date().toISOString(),integrityEngine:'sha256-mismatch'});return {state:'SUCCEEDED',resultRef:'REJECTED'};}
 await heartbeat();
 const r=await scanner.fetch('https://scanner.internal/scan',{method:'POST',headers:{'Content-Type':'application/octet-stream','X-Content-Sha256':d.sha256},body:bytes});
 const v=await r.json().catch(()=>null) as {verdict?:string;engine?:string}|null;
 if(!r.ok||!v||!v.engine||(v.verdict!=='CLEAN'&&v.verdict!=='INFECTED')){await move(d.id,'SCANNING','ERROR');throw new Error('SCANNER_ERROR');}
 const now=new Date().toISOString();
 await move(d.id,'SCANNING',v.verdict==='CLEAN'?'CLEAN':'REJECTED',{integrityEngine:String(v.engine).slice(0,100),integrityCheckedAt:now});
 return {state:'SUCCEEDED',resultRef:v.verdict==='CLEAN'?'CLEAN':'REJECTED'};
}
