import { z } from 'zod';
import type { NormalizedFacts, FactPath } from './normalization.ts';
import { jcs } from './v22-core.ts';
// CRS per the official IRCC grid in force from 3 November 2026 (page dated 2026-11-03): the Labour Market Integration
// factor gives EITHER Canadian work experience (work length + high-wage occupation points) OR a high-wage job offer, not both.
export const CRS_VERSION='crs-2026-11-03';
export const CRS_EFFECTIVE='2026-11-03';
export const CRS_SOURCE='https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/express-entry/check-score/crs-criteria.html';
export const CRS_CHANGES='https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/express-entry/changes.html';
export const crsEducation=[['below_secondary','أقل من الثانوية'],['secondary','الثانوية'],['one_year','مؤهل سنة واحدة'],['two_year','مؤهل سنتين'],['bachelor','بكالوريوس / مؤهل 3 سنوات فأكثر'],['two_or_more','مؤهلان فأكثر أحدهما 3 سنوات فأكثر'],['master','ماجستير / درجة مهنية مؤهلة'],['doctorate','دكتوراه']] as const;
const level=z.number().int().min(0).max(12),skills=z.tuple([level,level,level,level]),education=z.enum(['below_secondary','secondary','one_year','two_year','bachelor','two_or_more','master','doctorate']);
export const crsSchema=z.object({
 age:z.number().int().min(0).max(120),withSpouse:z.boolean(),education,english:skills,french:skills,firstLanguage:z.enum(['english','french']),englishDate:z.string().regex(/^$|^\d{4}-\d{2}-\d{2}$/),frenchDate:z.string().regex(/^$|^\d{4}-\d{2}-\d{2}$/),
 canadianYears:z.number().int().min(0).max(5),foreignYears:z.number().int().min(0).max(3),highWageWork:z.enum(['none','1.3','1.5','2']),highWageOffer:z.enum(['none','1.3','1.5','2']).optional(),
 spouseEducation:education,spouseLanguage:skills,spouseLanguageDate:z.string().regex(/^$|^\d{4}-\d{2}-\d{2}$/),spouseCanadianYears:z.number().int().min(0).max(5),
 tradeCertificate:z.boolean(),canadianEducation:z.enum(['none','one_two','three_plus']),sibling:z.boolean(),nomination:z.boolean(),verified:z.literal(true),
}).strict().superRefine((v,ctx)=>{if(v.canadianYears===0&&v.highWageWork!=='none')ctx.addIssue({code:'custom',path:['highWageWork'],message:'نقاط المهن عالية الأجر تتطلب سنة كندية مؤهلة على الأقل.'});if(v[v.firstLanguage].every(n=>n===0))ctx.addIssue({code:'custom',path:['firstLanguage'],message:'أدخل نتيجة اللغة الرسمية الأولى من اختبار ساري.'});});
export type CrsInput=z.infer<typeof crsSchema>;
export function calculateCrs(input:CrsInput,asOf=new Date()){
 const p=crsSchema.parse(input),today=asOf.toISOString().slice(0,10),validDate=(value:string)=>!!value&&Number.isFinite(Date.parse(value+'T00:00:00Z'))&&new Date(value+'T00:00:00Z').toISOString().slice(0,10)===value&&value<=today&&Date.parse(value+'T00:00:00Z')>Date.UTC(asOf.getUTCFullYear()-2,asOf.getUTCMonth(),asOf.getUTCDate());
 if(p.english.some(v=>v>0)&&!validDate(p.englishDate))throw new Error('اختبار الإنجليزية غير مؤرخ أو منتهٍ أو غير صحيح.');if(p.french.some(v=>v>0)&&!validDate(p.frenchDate))throw new Error('اختبار الفرنسية غير مؤرخ أو منتهٍ أو غير صحيح.');if(p.withSpouse&&p.spouseLanguage.some(v=>v>0)&&!validDate(p.spouseLanguageDate))throw new Error('اختبار الزوج أو الشريك غير مؤرخ أو منتهٍ أو غير صحيح.');
 const spouse=p.withSpouse,at=(single:number,married:number)=>spouse?married:single,first=p[p.firstLanguage],second=p[p.firstLanguage==='english'?'french':'english'],lowest=Math.min(...first),educationIndex=crsEducation.findIndex(e=>e[0]===p.education),ageTable=[[18,99,90],[19,105,95],[30,105,95],[31,99,90],[32,94,85],[33,88,80],[34,83,75],[35,77,70],[36,72,65],[37,66,60],[38,61,55],[39,55,50],[40,50,45],[41,39,35],[42,28,25],[43,17,15],[44,6,5]],ageRow=ageTable.find(r=>r[0]===p.age);
 const age=p.age>=20&&p.age<=29?at(110,100):ageRow?at(ageRow[1],ageRow[2]):0,educationPoints=at([0,30,90,98,120,128,135,150][educationIndex],[0,28,84,91,112,119,126,140][educationIndex]);
 const firstPoints=first.reduce((sum,l)=>sum+(l<4?0:l<=5?6:l===6?at(9,8):l===7?at(17,16):l===8?at(23,22):l===9?at(31,29):at(34,32)),0),secondPoints=Math.min(spouse?22:24,second.reduce((sum,l)=>sum+(l<5?0:l<=6?1:l<=8?3:6),0));
 const workLength=at([0,40,53,64,72,80][p.canadianYears],[0,35,46,56,63,70][p.canadianYears]),highWageWork=({'none':0,'1.3':20,'1.5':40,'2':70})[p.highWageWork],offer=({'none':0,'1.3':50,'1.5':70,'2':100})[p.highWageOffer||'none'],experience=workLength+highWageWork,integration=Math.max(experience,offer),integrationBasis=offer>experience?'job_offer':'canadian_experience',core=age+educationPoints+firstPoints+secondPoints+integration;
 const spouseEducation=spouse?[0,2,6,7,8,9,10,10][crsEducation.findIndex(e=>e[0]===p.spouseEducation)]:0,spouseLanguage=spouse?p.spouseLanguage.reduce((sum,l)=>sum+(l<5?0:l<=6?1:l<=8?3:5),0):0,spouseWork=spouse?[0,5,7,8,9,10][p.spouseCanadianYears]:0,spouseTotal=spouseEducation+spouseLanguage+spouseWork;
 const group=educationIndex>=5?2:educationIndex>=2?1:0,eduLanguage=group&&lowest>=7?(group===2?(lowest>=9?50:25):(lowest>=9?25:13)):0,eduWork=group&&p.canadianYears>=1?(group===2?(p.canadianYears>=2?50:25):(p.canadianYears>=2?25:13)):0,educationTransfer=Math.min(50,eduLanguage+eduWork),foreignBand=p.foreignYears>=3?2:p.foreignYears>=1?1:0,foreignLanguage=foreignBand&&lowest>=7?(foreignBand===2?(lowest>=9?50:25):(lowest>=9?25:13)):0,foreignWork=foreignBand&&p.canadianYears>=1?(foreignBand===2?(p.canadianYears>=2?50:25):(p.canadianYears>=2?25:13)):0,foreignTransfer=Math.min(50,foreignLanguage+foreignWork),trade=p.tradeCertificate&&lowest>=5?(lowest>=7?50:25):0,transfer=Math.min(100,educationTransfer+foreignTransfer+trade);
 const frenchMin=Math.min(...p.french),englishMin=Math.min(...p.english),frenchBonus=frenchMin>=7?(englishMin>=5?50:25):0,canadianEducation=p.canadianEducation==='three_plus'?30:p.canadianEducation==='one_two'?15:0,additional=Math.min(600,(p.nomination?600:0)+(p.sibling?15:0)+frenchBonus+canadianEducation);
 return {version:CRS_VERSION,asOf:today,total:core+spouseTotal+transfer+additional,effectiveDate:CRS_EFFECTIVE,integrationBasis,core,spouse:spouseTotal,transfer,additional,breakdown:{age,education:educationPoints,firstLanguage:firstPoints,secondLanguage:secondPoints,integration,workLength,highWageWork,offer,spouseEducation,spouseLanguage,spouseWork,educationTransfer,foreignTransfer,trade,frenchBonus,canadianEducation,sibling:p.sibling?15:0,nomination:p.nomination?600:0},sources:[CRS_SOURCE,CRS_CHANGES]};
}

// ---- v2.2 Gate 3: CRS from a sealed rule payload (05 "CRS computation contract"). Every point and every cap is payload
// data: the tables below name only the lookup contract (table id + dimensions), never a value. Missing table/row/cap or
// corrupt data => RULE_UNAVAILABLE; unknown or (for VERIFIED_SCREENING) unverified facts => INCOMPLETE; contradictory
// facts => INVALID_INPUT. A COMPLETE result is an exact integer sum whose trace reconciles with every component and cap.
export type PolicyRow = { dimensionValues: (string | number | boolean | null | string[])[]; points: number; sourceId: string; locator: string };
export type PolicyTable = { tableId: string; dimensions: string[]; rows: PolicyRow[] };
export type PolicyCap = { capId: string; points: number; sourceId: string };
export type CrsPolicy = { tables: readonly PolicyTable[]; caps: readonly PolicyCap[]; policyHash: string };
const SPOUSE: FactPath = 'family.spouseClassification';
export const CRS_POLICY_TABLES: Readonly<Record<string, readonly string[]>> = Object.freeze({
  CRS_AGE: [SPOUSE, 'person.ageYears'], CRS_EDUCATION: [SPOUSE, 'education.level'], CRS_FIRST_LANGUAGE: [SPOUSE, 'clb'],
  CRS_SECOND_LANGUAGE: ['clb'], CRS_CANADIAN_WORK: [SPOUSE, 'work.canadianYears'], CRS_HIGH_WAGE_WORK: ['work.highWageTier'],
  CRS_HIGH_WAGE_OFFER: ['offer.highWageTier'], CRS_SPOUSE_EDUCATION: ['spouse.education.level'], CRS_SPOUSE_LANGUAGE: ['clb'],
  CRS_SPOUSE_WORK: ['spouse.canadianWorkYears'], CRS_LANGUAGE_BAND: ['clb'], CRS_EDUCATION_GROUP: ['education.level'],
  CRS_CANADIAN_WORK_BAND: ['work.canadianYears'], CRS_FOREIGN_WORK_BAND: ['work.foreignYears'],
  CRS_TRANSFER_EDUCATION_LANGUAGE: ['educationGroup', 'languageBand'], CRS_TRANSFER_EDUCATION_CANADIAN_WORK: ['educationGroup', 'canadianWorkBand'],
  CRS_TRANSFER_FOREIGN_LANGUAGE: ['foreignWorkBand', 'languageBand'], CRS_TRANSFER_FOREIGN_CANADIAN_WORK: ['foreignWorkBand', 'canadianWorkBand'],
  CRS_TRADE_LANGUAGE_BAND: ['clb'], CRS_TRANSFER_TRADE: ['additional.tradeCertificate', 'tradeLanguageBand'],
  CRS_ADDITIONAL_SIBLING: ['additional.sibling'], CRS_FRENCH_BAND: ['clb'], CRS_ENGLISH_BAND: ['clb'], CRS_ADDITIONAL_FRENCH: ['frenchBand', 'englishBand'],
  CRS_ADDITIONAL_CANADIAN_EDUCATION: ['additional.canadianEducation'], CRS_ADDITIONAL_NOMINATION: ['additional.eeNomination'],
});
export const CRS_POLICY_CAPS = Object.freeze(['CRS_SECOND_LANGUAGE_CAP_WITH_SPOUSE', 'CRS_SECOND_LANGUAGE_CAP_WITHOUT_SPOUSE', 'CRS_LMIF_CAP_WITH_SPOUSE', 'CRS_LMIF_CAP_WITHOUT_SPOUSE', 'CRS_SPOUSE_CAP', 'CRS_TRANSFER_EDUCATION_CAP', 'CRS_TRANSFER_FOREIGN_CAP', 'CRS_TRANSFER_TOTAL_CAP', 'CRS_ADDITIONAL_CAP', 'CRS_MAX_TOTAL_WITH_SPOUSE', 'CRS_MAX_TOTAL_WITHOUT_SPOUSE'] as const);
export type CrsComponents = { age: number; education: number; firstLanguage: number; secondLanguage: number; lmif: number; spouse: number; skillTransferability: number; additional: number };
export type CrsPolicyTrace = { lmif: { workLengthPoints: number; highWageExperiencePoints: number; experienceRoute: number; offerRoute: number; cap: number; selected: 'EXPERIENCE' | 'OFFER' | 'NONE'; tie: boolean }; secondLanguageBeforeCap: number; spouse: { education: number; language: number; work: number; beforeCap: number }; transfer: { educationLanguage: number; educationCanadianWork: number; foreignLanguage: number; foreignCanadianWork: number; trade: number; educationBeforeCap: number; foreignBeforeCap: number; beforeTotalCap: number }; additional: { sibling: number; french: number; canadianEducation: number; nomination: number; beforeCap: number }; rows: string[] };
export type CrsPolicyResult =
  | { status: 'COMPLETE'; total: number; maxTotal: number; components: CrsComponents; rulePolicyHash: string; missingFields: []; reasonCodes: string[]; trace: CrsPolicyTrace }
  | { status: 'INCOMPLETE' | 'RULE_UNAVAILABLE' | 'INVALID_INPUT' | 'NOT_APPLICABLE'; total: null; maxTotal: number | null; components: null; rulePolicyHash: string | null; missingFields: string[]; reasonCodes: string[] };
class RuleDataError extends Error {}
const unavailable = (hash: string | null, code: string): CrsPolicyResult => ({ status: 'RULE_UNAVAILABLE', total: null, maxTotal: null, components: null, rulePolicyHash: hash, missingFields: [], reasonCodes: [code] });
// Index and check the tables/caps once: exact dimensions, integer non-negative points, unique rows and caps.
function indexPolicy(policy: CrsPolicy) {
  const tables = new Map<string, Map<string, PolicyRow>>(), caps = new Map<string, number>();
  for (const id of Object.keys(CRS_POLICY_TABLES)) {
    const found = policy.tables.filter(t => t.tableId === id);
    if (found.length !== 1) throw new RuleDataError('CRS_TABLE_MISSING:' + id);
    const t = found[0];
    if (jcs(t.dimensions) !== jcs(CRS_POLICY_TABLES[id])) throw new RuleDataError('CRS_TABLE_DIMENSIONS:' + id);
    const rows = new Map<string, PolicyRow>();
    for (const r of t.rows) {
      if (!Number.isSafeInteger(r.points) || r.points < 0 || r.dimensionValues.length !== t.dimensions.length) throw new RuleDataError('CRS_TABLE_ROW_INVALID:' + id);
      const k = jcs(r.dimensionValues);
      if (rows.has(k)) throw new RuleDataError('CRS_TABLE_DUPLICATE_ROW:' + id);
      rows.set(k, r);
    }
    tables.set(id, rows);
  }
  for (const id of CRS_POLICY_CAPS) {
    const found = policy.caps.filter(c => c.capId === id);
    if (found.length !== 1 || !Number.isSafeInteger(found[0].points) || found[0].points < 0) throw new RuleDataError('CRS_CAP_MISSING:' + id);
    caps.set(id, found[0].points);
  }
  return { tables, caps };
}
export function crsFromPolicy(policy: CrsPolicy | null, facts: NormalizedFacts, purpose: 'RAPID_SCREENING' | 'VERIFIED_SCREENING'): CrsPolicyResult {
  if (!policy) return unavailable(null, 'CRS_RULE_UNAVAILABLE');
  let idx: ReturnType<typeof indexPolicy>;
  try { idx = indexPolicy(policy); } catch (e) { if (e instanceof RuleDataError) return unavailable(policy.policyHash, e.message); throw e; }
  const missing: string[] = [], reasons: string[] = [];
  const need = (p: FactPath) => {
    const f = facts[p];
    if (f.state === 'UNKNOWN') { missing.push(p); return null; }
    if (f.state === 'REPORTED' && purpose === 'VERIFIED_SCREENING') { missing.push(p); if (!reasons.includes('FACT_NOT_VERIFIED')) reasons.push('FACT_NOT_VERIFIED'); return null; }
    return f.value;
  };
  const spouse = need(SPOUSE), withSpouse = spouse === 'WITH_SPOUSE';
  const age = need('person.ageYears'), education = need('education.level'), firstMin = need('language.first.min');
  const first = (['speaking', 'listening', 'reading', 'writing'] as const).map(a => need(`language.first.${a}` as FactPath));
  if (need('language.first.testValid') === false) return { status: 'INVALID_INPUT', total: null, maxTotal: null, components: null, rulePolicyHash: policy.policyHash, missingFields: [], reasonCodes: ['FIRST_LANGUAGE_TEST_NOT_VALID'] };
  const secondState = need('language.second.state');
  const second = secondState === 'TESTED' ? (['speaking', 'listening', 'reading', 'writing'] as const).map(a => need(`language.second.${a}` as FactPath)) : [0, 0, 0, 0];
  const cwe = need('work.canadianYears'), fwe = need('work.foreignYears'), hwWork = need('work.highWageTier'), hwOffer = need('offer.highWageTier');
  const trade = need('additional.tradeCertificate'), canEdu = need('additional.canadianEducation'), sibling = need('additional.sibling'), nomination = need('additional.eeNomination');
  const englishMin = need('language.english.min'), frenchMin = need('language.french.min');
  let spEdu: unknown = null, spLang: unknown[] = [0, 0, 0, 0], spWork: unknown = null;
  if (withSpouse) {
    spEdu = need('spouse.education.level'); spWork = need('spouse.canadianWorkYears');
    const st = need('spouse.language.state');
    if (st === 'TESTED') spLang = (['speaking', 'listening', 'reading', 'writing'] as const).map(a => need(`spouse.language.${a}` as FactPath));
  }
  if (missing.length) return { status: 'INCOMPLETE', total: null, maxTotal: null, components: null, rulePolicyHash: policy.policyHash, missingFields: [...new Set(missing)].sort(), reasonCodes: reasons.length ? reasons : ['FACT_UNKNOWN'] };
  if (hwWork !== 'NONE' && cwe === 0) return { status: 'INVALID_INPUT', total: null, maxTotal: null, components: null, rulePolicyHash: policy.policyHash, missingFields: [], reasonCodes: ['HIGH_WAGE_WITHOUT_CANADIAN_WORK'] };
  const used: string[] = [];
  const look = (id: string, dims: unknown[]): number => {
    const row = idx.tables.get(id)!.get(jcs(dims));
    if (!row) throw new RuleDataError('CRS_TABLE_ROW_MISSING:' + id);
    used.push(id + ':' + jcs(dims) + '=' + row.points);
    return row.points;
  };
  try {
    const cls = spouse as string, cap = (id: string) => idx.caps.get(id)!;
    const agePts = look('CRS_AGE', [cls, age]), eduPts = look('CRS_EDUCATION', [cls, education]);
    const firstPts = first.reduce<number>((s, v) => s + look('CRS_FIRST_LANGUAGE', [cls, v]), 0);
    const secondRaw = second.reduce<number>((s, v) => s + look('CRS_SECOND_LANGUAGE', [v]), 0);
    const secondPts = Math.min(secondRaw, cap(withSpouse ? 'CRS_SECOND_LANGUAGE_CAP_WITH_SPOUSE' : 'CRS_SECOND_LANGUAGE_CAP_WITHOUT_SPOUSE'));
    const work = look('CRS_CANADIAN_WORK', [cls, cwe]), hw = look('CRS_HIGH_WAGE_WORK', [hwWork]), offer = look('CRS_HIGH_WAGE_OFFER', [hwOffer]);
    const experienceRoute = work + hw, lmifCap = cap(withSpouse ? 'CRS_LMIF_CAP_WITH_SPOUSE' : 'CRS_LMIF_CAP_WITHOUT_SPOUSE');
    const lmif = Math.min(lmifCap, Math.max(experienceRoute, offer));
    const selected = experienceRoute === 0 && offer === 0 ? 'NONE' : offer > experienceRoute ? 'OFFER' : 'EXPERIENCE';
    let spEduPts = 0, spLangPts = 0, spWorkPts = 0;
    if (withSpouse) { spEduPts = look('CRS_SPOUSE_EDUCATION', [spEdu]); spLangPts = spLang.reduce<number>((s, v) => s + look('CRS_SPOUSE_LANGUAGE', [v]), 0); spWorkPts = look('CRS_SPOUSE_WORK', [spWork]); }
    const spouseBefore = spEduPts + spLangPts + spWorkPts, spousePts = Math.min(spouseBefore, cap('CRS_SPOUSE_CAP'));
    const langBand = look('CRS_LANGUAGE_BAND', [firstMin]), eduGroup = look('CRS_EDUCATION_GROUP', [education]), cweBand = look('CRS_CANADIAN_WORK_BAND', [cwe]), fweBand = look('CRS_FOREIGN_WORK_BAND', [fwe]);
    const el = look('CRS_TRANSFER_EDUCATION_LANGUAGE', [eduGroup, langBand]), ec = look('CRS_TRANSFER_EDUCATION_CANADIAN_WORK', [eduGroup, cweBand]);
    const fl = look('CRS_TRANSFER_FOREIGN_LANGUAGE', [fweBand, langBand]), fc = look('CRS_TRANSFER_FOREIGN_CANADIAN_WORK', [fweBand, cweBand]);
    const tradeBand = look('CRS_TRADE_LANGUAGE_BAND', [firstMin]), tr = look('CRS_TRANSFER_TRADE', [trade, tradeBand]);
    const eduT = Math.min(el + ec, cap('CRS_TRANSFER_EDUCATION_CAP')), forT = Math.min(fl + fc, cap('CRS_TRANSFER_FOREIGN_CAP'));
    const transferBefore = eduT + forT + tr, transfer = Math.min(transferBefore, cap('CRS_TRANSFER_TOTAL_CAP'));
    const sib = look('CRS_ADDITIONAL_SIBLING', [sibling]), fr = look('CRS_ADDITIONAL_FRENCH', [look('CRS_FRENCH_BAND', [frenchMin]), look('CRS_ENGLISH_BAND', [englishMin])]);
    const ce = look('CRS_ADDITIONAL_CANADIAN_EDUCATION', [canEdu]), nom = look('CRS_ADDITIONAL_NOMINATION', [nomination]);
    const addBefore = sib + fr + ce + nom, additional = Math.min(addBefore, cap('CRS_ADDITIONAL_CAP'));
    const components: CrsComponents = { age: agePts, education: eduPts, firstLanguage: firstPts, secondLanguage: secondPts, lmif, spouse: spousePts, skillTransferability: transfer, additional };
    const total = Object.values(components).reduce((s, v) => s + v, 0), maxTotal = cap(withSpouse ? 'CRS_MAX_TOTAL_WITH_SPOUSE' : 'CRS_MAX_TOTAL_WITHOUT_SPOUSE');
    if (!Object.values(components).every(v => Number.isSafeInteger(v) && v >= 0) || !Number.isSafeInteger(total) || total > maxTotal) return unavailable(policy.policyHash, 'CRS_TOTAL_EXCEEDS_POLICY');
    return { status: 'COMPLETE', total, maxTotal, components, rulePolicyHash: policy.policyHash, missingFields: [], reasonCodes: [],
      trace: { lmif: { workLengthPoints: work, highWageExperiencePoints: hw, experienceRoute, offerRoute: offer, cap: lmifCap, selected, tie: experienceRoute === offer && offer > 0 }, secondLanguageBeforeCap: secondRaw, spouse: { education: spEduPts, language: spLangPts, work: spWorkPts, beforeCap: spouseBefore }, transfer: { educationLanguage: el, educationCanadianWork: ec, foreignLanguage: fl, foreignCanadianWork: fc, trade: tr, educationBeforeCap: el + ec, foreignBeforeCap: fl + fc, beforeTotalCap: transferBefore }, additional: { sibling: sib, french: fr, canadianEducation: ce, nomination: nom, beforeCap: addBefore }, rows: used } };
  } catch (e) { if (e instanceof RuleDataError) return unavailable(policy.policyHash, e.message); throw e; }
}
