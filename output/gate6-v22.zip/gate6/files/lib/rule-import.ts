// v2.2 Gate 3 — rule payload import and release validation (pure; no I/O). Mirrors contracts/domain.schema.json
// RuleBundle / ReleaseInterval / ReleaseCreate. A payload is accepted only when it is complete: every source exists and
// its stored bytes hash to the recorded value, the obligation graph is acyclic and its node set equals the signed
// manifest, every decision table's row set hashes to its expected hash, caps/datasets cite payload sources, fact paths
// are in the engine contract, and the engine version is compatible. Draft or archived text is never a production rule.
import { z } from 'zod';
import { jcs, jcsHash, isRealDate } from './v22-core.ts';
import { V22_ENGINE_VERSION, isFactPath } from './normalization.ts';
import { CRS_POLICY_TABLES, CRS_POLICY_CAPS } from './crs.ts';

const Id = z.string().regex(/^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/);
const Hash = z.string().regex(/^[a-f0-9]{64}$/);
const RealDate = z.string().refine(isRealDate, 'INVALID_CALENDAR_DATE');
const DateBasis = z.enum(['PROFILE', 'INVITATION', 'APPLICATION', 'RECOMMENDATION', 'APPROVAL_TORONTO']);
const Phase = z.enum(['PROFILE', 'APPLICATION', 'PROCESSING']);
const Literal = z.union([z.string(), z.number(), z.boolean(), z.null(), z.array(z.string())]);
const ProgramRef = z.object({ programId: Id, streamId: Id.nullable(), phase: Phase }).strict();
const Expression = z.union([
  z.object({ operator: z.enum(['ALL', 'ANY']), nodeIds: z.array(Id).min(1) }).strict(),
  z.object({ operator: z.enum(['EQ', 'NE', 'IN', 'GE', 'GT', 'LE', 'LT', 'PRESENT']), normalizedFactPath: Id, expected: Literal, dateBasis: DateBasis }).strict(),
]);
// SourceCitation.locator is limited to 200 characters; an obligation locator that cannot be cited verbatim is rejected.
const ObligationSchema = z.object({ obligationId: Id, expression: Expression, sourceIds: z.array(Id).min(1), sourceLocator: z.string().min(1).max(200), scopeLimitations: z.array(z.string().min(1).max(2000)) }).strict();
const TableSchema = z.object({ tableId: Id, dimensions: z.array(Id).min(1), rows: z.array(z.object({ dimensionValues: z.array(Literal).min(1), points: z.number().int().min(0).max(100000), sourceId: Id, locator: z.string().min(1).max(2000) }).strict()).min(1), expectedRowSetHash: Hash }).strict();
const NormalizerSchema = z.object({ normalizerId: Id, implementationVersion: Id, sourceIds: z.array(Id).min(1), inputFactKeys: z.array(Id).min(1), outputSchemaId: Id, dateBasis: DateBasis, decisionTableIds: z.array(Id), evidencePolicyId: Id }).strict();
const NocDataset = z.object({ kind: z.literal('NOC_CATALOG'), datasetId: Id, version: Id, sourceId: Id, rows: z.array(z.object({ nocCode: z.string().regex(/^[0-9]{5}$/), teer: z.number().int().min(0).max(5), officialTitle: z.string().min(1).max(10000), leadStatement: z.string().min(1).max(10000), mainDuties: z.array(z.object({ dutyId: Id, text: z.string().min(1).max(10000) }).strict()).min(1), exclusions: z.array(z.string().min(1).max(10000)) }).strict()).min(1) }).strict();
const WageDataset = z.object({ kind: z.literal('HIGH_WAGE_BANDS'), datasetId: Id, nocVersion: Id, sourceId: Id, rows: z.array(z.object({ nocCode: z.string().regex(/^[0-9]{5}$/), tier: z.enum(['TIER_130', 'TIER_150', 'TIER_200']) }).strict()).min(1), invitationLockPolicyId: Id }).strict();
const EvidenceDataset = z.object({ kind: z.literal('EVIDENCE_POLICY'), datasetId: Id, sourceIds: z.array(Id).min(1), rows: z.array(z.object({ policyId: Id, factKey: Id, acceptedOrigins: z.array(z.enum(['DOCUMENT', 'ATTESTATION', 'OFFICIAL_RECORD', 'DERIVATION'])).min(1), independentReviewerRequired: z.literal(true), validityRuleId: Id }).strict()).min(1) }).strict();
export const ruleBundleSchema = z.object({
  schemaVersion: z.literal('2.0.0'), program: ProgramRef, family: Id,
  authorityClass: z.enum(['LEGISLATION', 'MINISTERIAL_INSTRUCTIONS', 'OFFICIAL_GUIDANCE']),
  sourceIds: z.array(Id).min(1), obligationManifestHash: Hash, requiredObligationIds: z.array(Id).min(1), rootObligationId: Id,
  obligations: z.array(ObligationSchema).min(1), decisionTables: z.array(TableSchema), normalizerPolicies: z.array(NormalizerSchema),
  caps: z.array(z.object({ capId: Id, points: z.number().int().min(0).max(100000), sourceId: Id }).strict()),
  dependencyBundleHashes: z.array(Hash), engineCompatibility: z.array(Id).min(1), independentFixtureHash: Hash,
  dataSets: z.array(z.union([NocDataset, WageDataset, EvidenceDataset])),
}).strict();
export type RuleBundle = z.infer<typeof ruleBundleSchema>;
export const bundleDraftSchema = z.object({ payload: z.unknown(), payloadHash: Hash, bundleId: Id.optional() }).strict();
export const releaseIntervalSchema = z.object({ programId: Id, family: Id, phase: Phase, dateBasis: DateBasis, effectiveFrom: RealDate, effectiveToExclusive: RealDate.nullable(), bundleId: Id }).strict()
  .refine(v => v.effectiveToExclusive === null || v.effectiveToExclusive > v.effectiveFrom, 'EMPTY_INTERVAL')
  .refine(v => !['RCIP_PILOT', 'RCIP_PERMANENT'].includes(v.programId) || v.dateBasis === 'APPROVAL_TORONTO', 'RCIP_DATE_BASIS_MUST_BE_APPROVAL_TORONTO');
export type ReleaseInterval = z.infer<typeof releaseIntervalSchema>;
export const releaseCreateSchema = z.object({ intervals: z.array(releaseIntervalSchema).min(1).max(200), manifestHash: Hash }).strict();
export const SOURCE_HOSTS: readonly string[] = ['canada.ca', 'gc.ca', 'gov.bc.ca', 'alberta.ca', 'saskatchewan.ca', 'gov.mb.ca', 'ontario.ca', 'quebec.ca', 'gnb.ca', 'novascotia.ca', 'princeedwardisland.ca', 'gov.nl.ca', 'yukon.ca', 'gov.nt.ca', 'gov.nu.ca'];
// Official Canadian government hosts only (the host itself or a subdomain); no IP literal, credentials or port.
export function allowedSourceUrl(raw: string): boolean {
  let u: URL; try { u = new URL(raw); } catch { return false; }
  if (u.protocol !== 'https:' || u.username || u.password || u.port || !/^[a-z0-9.-]+$/.test(u.hostname)) return false;
  return SOURCE_HOSTS.some(h => u.hostname === h || u.hostname.endsWith('.' + h));
}
export const CRS_PROGRAM_ID = 'EE_CRS';
export const CRS_FAMILY = 'CRS';
export const ELIGIBILITY_FAMILY = 'ELIGIBILITY';
export const NOC_PROGRAM_ID = 'NOC_2021';
export const NOC_FAMILY = 'NOC_CATALOG';
export const obligationManifestHash = (ids: readonly string[]) => jcsHash([...ids].sort());
export const rowSetHash = (rows: unknown[]) => jcsHash(rows);

export type SourceFacts = ReadonlyMap<string, { contentSha256: string; storedSha256: string | null }>;
export type BundleValidation = { ok: true; payloadHash: string; canonical: string; bundle: RuleBundle; codes: [] } | { ok: false; codes: string[] };
export async function validateBundle(raw: unknown, suppliedHash: string, sources: SourceFacts): Promise<BundleValidation> {
  const parsed = ruleBundleSchema.safeParse(raw);
  if (!parsed.success) return { ok: false, codes: parsed.error.issues.slice(0, 20).map(x => 'SCHEMA:' + x.path.join('.') + ':' + x.message) };
  const b = parsed.data, codes: string[] = [], canonical = jcs(b), payloadHash = await jcsHash(b);
  if (payloadHash !== suppliedHash) codes.push('PAYLOAD_HASH_MISMATCH');
  if (!b.engineCompatibility.includes(V22_ENGINE_VERSION)) codes.push('ENGINE_INCOMPATIBLE');
  const srcSet = new Set(b.sourceIds);
  if (srcSet.size !== b.sourceIds.length) codes.push('DUPLICATE_SOURCE_ID');
  for (const s of b.sourceIds) {
    const f = sources.get(s);
    if (!f) codes.push('SOURCE_MISSING:' + s);
    else if (f.storedSha256 !== f.contentSha256) codes.push('SOURCE_BYTES_MISMATCH:' + s);
  }
  const cite = (id: string, where: string) => { if (!srcSet.has(id)) codes.push('SOURCE_NOT_IN_BUNDLE:' + where + ':' + id); };
  const ids = new Map<string, (typeof b.obligations)[number]>();
  for (const o of b.obligations) { if (ids.has(o.obligationId)) codes.push('DUPLICATE_OBLIGATION:' + o.obligationId); ids.set(o.obligationId, o); o.sourceIds.forEach(s => cite(s, o.obligationId)); }
  for (const o of b.obligations) {
    const e = o.expression;
    if ('nodeIds' in e) { for (const n of e.nodeIds) if (!ids.has(n)) codes.push('OBLIGATION_NODE_MISSING:' + o.obligationId + '>' + n); }
    else {
      if (!isFactPath(e.normalizedFactPath)) codes.push('UNSUPPORTED_FACT_PATH:' + e.normalizedFactPath);
      if (e.operator === 'IN' && !Array.isArray(e.expected)) codes.push('OPERAND_TYPE_MISMATCH:' + o.obligationId);
      if (e.operator === 'PRESENT' && typeof e.expected !== 'boolean') codes.push('OPERAND_TYPE_MISMATCH:' + o.obligationId);
      if (['GE', 'GT', 'LE', 'LT'].includes(e.operator) && typeof e.expected !== 'number' && !isRealDate(e.expected)) codes.push('OPERAND_TYPE_MISMATCH:' + o.obligationId);
    }
  }
  // Reachability from the root, cycle detection, and manifest equality (no boolean "complete" flag is trusted).
  const reached = new Set<string>(), stack = new Set<string>();
  const walk = (id: string) => {
    if (stack.has(id)) { codes.push('OBLIGATION_CYCLE:' + id); return; }
    if (reached.has(id)) return;
    const o = ids.get(id); if (!o) return;
    reached.add(id); stack.add(id);
    if ('nodeIds' in o.expression) o.expression.nodeIds.forEach(walk);
    stack.delete(id);
  };
  if (!ids.has(b.rootObligationId)) codes.push('ROOT_OBLIGATION_MISSING'); else walk(b.rootObligationId);
  const required = new Set(b.requiredObligationIds);
  if (required.size !== b.requiredObligationIds.length) codes.push('DUPLICATE_REQUIRED_OBLIGATION');
  for (const id of ids.keys()) if (!required.has(id)) codes.push('OBLIGATION_NOT_IN_MANIFEST:' + id);
  for (const id of required) { if (!ids.has(id)) codes.push('MANIFEST_OBLIGATION_MISSING:' + id); else if (!reached.has(id)) codes.push('OBLIGATION_UNREACHABLE:' + id); }
  if (await obligationManifestHash(b.requiredObligationIds) !== b.obligationManifestHash) codes.push('OBLIGATION_MANIFEST_HASH_MISMATCH');
  const tableIds = new Set<string>();
  for (const t of b.decisionTables) {
    if (tableIds.has(t.tableId)) codes.push('DUPLICATE_TABLE:' + t.tableId); tableIds.add(t.tableId);
    const seen = new Set<string>();
    for (const r of t.rows) {
      if (r.dimensionValues.length !== t.dimensions.length) codes.push('TABLE_ROW_ARITY:' + t.tableId);
      const k = jcs(r.dimensionValues); if (seen.has(k)) codes.push('TABLE_DUPLICATE_ROW:' + t.tableId); seen.add(k);
      cite(r.sourceId, t.tableId);
    }
    if (await rowSetHash(t.rows) !== t.expectedRowSetHash) codes.push('TABLE_ROW_SET_HASH_MISMATCH:' + t.tableId);
  }
  const capIds = new Set<string>();
  for (const c of b.caps) { if (capIds.has(c.capId)) codes.push('DUPLICATE_CAP:' + c.capId); capIds.add(c.capId); cite(c.sourceId, c.capId); }
  for (const n of b.normalizerPolicies) { n.sourceIds.forEach(s => cite(s, n.normalizerId)); n.decisionTableIds.forEach(t => { if (!tableIds.has(t)) codes.push('NORMALIZER_TABLE_MISSING:' + n.normalizerId + '>' + t); }); }
  for (const d of b.dataSets) { if (d.kind === 'EVIDENCE_POLICY') d.sourceIds.forEach(s => cite(s, d.datasetId)); else cite(d.sourceId, d.datasetId); }
  if (b.family === CRS_FAMILY) {
    for (const [id, dims] of Object.entries(CRS_POLICY_TABLES)) {
      const t = b.decisionTables.find(x => x.tableId === id);
      if (!t) codes.push('CRS_TABLE_MISSING:' + id); else if (jcs(t.dimensions) !== jcs(dims)) codes.push('CRS_TABLE_DIMENSIONS:' + id);
    }
    for (const id of CRS_POLICY_CAPS) if (!capIds.has(id)) codes.push('CRS_CAP_MISSING:' + id);
  }
  if (b.family === NOC_FAMILY && !b.dataSets.some(d => d.kind === 'NOC_CATALOG')) codes.push('NOC_CATALOG_MISSING');
  return codes.length ? { ok: false, codes: [...new Set(codes)] } : { ok: true, payloadHash, canonical, bundle: b, codes: [] };
}

export type StoredBundle = { bundleId: string; payload: string; payloadSha256: string };
const intervalKey = (i: ReleaseInterval) => [i.programId, i.family, i.phase, i.dateBasis].join('|');
const sortIntervals = (list: readonly ReleaseInterval[]) => [...list].sort((a, b) => intervalKey(a).localeCompare(intervalKey(b)) || a.effectiveFrom.localeCompare(b.effectiveFrom));
export async function computeReleaseManifest(intervals: readonly ReleaseInterval[], bundleHashes: ReadonlyMap<string, string>): Promise<string> {
  return jcsHash({ schemaVersion: '2.0.0', engineVersion: V22_ENGINE_VERSION, intervals: sortIntervals(intervals).map(i => ({ ...i, bundlePayloadSha256: bundleHashes.get(i.bundleId) ?? null })) });
}
const overlaps = (a: { effectiveFrom: string; effectiveToExclusive: string | null }, b: { effectiveFrom: string; effectiveToExclusive: string | null }) =>
  (a.effectiveToExclusive === null || b.effectiveFrom < a.effectiveToExclusive) && (b.effectiveToExclusive === null || a.effectiveFrom < b.effectiveToExclusive);
export type ReleaseValidation = { codes: string[]; manifestHash: string; report: { engineVersion: string; intervals: number; bundles: string[]; codes: string[] } };
// Seal-time validation: stored payload bytes rehashed, each payload revalidated against its sources, identity match,
// no overlap per program/family/phase/dateBasis, and no overlapping RCIP pilot/permanent ranges.
export async function validateRelease(intervals: readonly ReleaseInterval[], bundles: ReadonlyMap<string, StoredBundle>, sources: SourceFacts): Promise<ReleaseValidation> {
  const codes: string[] = [], hashes = new Map<string, string>();
  for (const id of new Set(intervals.map(i => i.bundleId))) {
    const s = bundles.get(id);
    if (!s) { codes.push('BUNDLE_MISSING:' + id); continue; }
    let payload: unknown; try { payload = JSON.parse(s.payload); } catch { codes.push('BUNDLE_PAYLOAD_CORRUPT:' + id); continue; }
    const v = await validateBundle(payload, s.payloadSha256, sources);
    if (!v.ok) { codes.push(...v.codes.map(c => id + ':' + c)); continue; }
    if (v.canonical !== s.payload) codes.push('BUNDLE_PAYLOAD_NOT_CANONICAL:' + id);
    hashes.set(id, s.payloadSha256);
  }
  for (const i of intervals) {
    const s = bundles.get(i.bundleId); if (!s || !hashes.has(i.bundleId)) continue;
    const b = JSON.parse(s.payload) as RuleBundle;
    if (b.program.programId !== i.programId || b.family !== i.family || b.program.phase !== i.phase) codes.push('BUNDLE_IDENTITY_MISMATCH:' + i.bundleId);
  }
  const sorted = sortIntervals(intervals);
  for (let a = 0; a < sorted.length; a++) for (let c = a + 1; c < sorted.length; c++) {
    if (intervalKey(sorted[a]) === intervalKey(sorted[c]) && overlaps(sorted[a], sorted[c])) codes.push('RULE_INTERVAL_OVERLAP:' + intervalKey(sorted[a]));
  }
  const rcip = sorted.filter(i => i.programId === 'RCIP_PILOT' || i.programId === 'RCIP_PERMANENT');
  for (let a = 0; a < rcip.length; a++) for (let c = a + 1; c < rcip.length; c++) if (rcip[a].family === rcip[c].family && rcip[a].phase === rcip[c].phase && rcip[a].programId !== rcip[c].programId && overlaps(rcip[a], rcip[c])) codes.push('RCIP_RANGE_OVERLAP');
  const manifestHash = await computeReleaseManifest(intervals, hashes);
  const unique = [...new Set(codes)];
  return { codes: unique, manifestHash, report: { engineVersion: V22_ENGINE_VERSION, intervals: intervals.length, bundles: [...hashes.values()].sort(), codes: unique } };
}
