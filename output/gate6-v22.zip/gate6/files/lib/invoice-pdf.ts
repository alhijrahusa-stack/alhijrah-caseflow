// v2.2 Gate 5 — invoice PDF (AR or EN) rendered from the committed server invoice only: items, discount, payments and
// balance exactly as stored (integer cents formatted as text, no floating arithmetic). No tax line and no gateway: the
// office records offline payment methods only. The footer carries the invoice version and a JCS hash of the rendered data.
import { jsPDF } from 'jspdf';
import { PDF_FONT_BASE64 } from './pdf-font';
import { OFFICE } from './branding';

export type InvoicePdfData={reference:string;clientName:string;invoiceId:string;currency:string;status:string;version:number;createdAt:string;deadline:string|null;note:string|null;
 items:{serviceName:string;isFree:boolean;unitPriceCents:number;referencePriceCents:number|null}[];subtotalCents:number;discountCents:number;totalCents:number;paidCents:number;remainingCents:number;
 payments:{amountCents:number;method:string;paidAt:string}[];dataHash:string};
/** Integer cents → "1,234.56" without floats (BigInt-free string arithmetic is enough for safe integers). */
export function formatCents(cents:number){if(!Number.isSafeInteger(cents)||cents<0)throw new Error('INTEGER_CENTS_REQUIRED');const s=String(cents).padStart(3,'0'),whole=s.slice(0,-2),frac=s.slice(-2);return whole.replace(/\B(?=(\d{3})+(?!\d))/g,',')+'.'+frac;}
const STATUS:Record<string,[string,string]>={DRAFT:['مستحقة','Due'],PENDING_APPROVAL:['بانتظار اعتماد المدير','Pending manager approval'],PARTIAL:['مدفوعة جزئيًا','Partially paid'],PAID:['مدفوعة','Paid'],OVERDUE:['متأخرة','Overdue']};
const METHOD:Record<string,[string,string]>={CASH:['نقدًا','Cash'],CHEQUE:['شيك','Cheque'],ZELLE:['Zelle','Zelle'],CASH_APP:['Cash App','Cash App']};
export function renderInvoicePdf(d:InvoicePdfData,locale:'ar'|'en'){
 const ar=locale==='ar',L=(a:string,e:string)=>ar?a:e,money=(c:number)=>formatCents(c)+' '+d.currency;
 const doc=new jsPDF({unit:'mm',format:'a4',compress:true,putOnlyUsedFonts:true});
 doc.addFileToVFS('ALHArabic.ttf',PDF_FONT_BASE64);doc.addFont('ALHArabic.ttf','ALHArabic','normal');doc.setFont('ALHArabic');doc.setCreationDate(new Date(d.createdAt));doc.setFileId(d.dataHash.slice(0,32));
 doc.setProperties({title:'Invoice | '+d.reference,author:OFFICE.name,subject:'Invoice',creator:OFFICE.name});
 const rtl={align:'right' as const,isInputVisual:false,isOutputVisual:true,isInputRtl:true,isOutputRtl:false};
 const ltr={isInputVisual:true,isOutputVisual:true,isInputRtl:false,isOutputRtl:false};
 const isAr=(v:string)=>/[؀-ۿ]/.test(v);
 // Label on the reading-start side, value on the other side; Arabic glyphs always go through the RTL path.
 const put=(v:string,x:number,y:number,align:'left'|'right')=>{doc.setFont('ALHArabic','normal');if(isAr(v)){doc.text(v,x,y,{...rtl,align});}else doc.text(v,x,y,{...ltr,align});};
 const start=ar?192:18,end=ar?18:192,sa=ar?'right':'left',ea=ar?'left':'right';let y=44;
 const header=()=>{doc.setDrawColor(193,161,79);doc.setLineWidth(.4);doc.line(18,32,192,32);doc.setFont('helvetica','bold');doc.setFontSize(15);doc.setTextColor(18,43,68);doc.text('ALHIJRAH SERVICES',18,20);doc.setFont('helvetica','normal');doc.setFontSize(9);doc.text('CANADA DESK',18,26);doc.setFontSize(12);put(L('فاتورة','INVOICE'),192,24,'right');};
 const need=(h:number)=>{if(y+h>268){doc.addPage();header();y=44;}};
 const row=(label:string,value:string,size=10.5,bold=false)=>{need(8);doc.setFontSize(size);doc.setTextColor(bold?18:37,bold?43:55,bold?68:72);put(label,start,y,sa as 'left'|'right');put(value,end,y,ea as 'left'|'right');y+=7;};
 const rule=()=>{need(4);doc.setDrawColor(214,220,225);doc.line(18,y-3,192,y-3);y+=2;};
 header();doc.setFontSize(10);doc.setTextColor(37,55,72);
 row(L('رقم الملف','Case number'),d.reference);row(L('العميل','Client'),d.clientName||'—');row(L('رقم الفاتورة','Invoice number'),d.invoiceId.slice(0,8).toUpperCase());
 row(L('تاريخ الإصدار','Issued'),d.createdAt.slice(0,10));row(L('تاريخ الاستحقاق','Due date'),d.deadline||L('غير محدد','Not set'));row(L('الحالة','Status'),(STATUS[d.status]||[d.status,d.status])[ar?0:1]);row(L('العملة','Currency'),d.currency);
 y+=3;doc.setFillColor(242,246,248);doc.roundedRect(18,y-5,174,10,2,2,'F');doc.setFontSize(11);doc.setTextColor(15,58,77);put(L('الخدمة','Service'),start+(ar?-3:3),y+1.5,sa as 'left'|'right');put(L('المبلغ','Amount'),end+(ar?3:-3),y+1.5,ea as 'left'|'right');y+=12;
 for(const i of d.items){const value=i.isFree?L('مجانًا','Free')+(i.referencePriceCents!==null?' ('+L('القيمة المرجعية','reference')+' '+money(i.referencePriceCents)+')':''):money(i.unitPriceCents);
  const lines=doc.splitTextToSize(i.serviceName,110) as string[];for(const [n,line] of lines.entries()){need(7);doc.setFontSize(10);doc.setTextColor(37,55,72);put(line,start,y,sa as 'left'|'right');if(n===0)put(value,end,y,ea as 'left'|'right');y+=6.2;}y+=1;}
 rule();row(L('المجموع','Subtotal'),money(d.subtotalCents));if(d.discountCents>0)row(L('الخصم','Discount'),'- '+money(d.discountCents));row(L('الإجمالي','Total'),money(d.totalCents),11.5,true);row(L('المدفوع','Paid'),money(d.paidCents));row(L('المتبقي','Balance due'),money(d.remainingCents),11.5,true);
 if(d.payments.length){y+=4;row(L('الدفعات المسجلة','Recorded payments'),'',11,true);for(const p of d.payments)row(p.paidAt.slice(0,10)+' · '+(METHOD[p.method]||[p.method,p.method])[ar?0:1],money(p.amountCents),10);}
 if(d.note){y+=4;need(14);doc.setFontSize(10);doc.setTextColor(37,55,72);put(L('ملاحظة','Note'),start,y,sa as 'left'|'right');y+=6;for(const line of doc.splitTextToSize(d.note,170) as string[]){need(7);put(line,start,y,sa as 'left'|'right');y+=6;}}
 y+=6;need(12);doc.setFontSize(8.5);doc.setTextColor(100,113,124);put(L('طرق الدفع المقبولة: نقدًا، شيك، Zelle، Cash App. لا تتضمن الفاتورة ضرائب.','Accepted methods: cash, cheque, Zelle, Cash App. No tax is included.'),start,y,sa as 'left'|'right');
 const pages=doc.getNumberOfPages();for(let i=1;i<=pages;i++){doc.setPage(i);doc.setDrawColor(214,220,225);doc.line(18,279,192,279);doc.setFont('helvetica','normal');doc.setFontSize(7);doc.setTextColor(90,109,123);doc.text(OFFICE.email+'  ·  v'+d.version+'  ·  SHA-256 '+d.dataHash,18,286,ltr);doc.text(String(i)+' / '+String(pages),192,286,{...ltr,align:'right'});}
 return new Uint8Array(doc.output('arraybuffer'));
}
