import { getDb } from '@/db';
import { officeSettings,notificationPreferences,statusNotifications,deliveryOutbox } from '@/db/schema';
import { waitUntil } from 'cloudflare:workers';
import { outboxRow,dispatchOutbox } from './outbox';
import { eq } from 'drizzle-orm';
import { decrypt } from './security';
import { internationalPhone } from './otp-delivery';
import { statusLabels } from './model';
export async function notifyStatus(candidate:{id:string;reference:string;profile:string;version:number;status:string},_origin:string){void _origin;const db=getDb(),p=JSON.parse(candidate.profile),now=new Date().toISOString(),[preference]=await db.select().from(notificationPreferences).where(eq(notificationPreferences.candidateId,candidate.id));
 // v2.2 Gate 5: the email status notice is a PROGRESS_NOTICE row in the one delivery outbox (durable, deduplicated per
 // case version, limited text without case content); waitUntil only dispatches it sooner, the cron guarantees it.
 if(p.email){const row=await outboxRow('PROGRESS_NOTICE',candidate.id,'progress:'+candidate.id+':'+candidate.version,{});if(row){const [lock]=await db.insert(statusNotifications).values({id:row.eventId,candidateId:candidate.id,caseVersion:candidate.version,channel:'email',state:'queued',createdAt:now}).onConflictDoNothing().returning({id:statusNotifications.id});if(lock){await db.insert(deliveryOutbox).values(row).onConflictDoNothing();waitUntil(dispatchOutbox(5).then(()=>{}).catch(()=>{}));}}}
 waitUntil(whatsappStatus(candidate,p,preference?.whatsapp===true,now).catch(()=>{}));
}
async function whatsappStatus(candidate:{id:string;reference:string;version:number;status:string},p:{phone?:string},enabled:boolean,now:string){const db=getDb(),[s]=await db.select().from(officeSettings).where(eq(officeSettings.id,'office')).limit(1);
 if(!enabled)return;const phone=internationalPhone(p.phone||''),id=crypto.randomUUID(),configured=!!s?.whatsappSid&&!!s.whatsappToken&&!!s.whatsappFrom&&!!s.whatsappStatusTemplate;const [lock]=await db.insert(statusNotifications).values({id,candidateId:candidate.id,caseVersion:candidate.version,channel:'whatsapp',state:configured&&phone?'sending':'not_configured',createdAt:now}).onConflictDoNothing().returning({id:statusNotifications.id});if(!lock||!configured||!phone)return;
 const abort=new AbortController(),timeout=setTimeout(()=>abort.abort(),10000);let state='unknown',providerId='';try{const r=await fetch('https://api.twilio.com/2010-04-01/Accounts/'+s!.whatsappSid+'/Messages.json',{method:'POST',signal:abort.signal,headers:{Authorization:'Basic '+btoa(s!.whatsappSid+':'+await decrypt(s!.whatsappToken)),'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({To:'whatsapp:'+phone,From:'whatsapp:'+s!.whatsappFrom,ContentSid:s!.whatsappStatusTemplate,ContentVariables:JSON.stringify({'1':candidate.reference,'2':statusLabels[candidate.status]||candidate.status})})}),body=await r.json().catch(()=>null) as {sid?:string}|null;if(r.ok&&body?.sid){state='accepted';providerId=body.sid;}else if(r.status>=400&&r.status<500&&r.status!==408)state='failed';}catch{}finally{clearTimeout(timeout);}await db.update(statusNotifications).set({state,providerId}).where(eq(statusNotifications.id,id));
}
