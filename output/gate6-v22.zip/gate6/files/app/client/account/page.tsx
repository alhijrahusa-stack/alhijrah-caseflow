import { PortalFrame } from '@/components/client/chrome';
import { ClientAccount } from '@/components/client/account';
import { clientPageMetadata } from '@/lib/client-branding';
export const metadata=clientPageMetadata('/client/account');
// v2.2 Gate 4: one entry component (two intents, one account flow); RETURN is preselected on this route.
export default function Page(){return <PortalFrame tracking><ClientAccount initialIntent="RETURN"/></PortalFrame>;}
