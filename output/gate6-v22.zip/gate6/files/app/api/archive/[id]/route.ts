import { getDb } from '@/db';
import { generatedDocuments } from '@/db/schema';
import { eq } from 'drizzle-orm';
import { staff,candidateOwned,errorResponse,ApiError,staffWith } from '@/lib/server';
import { readCareerFile } from '@/lib/generated-documents';
import { operationLog } from '@/lib/professional-ai';
export async function GET(request:Request,ctx:{params:Promise<{id:string}>}){try{const s=await staffWith('view_documents'),{id}=await ctx.params,[row]=await getDb().select().from(generatedDocuments).where(eq(generatedDocuments.id,id)).limit(1);if(!row)throw new ApiError(404,'المستند غير موجود.');await candidateOwned(row.candidateId,s.scope);await operationLog('document_download',s.user.email,'staff',id,row.candidateId);return await readCareerFile(row,new URL(request.url).searchParams.get('part')||'');}catch(e){return errorResponse(e);}}
