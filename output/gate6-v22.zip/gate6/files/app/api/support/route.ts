import { staffWith,errorResponse } from '@/lib/server';
import { chatQueue } from '@/lib/case-chat';
import { legacyStatus } from '@/lib/support';
// v2.2 Gate 5: staff inbox = canonical case conversations (waiting for staff first). Office policy: every active staff
// member with `chat` sees every conversation. Legacy item shape kept for existing screens.
export const dynamic='force-dynamic';
export async function GET(){try{await staffWith('chat');const rows=await chatQueue(100);
 const items=rows.map(r=>({candidateId:r.caseId,status:legacyStatus(r.state),state:r.state,reason:'',staffUnread:r.state==='HANDOFF_PENDING'?1:0,lastMessageAt:r.waitingSince,assignedTo:r.assignedStaffId||'',reference:r.reference,name:r.name,conversationRevision:r.conversationRevision}));
 return Response.json({items,waiting:items.filter(r=>r.state==='HANDOFF_PENDING').length,unread:items.reduce((n,r)=>n+r.staffUnread,0)},{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
