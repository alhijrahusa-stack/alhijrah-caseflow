import { staff,candidateOwned,errorResponse,staffWith } from '@/lib/server';
import { attachmentOf } from '@/lib/support';
type Context={params:Promise<{id:string;mid:string}>};
export async function GET(_r:Request,ctx:Context){try{const s=await staffWith('chat'),{id,mid}=await ctx.params;await candidateOwned(id,s.scope);return await attachmentOf(id,mid);}catch(e){return errorResponse(e);}}
