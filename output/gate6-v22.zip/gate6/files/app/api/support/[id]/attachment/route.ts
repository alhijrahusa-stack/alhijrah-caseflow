import { candidateOwned,sameOrigin,errorResponse,staffWith } from '@/lib/server';
import { uploadDocument } from '@/lib/upload';
import { staffSend } from '@/lib/case-chat';
// v2.2 Gate 5 adapter: staff chat attachment → upload pipeline (QUARANTINED + INGESTION) + canonical message.
async function isAudio(request:Request){const form=await request.clone().formData(),f=form.get('file');if(!(f instanceof File))return false;const b=new Uint8Array(await f.slice(0,12).arrayBuffer()),t=new TextDecoder().decode(b);return f.type.startsWith('audio/')||(b[0]===0x1a&&b[1]===0x45&&b[2]===0xdf&&b[3]===0xa3)||t.startsWith('OggS');}
type Context={params:Promise<{id:string}>};
export async function POST(request:Request,ctx:Context){try{sameOrigin(request);const s=await staffWith('chat'),{id}=await ctx.params,c=await candidateOwned(id,s.scope);
 const voice=await isAudio(request),r=await uploadDocument(request,c,false,{voice});
 const m=await staffSend(id,s.authority.actor.userId,voice?{clientMessageId:'upload:'+r.id,repliedToMessageId:null,kind:'VOICE_NOTE',evidenceId:r.id}:{clientMessageId:'upload:'+r.id,repliedToMessageId:null,kind:'ATTACHMENT',evidenceIds:[r.id]});
 return Response.json({id:m.message.messageId,evidenceId:r.id},{status:201,headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
