import { z } from 'zod';
import { candidateOwned,sameOrigin,readJson,errorResponse,staffWith } from '@/lib/server';
import { unifiedMessages,legacyStatus,transitions as legacyTransitions } from '@/lib/support';
import { staffSend,transition,conversationOf } from '@/lib/case-chat';
// v2.2 Gate 5 adapter: legacy staff thread endpoint over the canonical case chat (writes/transitions there; legacy
// history stays readable). The new staff UI uses /api/candidates/[id]/chat.
type Context={params:Promise<{id:string}>};
const headers={'Cache-Control':'private, no-store'};
async function view(id:string){const u=await unifiedMessages(id,false),c=u.conversation;return {messages:u.messages,status:legacyStatus(c.state),reason:'',assignedTo:c.assignedStaffId||'',state:c.state,conversationRevision:c.conversationRevision,transitions:await legacyTransitions(id)};}
export async function GET(_r:Request,ctx:Context){try{const s=await staffWith('chat'),{id}=await ctx.params;await candidateOwned(id,s.scope);return Response.json(await view(id),{headers});}catch(e){return errorResponse(e);}}
export async function POST(request:Request,ctx:Context){try{sameOrigin(request);const s=await staffWith('chat'),{id}=await ctx.params;await candidateOwned(id,s.scope);const d=await readJson(request,z.object({body:z.string().trim().min(1).max(3000)}).strict());
 await staffSend(id,s.authority.actor.userId,{clientMessageId:crypto.randomUUID(),repliedToMessageId:null,kind:'TEXT',text:d.body});return Response.json(await view(id),{headers});}catch(e){return errorResponse(e);}}
export async function PATCH(request:Request,ctx:Context){try{sameOrigin(request);const s=await staffWith('chat'),{id}=await ctx.params;await candidateOwned(id,s.scope);const d=await readJson(request,z.object({status:z.enum(['ai','human','closed'])}).strict());
 const c=await conversationOf(id),action=d.status==='human'?(c.state==='HUMAN_ACTIVE'?null:c.state==='HANDOFF_PENDING'?'claim':'handoff'):d.status==='closed'?'close':'resume_bot';
 if(action)await transition(id,{kind:'STAFF',userId:s.authority.actor.userId},{action,expectedRevision:c.revision,requestKey:crypto.randomUUID()});
 return Response.json(await view(id),{headers});}catch(e){return errorResponse(e);}}
