import { candidateOwned,sameOrigin,errorResponse,staffWith } from '@/lib/server';
import { transition,conversationOf } from '@/lib/case-chat';
// v2.2 Gate 5 adapter: claim = canonical CAS transition (one owner; 409 when another staff member already holds it).
type Context={params:Promise<{id:string}>};
export async function POST(request:Request,ctx:Context){try{sameOrigin(request);const s=await staffWith('chat'),{id}=await ctx.params;await candidateOwned(id,s.scope);const me=s.authority.actor.userId,c=await conversationOf(id);
 let state=c.state,assigned=c.assignedTo;
 if(!(c.state==='HUMAN_ACTIVE'&&c.assignedTo===me)){let rev=c.revision;if(c.state==='BOT_ACTIVE'||c.state==='CLOSED'){const r=await transition(id,{kind:'STAFF',userId:me},{action:c.state==='CLOSED'?'reopen':'handoff',expectedRevision:rev,requestKey:crypto.randomUUID()});rev=r.conversation.conversationRevision;}
  const r=await transition(id,{kind:'STAFF',userId:me},{action:'claim',expectedRevision:rev,requestKey:crypto.randomUUID()});state=r.conversation.state;assigned=r.conversation.assignedStaffId;}
 return Response.json({assignedTo:assigned||'',state},{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
