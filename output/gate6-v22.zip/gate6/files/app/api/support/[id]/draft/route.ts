import { staff,candidateOwned,sameOrigin,errorResponse,ApiError,staffWith } from '@/lib/server';
import { rateLimit,decrypt } from '@/lib/security';
import { professionalConfig } from '@/lib/professional-ai';
import { unifiedMessages } from '@/lib/support';
import { maskIdentifiers } from '@/lib/faq-retrieval';
import { caseDetails } from '@/lib/staff-assistant';
type Context={params:Promise<{id:string}>};
// Staff-only: OpenAI drafts a reply to the client conversation for the staff member to edit and send.
export async function POST(request:Request,ctx:Context){try{sameOrigin(request);const s=await staffWith('chat'),{id}=await ctx.params;const c=await candidateOwned(id,s.scope);await rateLimit(request,'support-draft:'+s.user.email,60,3600);
 const cfg=await professionalConfig();if(!cfg.configured||cfg.provider!=='openai')throw new ApiError(503,'اقتراح الرد يحتاج OpenAI في إعدادات المكتب.');
 const profile=JSON.parse(c.profile),scrub=(t:string)=>{let x=t;for(const v of [profile.fullName,profile.email,profile.phone])if(v&&v.length>2)x=x.split(v).join('[العميل]');return maskIdentifiers(x);};
 const msgs=(await unifiedMessages(id,false)).messages.slice(-20).map(m=>`${m.sender==='client'?'العميل':m.sender==='staff'?'الموظف':'المساعد'}: ${scrub(m.body)}`).join('\n');const facts=await caseDetails(s.scope,c.reference);
 const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+await decrypt(cfg.key)},body:JSON.stringify({model:cfg.model,store:false,instructions:'اكتب ردًا واحدًا جاهزًا يرسله موظف مكتب ALHIJRAH Services للعميل، بالعربية (أو بلغة العميل)، مهذبًا ودقيقًا وقصيرًا، يعالج آخر رسالة للعميل بناءً على وقائع الملف فقط. بلا وعود بالقبول أو المدد، وبلا نصوص تقنية. أعد نص الرد فقط.',input:`وقائع الملف: ${JSON.stringify(facts)}\n\nالمحادثة:\n${msgs}`,max_output_tokens:1500})});
 if(!r.ok)throw new ApiError(502,`رفض OpenAI طلب الاقتراح (${r.status}).`);const b=await r.json() as {output?:{type:string;content?:{type:string;text?:string}[]}[]};const text=(b.output||[]).filter(o=>o.type==='message').flatMap(o=>o.content||[]).filter(p=>p.type==='output_text').map(p=>p.text||'').join('').trim();
 if(!text)throw new ApiError(502,'وصل اقتراح فارغ.');return Response.json({draft:text.slice(0,3000)},{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
