import { z } from "zod";
import { env } from "cloudflare:workers";
import { getDb } from "@/db";
import { documents,events,tasks,candidates } from "@/db/schema";
import { and,eq,sql } from "drizzle-orm";
import { recomputeCase } from '@/lib/case-engine';
import { owned,owner,sameOrigin,errorResponse,ApiError,readJson,ownerWith } from "@/lib/server";
export async function GET(request:Request,context:{params:Promise<{id:string}>}){
  try{
    const ownerId=await ownerWith('view_documents');const {id}=await context.params;const [doc]=await getDb().select().from(documents).where(and(eq(documents.id,id),owned(documents.ownerId,ownerId))).limit(1);
    if(!doc)throw new ApiError(404,"المستند غير موجود");const object=await env.BUCKET?.get(doc.objectKey);if(!object)throw new ApiError(404,"المستند غير متاح");
    await getDb().insert(events).values({id:crypto.randomUUID(),ownerId:doc.ownerId,candidateId:doc.candidateId,action:"اطّلع الموظف على مستند",note:doc.name,createdAt:new Date().toISOString()});
    const disposition=new URL(request.url).searchParams.get("preview")==="1"&&doc.mime!=="video/mp4"?"inline":"attachment";
    return new Response(object.body,{headers:{"Content-Security-Policy":"default-src 'none'; frame-ancestors 'self'","Content-Type":doc.mime,"Content-Disposition":disposition+"; filename*=UTF-8''"+encodeURIComponent(doc.name),"Cache-Control":"private, no-store","X-Content-Type-Options":"nosniff"}});
  }catch(e){return errorResponse(e);}
}
export async function PATCH(request:Request,context:{params:Promise<{id:string}>}){
  try{
    sameOrigin(request);const actorOwner=await ownerWith('review_case');const {id}=await context.params;const body=await readJson(request,z.object({verified:z.boolean()}));
    const db=getDb();const [doc]=await db.select().from(documents).where(and(eq(documents.id,id),owned(documents.ownerId,actorOwner))).limit(1);if(!doc)throw new ApiError(404,"المستند غير موجود");
    if(doc.verified===body.verified)return Response.json({ok:true});
    const ownerId=doc.ownerId,now=new Date().toISOString();
    await db.batch([
      db.update(documents).set({verified:body.verified}).where(and(eq(documents.id,id),owned(documents.ownerId,actorOwner))),
      db.update(tasks).set({status:sql`CASE WHEN EXISTS (SELECT 1 FROM documents d WHERE d.owner_id = ${ownerId} AND d.candidate_id = ${doc.candidateId} AND d.category = ${doc.category} AND d.verified = 1) THEN 'done' ELSE 'open' END`,version:sql`${tasks.version} + 1`,updatedAt:now}).where(and(owned(tasks.ownerId,actorOwner),eq(tasks.candidateId,doc.candidateId),eq(tasks.systemKey,"document:"+doc.category))),
      db.update(candidates).set({version:sql`${candidates.version}+1`,updatedAt:now}).where(eq(candidates.id,doc.candidateId)),
      db.insert(events).values({id:crypto.randomUUID(),ownerId,candidateId:doc.candidateId,action:body.verified?"تم اعتماد مراجعة مستند وتحديث مهمة النواقص":"ألغيت مراجعة مستند وتحديث مهمة النواقص",note:doc.name,createdAt:now}),
    ]);
    // Verified documents are an engine input: recompute the stored assessment.
    await recomputeCase(doc.candidateId,{mode:'write'});
    return Response.json({ok:true});
  }catch(e){return errorResponse(e);}
}
