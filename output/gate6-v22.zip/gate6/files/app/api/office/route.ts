import { z } from 'zod';
import { getDb } from '@/db';
import { officeSettings,officeMembers,users } from '@/db/schema';
import { staffUserId } from '@/lib/rbac';
import { eq,asc,and } from 'drizzle-orm';
import { staff,admin,sameOrigin,readJson,errorResponse,ApiError } from '@/lib/server';
import { encrypt } from '@/lib/security';
import { mailStatus } from '@/lib/mail';
import { deliveryOptions } from '@/lib/otp-delivery';
import { professionalConfig,professionalJson,operationLog } from '@/lib/professional-ai';
import { requireCapability } from '@/lib/rbac';
import { officeBilling,officeCurrency,catalog,setOfficeCurrency,upsertService } from '@/lib/billing';
import { reapplyErasures,erasureJournal } from '@/lib/privacy';
export const dynamic='force-dynamic';
// v2.2 Gate 5: ?view=billing = per-currency office totals and the keyset-paged invoice list (view_financials).
export async function GET(request:Request){try{const s=await staff(),db=getDb();
 const url=new URL(request.url);if(url.searchParams.get('view')==='billing'){requireCapability(s.authority,'view_financials');return Response.json({currency:await officeCurrency(),catalog:await catalog(false),...await officeBilling(url.searchParams.get('cursor'),Number(url.searchParams.get('limit')||25))},{headers:{'Cache-Control':'private, no-store'}});}
const [mail,channels,settings,members]=await Promise.all([mailStatus(),deliveryOptions(),db.select().from(officeSettings).where(eq(officeSettings.id,'office')).limit(1),s.role==='MANAGER'?db.select().from(officeMembers).orderBy(asc(officeMembers.createdAt)):Promise.resolve([])]);return Response.json({role:s.role,email:s.user.email,mail,channels,whatsapp:{sid:settings[0]?.whatsappSid||'',from:settings[0]?.whatsappFrom||'',template:settings[0]?.whatsappTemplate||'',configured:channels.whatsapp},ai:{configured:!!settings[0]?.aiKey,model:settings[0]?.aiModel||'llama-3.1-8b-instant'},professional:{provider:settings[0]?.professionalProvider||'',model:settings[0]?.professionalModel||'',configured:!!settings[0]?.professionalKey},services:{calendarUrl:settings[0]?.calendarUrl||'',captchaSiteKey:settings[0]?.captchaSiteKey||'',captchaConfigured:!!settings[0]?.captchaSecret,whatsappStatusTemplate:settings[0]?.whatsappStatusTemplate||''},members},{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
const schema=z.discriminatedUnion('action',[
 z.object({action:z.literal('professional'),provider:z.enum(['openai','anthropic']),model:z.string().trim().min(3).max(150).regex(/^[a-zA-Z0-9_.:-]+$/),key:z.string().trim().min(20).max(600).optional()}),
 z.object({action:z.literal('professional_test')}),
 z.object({action:z.literal('services'),calendarUrl:z.union([z.literal(''),z.string().url().refine(v=>new URL(v).protocol==='https:')]),captchaSiteKey:z.string().max(150),captchaSecret:z.string().max(500).optional(),whatsappStatusTemplate:z.string().regex(/^$|^HX[a-fA-F0-9]{32}$/)}),
 z.object({action:z.literal('mail'),sender:z.string().trim().email().max(254),key:z.string().trim().regex(/^re_[a-zA-Z0-9_\-]{10,200}$/,'أدخل مفتاح Resend صالحًا').optional()}),
 z.object({action:z.literal('member'),email:z.string().trim().email().max(254),name:z.string().trim().min(2).max(100),active:z.boolean()}),
 z.object({action:z.literal('whatsapp'),sid:z.string().regex(/^AC[a-fA-F0-9]{32}$/,'Account SID غير صحيح'),token:z.string().trim().min(20).max(250).optional(),from:z.string().regex(/^\+[1-9]\d{6,14}$/,'أدخل رقم مرسل WhatsApp الدولي المسجل لدى Twilio'),template:z.string().regex(/^HX[a-fA-F0-9]{32}$/,'Content SID غير صحيح'),approvedTemplate:z.literal(true)}),
 z.object({action:z.literal('ai'),key:z.string().trim().regex(/^gsk_[a-zA-Z0-9]{15,250}$/).optional(),model:z.string().trim().regex(/^[A-Za-z0-9][A-Za-z0-9._:\/-]{2,99}$/)}),
 z.object({action:z.literal('disable_channel'),channel:z.enum(['email','whatsapp','ai'])}),
 // v2.2 Gate 5 — MANAGER billing settings: the explicit office currency and the service catalog (integer cents).
 // v2.2 Gate 6 — restore support (MANAGER): export the erasure journal; re-apply it after a backup restore.
 z.object({action:z.literal('privacy_journal')}),
 z.object({action:z.literal('privacy_reapply'),journal:z.array(z.object({requestId:z.string(),caseId:z.string(),requestedBy:z.string(),requestKey:z.string(),reasonCode:z.string().nullable(),createdAt:z.string(),completedAt:z.string().nullable(),resultJson:z.string().nullable()}).strict()).max(10000)}),
 z.object({action:z.literal('billing_currency'),currency:z.string().regex(/^[A-Z]{3}$/)}),
 z.object({action:z.literal('service'),serviceId:z.string().regex(/^[a-z0-9][a-z0-9-]{1,63}$/),nameAr:z.string().trim().min(2).max(200),nameEn:z.string().trim().min(2).max(200),priceCents:z.number().int().min(0).max(Number.MAX_SAFE_INTEGER),currency:z.string().regex(/^[A-Z]{3}$/),active:z.boolean(),expectedVersion:z.number().int().min(1).nullable()}),
]);
export async function POST(request:Request){try{sameOrigin(request);const manager=await admin();const d=await readJson(request,schema),db=getDb(),now=new Date().toISOString();
 if(d.action==='privacy_journal')return Response.json({journal:await erasureJournal()},{headers:{'Cache-Control':'private, no-store'}});
 if(d.action==='privacy_reapply')return Response.json(await reapplyErasures(d.journal));
 if(d.action==='billing_currency'){await setOfficeCurrency(manager.authority,d.currency);return Response.json({ok:true,currency:d.currency});}
 if(d.action==='service'){const currency=await officeCurrency();if(!currency||d.currency!==currency)throw new ApiError(422,'عملة الخدمة يجب أن تطابق عملة المكتب المعتمدة.');await upsertService(manager.authority,d);return Response.json({ok:true,catalog:await catalog(false)});}
 if(d.action==='professional_test'){const s=await professionalConfig();try{const r=await professionalJson('Connection test. Return ok=true.',{},z.object({ok:z.literal(true)}).strict(),{type:'object',properties:{ok:{type:'boolean',enum:[true]}},required:['ok'],additionalProperties:false},300);await operationLog('professional_connection','admin','passed',r.provider);return Response.json({ok:true,provider:r.provider,model:r.model,checkedAt:now});}catch(e){await operationLog('professional_connection','admin','failed',s.provider);throw e;}}
 else if(d.action==='professional'){const c=await professionalConfig();if(!d.key&&(!c.configured||c.provider!==d.provider))throw new ApiError(400,'أدخل مفتاح المزود المحدد.');await db.update(officeSettings).set({professionalProvider:d.provider,professionalModel:d.model,...(d.key?{professionalKey:await encrypt(d.key)}:{}),updatedAt:now}).where(eq(officeSettings.id,'office'));}
 else if(d.action==='services')await db.update(officeSettings).set({calendarUrl:d.calendarUrl,captchaSiteKey:d.captchaSiteKey,whatsappStatusTemplate:d.whatsappStatusTemplate,...(d.captchaSecret?{captchaSecret:await encrypt(d.captchaSecret)}:{}),updatedAt:now}).where(eq(officeSettings.id,'office'));
 else if(d.action==='mail')await db.update(officeSettings).set({mailFrom:d.sender.toLowerCase(),...(d.key?{mailKey:await encrypt(d.key)}:{}),updatedAt:now}).where(eq(officeSettings.id,'office'));
 else if(d.action==='whatsapp')await db.update(officeSettings).set({whatsappSid:d.sid,whatsappFrom:d.from,whatsappTemplate:d.template,...(d.token?{whatsappToken:await encrypt(d.token)}:{}),updatedAt:now}).where(eq(officeSettings.id,'office'));
 else if(d.action==='ai')await db.update(officeSettings).set({aiModel:d.model,...(d.key?{aiKey:await encrypt(d.key)}:{}),updatedAt:now}).where(eq(officeSettings.id,'office'));
 else if(d.action==='disable_channel')await db.update(officeSettings).set({...d.channel==='email'?{mailKey:''}:d.channel==='whatsapp'?{whatsappToken:''}:{aiKey:''},updatedAt:now}).where(eq(officeSettings.id,'office'));
 else {const email=d.email.toLowerCase(),userId=staffUserId(email);
  // v2.2 Gate 2: office_members (manager-maintained) and the STAFF users row change together; deactivation is immediate
  // because every protected access re-reads users.active from D1.
  await db.batch([
   db.insert(officeMembers).values({email,name:d.name,active:d.active,createdAt:now}).onConflictDoUpdate({target:officeMembers.email,set:{name:d.name,active:d.active}}),
   db.insert(users).values({userId,role:'STAFF',active:d.active?1:0,createdAt:now}).onConflictDoNothing(),
   db.update(users).set({active:d.active?1:0}).where(and(eq(users.userId,userId),eq(users.role,'STAFF'))),
  ]);}
 return Response.json({ok:true});}catch(e){return errorResponse(e);}}
