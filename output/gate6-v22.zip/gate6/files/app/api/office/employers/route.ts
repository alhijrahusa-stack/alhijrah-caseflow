import { z } from 'zod';
import { staffWith,sameOrigin,readJson,errorResponse,candidateOwned } from '@/lib/server';
import { requireCapability } from '@/lib/rbac';
import { employersBoard,saveEmployer,saveVacancy,setStage,employerSchema,vacancySchema,stageSchema } from '@/lib/employer-ats';
// v2.2 Gate 5 — sourced employers, vacancies and ATS stages (view_crm to read; edit_case to change). Ranking unavailable.
const schema=z.discriminatedUnion('action',[employerSchema,vacancySchema,stageSchema]);
export const dynamic='force-dynamic';
export async function GET(request:Request){try{const s=await staffWith('view_crm'),caseId=new URL(request.url).searchParams.get('case');if(caseId)await candidateOwned(caseId,s.scope);return Response.json(await employersBoard(caseId),{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
export async function POST(request:Request){try{sameOrigin(request);const s=await staffWith('view_crm');requireCapability(s.authority,'edit_case');const d=await readJson(request,schema),actor=s.authority.actor.userId;
 if(d.action==='employer')return Response.json({employerId:await saveEmployer(actor,d)},{status:d.employerId?200:201});
 if(d.action==='vacancy')return Response.json({vacancyId:await saveVacancy(actor,d)},{status:d.vacancyId?200:201});
 await candidateOwned(d.caseId,s.scope);return Response.json({version:await setStage(actor,d)});}catch(e){return errorResponse(e);}}
