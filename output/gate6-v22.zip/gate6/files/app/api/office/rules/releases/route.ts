import { z } from 'zod';
import { staffWith,admin,sameOrigin,readJson,errorResponse } from '@/lib/server';
import { previewRelease,createAndSealRelease,activateRelease,rulesState } from '@/lib/rule-release';
import { releaseIntervalSchema } from '@/lib/rule-import';
// v2.2 Gate 3 — releases. GET: activation, intervals and program readiness (NOT_CONFIGURED stays visible) for staff.
// POST (MANAGER only): preview the manifest, create+seal in one action (optional CAS activation), or (de)activate.
const intervals=z.array(releaseIntervalSchema).min(1).max(200),hash=z.string().regex(/^[a-f0-9]{64}$/),reason=z.string().trim().min(1).max(200);
const schema=z.union([
 z.object({action:z.literal('preview'),intervals}).strict(),
 z.object({action:z.literal('seal'),intervals,manifestHash:hash,activate:z.object({expectedGeneration:z.number().int().min(0),reasonCode:reason}).strict().nullable()}).strict(),
 z.object({action:z.literal('activate'),expectedGeneration:z.number().int().min(0),releaseId:z.string().regex(/^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/).nullable(),reasonCode:reason}).strict(),
]);
const headers={'Cache-Control':'private, no-store'};
export async function GET(){try{await staffWith('view_crm');return Response.json(await rulesState(),{headers});}catch(e){return errorResponse(e);}}
export async function POST(request:Request){try{
 sameOrigin(request);const s=await admin(),d=await readJson(request,schema,200000);
 if(d.action==='preview'){const v=await previewRelease(s.authority,d.intervals);return Response.json({manifestHash:v.manifestHash,validationCodes:v.codes},{headers});}
 if(d.action==='seal'){const out=await createAndSealRelease(s.authority,d);return Response.json(out,{status:out.replayed?200:201,headers});}
 return Response.json(await activateRelease(s.authority,d),{headers});
}catch(e){return errorResponse(e);}}
