import { z } from 'zod';
import { staffWith,admin,sameOrigin,readJson,errorResponse } from '@/lib/server';
import { importSource,importBundle,rulesState } from '@/lib/rule-release';
// v2.2 Gate 3 — rule source and payload import. Reading is open to staff (readiness view); importing is MANAGER only.
// The server hashes the source bytes and the canonical payload; nothing supplied by the browser is trusted as state.
const Id=z.string().regex(/^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/);
const schema=z.union([
 z.object({action:z.literal('source'),sourceId:Id,officialUrl:z.string().url().max(2000),authority:z.string().trim().min(1).max(200),contentBase64:z.string().min(4).max(7_000_000)}).strict(),
 z.object({action:z.literal('bundle'),payload:z.unknown(),payloadHash:z.string().regex(/^[a-f0-9]{64}$/),bundleId:Id.optional()}).strict(),
]);
const headers={'Cache-Control':'private, no-store'};
export async function GET(){try{await staffWith('view_crm');const s=await rulesState();return Response.json({sources:s.sources,bundles:s.bundles},{headers});}catch(e){return errorResponse(e);}}
export async function POST(request:Request){try{
 sameOrigin(request);const s=await admin(),d=await readJson(request,schema,7_500_000);
 const out=d.action==='source'?await importSource(s.authority,d):await importBundle(s.authority,{payload:d.payload,payloadHash:d.payloadHash,bundleId:d.bundleId});
 return Response.json(out,{status:out.replayed?200:201,headers});
}catch(e){return errorResponse(e);}}
