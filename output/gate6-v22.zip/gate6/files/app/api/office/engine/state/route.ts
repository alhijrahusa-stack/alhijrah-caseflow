import { getDb } from '@/db';
import { sql } from 'drizzle-orm';
import { owner,owned,errorResponse } from '@/lib/server';
import { candidates } from '@/db/schema';
// Unified case state for every owned file, read from case_state_view (migration 0022).
export async function GET(){try{const o=await owner();
 const rows=await getDb().all<{candidate_id:string;status:string;inbox:string|null;review_state:string|null;unified_state:string}>(sql`SELECT v.candidate_id,v.status,v.inbox,v.review_state,v.unified_state FROM case_state_view v JOIN candidates ON candidates.id=v.candidate_id WHERE ${owned(candidates.ownerId,o)}`);
 const counts:Record<string,number>={};for(const r of rows)counts[r.unified_state]=(counts[r.unified_state]||0)+1;
 return Response.json({files:rows.length,counts,rows},{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
