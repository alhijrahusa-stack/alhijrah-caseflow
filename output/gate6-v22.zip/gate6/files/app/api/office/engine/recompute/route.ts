import { getDb } from '@/db';
import { candidates } from '@/db/schema';
import { admin,sameOrigin,errorResponse,owned } from '@/lib/server';
import { recomputeCase } from '@/lib/case-engine';
import { shadowOnly } from '@/lib/engine-mode';
// Write-mode recompute of every owned file through the single writer. Used only after the shadow report is approved.
export async function POST(request:Request){try{sameOrigin(request);const s=await admin();
 if(shadowOnly())return Response.json({error:'المحرك في وضع الظل (SHADOW_ONLY): إعادة الحساب الكتابية معطلة حتى اعتماد نتائج الظل.'},{status:409,headers:{'Cache-Control':'private, no-store'}});
 const list=await getDb().select({id:candidates.id}).from(candidates).where(owned(candidates.ownerId,s.scope));
 const results=[];for(const c of list){const r=await recomputeCase(c.id,{mode:'write'});results.push({candidateId:c.id,inputsHash:r.inputsHash,historyId:r.historyId});}
 return Response.json({recomputed:results.length,results},{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
