import { getDb } from '@/db';
import { candidates } from '@/db/schema';
import { admin,owned,sameOrigin,errorResponse } from '@/lib/server';
import { rateLimit } from '@/lib/security';
import { computeLead } from '@/lib/lead-score';
import { and,ne,desc } from 'drizzle-orm';
export async function POST(request:Request){try{sameOrigin(request);const a=await admin();await rateLimit(request,'scoring-recompute',6,3600);const rows=await getDb().select({id:candidates.id}).from(candidates).where(and(owned(candidates.ownerId,a.scope),ne(candidates.status,'archived'))).orderBy(desc(candidates.updatedAt)).limit(500);const counts={hot:0,warm:0,nurture:0};for(const r of rows){const l=await computeLead(r.id,false);if(l)counts[l.tier as keyof typeof counts]++;}return Response.json({recomputed:rows.length,counts},{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
