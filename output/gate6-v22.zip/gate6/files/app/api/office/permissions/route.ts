// v2.2 Gate 2 — MANAGER-only permission Toggles and the single STAFF open switch.
// The catalog comes from the server; the body never carries a role, a free capability name outside the catalog,
// a JSON policy, a duration or an end time. Every change is one audited D1 statement (triggers apply value+epoch).
import { z } from 'zod';
import { getDb } from '@/db';
import { users, rolePermissions, officeMembers } from '@/db/schema';
import { eq, asc } from 'drizzle-orm';
import { admin, sameOrigin, readJson, errorResponse } from '@/lib/server';
import { CATALOG, toggleStaffPermission, setOpenAll, requireCapability } from '@/lib/rbac';
import { openAllActive, STAFF_CAPABILITIES } from '@/lib/v22-core';
export const dynamic = 'force-dynamic';

const requestKey = z.string().regex(/^[A-Za-z0-9_-]{16,80}$/);
const version = z.number().int().min(1).max(Number.MAX_SAFE_INTEGER);
// One action per shape; the toggle target ('ROLE' | 'USER') is its own discriminator. Unknown fields are rejected.
const schema = z.union([
  z.object({ action: z.literal('toggle'), target: z.literal('ROLE'), key: z.enum(STAFF_CAPABILITIES), value: z.boolean(), expectedVersion: version, expectedEpoch: version, requestKey }).strict(),
  z.object({ action: z.literal('toggle'), target: z.literal('USER'), targetUserId: z.string().regex(/^staff:[^\s]{3,254}$/), key: z.enum(STAFF_CAPABILITIES), value: z.boolean(), expectedVersion: version, expectedEpoch: version, requestKey }).strict(),
  z.object({ action: z.literal('open_all'), enabled: z.boolean(), expectedEpoch: version, requestKey }).strict(),
]);

async function state() {
  const s = await admin(); requireCapability(s.authority, 'manage_permissions');
  const db = getDb();
  const [[policy], staffRows, members] = await Promise.all([
    db.select().from(rolePermissions).where(eq(rolePermissions.role, 'STAFF')).limit(1),
    db.select({ userId: users.userId, active: users.active, permissionVersion: users.permissionVersion, custom: users.customPermissions }).from(users).where(eq(users.role, 'STAFF')).orderBy(asc(users.userId)),
    db.select({ email: officeMembers.email, name: officeMembers.name }).from(officeMembers),
  ]);
  const names = new Map(members.map(m => [m.email, m.name]));
  const now = Date.now();
  return {
    epoch: s.authority.epoch,
    catalog: STAFF_CAPABILITIES.filter(k => CATALOG[k].staffAssignable),
    role: { version: policy.version, permissions: JSON.parse(policy.permissionsJson) as Record<string, boolean> },
    staff: staffRows.map(r => ({ userId: r.userId, email: r.userId.slice('staff:'.length), name: names.get(r.userId.slice('staff:'.length)) ?? '', active: r.active === 1, version: r.permissionVersion, permissions: JSON.parse(r.custom) as Record<string, boolean> })),
    openAll: { ...s.authority.open, active: openAllActive(s.authority.open, now) },
  };
}

export async function GET() {
  try { return Response.json(await state(), { headers: { 'Cache-Control': 'private, no-store' } }); }
  catch (e) { return errorResponse(e); }
}

export async function POST(request: Request) {
  try {
    sameOrigin(request);
    const s = await admin(), d = await readJson(request, schema, 4000);
    if (d.action === 'toggle') {
      requireCapability(s.authority, 'manage_permissions');
      await toggleStaffPermission(s.authority, d.target === 'USER'
        ? { target: 'USER', targetUserId: d.targetUserId, key: d.key, value: d.value, expectedVersion: d.expectedVersion, expectedEpoch: d.expectedEpoch, requestKey: d.requestKey }
        : { target: 'ROLE', key: d.key, value: d.value, expectedVersion: d.expectedVersion, expectedEpoch: d.expectedEpoch, requestKey: d.requestKey });
    } else {
      requireCapability(s.authority, 'open_staff_access');
      await setOpenAll(s.authority, { enabled: d.enabled, expectedEpoch: d.expectedEpoch, requestKey: d.requestKey });
    }
    return Response.json(await state(), { headers: { 'Cache-Control': 'private, no-store' } });
  } catch (e) { return errorResponse(e); }
}
