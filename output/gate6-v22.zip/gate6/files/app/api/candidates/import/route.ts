import { creatorGrants } from "@/lib/rbac";
import { z } from "zod";
import { and,eq,inArray } from "drizzle-orm";
import { getDb } from "@/db";
import { candidates } from "@/db/schema";
import { profileSchema,educationLabels } from "@/lib/model";
import type { Profile } from "@/lib/model";
import { parseCSV,importColumns } from "@/lib/csv";
import type { ImportRow } from "@/lib/csv";
import { contactKeys,newApplicant,isDuplicateConstraint } from "@/lib/applicants";
import { owned,owner,sameOrigin,errorResponse,ApiError,readJson,ownerWith } from "@/lib/server";
const schema=z.object({mode:z.enum(["preview","commit"]),csv:z.string().min(1).max(300000),consent:z.boolean().optional()}).strict();
export async function POST(request:Request) {
  try {
    sameOrigin(request);const ownerId=await ownerWith('edit_case'),data=await readJson(request,schema,1200000),db=getDb();
    if(data.mode==="commit"&&!data.consent)throw new ApiError(400,"أكد موافقات حفظ البيانات قبل الاستيراد.");
    let raw:string[][];try{raw=parseCSV(data.csv);}catch(e){throw new ApiError(400,(e as Error).message);}
    if(raw.length<2||raw.length>51)throw new ApiError(400,"يلزم صف عناوين و1 إلى 50 متقدمًا في الدفعة.");
    const headers=raw[0].map(v=>v.trim());const columns=headers.map(v=>importColumns[v.toLowerCase()]??null);
    if(!columns.includes("fullName")||!columns.includes("phone"))throw new ApiError(400,"يلزم عمود الاسم وعمود الهاتف. استخدم القالب المرفق.");
    if(new Set(columns.filter(Boolean)).size!==columns.filter(Boolean).length)throw new ApiError(400,"توجد أعمدة مكررة للبيانات نفسها.");
    const parsed=raw.slice(1).map((cells,index)=>{
      const entry:Record<string,unknown>={consent:true};
      columns.forEach((key,i)=>{if(!key)return;let value=(cells[i]||"").trim();if(key==="phone"&&value.startsWith("'"))value=value.slice(1);if(key==="education")entry[key]=Object.entries(educationLabels).find(([k,v])=>v===value||k===value)?.[0]??(value||"unknown");else entry[key]=value;});
      const result=profileSchema.safeParse(entry);
      const issue=cells.length!==headers.length?"عدد الخانات لا يطابق العناوين":result.success?"":result.error.issues[0].message;
      return {row:index+2,name:String(entry.fullName||""),profile:result.success&&!issue?result.data:null,issue};
    });
    const keys=parsed.flatMap(r=>r.profile?[contactKeys(r.profile)]:[]);
    const phoneKeys=keys.map(k=>k.dedupeKey),emailKeys=keys.map(k=>k.emailKey).filter(Boolean),contactPairs=keys.map(k=>k.contactPairKey).filter(Boolean);
    const select={reference:candidates.reference,profile:candidates.profile};
    const [byPhone,byEmail,byContact,legacy]=await Promise.all([
      phoneKeys.length?db.select(select).from(candidates).where(and(owned(candidates.ownerId,ownerId),inArray(candidates.dedupeKey,phoneKeys))):Promise.resolve([]),
      emailKeys.length?db.select(select).from(candidates).where(and(owned(candidates.ownerId,ownerId),inArray(candidates.emailKey,emailKeys))):Promise.resolve([]),
      contactPairs.length?db.select(select).from(candidates).where(and(owned(candidates.ownerId,ownerId),inArray(candidates.contactPairKey,contactPairs))):Promise.resolve([]),
      db.select(select).from(candidates).where(and(owned(candidates.ownerId,ownerId),eq(candidates.identityVersion,0))),
    ]);
    const identityKeys=(profile:Profile)=>{const k=contactKeys(profile);return ['name-phone:'+k.dedupeKey,...(k.emailKey?['name-email:'+k.emailKey]:[]),...(k.contactPairKey?['phone-email:'+k.contactPairKey]:[])];};
    const known=new Map<string,string>();
    for(const c of [...byPhone,...byEmail,...byContact,...legacy])for(const key of identityKeys(JSON.parse(c.profile)))known.set(key,c.reference);
    const rows:ImportRow[]=[],accepted:Profile[]=[];
    for(const r of parsed){
      if(!r.profile){rows.push({row:r.row,name:r.name,state:"invalid",message:r.issue});continue;}
      const identities=identityKeys(r.profile),existing=identities.map(key=>known.get(key)).find(Boolean);
      if(existing){rows.push({row:r.row,name:r.name,state:"duplicate",message:existing==="in-file"?"مكرر داخل الملف":"موجود في السجل: "+existing,reference:existing==="in-file"?undefined:existing});continue;}
      for(const key of identities)known.set(key,"in-file");
      accepted.push(r.profile);rows.push({row:r.row,name:r.name,state:"valid",message:"صالح للاستيراد"});
    }
    const result={rows,valid:accepted.length,duplicates:rows.filter(r=>r.state==="duplicate").length,invalid:rows.filter(r=>r.state==="invalid").length,ignoredColumns:headers.filter((_,i)=>!columns[i])};
    if(data.mode==="preview")return Response.json(result,{headers:{"Cache-Control":"private, no-store"}});
    const applicants=await Promise.all(accepted.map(profile=>newApplicant(ownerId.ownerId,profile,"csv"))),queries=[...applicants.flatMap(a=>[...a.queries]),...creatorGrants(ownerId.authority,applicants.map(a=>a.row.id))];
    const [first,...rest]=queries;if(first)await db.batch([first,...rest]);
    return Response.json({...result,created:accepted.length},{status:201});
  }catch(e){return errorResponse(isDuplicateConstraint(e)?new ApiError(409,"أضيف أحد الملفات في جلسة أخرى. أعد معاينة CSV قبل الاستيراد."):e);}
}
