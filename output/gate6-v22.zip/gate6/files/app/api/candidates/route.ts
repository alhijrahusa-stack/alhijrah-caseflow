import { creatorGrants } from "@/lib/rbac";
import { getDb } from "@/db";
import { candidates,documents } from "@/db/schema";
import { profileSchema,statusSchema,pathwaySchema,prioritySchema } from "@/lib/model";
import { officeJobsError } from "@/lib/office-jobs";
import { owned,owner,sameOrigin,errorResponse,ApiError,readJson,ownerWith } from "@/lib/server";
import { newApplicant,ensureUnique,isDuplicateConstraint } from "@/lib/applicants";
import { and,eq,desc,asc,sql,count,inArray } from "drizzle-orm";
export const dynamic="force-dynamic";
export async function GET(request:Request) {
  try {
    const ownerId=await owner(),db=getDb(),query=new URL(request.url).searchParams;
    const page=Math.max(1,Math.min(100000,Math.floor(Number(query.get("page")))||1));
    const q=(query.get("q")||"").slice(0,150),status=query.get("status"),pathway=query.get("pathway"),priority=query.get("priority");
    const filters=[owned(candidates.ownerId,ownerId)];
    if(status&&statusSchema.safeParse(status).success)filters.push(eq(candidates.status,status));
    if(pathway&&pathwaySchema.safeParse(pathway).success)filters.push(eq(candidates.pathway,pathway));
    if(priority&&prioritySchema.safeParse(priority).success)filters.push(eq(candidates.priority,priority));
    if(q){const match="%"+q.replace(/[\\%_]/g,"\\$&")+"%";filters.push(sql`(${candidates.reference} LIKE ${match} ESCAPE '\\' OR json_extract(${candidates.profile},'$.fullName') LIKE ${match} ESCAPE '\\' OR json_extract(${candidates.profile},'$.phone') LIKE ${match} ESCAPE '\\' OR json_extract(${candidates.profile},'$.email') LIKE ${match} ESCAPE '\\' OR json_extract(${candidates.profile},'$.occupation') LIKE ${match} ESCAPE '\\' OR json_extract(${candidates.profile},'$.country') LIKE ${match} ESCAPE '\\' OR json_extract(${candidates.profile},'$.noc') LIKE ${match} ESCAPE '\\')`);}
    const where=and(...filters);
    const sort=query.get("sort");const order=sort==="name"?asc(sql`json_extract(${candidates.profile},'$.fullName')`):sort==="created"?desc(candidates.createdAt):desc(candidates.updatedAt);
    const [rows,totals,groups]=await Promise.all([
      db.select().from(candidates).where(where).orderBy(order,asc(candidates.id)).limit(30).offset((page-1)*30),
      db.select({count:count()}).from(candidates).where(where),
      db.select({status:candidates.status,count:count()}).from(candidates).where(owned(candidates.ownerId,ownerId)).groupBy(candidates.status),
    ]);
    return Response.json({items:rows.map(({ownerId,dedupeKey,emailKey,contactPairKey,identityVersion,...r})=>({...r,profile:JSON.parse(r.profile),assessment:JSON.parse(r.assessment)})),total:totals[0].count,page,stats:Object.fromEntries(groups.map(g=>[g.status,g.count]))},{headers:{"Cache-Control":"private, no-store"}});
  }catch(e){return errorResponse(e);}
}
export async function POST(request:Request) {
  try {
    sameOrigin(request);const ownerId=await ownerWith('edit_case'),profile=await readJson(request,profileSchema);
    const jobsError=officeJobsError(profile.jobs);if(jobsError)throw new ApiError(400,jobsError);
    await ensureUnique(ownerId.ownerId,profile);const applicant=await newApplicant(ownerId.ownerId,profile);
    await getDb().batch([...applicant.queries,...creatorGrants(ownerId.authority,[applicant.row.id])]);
    return Response.json({id:applicant.row.id,reference:applicant.row.reference},{status:201});
  }catch(e){return errorResponse(isDuplicateConstraint(e)?new ApiError(409,"يوجد ملف بالاسم ووسيلة التواصل نفسيهما. ابحث في السجل قبل إعادة الإضافة."):e);}
}
