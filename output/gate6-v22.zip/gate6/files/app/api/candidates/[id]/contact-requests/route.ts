import { z } from 'zod';
import { getDb } from '@/db';
import { contactRequests,candidates,clientSessions,clientMessages,clientCases,events,loginCredentials,authChallenges } from '@/db/schema';
import { eq,and,desc,sql } from 'drizzle-orm';
import { staff,candidateOwned,sameOrigin,readJson,errorResponse,ApiError,staffWith } from '@/lib/server';
import { profileSchema } from '@/lib/model';
import { ensureUnique,contactKeys,isDuplicateConstraint } from '@/lib/applicants';
import { recomputeCase } from '@/lib/case-engine';
import { deliveryOptions,internationalPhone } from '@/lib/otp-delivery';
type Context={params:Promise<{id:string}>};
export async function GET(_request:Request,ctx:Context){try{const s=await staff(),{id}=await ctx.params;await candidateOwned(id,s.scope);return Response.json({items:await getDb().select().from(contactRequests).where(eq(contactRequests.candidateId,id)).orderBy(desc(contactRequests.createdAt)).limit(30)},{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
const schema=z.object({requestId:z.string().uuid(),decision:z.enum(['approve','reject']),candidateVersion:z.number().int().positive(),verifiedByStaff:z.boolean().default(false)}).strict();
export async function POST(request:Request,ctx:Context){try{
 sameOrigin(request);const s=await staffWith('edit_case'),{id}=await ctx.params,c=await candidateOwned(id,s.scope),d=await readJson(request,schema),db=getDb(),[r]=await db.select().from(contactRequests).where(and(eq(contactRequests.id,d.requestId),eq(contactRequests.candidateId,id))).limit(1);
 if(!r||r.state!=='pending')throw new ApiError(409,'الطلب غير متاح أو تمت مراجعته.');
 if(c.version!==d.candidateVersion)throw new ApiError(409,'تغير الملف. أعد فتحه قبل اعتماد تعديل التواصل.');
 const approving=d.decision==='approve';
 if(approving&&!d.verifiedByStaff)throw new ApiError(400,'أكد التحقق المستقل من هوية العميل ووسيلة التواصل الجديدة.');
 const old=JSON.parse(c.profile),profile=profileSchema.parse({...old,...(approving?{fullName:r.requestedName||old.fullName,email:r.requestedEmail||old.email,phone:r.requestedPhone||old.phone}:{})});
 if(approving){await ensureUnique(s.ownerId,profile,id);const channels=await deliveryOptions();if(!channels.email&&!(channels.whatsapp&&internationalPhone(profile.phone)))throw new ApiError(400,'فعّل قناة تحقق متاحة لبيانات العميل الجديدة قبل اعتماد تعديل التواصل.');}
 const now=new Date().toISOString(),state=approving?'approved':'rejected',auditId=crypto.randomUUID();
 const candidateScope=and(eq(candidates.id,id),eq(candidates.version,d.candidateVersion),sql`EXISTS (SELECT 1 FROM contact_requests r WHERE r.id = ${r.id} AND r.candidate_id = ${id} AND r.state = 'pending')`);
 const guarded=sql`EXISTS (SELECT 1 FROM events e WHERE e.id = ${auditId})`;
 // D1 batch is transactional: one guarded audit marker authorizes every change or none.
 const audit=db.insert(events).select(db.select({id:sql<string>`${auditId}`.as('id'),ownerId:candidates.ownerId,candidateId:candidates.id,action:sql<string>`'تمت مراجعة طلب تعديل التواصل'`.as('action'),note:sql<string>`${state+' · '+s.user.email}`.as('note'),createdAt:sql<string>`${now}`.as('created_at')}).from(candidates).where(candidateScope)).returning({id:events.id});
 const decision=db.update(contactRequests).set({state,resolvedAt:now,resolvedBy:s.user.email}).where(and(eq(contactRequests.id,r.id),eq(contactRequests.state,'pending'),guarded));
 if(approving){
  const result=await db.batch([audit,decision,
   db.update(candidates).set({profile:JSON.stringify(profile),...contactKeys(profile),version:sql`${candidates.version}+1`,updatedAt:now}).where(and(eq(candidates.id,id),guarded)),
   db.update(clientSessions).set({revokedAt:Date.now()}).where(and(eq(clientSessions.candidateId,id),guarded)),
   db.delete(loginCredentials).where(and(eq(loginCredentials.id,'client:'+id),guarded)),
   db.update(authChallenges).set({expiresAt:Date.now()}).where(and(eq(authChallenges.candidateId,id),guarded)),
   db.update(clientCases).set({otpOnly:true,version:sql`${clientCases.version}+1`}).where(and(eq(clientCases.candidateId,id),guarded)),
   db.insert(clientMessages).select(db.select({id:sql<string>`${crypto.randomUUID()}`.as('id'),candidateId:candidates.id,kind:sql<string>`'staff'`.as('kind'),recipient:sql<string>`${old.email}`.as('recipient'),subject:sql<string>`${'تحديث بيانات التواصل | '+c.reference}`.as('subject'),body:sql<string>`'راجع المكتب طلب تعديل بيانات التواصل في ملفك. إذا لم تطلب هذا التعديل، تواصل مع المكتب فورًا.'`.as('body'),state:sql<string>`'pending'`.as('state'),providerId:sql<string>`''`.as('provider_id'),error:sql<string>`''`.as('error'),actor:sql<string>`${s.user.email}`.as('actor'),requestKey:sql<string>`${'contact-update:'+r.id}`.as('request_key'),createdAt:sql<string>`${now}`.as('created_at'),sentAt:sql<string>`''`.as('sent_at')}).from(candidates).where(and(eq(candidates.id,id),guarded))),
  ]);if(!result[0].length)throw new ApiError(409,'تغير الطلب أو الملف أثناء المراجعة. حدّث السجل.');
  // The approved contact change edits the profile, an engine input.
  await recomputeCase(id,{mode:'write'});
 }else{const result=await db.batch([audit,decision]);if(!result[0].length)throw new ApiError(409,'تغير الطلب أو الملف أثناء المراجعة. حدّث السجل.');}
 return Response.json({ok:true});
 }catch(e){return errorResponse(isDuplicateConstraint(e)?new ApiError(409,'بيانات التواصل مرتبطة بملف آخر. راجع السجل قبل اعتماد التعديل.'):e);}}
