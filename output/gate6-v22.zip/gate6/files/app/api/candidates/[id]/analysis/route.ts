import { getDb } from '@/db';
import { candidates,clientCases,documents,caseIntelligence,documentAiPermissions } from '@/db/schema';
import { eq,and,or,lt,ne } from 'drizzle-orm';
import { candidateOwned,sameOrigin,errorResponse,ApiError,ownerWith,staffWith } from '@/lib/server';
import { RULE_VERSION,sources } from '@/lib/assessment';
import type { EngineAssessment } from '@/lib/case-engine';
import { detailsSchema } from '@/lib/intake';
import { screenIntake } from '@/lib/screening';
import { briefSchema,privateText } from '@/lib/intelligence';
import { rateLimit } from '@/lib/security';
import { professionalConfig,professionalJson,operationLog } from '@/lib/professional-ai';
import { DOCUMENT_PERMISSION_VERSION } from '@/lib/generated-documents';
import { teerFromNoc,nocSuggestionRequestSchema,nocProviderSchema,nocProviderJsonSchema,validateNocSuggestion,NOC_SYSTEM_PROMPT } from '@/lib/noc';
import type { NocCatalogRow } from '@/lib/noc';
import { z } from 'zod';
import { commitAssessment,latestV22 } from '@/lib/assessment-store';
import { loadActiveRelease,loadBundleRow } from '@/lib/rule-release';
import { resolveRule } from '@/lib/rule-resolver';
import { NOC_PROGRAM_ID,NOC_FAMILY } from '@/lib/rule-import';
import { jcsHash,torontoDate } from '@/lib/v22-core';
type Context={params:Promise<{id:string}>};
async function context(ctx:Context,capability='view_crm'){const {id}=await ctx.params,o=await ownerWith(capability),candidate=await candidateOwned(id,o),db=getDb();const [access]=await db.select().from(clientCases).where(eq(clientCases.candidateId,id)).limit(1);const files=await db.select({category:documents.category,verified:documents.verified}).from(documents).where(eq(documents.candidateId,id)),profile=JSON.parse(candidate.profile),details=detailsSchema.parse(JSON.parse(access?.details||'{}')),assessment=JSON.parse(candidate.assessment) as EngineAssessment,screening=screenIntake(profile,details,files),config=await professionalConfig();const [permission]=await db.select().from(documentAiPermissions).where(eq(documentAiPermissions.candidateId,id)).limit(1);const consented=!!permission?.consent&&permission.provider===config.provider&&permission.version===DOCUMENT_PERMISSION_VERSION;const [saved]=await db.select().from(caseIntelligence).where(eq(caseIntelligence.candidateId,id)).limit(1);const current=saved?.version===candidate.version&&saved.ruleVersion===RULE_VERSION&&saved.model===config.model&&config.configured?saved:null;return {id,candidate,db,profile,details,files,assessment,screening,config,current,consented};}
export async function GET(_request:Request,ctx:Context){try{const c=await context(ctx);return Response.json({assessment:c.assessment,screening:c.screening,sourceVersion:c.candidate.version,ai:{configured:c.config.configured,consented:c.consented,state:c.current?.state||'not_generated',model:c.current?.model||c.config.model,generatedAt:c.current?.generatedAt||null,report:c.current?.state==='ready'?briefSchema.parse(JSON.parse(c.current.report)):null},sources,checkedAt:'2026-11-10',v22:await latestV22(c.id)},{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
const Id=z.string().regex(/^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/),Day=z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
// v2.2 Gate 3: one engine, one history. RecomputeRequest (contracts) + requestKey for idempotency. approvalForSubmissionAt
// sent by the browser is ignored: the server reads the recorded value from the case.
const recomputeSchema=z.object({action:z.literal('recompute'),requestKey:z.string().regex(/^[A-Za-z0-9_-]{16,80}$/),expectedDataRevision:z.number().int().min(0),expectedPublicationRevision:z.number().int().min(0),assessmentMode:z.enum(['PRODUCTION','SHADOW']),selectedPrograms:z.array(z.object({programId:Id,streamId:Id.nullable(),phase:z.enum(['PROFILE','APPLICATION','PROCESSING'])}).strict()).min(1).max(20),eventContext:z.object({profileDate:Day,invitationDate:Day.nullable(),applicationDate:Day.nullable(),recommendationIssuedOn:Day.nullable(),approvalForSubmissionAt:z.string().max(40).nullable().optional()}).strict(),assessmentPurpose:z.enum(['RAPID_SCREENING','VERIFIED_SCREENING'])}).strict();
async function recompute(ctx:Context,body:unknown){
 const d=recomputeSchema.safeParse(body);if(!d.success)throw new ApiError(400,'طلب إعادة الحساب غير صالح.');
 const s=await staffWith('request_assessment'),{id}=await ctx.params;await candidateOwned(id,s.scope);
 const x=d.data,out=await commitAssessment(id,s.authority.actor.userId,{requestKey:x.requestKey,expectedDataRevision:x.expectedDataRevision,expectedPublicationRevision:x.expectedPublicationRevision,assessmentMode:x.assessmentMode,selectedPrograms:x.selectedPrograms,eventContext:x.eventContext,assessmentPurpose:x.assessmentPurpose});
 return Response.json(out,{status:out.status==='CREATED'?201:200,headers:{'Cache-Control':'private, no-store'}});
}
// NOC suggestion: RBAC (review_case) + case scope + data revision + configured provider + sealed catalog. No consent.
async function nocSuggestion(ctx:Context,body:unknown){
 const d=nocSuggestionRequestSchema.safeParse(body);if(!d.success)throw new ApiError(400,'طلب اقتراح NOC غير صالح.');
 const s=await staffWith('review_case'),{id}=await ctx.params,candidate=await candidateOwned(id,s.scope),db=getDb();
 const [cur]=await db.select({dataRevision:candidates.dataRevision}).from(candidates).where(eq(candidates.id,id)).limit(1);
 if(cur?.dataRevision!==d.data.expectedDataRevision)throw new ApiError(409,'تغيّرت بيانات الملف؛ أعد التحميل.');
 const [access]=await db.select().from(clientCases).where(eq(clientCases.candidateId,id)).limit(1),profile=JSON.parse(candidate.profile),details=detailsSchema.parse(JSON.parse(access?.details||'{}'));
 const jobs=(access?details.jobs:(Array.isArray(profile.jobs)?profile.jobs:[])) as {title?:string;employer?:string;duties?:string}[],m=/^job:(\d{1,2})$/.exec(d.data.workEpisodeId),job=m?jobs[Number(m[1])]:undefined;
 if(!job)throw new ApiError(404,'الخبرة المحددة غير موجودة في الملف.');
 const episodeText=privateText(String(job.duties||''),[profile.fullName,profile.email,profile.phone,candidate.reference,...jobs.map(j=>String(j.employer||''))]).slice(0,4000);
 if(episodeText.trim().length<10)throw new ApiError(422,'أضف مهام الخبرة الفعلية قبل طلب الاقتراح.');
 const config=await professionalConfig();if(!config.configured)throw new ApiError(503,'يلزم إعداد مزود OpenAI أو Anthropic في إعدادات المكتب.');
 const r=await resolveRule(await loadActiveRelease(),{programId:NOC_PROGRAM_ID,family:NOC_FAMILY,phase:'PROFILE'},{profileDate:torontoDate(Date.now()),invitationDate:null,applicationDate:null,recommendationIssuedOn:null},loadBundleRow);
 if(r.status!=='RESOLVED')throw new ApiError(409,'دليل NOC الرسمي غير مفعّل في القواعد المختومة (RULE_UNAVAILABLE).');
 const sets=r.bundle.dataSets.filter(x=>x.kind==='NOC_CATALOG');if(sets.length!==1||sets[0].kind!=='NOC_CATALOG')throw new ApiError(409,'دليل NOC الرسمي غير محدد بشكل فريد في القواعد المختومة.');
 const catalog=sets[0].rows as NocCatalogRow[],rows=d.data.targetNocCodes.map(code=>catalog.find(x=>x.nocCode===code));
 if(rows.some(x=>!x))throw new ApiError(422,'رمز NOC غير موجود في الدليل الرسمي المختوم.');
 const catalogHash=await jcsHash(sets[0]);
 const result=await professionalJson(NOC_SYSTEM_PROMPT,{episode:{id:d.data.workEpisodeId,title:privateText(String(job.title||'')).slice(0,150),text:episodeText},catalog:rows},nocProviderSchema,nocProviderJsonSchema as unknown as Record<string,unknown>,2500);
 const v=validateNocSuggestion(result.data,{episodeText,targets:d.data.targetNocCodes,catalog});
 if(!v.ok){await operationLog('noc_suggestion',s.user.email||s.authority.actor.userId,'rejected',v.code,id);throw new ApiError(502,'رُفض اقتراح المزود: استشهاد لا يطابق الدليل الرسمي أو نص الخبرة ('+v.code+').');}
 await operationLog('noc_suggestion',s.user.email||s.authority.actor.userId,'provisional',catalogHash,id);
 return Response.json({status:'PROVISIONAL',requiresProfessionalReview:true,workEpisodeId:d.data.workEpisodeId,catalogHash,catalogVersion:sets[0].version,ruleHash:r.bundleHash,provider:result.provider,model:result.model,suggestions:v.output.suggestions,warnings:v.output.warnings},{headers:{'Cache-Control':'private, no-store'}});
}
export async function POST(request:Request,ctx:Context){try{sameOrigin(request);
 const raw=await request.text();if(raw.length>20000)throw new ApiError(413,'الطلب أكبر من الحد المسموح.');
 if(raw.trim()){let body:unknown;try{body=JSON.parse(raw);}catch{throw new ApiError(400,'JSON غير صالح.');}const action=(body as {action?:unknown})?.action;if(action==='recompute')return await recompute(ctx,body);if(action==='noc_suggestion')return await nocSuggestion(ctx,body);throw new ApiError(400,'إجراء غير معروف.');}
 const c=await context(ctx,'edit_case');if(!c.consented)throw new ApiError(409,c.candidate.source==='client'?'سجّل تفويض العميل الصريح من ملف المتقدم قبل التحليل.':'سجّل تفويض العميل (ai_analysis_consent) قبل إرسال الملخص إلى مزود الذكاء الاصطناعي.');if(!c.config.configured)throw new ApiError(503,'يلزم إعداد مزود OpenAI أو Anthropic في إعدادات المكتب.');if(c.current?.state==='ready')return GET(request,ctx);await rateLimit(request,'case-analysis:'+c.id,6,900);
 const now=Date.now(),[lease]=await c.db.insert(caseIntelligence).values({candidateId:c.id,version:c.candidate.version,ruleVersion:RULE_VERSION,state:'generating',leaseUntil:now+30000}).onConflictDoUpdate({target:caseIntelligence.candidateId,set:{version:c.candidate.version,ruleVersion:RULE_VERSION,state:'generating',report:'{}',leaseUntil:now+30000},setWhere:or(lt(caseIntelligence.version,c.candidate.version),and(eq(caseIntelligence.version,c.candidate.version),or(ne(caseIntelligence.ruleVersion,RULE_VERSION),lt(caseIntelligence.leaseUntil,now))))}).returning({id:caseIntelligence.candidateId});if(!lease)return Response.json({state:'generating'},{status:202,headers:{'Cache-Control':'private, no-store'}});
 try{const redact=(s:string)=>privateText(s,[c.profile.fullName,c.profile.email,c.profile.phone,c.candidate.reference,...c.details.jobs.map(j=>j.employer)]);const facts={occupation:{title:redact(c.profile.occupation),noc:c.profile.noc||null,teer:teerFromNoc(c.profile.noc||'')},experience:{months3:c.assessment.derived?.experience3??null,months10:c.assessment.derived?.experience10??null,continuous12:c.profile.continuous12,paidEmployee:c.profile.paidEmployee,jobs:c.details.jobs.slice(0,6).map(j=>({title:redact(j.title),duties:redact(j.duties).slice(0,450),schedule:j.schedule}))},education:{level:c.profile.education,eca:c.profile.eca},language:{english:c.profile.englishMin,french:c.profile.frenchMin,englishDate:c.profile.englishDate,frenchDate:c.profile.frenchDate},offer:{available:c.profile.jobOffer,designated:c.profile.designated,recommendation:c.profile.recommendation,conditions:c.profile.jobConditions,lmia:c.details.lmiaStatus,offerNoc:c.details.offerNoc,offerTeer:c.details.offerTeer},documents:c.files};
 const result=await professionalJson('You are an internal case-preparation analyst. Write Arabic. Compare administrative preparation routes, not final legal eligibility. Use only supplied facts and the verified rule checks; distinguish client declarations from reviewed document categories. No acceptance likelihood, CRS guesses, NOC invention, job matching claims, admissibility decision or automatic approval/rejection. The employee reviews every conclusion. LMIA is an employer process distinct from RCIP permanent residence and a work permit. Do not treat missing information as a refusal. Return {summary:string,comparisons:[{pathwayId:"lmia"|"rcip"|"fsw"|"french",reason:string,evidenceIds:array of supplied fact keys}],questions:string[],nextSteps:string[]}. Every comparison must cite fact keys supporting its explanation. Include the missing facts that prevent choosing a route. Keep next steps concrete.',{facts,checks:c.assessment.pathways,missingFields:c.screening.missingFields,sourceCheckedAt:'2026-11-10',ruleVersion:RULE_VERSION},briefSchema,{type:'object',properties:{summary:{type:'string'},comparisons:{type:'array',items:{type:'object',properties:{pathwayId:{type:'string',enum:['lmia','rcip','fsw','french']},reason:{type:'string'},evidenceIds:{type:'array',items:{type:'string',enum:['occupation','experience','education','language','offer','documents']}}},required:['pathwayId','reason','evidenceIds'],additionalProperties:false}},questions:{type:'array',items:{type:'string'}},nextSteps:{type:'array',items:{type:'string'}}},required:['summary','comparisons','questions','nextSteps'],additionalProperties:false},3000);
 const [latest]=await c.db.select({version:candidates.version}).from(candidates).where(eq(candidates.id,c.id)).limit(1);if(latest?.version!==c.candidate.version)throw new ApiError(409,'تغيّر الملف أثناء التحليل. حدّث التقييم.');
 await c.db.update(caseIntelligence).set({state:'ready',report:JSON.stringify(result.data),model:result.model,generatedAt:new Date().toISOString(),leaseUntil:0}).where(and(eq(caseIntelligence.candidateId,c.id),eq(caseIntelligence.version,c.candidate.version),eq(caseIntelligence.leaseUntil,now+30000)));return GET(request,ctx);
 }catch(e){await c.db.update(caseIntelligence).set({state:'failed',leaseUntil:0}).where(and(eq(caseIntelligence.candidateId,c.id),eq(caseIntelligence.version,c.candidate.version),eq(caseIntelligence.leaseUntil,now+30000)));throw e;}
 }catch(e){return errorResponse(e);}}
