import { notifyStatus } from '@/lib/status-notifications';
import { waitUntil } from 'cloudflare:workers';
import { getDb } from "@/db";
import { candidates,documents,events,tasks,clientCases,caseAccess,users } from "@/db/schema";
import { profileSchema,statusSchema,prioritySchema,pathwaySchema,statusLabels } from "@/lib/model";
import { recomputeCase } from "@/lib/case-engine";
import { officeJobsError } from "@/lib/office-jobs";
import { owned,owner,sameOrigin,candidateOwned,errorResponse,ApiError,readJson,ownerWith } from "@/lib/server";
import { ensureUnique,contactKeys,isDuplicateConstraint } from "@/lib/applicants";
import { resolveAssignee } from "@/lib/rbac";
import { and,eq,desc,asc,sql } from "drizzle-orm";
import { z } from "zod";
export const dynamic="force-dynamic";
type Context={params:Promise<{id:string}>};
export async function GET(_request:Request,context:Context) {
  try {
    const ownerId=await owner(),{id}=await context.params,row=await candidateOwned(id,ownerId),db=getDb();
    const [files,history,work]=await Promise.all([
      db.select().from(documents).where(and(eq(documents.candidateId,id),owned(documents.ownerId,ownerId))).orderBy(desc(documents.createdAt)),
      db.select().from(events).where(and(eq(events.candidateId,id),owned(events.ownerId,ownerId))).orderBy(desc(events.createdAt)).limit(200),
      db.select().from(tasks).where(and(eq(tasks.candidateId,id),owned(tasks.ownerId,ownerId))).orderBy(asc(tasks.status),desc(tasks.createdAt)),
    ]);
    // Stored assessment only; it is written by lib/case-engine.ts (recomputeCase), never recomputed on read.
    const profile=JSON.parse(row.profile),assessment=JSON.parse(row.assessment);
    const {ownerId:_,dedupeKey,emailKey,contactPairKey,identityVersion,...candidate}=row;
    return Response.json({...candidate,profile,assessment,documents:files.map(({objectKey,ownerId,sha256,...f})=>f),events:history.map(({ownerId,...e})=>e),tasks:work.map(({ownerId,...t})=>t)},{headers:{"Cache-Control":"private, no-store"}});
  }catch(e){return errorResponse(e);}
}
const patchSchema=z.object({
  version:z.number().int().positive(),profile:profileSchema.optional(),status:statusSchema.optional(),
  note:z.string().trim().min(1).max(2000).optional(),priority:prioritySchema.optional(),pathway:pathwaySchema.optional(),
  assignedTo:z.string().trim().max(120).optional(),referralTo:z.string().trim().max(150).optional(),sharingConsent:z.boolean().optional(),
}).strict();
export async function PATCH(request:Request,context:Context) {
  try {
    sameOrigin(request);const ownerId=await ownerWith('edit_case'),{id}=await context.params,row=await candidateOwned(id,ownerId),data=await readJson(request,patchSchema);
    if(data.version!==row.version)throw new ApiError(409,"تم تحديث الملف في جلسة أخرى. أعد فتحه قبل الحفظ.");
    if(Object.keys(data).length===1)throw new ApiError(400,"لا توجد تغييرات");
    const newReferral=(data.status==="referred"&&row.status!=="referred")||(row.status==="referred"&&data.referralTo!==undefined&&data.referralTo!==row.referralTo);
    if(newReferral&&(!(data.sharingConsent??row.sharingConsent)||!(data.referralTo??row.referralTo).trim()))throw new ApiError(400,"سجّل جهة الإحالة وموافقة المتقدم على المشاركة في تبويب المتابعة قبل تسجيل الإحالة.");
    // Office policy: any staff member with edit_case may assign a case to himself or a colleague by name or email.
    // case_access records the resolved assignee in the same batch; it does not restrict who can read the case.
    const reassigned=data.assignedTo!==undefined&&data.assignedTo!==row.assignedTo;
    const assignee=reassigned?await resolveAssignee(data.assignedTo??""):null;
    if(data.profile)await ensureUnique(ownerId.ownerId,data.profile,id);
    const db=getDb(),[clientCase]=await db.select({id:clientCases.candidateId}).from(clientCases).where(eq(clientCases.candidateId,id)).limit(1);
    // One source per fact: a client file's jobs and pathway come from the client request (client_cases.details).
    if(clientCase&&data.pathway!==undefined)throw new ApiError(400,"مسار ملف العميل يُؤخذ من طلبه، ولا يُعدَّل من هنا.");
    if(clientCase&&data.profile&&data.profile.jobs.length)throw new ApiError(400,"وظائف ملف العميل تُدار من طلب العميل.");
    if(!clientCase&&data.profile){const jobsError=officeJobsError(data.profile.jobs);if(jobsError)throw new ApiError(400,jobsError);}
    const profile=data.profile??JSON.parse(row.profile),now=new Date().toISOString();
    const changes:string[]=[];
    if(data.profile)changes.push("تحديث البيانات وإعادة التقييم");
    if(data.status&&data.status!==row.status)changes.push("الحالة: "+statusLabels[row.status]+" ← "+statusLabels[data.status]);
    if(data.priority!==undefined)changes.push("تحديث الأولوية");if(data.pathway!==undefined)changes.push("تحديث المسار");
    if(data.assignedTo!==undefined)changes.push("مسؤول المتابعة: "+(data.assignedTo||"لم يحدد"));
    if(data.referralTo!==undefined)changes.push("جهة الإحالة المسجلة: "+(data.referralTo||"لم تحدد"));
    if(data.sharingConsent!==undefined&&data.sharingConsent!==row.sharingConsent)changes.push(data.sharingConsent?"سجّل الموظف موافقة المتقدم على مشاركة الملف":"ألغى الموظف موافقة مشاركة الملف");
    const eventId=crypto.randomUUID();
    const results=await db.batch([
      db.insert(events).select(db.select({id:sql<string>`${eventId}`.as("id"),ownerId:candidates.ownerId,candidateId:candidates.id,action:sql<string>`${changes.join(" · ")||"أضيفت ملاحظة"}`.as("action"),note:sql<string>`${data.note??""}`.as("note"),createdAt:sql<string>`${now}`.as("created_at")}).from(candidates).where(and(eq(candidates.id,id),owned(candidates.ownerId,ownerId),eq(candidates.version,data.version)))),
      db.update(candidates).set({profile:JSON.stringify(profile),status:data.status??row.status,priority:data.priority??row.priority,pathway:data.pathway??row.pathway,assignedTo:data.assignedTo??row.assignedTo,referralTo:data.referralTo??row.referralTo,sharingConsent:data.sharingConsent??row.sharingConsent,...(data.profile?contactKeys(profile):{}),version:row.version+1,updatedAt:now}).where(and(eq(candidates.id,id),owned(candidates.ownerId,ownerId),eq(candidates.version,data.version))).returning({id:candidates.id}),
      ...(reassigned?(()=>{const committed=sql`EXISTS (SELECT 1 FROM candidates c WHERE c.id=${id} AND c.version=${row.version+1})`;return [
        db.delete(caseAccess).where(and(eq(caseAccess.caseId,id),committed)),
        ...(assignee?[db.insert(users).values({userId:assignee.userId,role:"STAFF",active:1,createdAt:now}).onConflictDoNothing(),
          db.insert(caseAccess).select(db.select({caseId:sql<string>`${id}`.as("case_id"),userId:users.userId,grantedBy:sql<string>`${ownerId.authority!.actor.userId}`.as("granted_by"),createdAt:sql<string>`${now}`.as("created_at")}).from(users).where(and(eq(users.userId,assignee.userId),eq(users.role,"STAFF"),eq(users.active,1),committed)))]:[]),
      ] as const;})():[]),
    ]);
    if(results[1].length===0)throw new ApiError(409,"تغير الملف أثناء الحفظ. أعد تحميله.");
    await recomputeCase(id,{mode:'write'});
    if(row.source==='client'&&data.status&&data.status!==row.status)waitUntil(notifyStatus({...row,profile:JSON.stringify(profile),status:data.status,version:row.version+1},new URL(request.url).origin).catch(()=>console.error('status_notification_failed')));
    return Response.json({ok:true});
  }catch(e){return errorResponse(isDuplicateConstraint(e)?new ApiError(409,"التحديث يكرر ملفًا موجودًا بالاسم ووسيلة التواصل نفسيهما."):e);}
}
