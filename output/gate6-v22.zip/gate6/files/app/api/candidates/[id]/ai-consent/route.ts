import { z } from 'zod';
import { getDb } from '@/db';
import { documentAiPermissions,events } from '@/db/schema';
import { staff,candidateOwned,sameOrigin,readJson,errorResponse,ApiError,staffWith } from '@/lib/server';
import { professionalConfig,operationLog } from '@/lib/professional-ai';
import { DOCUMENT_PERMISSION_VERSION } from '@/lib/generated-documents';
// ai_analysis_consent: staff records the client's explicit consent for office-created or imported cases.
// Client-facing screens show no AI choice; the office records the client's explicit consent for every case.
const schema=z.object({consent:z.boolean(),confirmed:z.literal(true,{errorMap:()=>({message:'أكّد أن العميل وافق صراحة على المعالجة لدى المزود.'})})}).strict();
export async function POST(request:Request,ctx:{params:Promise<{id:string}>}){try{
 sameOrigin(request);const s=await staffWith('edit_case'),{id}=await ctx.params,c=await candidateOwned(id,s.scope),d=await readJson(request,schema);
 const config=await professionalConfig();if(!config.configured)throw new ApiError(503,'يلزم إعداد مزود OpenAI أو Anthropic أولًا.');
 const now=new Date().toISOString(),row={candidateId:id,provider:config.provider,consent:d.consent,version:DOCUMENT_PERMISSION_VERSION,updatedAt:now},db=getDb();
 await db.batch([
  db.insert(documentAiPermissions).values(row).onConflictDoUpdate({target:documentAiPermissions.candidateId,set:row}),
  db.insert(events).values({id:crypto.randomUUID(),ownerId:c.ownerId,candidateId:id,action:d.consent?'سُجّل تفويض العميل لتحليل الذكاء الاصطناعي':'سُحب تفويض تحليل الذكاء الاصطناعي',note:s.user.email+' · '+config.provider,createdAt:now}),
 ]);
 await operationLog('ai_analysis_consent',s.user.email,d.consent?'granted':'withdrawn',config.provider,id);
 return Response.json({ok:true,consent:d.consent,provider:config.provider},{headers:{'Cache-Control':'private, no-store'}});
}catch(e){return errorResponse(e);}}
