import { owner,sameOrigin,candidateOwned,errorResponse,ownerWith } from '@/lib/server';
import { uploadDocument } from '@/lib/upload';
export async function POST(request:Request,ctx:{params:Promise<{id:string}>}){try{sameOrigin(request);const o=await ownerWith('upload_documents'),{id}=await ctx.params,c=await candidateOwned(id,o);return Response.json(await uploadDocument(request,c),{status:201});}catch(e){return errorResponse(e);}}
