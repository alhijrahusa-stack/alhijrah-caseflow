import { owner,candidateOwned,errorResponse,ownerWith } from '@/lib/server';
import { authorizationPdfResponse } from '@/lib/authorization';
export async function GET(_request:Request,ctx:{params:Promise<{id:string}>}){try{const o=await ownerWith('view_documents'),{id}=await ctx.params,candidate=await candidateOwned(id,o);return await authorizationPdfResponse(candidate.id,candidate.reference);}catch(e){return errorResponse(e);}}
