import { z } from 'zod';
import { getDb } from '@/db';
import { clientMessages } from '@/db/schema';
import { eq,and,desc } from 'drizzle-orm';
import { staff,candidateOwned,sameOrigin,readJson,errorResponse,ApiError,staffWith } from '@/lib/server';
import { mailStatus,sendMessage } from '@/lib/mail';
type Context={params:Promise<{id:string}>};
export async function GET(_request:Request,ctx:Context){try{const s=await staff(),{id}=await ctx.params;await candidateOwned(id,s.scope);const messages=await getDb().select().from(clientMessages).where(eq(clientMessages.candidateId,id)).orderBy(desc(clientMessages.createdAt)).limit(100);return Response.json({messages,mail:await mailStatus()},{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
const schema=z.union([z.object({messageId:z.string().uuid()}).strict(),z.object({requestKey:z.string().uuid(),subject:z.string().trim().min(3).max(180),body:z.string().trim().min(5).max(5000)}).strict()]);
export async function POST(request:Request,ctx:Context){try{sameOrigin(request);const s=await staffWith('edit_case'),{id}=await ctx.params,c=await candidateOwned(id,s.scope),d=await readJson(request,schema),db=getDb();let messageId:string;
 if('messageId'in d){const [m]=await db.select().from(clientMessages).where(and(eq(clientMessages.id,d.messageId),eq(clientMessages.candidateId,id))).limit(1);if(!m)throw new ApiError(404,'الإشعار غير موجود');messageId=m.id;}
 else{const p=JSON.parse(c.profile);if(!p.email)throw new ApiError(400,'أضف بريد العميل أولًا');const key='staff:'+d.requestKey;await db.insert(clientMessages).values({id:crypto.randomUUID(),candidateId:id,kind:'staff',recipient:p.email,subject:d.subject,body:d.body,actor:s.user.email,requestKey:key,createdAt:new Date().toISOString()}).onConflictDoNothing();const [m]=await db.select().from(clientMessages).where(eq(clientMessages.requestKey,key)).limit(1);if(m.candidateId!==id||m.subject!==d.subject||m.body!==d.body)throw new ApiError(409,'تغير محتوى الإشعار؛ حدّث النموذج قبل الإرسال');messageId=m.id;}
 return Response.json(await sendMessage(messageId,new URL(request.url).origin,s.user.email));}catch(e){return errorResponse(e);}}
