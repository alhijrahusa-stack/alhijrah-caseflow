import { getDb } from '@/db';
import { assessmentHistory } from '@/db/schema';
import { eq,desc } from 'drizzle-orm';
import { staff,candidateOwned,errorResponse } from '@/lib/server';
type Context={params:Promise<{id:string}>};
// Read-only: the latest engine evaluation recorded for the file (assessment_history). Never writes candidates.assessment.
export async function GET(_request:Request,ctx:Context){try{const s=await staff(),{id}=await ctx.params;await candidateOwned(id,s.scope);
 const [row]=await getDb().select().from(assessmentHistory).where(eq(assessmentHistory.candidateId,id)).orderBy(desc(assessmentHistory.computedAt)).limit(1);
 const output=row?JSON.parse(row.outputJson) as {preliminary?:unknown}:null;
 return Response.json(row?{state:output?.preliminary?'available':'computed_before_preliminary',historyId:row.id,computedAt:row.computedAt,inputsHash:row.inputsHash,engineVersion:row.engineVersion,preliminary:output?.preliminary??null}:{state:'not_computed',preliminary:null},{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
