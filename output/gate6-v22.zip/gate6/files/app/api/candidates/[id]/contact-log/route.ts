import { z } from 'zod';
import { getDb } from '@/db';
import { events } from '@/db/schema';
import { staff,candidateOwned,sameOrigin,readJson,errorResponse,staffWith } from '@/lib/server';
import { rateLimit } from '@/lib/security';
// Records that a staff member opened a one-click contact template (e.g. WhatsApp). Opening a template does not
// prove delivery, so the activity log says "opened", never "sent".
const TEMPLATES={status:'تحديث الحالة',missing:'استكمال المستندات',appointment:'تذكير بموعد',welcome:'ترحيب واستلام'} as const;
const schema=z.object({channel:z.literal('whatsapp'),template:z.enum(['status','missing','appointment','welcome'])}).strict();
export async function POST(request:Request,ctx:{params:Promise<{id:string}>}){try{
 sameOrigin(request);const s=await staffWith('edit_case'),{id}=await ctx.params,c=await candidateOwned(id,s.scope);await rateLimit(request,'contact-log:'+id,60,3600);
 const d=await readJson(request,schema);
 await getDb().insert(events).values({id:crypto.randomUUID(),ownerId:c.ownerId,candidateId:id,action:'فتح الموظف قالب WhatsApp: '+TEMPLATES[d.template],note:s.user.email,createdAt:new Date().toISOString()});
 return Response.json({ok:true},{headers:{'Cache-Control':'private, no-store'}});
}catch(e){return errorResponse(e);}}
