import { z } from 'zod';
import { staffWith,candidateOwned,sameOrigin,readJson,errorResponse,ApiError } from '@/lib/server';
import { uploadDocument } from '@/lib/upload';
import { requireCapability } from '@/lib/rbac';
import { messageCreateSchema,staffSend,replay,transition,transitionSchema,writeReceipt,chatMedia,receipts,consents,requestRapidAssessment } from '@/lib/case-chat';
import { connect,transportMode } from '@/lib/chat-transport';
import { caseJobs } from '@/lib/jobs';
import { caseOutbox } from '@/lib/outbox';
// v2.2 Gate 5 — staff side of the case chat (capability `chat`; office policy: every active staff member with it reads
// every conversation). Claim/release/close are CAS transitions: concurrent claims produce one owner.
type Context={params:Promise<{id:string}>};
const Id=z.string().min(8).max(200);
const schema=z.discriminatedUnion('action',[
 z.object({action:z.literal('send'),message:messageCreateSchema}).strict(),
 z.object({action:z.literal('receipt'),deliveredSequence:z.number().int().min(0),readSequence:z.number().int().min(0)}).strict(),
 z.object({action:z.literal('transition'),transition:transitionSchema}).strict(),
 z.object({action:z.literal('rapid_assessment'),requestKey:Id}).strict(),
]);
const noStore={'Cache-Control':'private, no-store'};
export async function GET(request:Request,ctx:Context){try{const s=await staffWith('chat'),{id}=await ctx.params;await candidateOwned(id,s.scope);const url=new URL(request.url);
 const media=url.searchParams.get('media');if(media)return await chatMedia(id,media);
 if(url.searchParams.get('socket')==='1')return await connect(request,{kind:'STAFF',caseId:id,userId:s.authority.actor.userId});
 const page=await replay(id,Math.max(0,Number(url.searchParams.get('after')||0)|0),Number(url.searchParams.get('limit')||50),false);
 return Response.json({...page,receipts:await receipts(id),consents:await consents(id),jobs:await caseJobs(id),outbox:await caseOutbox(id),transport:transportMode(),me:s.authority.actor.userId},{headers:noStore});}catch(e){return errorResponse(e);}}
export async function POST(request:Request,ctx:Context){try{sameOrigin(request);const s=await staffWith('chat'),{id}=await ctx.params,c=await candidateOwned(id,s.scope),me=s.authority.actor.userId;
 const upload=new URL(request.url).searchParams.get('upload');
 if(upload){if(upload!=='file'&&upload!=='voice')throw new ApiError(400,'نوع الرفع غير صحيح.');const r=await uploadDocument(request,c,false,{voice:upload==='voice'});return Response.json({evidenceId:r.id},{status:201,headers:noStore});}
 const d=await readJson(request,schema);
 if(d.action==='send'){const out=await staffSend(id,me,d.message);return Response.json({sequence:out.message.sequence,messageId:out.message.messageId,replayed:out.replayed},{status:out.replayed?200:201,headers:noStore});}
 if(d.action==='receipt')return Response.json(await writeReceipt(id,me,d.deliveredSequence,d.readSequence),{headers:noStore});
 if(d.action==='transition')return Response.json(await transition(id,{kind:'STAFF',userId:me},d.transition),{headers:noStore});
 requireCapability(s.authority,'request_assessment');return Response.json(await requestRapidAssessment(id,{kind:'STAFF',userId:me},d.requestKey),{status:201,headers:noStore});
}catch(e){return errorResponse(e);}}
