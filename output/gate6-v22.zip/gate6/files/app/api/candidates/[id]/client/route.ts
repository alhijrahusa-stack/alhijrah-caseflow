import { authorizationFor,authorizationSummary } from '@/lib/authorization';
import { z } from 'zod';
import { getDb } from '@/db';
import { clientCases,candidates,documents,events } from '@/db/schema';
import { eq,and,sql } from 'drizzle-orm';
import { owner,staff,candidateOwned,sameOrigin,errorResponse,readJson,ApiError,staffWith } from '@/lib/server';
import { screenIntake } from '@/lib/screening';
import { dateSchema } from '@/lib/model';
import { detailsSchema,categoryKeys } from '@/lib/intake';
type Context={params:Promise<{id:string}>};
export async function GET(_request:Request,ctx:Context){try{
 const o=await owner(),{id}=await ctx.params,c=await candidateOwned(id,o),db=getDb(),[client]=await db.select().from(clientCases).where(eq(clientCases.candidateId,id)).limit(1);
 if(!client)return Response.json({client:null},{headers:{'Cache-Control':'private, no-store'}});
 const files=await db.select({category:documents.category,verified:documents.verified}).from(documents).where(eq(documents.candidateId,id)),details=detailsSchema.parse(JSON.parse(client.details));
 const authorization=authorizationSummary(await authorizationFor(id));
 return Response.json({authorization,client:{inbox:client.inbox,version:client.version,details,instructions:client.instructions,requestedDocuments:JSON.parse(client.requestedDocuments),followUpDate:client.followUpDate,lmiaStream:client.lmiaStream,lmiaCompleteDate:client.lmiaCompleteDate,lmiaEvidenceId:client.lmiaEvidenceId,submittedAt:client.submittedAt,consentVersion:client.consentVersion},screening:screenIntake(JSON.parse(c.profile),details,files,JSON.parse(client.requestedDocuments))},{headers:{'Cache-Control':'private, no-store'}});
 }catch(e){return errorResponse(e);}}
const schema=z.object({version:z.number().int().positive(),inbox:z.enum(['pending','needs_info','accepted']),instructions:z.string().trim().max(4000),requestedDocuments:z.array(z.enum(categoryKeys)).max(20),followUpDate:dateSchema.optional(),lmiaStream:z.enum(['','global_talent','agricultural','seasonal','high_wage','low_wage','permanent_resident']).optional(),lmiaCompleteDate:dateSchema.optional(),lmiaEvidenceId:z.union([z.literal(''),z.string().uuid()]).optional()}).strict();
export async function PATCH(request:Request,ctx:Context){try{
 sameOrigin(request);const s=await staffWith('edit_case'),{id}=await ctx.params,c=await candidateOwned(id,s.scope),d=await readJson(request,schema),db=getDb();
 const [current]=await db.select().from(clientCases).where(eq(clientCases.candidateId,id)).limit(1);
 if(!current)throw new ApiError(404,'هذا الملف لا يحتوي طلب بوابة عميل');if(current.version!==d.version)throw new ApiError(409,'تم تحديث الطلب. أعد فتحه.');
 const lmia={stream:d.lmiaStream??current.lmiaStream,date:d.lmiaCompleteDate??current.lmiaCompleteDate,proof:d.lmiaEvidenceId??current.lmiaEvidenceId};if(lmia.stream||lmia.date||lmia.proof){if(!lmia.stream||!lmia.date||!lmia.proof||lmia.date>new Date().toISOString().slice(0,10))throw new ApiError(400,'أكمل مسار LMIA وتاريخ اكتمال الطلب ودليل الإيداع.');const [proof]=await db.select({verified:documents.verified}).from(documents).where(and(eq(documents.id,lmia.proof),eq(documents.candidateId,id))).limit(1);if(!proof?.verified)throw new ApiError(400,'يلزم مستند إيداع راجعه الموظف قبل عرض مرجع المدة للعميل.');}
 const now=new Date().toISOString(),eid=crypto.randomUUID(),action={pending:'أعيد الطلب إلى الوارد',accepted:'بدأ الموظف مراجعة طلب العميل',needs_info:'طلب الموظف استكمال الملف'}[d.inbox];
 const scope=and(eq(clientCases.candidateId,id),eq(clientCases.version,d.version));
 const status=d.inbox==='needs_info'?'documents':d.inbox==='accepted'?'reviewing':null;
 const result=await db.batch([
 db.insert(events).select(db.select({id:sql<string>`${eid}`.as('id'),ownerId:sql<string>`${c.ownerId}`.as('owner_id'),candidateId:clientCases.candidateId,action:sql<string>`${action}`.as('action'),note:sql<string>`${s.user.email}`.as('note'),createdAt:sql<string>`${now}`.as('created_at')}).from(clientCases).where(scope)),
 db.update(candidates).set({...(status?{status:sql`CASE WHEN ${candidates.status} IN ('new','reviewing','documents') THEN ${status} ELSE ${candidates.status} END`}:{}),version:sql`${candidates.version}+1`,updatedAt:now}).where(and(eq(candidates.id,id),sql`EXISTS (SELECT 1 FROM client_cases cc WHERE cc.candidate_id = ${id} AND cc.version = ${d.version})`)),
 db.update(clientCases).set({inbox:d.inbox,followUpDate:d.followUpDate??current.followUpDate,lmiaStream:lmia.stream,lmiaCompleteDate:lmia.date,lmiaEvidenceId:lmia.proof,instructions:d.instructions,requestedDocuments:JSON.stringify(d.requestedDocuments),version:d.version+1}).where(scope).returning({id:clientCases.candidateId}),
 ]);
 if(!result[2].length)throw new ApiError(409,'تغير الطلب أثناء الحفظ');return Response.json({ok:true});
 }catch(e){return errorResponse(e);}}
