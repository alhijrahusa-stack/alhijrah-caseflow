import { staffWith,candidateOwned,sameOrigin,readJson,errorResponse } from '@/lib/server';
import { requireCapability } from '@/lib/rbac';
import { createInvoice,createInvoiceSchema,caseInvoices,catalog,officeCurrency } from '@/lib/billing';
// v2.2 Gate 5 — case invoices. Reading needs view_financials; creating needs create_invoice (re-checked by the 0025 trigger).
type Context={params:Promise<{id:string}>};
const noStore={'Cache-Control':'private, no-store'};
export async function GET(_request:Request,ctx:Context){try{const s=await staffWith('view_financials'),{id}=await ctx.params;await candidateOwned(id,s.scope);
 return Response.json({currency:await officeCurrency(),catalog:await catalog(true),invoices:await caseInvoices(id)},{headers:noStore});}catch(e){return errorResponse(e);}}
export async function POST(request:Request,ctx:Context){try{sameOrigin(request);const s=await staffWith('view_financials');requireCapability(s.authority,'create_invoice');const {id}=await ctx.params;await candidateOwned(id,s.scope);
 const d=await readJson(request,createInvoiceSchema);return Response.json(await createInvoice(s.authority,id,d),{status:201,headers:noStore});}catch(e){return errorResponse(e);}}
