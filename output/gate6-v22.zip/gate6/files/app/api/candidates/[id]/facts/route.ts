import { z } from 'zod';
import { staff,candidateOwned,sameOrigin,readJson,errorResponse,audit,staffWith } from '@/lib/server';
import { factHistory,reviewFact } from '@/lib/facts';
import { recomputeCase } from '@/lib/case-engine';
type Context={params:Promise<{id:string}>};
// Staff only: full fact history, and the evidence review that turns a REPORTED fact into VERIFIED or CONFLICTED.
export async function GET(_request:Request,ctx:Context){try{const s=await staff(),{id}=await ctx.params;await candidateOwned(id,s.scope);return Response.json({items:await factHistory(id)},{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
const schema=z.object({key:z.string().regex(/^[a-z_]{1,60}$/),documentId:z.string().min(1).max(100),outcome:z.enum(['verified','conflicted'])}).strict();
export async function POST(request:Request,ctx:Context){try{sameOrigin(request);const s=await staffWith('review_case'),{id}=await ctx.params;await candidateOwned(id,s.scope);const d=await readJson(request,schema);
 const fact=await reviewFact(id,d.key,d.documentId,d.outcome,{userId:s.authority.actor.userId,label:s.user.email});
 await audit(s.ownerId,id,'fact_review',`${d.key}:${fact.status}`);
 await recomputeCase(id,{mode:'write'});
 return Response.json({fact},{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
