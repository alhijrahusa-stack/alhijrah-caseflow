import { staff,candidateOwned,sameOrigin,errorResponse,staffWith } from '@/lib/server';
import { rateLimit } from '@/lib/security';
import { runCaseReview,latestReview } from '@/lib/case-review';
import { professionalConfig } from '@/lib/professional-ai';
type Context={params:Promise<{id:string}>};
const headers={'Cache-Control':'private, no-store'};
export async function GET(_request:Request,ctx:Context){try{const s=await staff(),{id}=await ctx.params,c=await candidateOwned(id,s.scope);const [latest,cfg]=await Promise.all([latestReview(id),professionalConfig()]);return Response.json({latest,stale:!!latest&&latest.sourceVersion!==c.version,available:cfg.configured&&cfg.provider==='openai'},{headers});}catch(e){return errorResponse(e);}}
export async function POST(request:Request,ctx:Context){try{sameOrigin(request);const s=await staffWith('review_case'),{id}=await ctx.params;await candidateOwned(id,s.scope);await rateLimit(request,'ai-review:'+id,10,3600);const r=await runCaseReview(id,s.user.email);return Response.json({latest:{...r,createdBy:s.user.email},stale:false,available:true},{status:201,headers});}catch(e){return errorResponse(e);}}
