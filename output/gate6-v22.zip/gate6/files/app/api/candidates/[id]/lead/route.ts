import { getDb } from '@/db';
import { leadScores } from '@/db/schema';
import { staff,candidateOwned,errorResponse } from '@/lib/server';
import { computeLead } from '@/lib/lead-score';
import { eq } from 'drizzle-orm';
type Context={params:Promise<{id:string}>};
export async function GET(_r:Request,ctx:Context){try{const s=await staff(),{id}=await ctx.params;await candidateOwned(id,s.scope);let [row]=await getDb().select().from(leadScores).where(eq(leadScores.candidateId,id)).limit(1);if(!row){await computeLead(id,false);[row]=await getDb().select().from(leadScores).where(eq(leadScores.candidateId,id)).limit(1);}return Response.json(row?{score:row.score,tier:row.tier,factors:JSON.parse(row.factors),computedAt:row.computedAt}:null,{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
