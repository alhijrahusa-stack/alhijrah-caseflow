import { z } from 'zod';
import { getDb } from '@/db';
import { caseReviews,candidates,events,documents,clientCases } from '@/db/schema';
import { eq,and,sql } from 'drizzle-orm';
import { staff,candidateOwned,sameOrigin,readJson,errorResponse,ApiError,staffWith } from '@/lib/server';
import { reviewChecks } from '@/lib/reviews';
import { detailsSchema } from '@/lib/intake';
import { screenIntake } from '@/lib/screening';
type Context={params:Promise<{id:string}>};
export async function GET(_r:Request,ctx:Context){try{const s=await staffWith('review_case'),{id}=await ctx.params,c=await candidateOwned(id,s.scope),[review]=await getDb().select().from(caseReviews).where(eq(caseReviews.candidateId,id)).limit(1);return Response.json({actor:s.user.email,review:review?{...review,checklist:JSON.parse(review.checklist),stale:review.contentVersion!==c.version}:null},{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
const checks=z.object({identity:z.boolean(),contacts:z.boolean(),dates:z.boolean(),evidence:z.boolean(),wording:z.boolean(),consent:z.boolean()});
const schema=z.object({version:z.number().int().min(0),action:z.enum(['submit','approve','request_changes']),checklist:checks.optional(),note:z.string().trim().max(2000).default('')}).strict();
export async function POST(request:Request,ctx:Context){try{
 sameOrigin(request);const s=await staffWith('review_case'),{id}=await ctx.params,c=await candidateOwned(id,s.scope),d=await readJson(request,schema),db=getDb();
 if(c.status==='archived')throw new ApiError(400,'أعد فتح الملف قبل مراجعته.');
 const [current]=await db.select().from(caseReviews).where(eq(caseReviews.candidateId,id)).limit(1);
 if((current?.version??0)!==d.version)throw new ApiError(409,'تغيرت المراجعة؛ أعد تحميلها.');
 if(d.action!=='submit'){
  if(!current||current.state!=='in_review')throw new ApiError(400,'أرسل الملف للمراجعة أولًا.');
  if(current.preparedBy.toLowerCase()===s.user.email.toLowerCase())throw new ApiError(403,'يلزم مراجع آخر غير مُعدّ الملف.');
  if(current.contentVersion!==c.version)throw new ApiError(409,'تغيرت بيانات الملف بعد إرساله. يلزم إعادة إرساله للمراجعة.');
 }
 if(d.action==='request_changes'&&d.note.length<3)throw new ApiError(400,'حدد التصحيح المطلوب.');
 if(d.action==='approve'){
  if(!d.checklist||!Object.keys(reviewChecks).every(k=>d.checklist?.[k as keyof typeof reviewChecks]))throw new ApiError(400,'أكمل قائمة تدقيق المراجع.');
  const files=await db.select({category:documents.category,verified:documents.verified}).from(documents).where(eq(documents.candidateId,id));
  if(!['passport','resume'].every(category=>files.some(f=>f.category===category&&f.verified)))throw new ApiError(400,'راجع مستندي الهوية والسيرة قبل اعتماد المراجعة الإدارية.');
  const [client]=await db.select({details:clientCases.details}).from(clientCases).where(eq(clientCases.candidateId,id)).limit(1);
  if(client&&screenIntake(JSON.parse(c.profile),detailsSchema.parse(JSON.parse(client.details)),files).conflicts.some(x=>x.level==='critical'))throw new ApiError(400,'عالج التنبيه الحرج قبل الاعتماد.');
 }
 const now=new Date().toISOString(),state=d.action==='submit'?'in_review':d.action==='approve'?'approved':'changes_requested';
 const values={state,preparedBy:d.action==='submit'?s.user.email:current!.preparedBy,reviewedBy:d.action==='submit'?'':s.user.email,checklist:JSON.stringify(d.action==='submit'?{}:d.checklist??{}),note:d.note,contentVersion:c.version,version:d.version+1,submittedAt:d.action==='submit'?now:current!.submittedAt,reviewedAt:d.action==='submit'?'':now,updatedAt:now};
 const action=d.action==='submit'?'أُرسل الملف إلى مراجعة الفريق':d.action==='approve'?'اعتمد مراجع مستقل المراجعة الإدارية':'أعاد المراجع الملف للتصحيح';
 const mutation=current?db.update(caseReviews).set(values).where(and(eq(caseReviews.candidateId,id),eq(caseReviews.version,d.version),sql`EXISTS (SELECT 1 FROM candidates c WHERE c.id = ${id} AND c.version = ${c.version})`)).returning({id:caseReviews.candidateId}):db.insert(caseReviews).select(db.select({candidateId:candidates.id,state:sql<string>`${state}`.as('state'),preparedBy:sql<string>`${s.user.email}`.as('prepared_by'),reviewedBy:sql<string>`''`.as('reviewed_by'),checklist:sql<string>`'{}'`.as('checklist'),note:sql<string>`${d.note}`.as('note'),contentVersion:candidates.version,version:sql<number>`1`.as('version'),submittedAt:sql<string>`${now}`.as('submitted_at'),reviewedAt:sql<string>`''`.as('reviewed_at'),updatedAt:sql<string>`${now}`.as('updated_at')}).from(candidates).where(and(eq(candidates.id,id),eq(candidates.version,c.version)))).onConflictDoNothing().returning({id:caseReviews.candidateId});
 const result=await db.batch([mutation,db.insert(events).select(db.select({id:sql<string>`${crypto.randomUUID()}`.as('id'),ownerId:candidates.ownerId,candidateId:candidates.id,action:sql<string>`${action}`.as('action'),note:sql<string>`${s.user.email+' · '+d.note}`.as('note'),createdAt:sql<string>`${now}`.as('created_at')}).from(candidates).where(and(eq(candidates.id,id),sql`changes() > 0`)))]);
 if(!result[0].length)throw new ApiError(409,'تغير الملف أثناء المراجعة. أعد فتحه.');return Response.json({ok:true,state});
 }catch(e){return errorResponse(e);}}
