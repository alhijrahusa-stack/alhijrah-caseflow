import { getDb } from "@/db";
import { tasks,events } from "@/db/schema";
import { dateSchema,prioritySchema } from "@/lib/model";
import { owned,owner,sameOrigin,errorResponse,ApiError,readJson,ownerWith } from "@/lib/server";
import { and,eq,sql } from "drizzle-orm";
import { z } from "zod";
const schema=z.object({version:z.number().int().positive(),title:z.string().trim().min(3).max(200).optional(),dueDate:dateSchema.optional(),priority:prioritySchema.optional(),status:z.enum(["open","done"]).optional()}).strict();
export async function PATCH(request:Request,context:{params:Promise<{id:string}>}) {
  try {
    sameOrigin(request);const ownerId=await ownerWith('edit_case'),{id}=await context.params,data=await readJson(request,schema),db=getDb();
    const [task]=await db.select().from(tasks).where(and(eq(tasks.id,id),owned(tasks.ownerId,ownerId))).limit(1);
    if(!task)throw new ApiError(404,"المهمة غير موجودة");
    if(task.version!==data.version)throw new ApiError(409,"تغيرت المهمة. أعد تحميل قائمة المتابعة.");
    if(Object.keys(data).length===1)throw new ApiError(400,"لا توجد تغييرات");
    const now=new Date().toISOString(),eventId=crypto.randomUUID(),action=data.status==="done"?"أُنجزت مهمة متابعة":data.status==="open"?"أُعيد فتح مهمة متابعة":"حُدثت مهمة متابعة";
    const note=(data.title??task.title)+(data.dueDate?" · "+data.dueDate:"");
    const results=await db.batch([
      db.insert(events).select(db.select({id:sql<string>`${eventId}`.as("id"),ownerId:tasks.ownerId,candidateId:tasks.candidateId,action:sql<string>`${action}`.as("action"),note:sql<string>`${note}`.as("note"),createdAt:sql<string>`${now}`.as("created_at")}).from(tasks).where(and(eq(tasks.id,id),owned(tasks.ownerId,ownerId),eq(tasks.version,data.version)))),
      db.update(tasks).set({title:data.title??task.title,dueDate:data.dueDate??task.dueDate,priority:data.priority??task.priority,status:data.status??task.status,version:task.version+1,updatedAt:now}).where(and(eq(tasks.id,id),owned(tasks.ownerId,ownerId),eq(tasks.version,data.version))).returning({id:tasks.id}),
    ]);
    if(!results[1].length)throw new ApiError(409,"تغيرت المهمة أثناء الحفظ. أعد تحميلها.");
    return Response.json({ok:true});
  }catch(e){return errorResponse(e);}
}
