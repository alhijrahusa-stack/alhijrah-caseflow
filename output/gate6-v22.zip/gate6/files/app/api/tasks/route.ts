import { getDb } from "@/db";
import { candidates,documents,events,tasks } from "@/db/schema";
import { prioritySchema,dateSchema,documentLabels } from "@/lib/model";
import { owned,owner,sameOrigin,candidateOwned,errorResponse,ApiError,readJson,ownerWith } from "@/lib/server";
import { and,eq,asc,desc,sql,count } from "drizzle-orm";
import { z } from "zod";
export const dynamic="force-dynamic";
// Dates in the work queue are staff follow-up dates, never government deadlines.
export async function GET(request:Request) {
  try {
    const ownerId=await owner(),db=getDb(),q=new URL(request.url).searchParams;
    const page=Math.max(1,Math.floor(Number(q.get("page")))||1),candidateId=q.get("candidateId"),today=q.get("today")||new Date().toISOString().slice(0,10);
    if(!dateSchema.safeParse(today).success||!today)throw new ApiError(400,"تاريخ العرض غير صحيح");
    const scope=and(owned(tasks.ownerId,ownerId),owned(candidates.ownerId,ownerId),candidateId?eq(tasks.candidateId,candidateId):sql`${candidates.status} <> 'archived'`);
    const filters=[scope];
    filters.push(eq(tasks.status,q.get("status")==="done"?"done":"open"));
    if(q.get("due")==="overdue")filters.push(sql`${tasks.dueDate} <> '' AND ${tasks.dueDate} < ${today}`);
    if(q.get("due")==="today")filters.push(eq(tasks.dueDate,today));
    if(q.get("due")==="unscheduled")filters.push(eq(tasks.dueDate,""));
    const where=and(...filters);
    const [rows,total,summary]=await Promise.all([
      db.select({task:tasks,reference:candidates.reference,profile:candidates.profile}).from(tasks).innerJoin(candidates,eq(tasks.candidateId,candidates.id)).where(where).orderBy(sql`CASE ${tasks.priority} WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 ELSE 2 END`,sql`CASE WHEN ${tasks.dueDate} = '' THEN 1 ELSE 0 END`,asc(tasks.dueDate),desc(tasks.createdAt),asc(tasks.id)).limit(30).offset((page-1)*30),
      db.select({count:count()}).from(tasks).innerJoin(candidates,eq(tasks.candidateId,candidates.id)).where(where),
      db.select({open:sql<number>`coalesce(sum(CASE WHEN ${tasks.status} = 'open' THEN 1 ELSE 0 END),0)`,overdue:sql<number>`coalesce(sum(CASE WHEN ${tasks.status} = 'open' AND ${tasks.dueDate} <> '' AND ${tasks.dueDate} < ${today} THEN 1 ELSE 0 END),0)`,today:sql<number>`coalesce(sum(CASE WHEN ${tasks.status} = 'open' AND ${tasks.dueDate} = ${today} THEN 1 ELSE 0 END),0)`}).from(tasks).innerJoin(candidates,eq(tasks.candidateId,candidates.id)).where(scope),
    ]);
    return Response.json({items:rows.map(({task:{ownerId,...task},profile,reference})=>({...task,candidateName:JSON.parse(profile).fullName,reference})),total:total[0].count,page,summary:summary[0]},{headers:{"Cache-Control":"private, no-store"}});
  }catch(e){return errorResponse(e);}
}
const createSchema=z.discriminatedUnion("mode",[
  z.object({mode:z.literal("manual"),candidateId:z.string().uuid(),title:z.string().trim().min(3,"أدخل عنوان المهمة").max(200),dueDate:dateSchema.default(""),priority:prioritySchema.default("normal")}),
  z.object({mode:z.literal("suggest"),candidateId:z.string().uuid()}),
]);
export async function POST(request:Request) {
  try {
    sameOrigin(request);const actorOwner=await ownerWith('edit_case'),data=await readJson(request,createSchema),candidate=await candidateOwned(data.candidateId,actorOwner),ownerId=candidate.ownerId,db=getDb();
    if(candidate.status==="archived")throw new ApiError(400,"أعد تنشيط الملف قبل إضافة مهام إليه.");
    const [{total}]=await db.select({total:count()}).from(tasks).where(and(owned(tasks.ownerId,actorOwner),eq(tasks.candidateId,candidate.id),eq(tasks.status,"open")));
    if(total>=200)throw new ApiError(400,"أكمل المهام المفتوحة قبل إضافة المزيد.");
    const now=new Date().toISOString();
    if(data.mode==="manual") {
      const task={id:crypto.randomUUID(),ownerId,candidateId:candidate.id,title:data.title,dueDate:data.dueDate,priority:data.priority,createdAt:now,updatedAt:now};
      await db.batch([db.insert(tasks).values(task),db.insert(events).values({id:crypto.randomUUID(),ownerId,candidateId:candidate.id,action:"أضيفت مهمة متابعة",note:data.title+(data.dueDate?" · متابعة: "+data.dueDate:""),createdAt:now})]);
      return Response.json({ok:true,created:1},{status:201});
    }
    // Missing documents come from the stored engine assessment (lib/case-engine.ts), never recomputed here.
    const assessment=JSON.parse(candidate.assessment) as {missingDocuments:string[]};
    if(!assessment.missingDocuments.length)return Response.json({ok:true,created:0});
    const queries=assessment.missingDocuments.map(category=>db.insert(tasks).values({id:crypto.randomUUID(),ownerId,candidateId:candidate.id,title:"استلام ومراجعة "+documentLabels[category],systemKey:"document:"+category,createdAt:now,updatedAt:now}).onConflictDoNothing().returning({id:tasks.id}));
    const [first,...rest]=queries;
    const results=await db.batch([first,...rest]);
    const created=results.reduce((sum,r)=>sum+(Array.isArray(r)?r.length:0),0);
    if(created)await db.insert(events).values({id:crypto.randomUUID(),ownerId,candidateId:candidate.id,action:"أُنشئت مهام النواقص",note:String(created)+" مهام مستندات؛ بلا مواعيد حكومية مفترضة",createdAt:now});
    return Response.json({ok:true,created},{status:201});
  }catch(e){return errorResponse(e);}
}
