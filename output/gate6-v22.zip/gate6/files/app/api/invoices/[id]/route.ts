import { z } from 'zod';
import { staffWith,candidateOwned,sameOrigin,readJson,errorResponse } from '@/lib/server';
import { requireCapability } from '@/lib/rbac';
import { invoiceDetail,invoiceCase,editInvoice,editInvoiceSchema,discountSchema } from '@/lib/billing';
// v2.2 Gate 5 — one invoice: detail (view_financials), full edit (edit_invoice) or discount-only change (edit_discount).
// A discount change inside a full edit also needs edit_discount: checked here and again by the financial audit trigger.
type Context={params:Promise<{id:string}>};
const noStore={'Cache-Control':'private, no-store'};
const schema=z.union([editInvoiceSchema,discountSchema]);
export async function GET(_request:Request,ctx:Context){try{const s=await staffWith('view_financials'),{id}=await ctx.params;await candidateOwned(await invoiceCase(id),s.scope);return Response.json(await invoiceDetail(id),{headers:noStore});}catch(e){return errorResponse(e);}}
export async function PATCH(request:Request,ctx:Context){try{sameOrigin(request);const s=await staffWith('view_financials'),{id}=await ctx.params;await candidateOwned(await invoiceCase(id),s.scope);
 const d=await readJson(request,schema);
 if(d.action==='discount')requireCapability(s.authority,'edit_discount');
 else{requireCapability(s.authority,'edit_invoice');const cur=await invoiceDetail(id);if(cur.discountCents!==d.discountCents)requireCapability(s.authority,'edit_discount');}
 return Response.json(await editInvoice(s.authority,id,d),{headers:noStore});}catch(e){return errorResponse(e);}}
