import { staffWith,candidateOwned,errorResponse } from '@/lib/server';
import { requireCapability } from '@/lib/rbac';
import { invoicePdfData,invoiceCase } from '@/lib/billing';
import { renderInvoicePdf } from '@/lib/invoice-pdf';
// v2.2 Gate 5 — invoice PDF (?locale=ar|en) from the committed server invoice; export_invoice_pdf + view_financials.
type Context={params:Promise<{id:string}>};
export async function GET(request:Request,ctx:Context){try{const s=await staffWith('view_financials');requireCapability(s.authority,'export_invoice_pdf');const {id}=await ctx.params;await candidateOwned(await invoiceCase(id),s.scope);
 const locale=new URL(request.url).searchParams.get('locale')==='en'?'en':'ar',data=await invoicePdfData(id),bytes=renderInvoicePdf(data,locale);
 return new Response(bytes,{headers:{'Content-Type':'application/pdf','Content-Disposition':`attachment; filename="invoice-${data.reference}-v${data.version}-${locale}.pdf"`,'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','X-Invoice-Data-Hash':data.dataHash}});}catch(e){return errorResponse(e);}}
