import { staffWith,candidateOwned,sameOrigin,errorResponse,ApiError } from '@/lib/server';
import { requireCapability } from '@/lib/rbac';
import { recordPayment,paymentSchema,invoiceCase,receiptObject } from '@/lib/billing';
import { mailStatus } from '@/lib/mail';
// v2.2 Gate 5 — offline payments (CASH/CHEQUE/ZELLE/CASH_APP). multipart: `payload` (JSON) + optional `receipt` (PDF/JPEG/PNG,
// private R2). JSON body is accepted when there is no receipt. Receipts are read back only by staff with view_financials.
type Context={params:Promise<{id:string}>};
const noStore={'Cache-Control':'private, no-store'};
export async function GET(request:Request,ctx:Context){try{const s=await staffWith('view_financials'),{id}=await ctx.params;await candidateOwned(await invoiceCase(id),s.scope);
 const paymentId=new URL(request.url).searchParams.get('receipt')||'';if(!/^[0-9a-f-]{36}$/.test(paymentId))throw new ApiError(400,'حدد الدفعة.');return await receiptObject(id,paymentId);}catch(e){return errorResponse(e);}}
export async function POST(request:Request,ctx:Context){try{sameOrigin(request);const s=await staffWith('view_financials');requireCapability(s.authority,'record_payment');const {id}=await ctx.params;await candidateOwned(await invoiceCase(id),s.scope);
 const type=request.headers.get('content-type')||'';let raw:unknown,receipt:File|null=null;
 if(Number(request.headers.get('content-length'))>11*1024*1024)throw new ApiError(413,'الطلب أكبر من الحد المسموح.');
 if(type.startsWith('multipart/form-data')){const form=await request.formData(),payload=form.get('payload'),file=form.get('receipt');if(typeof payload!=='string')throw new ApiError(400,'بيانات الدفعة مفقودة.');raw=JSON.parse(payload);receipt=file instanceof File&&file.size>0?file:null;}
 else if(type.includes('application/json'))raw=await request.json();else throw new ApiError(415,'صيغة الطلب غير مدعومة.');
 const parsed=paymentSchema.safeParse(raw);if(!parsed.success)throw new ApiError(422,parsed.error.issues[0]?.message||'بيانات الدفعة غير صالحة.');
 if(parsed.data.notify)requireCapability(s.authority,'send_payment_notice');
 return Response.json(await recordPayment(s.authority,id,parsed.data,receipt,(await mailStatus()).configured),{status:201,headers:noStore});}catch(e){return errorResponse(e);}}
