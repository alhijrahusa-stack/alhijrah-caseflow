import { z } from 'zod';
import { staffWith,candidateOwned,sameOrigin,readJson,errorResponse } from '@/lib/server';
import { requireCapability,requireManager } from '@/lib/rbac';
import { referInvoice,approveInvoice,invoiceCase } from '@/lib/billing';
// v2.2 Gate 5 — referral (STAFF with edit_invoice) locks the invoice as PENDING_APPROVAL; one active MANAGER approves.
type Context={params:Promise<{id:string}>};
const schema=z.object({action:z.enum(['refer','approve']),expectedVersion:z.number().int().min(0),requestKey:z.string().min(8).max(200)}).strict();
export async function POST(request:Request,ctx:Context){try{sameOrigin(request);const s=await staffWith('view_financials'),{id}=await ctx.params;await candidateOwned(await invoiceCase(id),s.scope);
 const {action,...input}=await readJson(request,schema);
 if(action==='approve'){requireManager(s.authority);return Response.json(await approveInvoice(s.authority,id,input),{headers:{'Cache-Control':'private, no-store'}});}
 requireCapability(s.authority,'edit_invoice');return Response.json(await referInvoice(s.authority,id,input),{headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
