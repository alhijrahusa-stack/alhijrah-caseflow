import { staffWith,candidateOwned,sameOrigin,readJson,errorResponse } from '@/lib/server';
import { requireCapability } from '@/lib/rbac';
import { queuePaymentNotice,noticeSchema,invoiceCase } from '@/lib/billing';
import { mailStatus } from '@/lib/mail';
// v2.2 Gate 5 — limited payment notice queued in the delivery outbox (EMAIL only; SMS is not configured and is refused).
type Context={params:Promise<{id:string}>};
export async function POST(request:Request,ctx:Context){try{sameOrigin(request);const s=await staffWith('view_financials');requireCapability(s.authority,'send_payment_notice');const {id}=await ctx.params;await candidateOwned(await invoiceCase(id),s.scope);
 const d=await readJson(request,noticeSchema);return Response.json(await queuePaymentNotice(s.authority,id,d,(await mailStatus()).configured),{status:202,headers:{'Cache-Control':'private, no-store'}});}catch(e){return errorResponse(e);}}
