import { captchaConfig } from '@/lib/captcha';
import { publicCatalog } from '@/lib/services';
export const dynamic='force-dynamic';
// v2.2 Gate 5: the public catalog (active services, explicit office currency only) is added next to the captcha key.
export async function GET(){const c=await captchaConfig();return Response.json({captchaSiteKey:c.configured?c.siteKey:'',catalog:await publicCatalog()},{headers:{'Cache-Control':'no-store'}});}
