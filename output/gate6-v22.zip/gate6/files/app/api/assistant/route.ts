import { z } from 'zod';
import { staff,sameOrigin,readJson,errorResponse,ApiError } from '@/lib/server';
import { rateLimit } from '@/lib/security';
import { groqChat,aiConfig } from '@/lib/intelligence';
import { faqAnswer } from '@/lib/faq';
import { rankFaq,maskIdentifiers } from '@/lib/faq-retrieval';
import { workSnapshot,runOpenAI,resolveReferences } from '@/lib/staff-assistant';
// Staff assistant: open questions, live official sources (OpenAI web search) and work organisation from a
// pseudonymous snapshot of the office's files. Groq answers when OpenAI is not configured or fails.
const file=z.object({name:z.string().trim().min(1).max(120),mime:z.enum(['application/pdf','image/jpeg','image/png','image/webp']),data:z.string().regex(/^[A-Za-z0-9+/=]+$/).max(14_000_000)}).strict();
const schema=z.object({messages:z.array(z.object({role:z.enum(['user','assistant']),content:z.string().trim().min(1).max(4000)}).strict()).min(1).max(16),files:z.array(file).max(3).default([])}).strict();
const BASE=`أنت مساعد العمليات لموظفي مكتب ALHIJRAH Services لإعداد ملفات الهجرة والعمل إلى كندا.
- أجب عن أي سؤال يطرحه الموظف: الهجرة والعمل والدراسة في كندا، صياغة الردود والرسائل، تنظيم العمل، أو أي موضوع آخر. لا ترفض لأن السؤال خارج دليل المكتب.
- اكتب بالعربية الواضحة (أو الإنجليزية إذا كتب الموظف بها)، بإيجاز ونقاط مرتبة، والمطلوب أولًا.
- لا تخترع وقائع أو أرقامًا أو تواريخ أو بيانات ملفات. ميّز بين ما تحققت منه وما لم تتحقق منه.
- لا تضمن قبولًا أو وظيفة أو نتيجة. الأهلية النهائية يقررها المختص المرخّص.
- تنظيم العمل: استخدم «لقطة العمل» أدناه. رتّب: المتأخر، ثم مستحق اليوم، ثم طلبات العملاء المنتظرة، ثم الملفات الراكدة، واقترح خطوة محددة لكل ملف. أشر إلى الملفات برقمها (CA-…) فقط.
- المعلومات الشخصية للعملاء غير متاحة لك عمدًا. لا تطلبها.
- أجب مباشرة بالمعلومة المطلوبة أولًا، باختصار، بلا مقدمات أو حشو أو تنظير. لا تكتب الروابط داخل النص؛ المصادر تُعرض تلقائيًا أسفل الإجابة.
- إذا أرفق الموظف ملفًا أو صورة (سيرة، جواز، عرض عمل، رسالة رسمية) فاقرأه كاملًا وأجب بناءً عليه، واذكر ما قرأته منه بدقة دون تخمين ما لم يظهر.`;
const OPENAI_RULES=`- لأي معلومة متغيرة (سحوبات Express Entry ونقاط CRS، الرسوم، مدد المعالجة، فتح وإغلاق برامج المقاطعات، تغييرات السياسات): ابحث في الويب أولًا وفضّل canada.ca والمواقع الرسمية للمقاطعات، واذكر تاريخ المعلومة.
- لتفاصيل ملف معيّن استخدم get_case. للمراجعة الشاملة وأقوى 3 مسارات استخدم review_case. لتجهيز CV أو Cover Letter استخدم generate_document (تُحفظ مسودة للمراجعة). لاقتراح مهام استخدم propose_tasks (لا تُنشأ إلا بعد تأكيد الموظف)، ثم لخّص النتيجة في إجابتك مع رقم الملف.`;
const GROQ_RULES=`- لا تملك بحثًا حيًا في هذه الجلسة. أي رقم أو تاريخ متغير (السحوبات، الرسوم، المدد) اكتب بجانبه «غير متحقق — راجع canada.ca».`;
export async function POST(request:Request){try{
 sameOrigin(request);const s=await staff();await rateLimit(request,'assistant:'+s.user.email.toLowerCase(),60,3600);
 const d=await readJson(request,schema,30_000_000);if(d.files.reduce((n,f)=>n+f.data.length,0)>20_000_000)throw new ApiError(413,'مجموع المرفقات أكبر من 15 MB.');const history=d.messages.map(m=>({role:m.role,content:maskIdentifiers(m.content)}));
 const last=[...history].reverse().find(m=>m.role==='user')?.content||'';const faq=rankFaq(last,3);const snapshot=await workSnapshot(s.scope);
 const reference=faq.length?'\n\nمن دليل إجابات المكتب (اعتمده عند الصلة):\n'+faq.map(e=>`[${e.id}] ${e.question}\n${faqAnswer(e).slice(0,1200)}`).join('\n\n'):'';
 const context=`\n\nلقطة العمل الحالية (بلا بيانات شخصية):\n${snapshot.text}${reference}`;
 let answer:{text:string;model:string;sources:{title:string;url:string}[];proposals:{reference:string;title:string;dueDate:string;priority:string}[];webSearch:boolean}|null=null,engine:'openai'|'groq'='openai',notice='';
 try{answer=await runOpenAI(s.scope,BASE+'\n'+OPENAI_RULES+context,history,s.user.email,d.files);}catch(e){if(!(await aiConfig()).configured)throw e;notice=`تعذّر OpenAI: ${(e as Error).message} — أُجيب عبر Groq بلا بحث حي.`;}
 if(!answer){engine='groq';if(!(await aiConfig()).configured)throw new ApiError(503,'لم يُربط محرك للمساعد. احفظ مفتاح OpenAI في «توليد المستندات المهنية» أو مفتاح Groq في «مساعد المحادثة السريعة».');
  const r=await groqChat([{role:'system',content:BASE+'\n'+GROQ_RULES+context},...history],1200,false);answer={text:r.text,model:r.model,sources:[],proposals:[],webSearch:false};if(d.files.length)notice=(notice?notice+' ':'')+'المرفقات لا تُقرأ عبر Groq؛ تحتاج OpenAI.';}
 const mentioned=Array.from(answer.text.matchAll(/(?:ALH-)?CA-\d{4}-[0-9A-F]{6,12}/gi)).map(m=>m[0].toUpperCase());
 const refs={...snapshot.refs,...await resolveReferences(s.scope,[...mentioned,...answer.proposals.map(p=>p.reference)])};
 const proposals=answer.proposals.filter(p=>refs[p.reference]).map(p=>({...p,candidateId:refs[p.reference]}));
 return Response.json({answer:answer.text,engine,model:answer.model,webSearch:answer.webSearch,sources:answer.sources,proposals,refs,notice,faqSources:faq.map(e=>({id:e.id,question:e.question}))},{headers:{'Cache-Control':'private, no-store'}});
}catch(e){return errorResponse(e);}}
