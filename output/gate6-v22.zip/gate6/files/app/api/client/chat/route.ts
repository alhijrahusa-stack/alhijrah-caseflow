import { z } from 'zod';
import { clientCase,clientResponse,readCookie,SESSION_COOKIE } from '@/lib/client-access';
import { sameOrigin,readJson,errorResponse,ApiError } from '@/lib/server';
import { rateLimit,sha } from '@/lib/security';
import { uploadDocument } from '@/lib/upload';
import { messageCreateSchema,clientSend,replay,transition,transitionSchema,writeReceipt,ensureClientUser,clientPrincipalId,setConsent,consentSchema,consents,CONSENT_NOTICE_VERSION,chatMedia,requestRapidAssessment,receipts } from '@/lib/case-chat';
import { connect,transportMode } from '@/lib/chat-transport';
// v2.2 Gate 5 — client case chat (full_case session only). GET: replay (?after=&limit=), ?media=<evidenceId> (CLEAN only),
// ?socket=1 (WebSocket upgrade when the room binding exists). POST: send / receipt / transition / consent /
// rapid_assessment (JSON) or an attachment/voice upload (multipart, ?upload=file|voice) through the normal upload,
// quarantine and INGESTION pipeline.
const Id=z.string().min(8).max(200);
const schema=z.discriminatedUnion('action',[
 z.object({action:z.literal('send'),message:messageCreateSchema,wantsHuman:z.boolean().default(false)}).strict(),
 z.object({action:z.literal('receipt'),deliveredSequence:z.number().int().min(0),readSequence:z.number().int().min(0)}).strict(),
 z.object({action:z.literal('transition'),transition:transitionSchema}).strict(),
 z.object({action:z.literal('consent'),consent:consentSchema}).strict(),
 z.object({action:z.literal('rapid_assessment'),requestKey:Id,confirmed:z.literal(true)}).strict(),
]);
export async function GET(request:Request){try{const {candidate}=await clientCase(request),url=new URL(request.url);
 const media=url.searchParams.get('media');if(media)return await chatMedia(candidate.id,media);
 if(url.searchParams.get('socket')==='1')return await connect(request,{kind:'CLIENT',caseId:candidate.id,sessionHash:await sha(readCookie(request,SESSION_COOKIE))});
 const page=await replay(candidate.id,Math.max(0,Number(url.searchParams.get('after')||0)|0),Number(url.searchParams.get('limit')||50),true);
 return clientResponse({...page,receipts:await receipts(candidate.id,true),consents:await consents(candidate.id),consentNoticeVersion:CONSENT_NOTICE_VERSION,transport:transportMode()});}catch(e){return errorResponse(e);}}
export async function POST(request:Request){try{sameOrigin(request);const {candidate}=await clientCase(request);await rateLimit(request,'case-chat:'+candidate.id,60,900);
 const upload=new URL(request.url).searchParams.get('upload');
 if(upload){if(upload!=='file'&&upload!=='voice')throw new ApiError(400,'نوع الرفع غير صحيح.');const r=await uploadDocument(request,candidate,true,{voice:upload==='voice'});return clientResponse({evidenceId:r.id,duplicate:!!(r as {duplicate?:boolean}).duplicate},201);}
 const d=await readJson(request,schema);const userId=await ensureClientUser(candidate.id);
 if(d.action==='send'){const out=await clientSend(candidate.id,d.message,d.wantsHuman);return clientResponse({sequence:out.message.sequence,messageId:out.message.messageId,replayed:out.replayed},out.replayed?200:201);}
 if(d.action==='receipt')return clientResponse(await writeReceipt(candidate.id,userId,d.deliveredSequence,d.readSequence));
 if(d.action==='transition')return clientResponse(await transition(candidate.id,{kind:'CLIENT',userId:clientPrincipalId(candidate.id),caseId:candidate.id},d.transition));
 if(d.action==='consent')return clientResponse({consents:await setConsent(candidate.id,userId,d.consent)});
 return clientResponse(await requestRapidAssessment(candidate.id,{kind:'CLIENT',userId,caseId:candidate.id},d.requestKey),201);
}catch(e){return errorResponse(e);}}
