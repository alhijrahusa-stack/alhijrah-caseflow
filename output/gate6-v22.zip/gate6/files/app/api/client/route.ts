import { authorizationFor,authorizationSummary } from '@/lib/authorization';
import { getDb } from '@/db';
import { documents,clientMessages,candidates,clientCases,events,caseReviews } from '@/db/schema';
import { eq,desc,and,or,sql } from 'drizzle-orm';
import { clientCase,clientResponse } from '@/lib/client-access';
import { errorResponse,readJson,sameOrigin,ApiError } from '@/lib/server';
import { screenIntake } from '@/lib/screening';
import { detailsSchema,publicSupplementSchema,pathwayConsistent } from '@/lib/intake';
import { pathwayById } from '@/lib/pathways';
import { profileSchema,blankProfile } from '@/lib/model';
import { recomputeCase } from '@/lib/case-engine';
import { recordSkillsNote } from '@/lib/facts';
import { clientJobsError } from '@/lib/office-jobs';
import { dashboardProgress,publicEvent,caseStages,clientBilling } from '@/lib/client-view';
import { verificationPath } from '@/lib/verification';
import { portalOrigin } from '@/lib/branding';
export const dynamic='force-dynamic';
export async function GET(request:Request){try{
 const {candidate:c,client,authentication}=await clientCase(request),db=getDb();
 const [files,messages,history,reviewRows]=await Promise.all([
 db.select({id:documents.id,name:documents.name,category:documents.category,size:documents.size,mime:documents.mime,verified:documents.verified,createdAt:documents.createdAt}).from(documents).where(and(eq(documents.candidateId,c.id),eq(documents.ownerId,c.ownerId))).orderBy(desc(documents.createdAt)),
 db.select({id:clientMessages.id,subject:clientMessages.subject,body:clientMessages.body,state:clientMessages.state,kind:clientMessages.kind,createdAt:clientMessages.createdAt}).from(clientMessages).where(and(eq(clientMessages.candidateId,c.id),or(eq(clientMessages.kind,'receipt'),eq(clientMessages.state,'sent')))).orderBy(desc(clientMessages.createdAt)).limit(50),
 db.select({id:events.id,action:events.action,createdAt:events.createdAt}).from(events).where(and(eq(events.candidateId,c.id),eq(events.ownerId,c.ownerId))).orderBy(desc(events.createdAt)).limit(80),
 db.select({state:caseReviews.state,contentVersion:caseReviews.contentVersion}).from(caseReviews).where(eq(caseReviews.candidateId,c.id)).limit(1),
 ]);
 const profile=JSON.parse(c.profile),details=detailsSchema.parse(JSON.parse(client.details)),requested=JSON.parse(client.requestedDocuments),reviewed=reviewRows[0]?.state==='approved'&&reviewRows[0].contentVersion===c.version;
 const authorization=authorizationSummary(await authorizationFor(c.id));
 return clientResponse({authorization,reference:c.reference,status:c.status,inbox:client.inbox,authentication,progress:dashboardProgress(profile,details,files,requested,client.inbox),stages:caseStages(c.status,client.inbox,reviewed,files.some(f=>f.category==='offer'&&f.verified)),activity:history.flatMap(e=>{const title=publicEvent(e.action);return title?[{id:e.id,title,at:e.createdAt}]:[]}),lmiaRecorded:!!client.lmiaStream&&!!client.lmiaCompleteDate&&files.some(f=>f.id===client.lmiaEvidenceId&&f.verified),version:c.version,profile,details,followUpDate:client.followUpDate,submittedAt:client.submittedAt,updatedAt:c.updatedAt,instructions:client.instructions,screening:screenIntake(profile,details,files,JSON.parse(client.requestedDocuments)),documents:files,messages,verificationUrl:new URL(await verificationPath(c.id),portalOrigin(request.url)).href,billing:await clientBilling(c.id)});
 }catch(e){return errorResponse(e);}}
export async function PATCH(request:Request){try{
 sameOrigin(request);const {candidate:c,client}=await clientCase(request),d=await readJson(request,publicSupplementSchema,70000);{const jobsError=clientJobsError(d.details.jobs);if(jobsError)throw new ApiError(400,jobsError);}if(!pathwayConsistent(d.details))throw new ApiError(400,'المسار المختار لا يتبع الفئة المختارة.');{const pw=pathwayById(d.details.pathway);if(pw)d.details.service=pw.service;}
 if(c.status==='archived')throw new ApiError(400,'الملف مؤرشف. تواصل مع المكتب لتحديثه.');
 if(c.version!==d.version)throw new ApiError(409,'تغيّر الملف. حدّث الصفحة قبل حفظ الإضافات.');
 // Client-portal edits may fill office-assessed fields only while blank; values already recorded are kept.
 // Staff/admin edits go through /api/candidates/[id] and are not affected.
 const current=JSON.parse(c.profile) as Record<string,unknown>,supplement:Record<string,unknown>={...d.profile},blank=blankProfile as Record<string,unknown>;
 for(const k of ['noc','eca','jobOffer','designated','jobConditions','recommendation'])if(current[k]!==undefined&&current[k]!==blank[k])delete supplement[k];
 const db=getDb(),now=new Date().toISOString(),profile=profileSchema.parse({...current,...supplement});
 const candidateScope=and(eq(candidates.id,c.id),eq(candidates.version,d.version));
 const results=await db.batch([
 db.insert(events).select(db.select({id:sql<string>`${crypto.randomUUID()}`.as('id'),ownerId:candidates.ownerId,candidateId:candidates.id,action:sql<string>`'استكمل العميل بيانات الطلب'`.as('action'),note:sql<string>`'بيانات إضافية مقدمة من العميل عبر رابط المتابعة'`.as('note'),createdAt:sql<string>`${now}`.as('created_at')}).from(candidates).where(candidateScope)),
 db.update(clientCases).set({details:JSON.stringify(d.details),inbox:client.inbox==='needs_info'?'pending':client.inbox,version:client.version+1}).where(and(eq(clientCases.candidateId,c.id),eq(clientCases.version,client.version),sql`EXISTS (SELECT 1 FROM candidates c WHERE c.id = ${c.id} AND c.version = ${d.version})`)),
 db.update(candidates).set({profile:JSON.stringify(profile),version:d.version+1,updatedAt:now}).where(and(candidateScope,sql`EXISTS (SELECT 1 FROM client_cases cc WHERE cc.candidate_id = ${c.id} AND cc.version = ${client.version+1})`)).returning({id:candidates.id}),
 ]);
 if(!results[2].length)throw new ApiError(409,'تغيرت البيانات أثناء الحفظ. حدّث الملف.');
 await recordSkillsNote(c.id,d.details.additionalSkills,'client');
 await recomputeCase(c.id,{mode:'write'});
 return clientResponse({ok:true});
 }catch(e){return errorResponse(e);}}
