import { z } from 'zod';
import { getDb } from '@/db';
import { clientSessions,loginCredentials,events } from '@/db/schema';
import { eq,and,sql,gt,isNull } from 'drizzle-orm';
import { sameOrigin,readJson,errorResponse,ApiError } from '@/lib/server';
import { rateLimit,sha,accessCode } from '@/lib/security';
import { clientCase,clientResponse,sessionCookie,SESSION_SECONDS } from '@/lib/client-access';
import { hashPassword } from '@/lib/password';
import { authChallenges } from '@/db/schema';
import { accountSession,accountKeyOf } from '@/lib/client-account';
const schema=z.object({password:z.string().min(15).max(128)}).strict();
const accountSchema=z.object({scope:z.literal('account'),password:z.string().min(15).max(128)}).strict();
// v2.2 Gate 4 — account password: only after a fresh email OTP (account_login session verified within 10 minutes).
// It is a new credential of scope client_account; no case password hash is copied. Setting it ends the previous
// email+password account sessions (the current OTP session stays).
async function setAccountPassword(request:Request){
 const account=await accountSession(request);if(!account)throw new ApiError(401,'يلزم تأكيد البريد الإلكتروني.');
 if(account.purpose!=='account_login'||Date.now()-account.verifiedAt>600000)throw new ApiError(403,'يلزم رمز تحقق جديد بالبريد قبل تعيين كلمة المرور.');
 await rateLimit(request,'client-account-set-password:'+account.email,5,3600);
 const d=await readJson(request,accountSchema),db=getDb(),now=Date.now(),accountKey=await accountKeyOf(account.email),passwordHash=await hashPassword('client_account',accountKey,d.password);
 await db.batch([
  db.insert(loginCredentials).values({id:'client_account:'+accountKey,scope:'client_account',subject:accountKey,passwordHash,version:1,changedAt:now}).onConflictDoUpdate({target:loginCredentials.id,set:{passwordHash,version:sql`${loginCredentials.version}+1`,changedAt:now}}),
  db.update(authChallenges).set({expiresAt:now}).where(and(eq(authChallenges.channel,'account_email'),eq(authChallenges.purpose,'account_password'),eq(authChallenges.contactHash,await sha(account.email)),gt(authChallenges.expiresAt,now))),
 ]);
 return clientResponse({ok:true});
}
export async function POST(request:Request){try{
 sameOrigin(request);if((await request.clone().json().catch(()=>null) as {scope?:unknown}|null)?.scope==='account')return await setAccountPassword(request);const access=await clientCase(request);await rateLimit(request,'client-set-password:'+access.candidate.id,5,3600);const d=await readJson(request,schema),{candidate:c,authentication}=access;if(!authentication.method.startsWith('otp_')||Date.now()-authentication.createdAt>600000||!('session' in access))throw new ApiError(403,'يلزم رمز تحقق جديد قبل تعيين كلمة المرور.');
 const db=getDb(),now=Date.now(),auditId=crypto.randomUUID(),token=accessCode(),tokenHash=await sha(token),passwordHash=await hashPassword('client',c.id,d.password),guard=sql`EXISTS (SELECT 1 FROM events e WHERE e.id=${auditId})`;
 const result=await db.batch([
 db.insert(events).select(db.select({id:sql<string>`${auditId}`.as('id'),ownerId:sql<string>`${c.ownerId}`.as('owner_id'),candidateId:clientSessions.candidateId,action:sql<string>`'حدّث العميل كلمة مرور الدخول'`.as('action'),note:sql<string>`'بتحقق حديث من وسيلة التواصل'`.as('note'),createdAt:sql<string>`${new Date(now).toISOString()}`.as('created_at')}).from(clientSessions).where(and(eq(clientSessions.tokenHash,access.session.tokenHash),isNull(clientSessions.revokedAt),gt(clientSessions.expiresAt,now)))).returning({id:events.id}),
 db.insert(loginCredentials).select(db.select({id:sql<string>`${'client:'+c.id}`.as('id'),scope:sql<string>`'client'`.as('scope'),subject:events.candidateId,passwordHash:sql<string>`${passwordHash}`.as('password_hash'),version:sql<number>`1`.as('version'),changedAt:sql<number>`${now}`.as('changed_at')}).from(events).where(eq(events.id,auditId))).onConflictDoUpdate({target:loginCredentials.id,set:{passwordHash,version:sql`${loginCredentials.version}+1`,changedAt:now}}),
 db.update(clientSessions).set({revokedAt:now}).where(and(eq(clientSessions.candidateId,c.id),guard)),
 db.insert(clientSessions).select(db.select({tokenHash:sql<string>`${tokenHash}`.as('token_hash'),candidateId:events.candidateId,method:sql<string>`'password_reset'`.as('method'),createdAt:sql<number>`${now}`.as('created_at'),expiresAt:sql<number>`${now+SESSION_SECONDS*1000}`.as('expires_at'),revokedAt:sql<number|null>`NULL`.as('revoked_at'),scope:sql<string>`'full_case'`.as('scope')}).from(events).where(eq(events.id,auditId))),
 ]);if(!result[0].length)throw new ApiError(409,'تغيرت الجلسة. اطلب رمز تحقق جديدًا.');return clientResponse({ok:true},200,{'Set-Cookie':sessionCookie(token,request)});
 }catch(e){return errorResponse(e);}}
