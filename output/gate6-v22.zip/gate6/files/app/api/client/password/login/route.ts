import { z } from 'zod';
import { getDb } from '@/db';
import { candidates,clientCases,loginCredentials,clientSessions } from '@/db/schema';
import { eq,and,sql } from 'drizzle-orm';
import { sameOrigin,readJson,errorResponse,ApiError } from '@/lib/server';
import { rateLimit,sha,accessCode } from '@/lib/security';
import { targetThrottle } from '@/lib/otp';
import { checkPassword } from '@/lib/password';
import { sessionCookie,clientResponse,SESSION_SECONDS } from '@/lib/client-access';
import { accountKeyOf,accountCookie,accountCases,accountProfile,createPasswordAccountSession,openAccountCase } from '@/lib/client-account';
// v2.2 Gate 4 — two explicit alternatives. {email,password}: the account credential (scope client_account, subject =
// server-derived account key) opens an ACCOUNT session. {reference,password}: the legacy case credential opens that ONE
// case only; it never grants access to other files that share the email. Unknown subjects still run the dummy hash.
const schema=z.union([
 z.object({email:z.string().trim().email().max(254),password:z.string().min(1).max(128)}).strict(),
 z.object({reference:z.string().trim().min(4).max(100),password:z.string().min(1).max(128)}).strict(),
]);
export async function POST(request:Request){try{sameOrigin(request);await rateLimit(request,'client-password',15,900);const d=await readJson(request,schema),db=getDb();
 if('email' in d){
  const email=d.email.toLowerCase(),accountKey=await accountKeyOf(email);await targetThrottle('client-account-password:'+email,8,900);
  const [credential]=await db.select().from(loginCredentials).where(and(eq(loginCredentials.scope,'client_account'),eq(loginCredentials.subject,accountKey))).limit(1);
  if(!await checkPassword('client_account',accountKey,d.password,credential?.passwordHash||null)||!credential)throw new ApiError(401,'تعذّر الدخول. تحقق من البريد الإلكتروني وكلمة المرور.');
  const [still]=await db.select({version:loginCredentials.version}).from(loginCredentials).where(and(eq(loginCredentials.id,credential.id),eq(loginCredentials.version,credential.version),eq(loginCredentials.passwordHash,credential.passwordHash))).limit(1);
  if(!still)throw new ApiError(401,'تغيرت بيانات الدخول. أعد المحاولة.');
  const session=await createPasswordAccountSession(email),cases=await accountCases(email),profile=await accountProfile(email),headers=new Headers({'Cache-Control':'private, no-store'});headers.append('Set-Cookie',accountCookie(session.value,request));
  let destination:'/apply'|'/client'|'/client/account'='/apply';
  if(cases.length===1){headers.append('Set-Cookie',sessionCookie(await openAccountCase(email,cases[0].reference),request));destination='/client';}else if(cases.length>1)destination='/client/account';
  return Response.json({authenticated:true,displayName:profile?.displayName??null,intent:'RETURN',destination,caseReferences:cases.map(c=>c.reference)},{headers});
 }
 const ref=d.reference.toUpperCase();await targetThrottle('client-password:'+ref,8,900);const [row]=await db.select({id:candidates.id}).from(candidates).innerJoin(clientCases,eq(clientCases.candidateId,candidates.id)).where(eq(candidates.reference,ref)).limit(1),subject=row?.id||'unmatched',[credential]=await db.select().from(loginCredentials).where(eq(loginCredentials.id,'client:'+subject)).limit(1),valid=await checkPassword('client',subject,d.password,credential?.passwordHash||null);if(!valid||!row)throw new ApiError(401,'تعذّر الدخول. تحقق من رقم الملف وكلمة المرور.');const token=accessCode(),now=Date.now(),inserted=await db.insert(clientSessions).select(db.select({tokenHash:sql<string>`${await sha(token)}`.as('token_hash'),candidateId:loginCredentials.subject,method:sql<string>`'password'`.as('method'),createdAt:sql<number>`${now}`.as('created_at'),expiresAt:sql<number>`${now+SESSION_SECONDS*1000}`.as('expires_at'),revokedAt:sql<number|null>`NULL`.as('revoked_at'),scope:sql<string>`'full_case'`.as('scope')}).from(loginCredentials).where(and(eq(loginCredentials.id,credential!.id),eq(loginCredentials.version,credential!.version),eq(loginCredentials.passwordHash,credential!.passwordHash)))).returning({id:clientSessions.tokenHash});if(!inserted.length)throw new ApiError(401,'تغيرت بيانات الدخول. أعد المحاولة.');return clientResponse({ok:true},200,{'Set-Cookie':sessionCookie(token,request)});}catch(e){return errorResponse(e);}}
