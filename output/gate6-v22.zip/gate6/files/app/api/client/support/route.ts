import { z } from 'zod';
import { clientCase,clientResponse } from '@/lib/client-access';
import { sameOrigin,readJson,errorResponse,ApiError } from '@/lib/server';
import { rateLimit } from '@/lib/security';
import { unifiedMessages } from '@/lib/support';
import { clientSend } from '@/lib/case-chat';
// v2.2 Gate 5 adapter: legacy client support endpoint. Writes go to the canonical case chat; reads show the legacy
// history followed by the canonical conversation. The new client UI uses /api/client/chat.
const schema=z.object({body:z.string().trim().min(1).max(2000),human:z.boolean().default(false)}).strict(),resume=z.object({resume:z.literal(true)}).strict();
async function view(candidateId:string){const u=await unifiedMessages(candidateId,true),withStaff=u.conversation.state==='HANDOFF_PENDING'||u.conversation.state==='HUMAN_ACTIVE';return {messages:u.messages,withStaff,queue:0};}
export async function GET(request:Request){try{const {candidate}=await clientCase(request);return clientResponse(await view(candidate.id));}catch(e){return errorResponse(e);}}
export async function PATCH(request:Request){try{sameOrigin(request);await clientCase(request);await readJson(request,resume);throw new ApiError(409,'بعد التحويل إلى موظف يتابع المكتب المحادثة؛ يمكنك متابعة الكتابة هنا.');}catch(e){return errorResponse(e);}}
export async function POST(request:Request){try{sameOrigin(request);const {candidate}=await clientCase(request);await rateLimit(request,'support:'+candidate.id,40,900);const d=await readJson(request,schema);
 await clientSend(candidate.id,{clientMessageId:crypto.randomUUID(),repliedToMessageId:null,kind:'TEXT',text:d.body},d.human);return clientResponse(await view(candidate.id));}catch(e){return errorResponse(e);}}
