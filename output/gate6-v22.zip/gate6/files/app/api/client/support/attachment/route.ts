import { clientCase,clientResponse } from '@/lib/client-access';
import { sameOrigin,errorResponse } from '@/lib/server';
import { rateLimit } from '@/lib/security';
import { uploadDocument } from '@/lib/upload';
import { clientSend } from '@/lib/case-chat';
// v2.2 Gate 5 adapter: legacy client chat attachment → normal upload pipeline (QUARANTINED + INGESTION) and a canonical
// ATTACHMENT / VOICE_NOTE message. Audio is detected from the file signature.
async function isAudio(request:Request){const form=await request.clone().formData(),f=form.get('file');if(!(f instanceof File))return false;const b=new Uint8Array(await f.slice(0,12).arrayBuffer()),t=new TextDecoder().decode(b);return f.type.startsWith('audio/')||(b[0]===0x1a&&b[1]===0x45&&b[2]===0xdf&&b[3]===0xa3)||t.startsWith('OggS');}
export async function POST(request:Request){try{sameOrigin(request);const {candidate}=await clientCase(request);await rateLimit(request,'support-file:'+candidate.id,20,900);
 const voice=await isAudio(request),r=await uploadDocument(request,candidate,true,{voice});
 const m=await clientSend(candidate.id,voice?{clientMessageId:'upload:'+r.id,repliedToMessageId:null,kind:'VOICE_NOTE',evidenceId:r.id}:{clientMessageId:'upload:'+r.id,repliedToMessageId:null,kind:'ATTACHMENT',evidenceIds:[r.id]});
 return clientResponse({id:m.message.messageId,evidenceId:r.id},201);}catch(e){return errorResponse(e);}}
