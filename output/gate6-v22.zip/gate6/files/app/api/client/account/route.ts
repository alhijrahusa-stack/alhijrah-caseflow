import { z } from 'zod';
import { getDb } from '@/db';
import { authChallenges,clientSessions } from '@/db/schema';
import { and,eq,gt,isNull } from 'drizzle-orm';
import { readJson,sameOrigin,errorResponse,ApiError } from '@/lib/server';
import { clientResponse,sessionCookie,readCookie,SESSION_COOKIE } from '@/lib/client-access';
import { accountSession,accountCases,accountCookie,requestAccountCode,verifyAccountCode,openAccountCase,accountProfile,ensureAccountProfile } from '@/lib/client-account';
import type { AccountIntent } from '@/lib/client-account';
import { rateLimit,sha } from '@/lib/security';
// v2.2 Gate 4 — one account flow for the two entries: START_NEW (name + email + OTP) and RETURN (email + OTP; the
// password alternative is /api/client/password/login). The server derives scope and destination; nothing in the body
// is authority. START_NEW never redirects to an old file; RETURN with several files never opens the first one.
const code=z.string().transform(s=>s.replace(/[٠-٩]/g,c=>String(c.charCodeAt(0)-1632)).replace(/[۰-۹]/g,c=>String(c.charCodeAt(0)-1776))).pipe(z.string().regex(/^\d{6}$/));
const schema=z.union([
 z.object({action:z.literal('request'),email:z.string().trim().email().max(254),name:z.string().trim().min(2).max(150).optional(),intent:z.enum(['START_NEW','RETURN']).default('RETURN'),requestKey:z.string().uuid(),locale:z.enum(['ar','en'])}).strict().refine(d=>d.intent!=='START_NEW'||!!d.name,{message:'أدخل الاسم الكامل لبدء طلب جديد.',path:['name']}),
 z.object({action:z.literal('verify'),ticket:z.string().min(20).max(4000),code}).strict(),
 z.object({action:z.literal('open'),reference:z.string().min(4).max(100)}).strict(),
 z.object({action:z.literal('profile'),name:z.string().trim().min(2).max(150)}).strict(),
]);
const noStore={'Cache-Control':'private, no-store'};
// Minimal, no-store session summary for the header indicator: a full account or case session only (never the
// limited status-lookup token), its expiry, and whether the request arrived over HTTPS.
async function sessionSummary(request:Request){
 const secureTransport=new URL(request.url).protocol==='https:',account=await accountSession(request);
 if(account)return {authenticated:true as const,scope:'account' as const,expiresAt:Math.min(account.expiresAt,account.sessionExpiresAt),secureTransport};
 const token=readCookie(request,SESSION_COOKIE);
 if(/^[a-f0-9]{64}$/.test(token)){const [row]=await getDb().select({expiresAt:clientSessions.expiresAt}).from(clientSessions).where(and(eq(clientSessions.tokenHash,await sha(token)),eq(clientSessions.scope,'full_case'),isNull(clientSessions.revokedAt),gt(clientSessions.expiresAt,Date.now()))).limit(1);if(row)return {authenticated:true as const,scope:'case' as const,expiresAt:row.expiresAt,secureTransport};}
 return {authenticated:false as const,scope:'none' as const,expiresAt:null,secureTransport};
}
async function result(email:string,intent:AccountIntent,displayName:string|null,request:Request,headers:Headers){
 const cases=await accountCases(email);
 let destination:'/apply'|'/client'|'/client/account';
 if(intent==='START_NEW'||cases.length===0)destination='/apply';
 else if(cases.length===1){headers.append('Set-Cookie',sessionCookie(await openAccountCase(email,cases[0].reference),request));destination='/client';}
 else destination='/client/account';
 if(destination!=='/client')headers.append('Set-Cookie',sessionCookie('',request).replace(/Max-Age=\d+/,'Max-Age=0'));
 return Response.json({authenticated:true,displayName,intent,destination,caseReferences:cases.map(c=>c.reference)},{headers});
}
export async function GET(request:Request){try{
 if(new URL(request.url).searchParams.get('view')==='session')return Response.json(await sessionSummary(request),{headers:noStore});
 const account=await accountSession(request);if(!account)return clientResponse({authenticated:false});
 const profile=await accountProfile(account.email);
 return clientResponse({authenticated:true,email:account.email,displayName:profile?.displayName??null,cases:await accountCases(account.email)});
}catch(e){return errorResponse(e);}}
export async function POST(request:Request){try{sameOrigin(request);await rateLimit(request,'client-account',30,900);const d=await readJson(request,schema);
 if(d.action==='request'){await rateLimit(request,'client-account-request-day',8,86400);return clientResponse(await requestAccountCode(d.email,d.requestKey,d.locale,d.intent,d.name));}
 if(d.action==='open'){const account=await accountSession(request);if(!account)throw new ApiError(401,'يلزم تأكيد البريد الإلكتروني.');return clientResponse({destination:'/client'},200,{'Set-Cookie':sessionCookie(await openAccountCase(account.email,d.reference),request)});}
 if(d.action==='profile'){const account=await accountSession(request);if(!account)throw new ApiError(401,'يلزم تأكيد البريد الإلكتروني.');const profile=await ensureAccountProfile(account.email,d.name);return clientResponse({displayName:profile.displayName});}
 const account=await verifyAccountCode(d.ticket,d.code),db=getDb();
 const previousAccount=await accountSession(request);if(previousAccount)await db.update(authChallenges).set({expiresAt:Date.now()}).where(eq(authChallenges.id,previousAccount.id));
 const previous=readCookie(request,SESSION_COOKIE);if(previous)await db.update(clientSessions).set({revokedAt:Date.now()}).where(eq(clientSessions.tokenHash,await sha(previous)));
 // START_NEW: the account profile is created (or reused, never duplicated) only now, after proof of the email.
 const profile=account.intent==='START_NEW'&&account.name?await ensureAccountProfile(account.email,account.name):await accountProfile(account.email);
 const headers=new Headers(noStore);headers.append('Set-Cookie',accountCookie(account.value,request));
 return result(account.email,account.intent,profile?.displayName??null,request,headers);
 }catch(e){return errorResponse(e);}}
export async function DELETE(request:Request){try{sameOrigin(request);const token=readCookie(request,SESSION_COOKIE);if(token)await getDb().update(clientSessions).set({revokedAt:Date.now()}).where(eq(clientSessions.tokenHash,await sha(token)));const account=await accountSession(request);if(account)await getDb().update(authChallenges).set({expiresAt:Date.now()}).where(eq(authChallenges.id,account.id));return clientResponse({ok:true},200,{'Set-Cookie':accountCookie('',request,0)});}catch(e){return errorResponse(e);}}
