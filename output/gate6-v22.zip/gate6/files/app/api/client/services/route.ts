import { clientCase,clientResponse } from '@/lib/client-access';
import { sameOrigin,readJson,errorResponse } from '@/lib/server';
import { rateLimit } from '@/lib/security';
import { publicCatalog,requestService,serviceRequestSchema,caseServiceRequests } from '@/lib/services';
// v2.2 Gate 5 — the client's service catalog and explicit service requests (the only source of a service CRM event).
export async function GET(request:Request){try{const {candidate}=await clientCase(request);return clientResponse({...await publicCatalog(),requests:await caseServiceRequests(candidate.id)});}catch(e){return errorResponse(e);}}
export async function POST(request:Request){try{sameOrigin(request);const {candidate}=await clientCase(request);await rateLimit(request,'service-request:'+candidate.id,10,3600);const d=await readJson(request,serviceRequestSchema);const r=await requestService(candidate.id,d);return clientResponse(r,r.replayed?200:201);}catch(e){return errorResponse(e);}}
