import { z } from 'zod';
import { waitUntil } from 'cloudflare:workers';
import { sameOrigin,readJson,errorResponse } from '@/lib/server';
import { rateLimit } from '@/lib/security';
import { requestLookup,dispatchLookupDeliveries,lookupResult } from '@/lib/status-lookup';
// v2.2 Gate 4 — POST: request (identifier only; generic 202 for matched, unmatched and failed delivery).
// GET: the limited status answer for a valid case_status token (cookie scoped to this path, 5 minutes).
const headers={'Cache-Control':'private, no-store'};
const schema=z.object({identifier:z.string().trim().min(4).max(254),requestKey:z.string().uuid(),locale:z.enum(['ar','en'])}).strict();
export async function POST(request:Request){try{
 sameOrigin(request);await rateLimit(request,'status-lookup',10,900);const d=await readJson(request,schema);
 const out=await requestLookup(d.identifier,d.requestKey,d.locale);
 waitUntil(dispatchLookupDeliveries(3).catch(()=>0));
 return Response.json(out,{status:202,headers});
}catch(e){return errorResponse(e);}}
export async function GET(request:Request){try{const locale=new URL(request.url).searchParams.get('locale')==='en'?'en':'ar';return Response.json(await lookupResult(request,locale),{headers});}catch(e){return errorResponse(e);}}
