import { z } from 'zod';
import { sameOrigin,readJson,errorResponse } from '@/lib/server';
import { rateLimit } from '@/lib/security';
import { verifyLookup,selectLookupCase,lookupCookie } from '@/lib/status-lookup';
// v2.2 Gate 4 — {requestId,code}: one-use purpose-scoped proof (no session). {proofTicket,caseNumber}: issue the
// case_status token for one file proven by that contact. Never sets the account cookie or a full_case session.
const headers={'Cache-Control':'private, no-store'};
const code=z.string().trim().transform(v=>v.replace(/[٠-٩]/g,c=>String(c.charCodeAt(0)-1632)).replace(/[۰-۹]/g,c=>String(c.charCodeAt(0)-1776))).pipe(z.string().regex(/^\d{6}$/));
const schema=z.union([z.object({requestId:z.string().uuid(),code}).strict(),z.object({proofTicket:z.string().min(20).max(4000),caseNumber:z.string().trim().min(4).max(100)}).strict()]);
export async function POST(request:Request){try{
 sameOrigin(request);await rateLimit(request,'status-lookup-verify',30,900);const d=await readJson(request,schema);
 if('requestId' in d)return Response.json(await verifyLookup(d.requestId,d.code),{headers});
 const token=await selectLookupCase(d.proofTicket,d.caseNumber);
 return Response.json({ok:true},{headers:{...headers,'Set-Cookie':lookupCookie(token,request)}});
}catch(e){return errorResponse(e);}}
