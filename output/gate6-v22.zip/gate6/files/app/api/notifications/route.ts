import { getDb } from '@/db';
import { candidates,clientCases,documents,caseConversations } from '@/db/schema';
import { owner,owned,errorResponse } from '@/lib/server';
import { and,eq,desc,sql } from 'drizzle-orm';
import { documentLabels } from '@/lib/model';
// Staff notification feed: new client requests and documents attached to client cases, newest first.
export const dynamic='force-dynamic';
export async function GET(){try{
 const ownerId=await owner(),db=getDb(),name=sql<string>`json_extract(${candidates.profile},'$.fullName')`;
const [requests,files,chats]=await Promise.all([
  db.select({id:clientCases.candidateId,at:clientCases.submittedAt,name,reference:candidates.reference}).from(clientCases).innerJoin(candidates,eq(candidates.id,clientCases.candidateId)).where(owned(candidates.ownerId,ownerId)).orderBy(desc(clientCases.submittedAt)).limit(15),
  db.select({id:documents.id,candidateId:documents.candidateId,at:documents.createdAt,category:documents.category,name,reference:candidates.reference}).from(documents).innerJoin(candidates,eq(candidates.id,documents.candidateId)).where(and(owned(documents.ownerId,ownerId),eq(candidates.source,'client'))).orderBy(desc(documents.createdAt)).limit(15),
  // v2.2 Gate 5: canonical case conversations waiting for a staff member.
  db.select({candidateId:caseConversations.caseId,at:caseConversations.updatedAt,reason:sql<string>`''`,name,reference:candidates.reference}).from(caseConversations).innerJoin(candidates,eq(candidates.id,caseConversations.caseId)).where(and(owned(candidates.ownerId,ownerId),eq(caseConversations.state,'HANDOFF_PENDING'))).orderBy(desc(caseConversations.updatedAt)).limit(15),
 ]);
 const items=[...chats.map(c=>({id:'chat:'+c.candidateId+':'+c.at,kind:'chat' as const,candidateId:c.candidateId,at:c.at,title:'محادثة عميل بانتظار موظف',detail:`${c.name} · ${c.reason||c.reference}`})),...requests.map(r=>({id:'req:'+r.id,kind:'request' as const,candidateId:r.id,at:r.at,title:'طلب تقييم جديد',detail:`${r.name} · ${r.reference}`})),...files.map(f=>({id:'doc:'+f.id,kind:'document' as const,candidateId:f.candidateId,at:f.at,title:'مستند جديد من العميل',detail:`${documentLabels[f.category]||'مستند'} · ${f.name}`}))].sort((a,b)=>b.at.localeCompare(a.at)).slice(0,20);
 return Response.json({items},{headers:{'Cache-Control':'private, no-store'}});
}catch(e){return errorResponse(e);}}
