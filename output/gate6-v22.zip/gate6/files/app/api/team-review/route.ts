import { getDb } from '@/db';
import { candidates,caseReviews,documents } from '@/db/schema';
import { owner,owned,errorResponse,ownerWith } from '@/lib/server';
import { and,eq,ne,desc,count,sql,inArray } from 'drizzle-orm';
export const dynamic='force-dynamic';
export async function GET(request:Request){try{
 const o=await ownerWith('review_case'),db=getDb(),q=new URL(request.url).searchParams,filter=q.get('state')||'in_review',page=Math.max(1,Math.min(100000,Math.floor(Number(q.get('page')))||1));
 const state=sql<string>`CASE WHEN ${caseReviews.state} IN ('approved','in_review') AND ${caseReviews.contentVersion} <> ${candidates.version} THEN 'stale' ELSE coalesce(${caseReviews.state},'draft') END`;
 const scope=and(owned(candidates.ownerId,o),ne(candidates.status,'archived')),where=and(scope,filter==='all'?undefined:eq(state,['in_review','draft','changes_requested','approved','stale'].includes(filter)?filter:'in_review'));
 const [rows,totals,stats]=await Promise.all([
 db.select({candidate:candidates,review:caseReviews,state}).from(candidates).leftJoin(caseReviews,eq(candidates.id,caseReviews.candidateId)).where(where).orderBy(desc(candidates.updatedAt)).limit(30).offset((page-1)*30),
 db.select({total:count()}).from(candidates).leftJoin(caseReviews,eq(candidates.id,caseReviews.candidateId)).where(where),
 db.select({state,total:count()}).from(candidates).leftJoin(caseReviews,eq(candidates.id,caseReviews.candidateId)).where(scope).groupBy(state),
 ]);
 const ids=rows.map(r=>r.candidate.id),files=ids.length?await db.select({candidateId:documents.candidateId,total:count(),reviewed:sql<number>`sum(CASE WHEN ${documents.verified} = 1 THEN 1 ELSE 0 END)`}).from(documents).where(inArray(documents.candidateId,ids)).groupBy(documents.candidateId):[];
 return Response.json({items:rows.map(({candidate:c,review,state})=>{const p=JSON.parse(c.profile),f=files.find(d=>d.candidateId===c.id);return {id:c.id,reference:c.reference,name:p.fullName,occupation:p.occupation,assignedTo:c.assignedTo,priority:c.priority,state,preparedBy:review?.preparedBy||'',reviewedBy:review?.reviewedBy||'',note:review?.note||'',documents:f?.total||0,reviewedDocuments:f?.reviewed||0,updatedAt:c.updatedAt};}),total:totals[0].total,page,stats:Object.fromEntries(stats.map(s=>[s.state,s.total]))},{headers:{'Cache-Control':'private, no-store'}});
 }catch(e){return errorResponse(e);}}
