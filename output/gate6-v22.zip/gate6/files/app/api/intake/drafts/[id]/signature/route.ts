import { z } from 'zod';
import { sameOrigin,readJson,errorResponse,ApiError } from '@/lib/server';
import { rateLimit } from '@/lib/security';
import { requireAccount,saveSignature,clearSignature,signatureImage,signatureManifestSchema,signatureClearSchema,DraftConflict,conflictResponse } from '@/lib/application-drafts';
import { SIGNATURE_MAX_BYTES } from '@/lib/signature';
// v2.2 Gate 4 — fixed signature: PUT multipart {manifest, image PNG}, GET the private image to its owner, DELETE =
// explicit clear. No STALE state, no automatic invalidation or re-sign request when the draft changes later.
type Context={params:Promise<{id:string}>};
const headers={'Cache-Control':'private, no-store'},id=z.string().uuid();
const fail=(e:unknown)=>e instanceof DraftConflict?conflictResponse(e):e instanceof z.ZodError?Response.json({error:'طلب غير صالح.'},{status:400}):errorResponse(e);
export async function GET(request:Request,ctx:Context){try{const a=await requireAccount(request);return await signatureImage(a.accountKey,id.parse((await ctx.params).id));}catch(e){return fail(e);}}
export async function PUT(request:Request,ctx:Context){try{
 sameOrigin(request);await rateLimit(request,'intake-signature',30,900);const a=await requireAccount(request),draftId=id.parse((await ctx.params).id);
 if(!request.headers.get('content-type')?.toLowerCase().startsWith('multipart/form-data'))throw new ApiError(415,'صيغة الطلب يجب أن تكون multipart/form-data.');
 if(Number(request.headers.get('content-length'))>SIGNATURE_MAX_BYTES+8192)throw new ApiError(413,'صورة التوقيع أكبر من الحد المسموح.');
 const form=await request.formData(),manifestRaw=form.get('manifest'),image=form.get('image');
 if(typeof manifestRaw!=='string'||!(image instanceof File))throw new ApiError(400,'أرسل بيان التوقيع والصورة.');
 if(image.type!=='image/png'||image.size>SIGNATURE_MAX_BYTES)throw new ApiError(422,'صورة التوقيع يجب أن تكون PNG لا تتجاوز 256KB.');
 let manifest:unknown;try{manifest=JSON.parse(manifestRaw);}catch{throw new ApiError(400,'بيان التوقيع غير صالح.');}
 const m=signatureManifestSchema.safeParse(manifest);if(!m.success)throw new ApiError(400,'بيان التوقيع غير صالح.');
 return Response.json(await saveSignature(a,draftId,m.data,new Uint8Array(await image.arrayBuffer())),{headers});
}catch(e){return fail(e);}}
export async function DELETE(request:Request,ctx:Context){try{sameOrigin(request);const a=await requireAccount(request),draftId=id.parse((await ctx.params).id),d=await readJson(request,signatureClearSchema);return Response.json(await clearSignature(a,draftId,d),{headers});}catch(e){return fail(e);}}
