import { z } from 'zod';
import { sameOrigin,readJson,errorResponse } from '@/lib/server';
import { rateLimit } from '@/lib/security';
import { requireAccount,readDraft,saveDraft,draftWriteSchema,DraftConflict,conflictResponse } from '@/lib/application-drafts';
// v2.2 Gate 4 — read / save one owned draft revision (CAS on expectedRevision, idempotent mutationId).
type Context={params:Promise<{id:string}>};
const headers={'Cache-Control':'private, no-store'},id=z.string().uuid();
export async function GET(request:Request,ctx:Context){try{const a=await requireAccount(request),draftId=id.parse((await ctx.params).id);return Response.json(await readDraft(a.accountKey,draftId),{headers});}catch(e){return e instanceof z.ZodError?Response.json({error:'معرّف غير صالح.'},{status:400}):errorResponse(e);}}
export async function PUT(request:Request,ctx:Context){try{sameOrigin(request);await rateLimit(request,'intake-draft-save',240,900);const a=await requireAccount(request),draftId=id.parse((await ctx.params).id),d=await readJson(request,draftWriteSchema,110000);return Response.json(await saveDraft(a,draftId,d),{headers});}catch(e){if(e instanceof DraftConflict)return conflictResponse(e);return e instanceof z.ZodError?Response.json({error:'معرّف غير صالح.'},{status:400}):errorResponse(e);}}
