import { z } from 'zod';
import { sameOrigin,readJson,errorResponse } from '@/lib/server';
import { rateLimit } from '@/lib/security';
import { requireAccount,listDrafts,createDraft } from '@/lib/application-drafts';
// v2.2 Gate 4 — account drafts (list / idempotent create). Owner = the verified email session; never a body field.
const headers={'Cache-Control':'private, no-store'};
export async function GET(request:Request){try{const a=await requireAccount(request);return Response.json(await listDrafts(a.accountKey),{headers});}catch(e){return errorResponse(e);}}
export async function POST(request:Request){try{sameOrigin(request);await rateLimit(request,'intake-draft-create',30,900);const a=await requireAccount(request),d=await readJson(request,z.object({requestKey:z.string().uuid()}).strict());const out=await createDraft(a,d.requestKey);return Response.json(out.draft,{status:out.created?201:200,headers});}catch(e){return errorResponse(e);}}
