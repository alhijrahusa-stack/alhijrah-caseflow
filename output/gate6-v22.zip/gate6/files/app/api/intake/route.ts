import { verifyCaptcha } from '@/lib/captcha';
import { recordSkillsNote } from '@/lib/facts';
import { recomputeCase } from '@/lib/case-engine';
import { getDb } from '@/db';
import { candidates,clientCases,clientMessages,applicationAuthorizations,officeSettings,assessmentHistory } from '@/db/schema';
import { eq } from 'drizzle-orm';
import { AUTHORIZATION_TEXT,LEGAL_TERMS,LEGAL_VERSION } from '@/lib/legal';
import { ensureAuthorizationPdf,authorizationFor } from '@/lib/authorization';
import { intakeSchema,CONSENT_VERSION,pathwayConsistent } from '@/lib/intake';
import { pathwayById } from '@/lib/pathways';
import { clientJobsError } from '@/lib/office-jobs';
import { newApplicant,findDuplicate,isDuplicateConstraint } from '@/lib/applicants';
import { sameOrigin,readJson,ApiError,errorResponse,PUBLIC_OWNER } from '@/lib/server';
import { accessCode,sha,encrypt,decrypt,rateLimit } from '@/lib/security';
import { sendMessage } from '@/lib/mail';
import { notifyOfficeOfRequest } from '@/lib/office-notify';
import { autoReview } from '@/lib/case-review';
import { computeLead } from '@/lib/lead-score';
import { waitUntil } from 'cloudflare:workers';
import { verificationPath } from '@/lib/verification';
import { portalOrigin } from '@/lib/branding';
import { accountSession } from '@/lib/client-account';
import { deliveryOptions } from '@/lib/otp-delivery';
import { storedIdentity,flagIdentityConflict } from '@/lib/identity-conflict';
import { clientResponse,sessionCookie,createClientSession } from '@/lib/client-access';
import { accountKeyOf } from '@/lib/client-account';
import { submissionBinding,submissionStatements,DraftConflict,conflictResponse } from '@/lib/application-drafts';
function duplicateResponse(){return clientResponse({code:'APPLICATION_EXISTS',error:'يوجد ملف سابق مرتبط ببياناتك. تحقّق من وسيلة التواصل المسجّلة لعرض رقم الملف ومتابعته.'},409);}
export async function POST(request:Request){try{
 sameOrigin(request);await rateLimit(request,'intake',12);const data=await readJson(request,intakeSchema,70000);if(data.profile.jobs.length)throw new ApiError(400,'وظائف طلب العميل تُرسل ضمن تفاصيل الطلب فقط.');{const jobsError=clientJobsError(data.details.jobs);if(jobsError)throw new ApiError(400,jobsError);}if(!pathwayConsistent(data.details))throw new ApiError(400,'المسار المختار لا يتبع الفئة المختارة.');{const pw=pathwayById(data.details.pathway);if(pw)data.details.service=pw.service;}if(data.details.passportExpiry&&Date.parse(data.details.passportExpiry+'T00:00:00Z')-Date.now()<183*86400000)throw new ApiError(422,'صلاحية جواز السفر أقل من 6 أشهر أو منتهية. جدّد الجواز أولًا ثم أرسل الطلب.');const db=getDb(),hash=await sha(JSON.stringify({profile:data.profile,details:data.details,consent:data.consentVersion,...(['intake-2026-11-v3',LEGAL_VERSION].includes(data.consentVersion)?{legalAuthorization:data.legalAuthorization}:{})}));
 const account=await accountSession(request);if(account&&account.email!==data.profile.email.trim().toLowerCase())throw new ApiError(403,'استخدم البريد الإلكتروني الذي أكدت ملكيته.');
 const [existing]=await db.select().from(clientCases).where(eq(clientCases.requestId,data.requestId)).limit(1);
 if(existing){if(existing.payloadHash!==hash)throw new ApiError(409,'تغيرت البيانات بعد الإرسال؛ افتح ملفك لتحديثه مع المكتب.');
 if(Date.now()-Date.parse(existing.submittedAt)>3600000)throw new ApiError(409,'هذا الطلب مسجل. استخدم رابط المتابعة المحفوظ لديك.');
 const [c]=await db.select().from(candidates).where(eq(candidates.id,existing.candidateId)).limit(1);const code=await decrypt(existing.accessEncrypted),options=await deliveryOptions(),loginMode=options.email||options.whatsapp||existing.otpOnly?'otp':'link';const token=await createClientSession(c.id,'intake');const [mail]=await db.select({state:clientMessages.state}).from(clientMessages).where(eq(clientMessages.requestKey,'receipt:'+c.id)).limit(1);
 const authorization=await authorizationFor(c.id);
 return clientResponse({reference:c.reference,submittedAt:c.createdAt,accessCode:code,profile:JSON.parse(c.profile),emailState:mail?.state||'pending',loginMode,...(authorization?{authorizationUrl:'/api/client/authorization/pdf',authorizationPdfReady:!!authorization.pdfObjectKey}:{}),verificationUrl:new URL(await verificationPath(c.id),portalOrigin(request.url)).href },200,{'Set-Cookie':sessionCookie(token,request)});}
 if(data.consentVersion!==LEGAL_VERSION||data.legalAuthorization!==true)throw new ApiError(400,'يلزم الموافقة على تفويض التعامل مع البيانات.');
 if(!account)throw new ApiError(428,'أكّد البريد الإلكتروني برمز التحقق قبل إرسال الطلب.');
 // v2.2 Gate 4: a new submission needs the account draft and its saved signature (server-verified; no browser flag).
 if(!data.draftId||!data.expectedDraftRevision||!data.signatureId||!data.signedPayloadHash)throw new ApiError(422,'وقّع الطلب في خطوة المراجعة قبل الإرسال.');
 const accountKey=await accountKeyOf(account.email),binding=await submissionBinding(accountKey,{draftId:data.draftId,expectedDraftRevision:data.expectedDraftRevision,signatureId:data.signatureId,signedPayloadHash:data.signedPayloadHash});

 await verifyCaptcha(request,data.captchaToken||'');
 const duplicate=await findDuplicate(PUBLIC_OWNER,data.profile);
 if(duplicate){const stored=await storedIdentity(duplicate.id);if(stored&&stored.contact.email!==account.email)await flagIdentityConflict(duplicate.id,stored.ownerId,account.email,'طلب جديد بالاسم والهاتف نفسيهما ببريد مختلف مُتحقق منه');return duplicateResponse();}
 const applicant=await newApplicant(PUBLIC_OWNER,data.profile,'client',data.details),code=accessCode(),now=applicant.row.createdAt,options=await deliveryOptions(),loginMode=options.email||options.whatsapp?'otp':'link';
 applicant.row.reference='ALH-CA-'+now.slice(0,4)+'-'+applicant.row.id.replace(/-/g,'').slice(0,12).toUpperCase();
 // newApplicant query values capture row by value; recreate the candidate insert with the final server reference.
 const [_,event,task]=applicant.queries;
 const body=data.details.preferredLanguage==='en'
 ? `Hello ${data.profile.fullName},\nALHIJRAH has received your application.\nCase number: ${applicant.row.reference}\nEmail: ${data.profile.email}\nPhone: ${data.profile.phone}\nReceived: ${now}\nDocuments are subject to staff review.`
 : `مرحبًا ${data.profile.fullName}\nتم استلام طلبك لدى ALHIJRAH.\nرقم الملف: ${applicant.row.reference}\nالبريد: ${data.profile.email}\nالهاتف: ${data.profile.phone}\nتاريخ الاستلام: ${now}\nالمرفقات تخضع لمراجعة الموظف.`;
 const messageId=crypto.randomUUID();
 const snapshot=JSON.stringify({reference:applicant.row.reference,acceptedAt:now,version:LEGAL_VERSION,authorizationText:AUTHORIZATION_TEXT,termsText:LEGAL_TERMS,profile:data.profile,details:data.details,signature:{signatureId:binding.signature.signatureId,imageHash:binding.signature.signatureSha256,signedAt:binding.signature.signatureSignedAt,signedPayloadHash:binding.signature.signedPayloadHash,legalVersion:binding.row.signatureLegalVersion}});const snapshotHash=await sha(snapshot);
 await db.batch([db.insert(candidates).values(applicant.row),db.insert(assessmentHistory).values(applicant.history),event,task,db.insert(clientCases).values({candidateId:applicant.row.id,otpOnly:loginMode==='otp',requestId:data.requestId,payloadHash:hash,accessHash:await sha(code),accessEncrypted:await encrypt(code),details:JSON.stringify(data.details),consentVersion:data.consentVersion,submittedAt:now}),db.insert(applicationAuthorizations).values({candidateId:applicant.row.id,version:LEGAL_VERSION,acceptedAt:now,authorizationText:AUTHORIZATION_TEXT,termsText:JSON.stringify(LEGAL_TERMS),snapshot,snapshotHash,...binding.signature}),...submissionStatements(accountKey,data.draftId,data.expectedDraftRevision,data.requestId,applicant.row.id,binding.signature.signedPayloadHash,now),db.insert(clientMessages).values({id:messageId,candidateId:applicant.row.id,kind:'receipt',recipient:data.profile.email,subject:data.details.preferredLanguage==='en'?`Application received | ${applicant.row.reference}`:`إشعار استلام الطلب | ${applicant.row.reference}`,body,state:'pending',actor:'system',requestKey:'receipt:'+applicant.row.id,createdAt:now})]);
 if(data.details.additionalSkills){await recordSkillsNote(applicant.row.id,data.details.additionalSkills,'client');await recomputeCase(applicant.row.id,{mode:'write'});}
 const pdfReady=await ensureAuthorizationPdf(applicant.row.id).then(()=>true).catch(()=>false);
 const token=await createClientSession(applicant.row.id,account?'otp_email':'intake');
 const mail=await sendMessage(messageId,new URL(request.url).origin,'system').catch(()=>({state:'pending'}));
 waitUntil(notifyOfficeOfRequest(applicant.row.reference,applicant.row.id,new URL(request.url).origin).catch(()=>'failed'));
 waitUntil(autoReview(applicant.row.id));
 const lead=await computeLead(applicant.row.id,true).catch(()=>null);const [office]=lead?.track==='direct'?await db.select({calendarUrl:officeSettings.calendarUrl}).from(officeSettings).where(eq(officeSettings.id,'office')).limit(1):[];
 return clientResponse({reference:applicant.row.reference,submittedAt:now,accessCode:code,profile:data.profile,emailState:mail.state,loginMode,authorizationUrl:'/api/client/authorization/pdf',authorizationPdfReady:pdfReady,verificationUrl:new URL(await verificationPath(applicant.row.id),portalOrigin(request.url)).href,track:lead?.track||'qualifying',bookingUrl:lead?.track==='direct'&&office?.calendarUrl?.startsWith('https://')?office.calendarUrl:''},201,{'Set-Cookie':sessionCookie(token,request)});
 }catch(e){if(e instanceof DraftConflict)return conflictResponse(e);if(e instanceof Error&&/IMMUTABLE_SIGNATURE_BINDING|authorization_signature_id|INVALID_DRAFT_UPDATE|DRAFT_REVISION_CONFLICT|DRAFT_MUTATION_REQUIRED/.test(e.message+String((e as {cause?:unknown}).cause??'')))return conflictResponse(new DraftConflict('DRAFT_REVISION_CONFLICT',null));return isDuplicateConstraint(e)?duplicateResponse():errorResponse(e);}}
