// v2.2 Gate 5 — CaseChatRoom Durable Object: WebSocket coordination for one case only. It stores nothing canonical
// (messages, receipts and states are committed to D1 by lib/case-chat before any frame is sent here). Hibernation API:
// sockets survive room eviction; on reconnect the client replays from its last sequence over HTTP. The room re-checks
// each socket's principal against D1 on every inbound frame and every fan-out (logical revocation is immediate), and a
// Durable Object alarm re-checks idle sockets every 15 s, so a revoked socket is physically closed (code 4401) within
// 30 s even when it sends nothing (AC-32).
import { DurableObject } from "cloudflare:workers";
import { stillAuthorized, type SocketPrincipal } from "../lib/chat-transport";

type Attachment = { principal: SocketPrincipal; checkedAt: number };
const ALARM_MS = 15_000;
export class CaseChatRoom extends DurableObject {
  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    if (url.pathname === "/broadcast" && request.method === "POST") {
      const frame = await request.text();
      for (const ws of this.ctx.getWebSockets()) await this.relay(ws, frame);
      return new Response(null, { status: 204 });
    }
    if (url.pathname === "/connect") {
      const raw = request.headers.get("X-Chat-Principal");
      if (!raw || request.headers.get("upgrade")?.toLowerCase() !== "websocket") return new Response("bad request", { status: 400 });
      const principal = JSON.parse(raw) as SocketPrincipal;
      const pair = new WebSocketPair(), [client, server] = Object.values(pair);
      this.ctx.acceptWebSocket(server, [principal.kind]);
      server.serializeAttachment({ principal, checkedAt: Date.now() } satisfies Attachment);
      if ((await this.ctx.storage.getAlarm()) === null) await this.ctx.storage.setAlarm(Date.now() + ALARM_MS);
      return new Response(null, { status: 101, webSocket: client });
    }
    return new Response("not found", { status: 404 });
  }
  // Idle sweep: every open socket is re-validated; the alarm re-arms while sockets remain.
  async alarm() {
    const sockets = this.ctx.getWebSockets();
    for (const ws of sockets) await this.authorized(ws);
    if (this.ctx.getWebSockets().length) await this.ctx.storage.setAlarm(Date.now() + ALARM_MS);
  }
  private async authorized(ws: WebSocket) {
    const a = ws.deserializeAttachment() as Attachment | null;
    if (!a) { ws.close(4401, "unauthorized"); return false; }
    const ok = await stillAuthorized(a.principal).catch(() => false);
    if (!ok) { try { ws.close(4401, "revoked"); } catch { /* already closed */ } return false; }
    ws.serializeAttachment({ ...a, checkedAt: Date.now() } satisfies Attachment);
    return true;
  }
  private async relay(ws: WebSocket, frame: string) {
    if (await this.authorized(ws)) { try { ws.send(this.forPrincipal(ws, frame)); } catch { /* client gone; it will replay */ } }
  }
  // Client sockets never receive staff identities: the holder/sender/receipt owner is shown as "office".
  private forPrincipal(ws: WebSocket, frame: string) {
    const a = ws.deserializeAttachment() as Attachment | null;
    if (a?.principal.kind !== "CLIENT") return frame;
    try {
      const f = JSON.parse(frame);
      if (f.type === "CONVERSATION_STATE" && f.conversation?.assignedStaffId) f.conversation.assignedStaffId = "office";
      if (f.type === "RECEIPT_UPDATED" && f.receipt?.principalDisplayRef !== "client") f.receipt.principalDisplayRef = "office";
      if (f.type === "MESSAGE_COMMITTED" && f.message?.actorType === "STAFF") f.message.senderDisplayRef = "office";
      return JSON.stringify(f);
    } catch { return frame; }
  }
  // Contract frames (2.0.0): SEND_MESSAGE and RECEIPT go through the same canonical lib/case-chat writers as HTTP (D1
  // commit first, then fan-out); HEARTBEAT forces a D1 re-validation; TYPING is ephemeral and ignored.
  async webSocketMessage(ws: WebSocket, message: string | ArrayBuffer) {
    let frame: { protocolVersion?: string; type?: string; commandId?: string; message?: unknown; receipt?: { deliveredSequence?: number; readSequence?: number } } | null = null;
    try { frame = JSON.parse(typeof message === "string" ? message : new TextDecoder().decode(message)); } catch { frame = null; }
    const commandId = typeof frame?.commandId === "string" ? frame.commandId : null;
    const error = (code: string) => ws.send(JSON.stringify({ protocolVersion: "2.0.0", type: "ERROR", commandId, error: { code, messageKey: "chat." + code.toLowerCase(), correlationId: commandId ?? crypto.randomUUID(), details: [] } }));
    if (!frame || frame.protocolVersion !== "2.0.0" || !commandId) return error("PROTOCOL_VERSION");
    if (frame.type === "TYPING") return;
    if (!(await this.authorized(ws))) return;
    if (frame.type === "HEARTBEAT") return;
    const { principal } = ws.deserializeAttachment() as Attachment;
    const chat = await import("../lib/case-chat");
    try {
      if (frame.type === "SEND_MESSAGE") {
        const m = chat.messageCreateSchema.safeParse(frame.message); if (!m.success) return error("VALIDATION_FAILED");
        const out = principal.kind === "CLIENT" ? await chat.clientSend(principal.caseId, m.data) : await chat.staffSend(principal.caseId, principal.userId, m.data);
        const page = await chat.replay(principal.caseId, out.message.sequence - 1, 1, principal.kind === "CLIENT");
        ws.send(JSON.stringify({ protocolVersion: "2.0.0", type: "MESSAGE_COMMITTED", commandId, message: page.items[0] }));
        return;
      }
      if (frame.type === "RECEIPT") {
        const userId = principal.kind === "CLIENT" ? await chat.ensureClientUser(principal.caseId) : principal.userId;
        await chat.writeReceipt(principal.caseId, userId, Number(frame.receipt?.deliveredSequence ?? 0), Number(frame.receipt?.readSequence ?? 0));
        return;
      }
      return error("UNSUPPORTED_FRAME");
    } catch (e) { const status = (e as { status?: number }).status; return error(status === 409 ? "CONFLICT" : status === 422 ? "VALIDATION_FAILED" : status === 403 ? "FORBIDDEN" : "INTERNAL"); }
  }
  async webSocketClose(ws: WebSocket, code: number) { try { ws.close(code, "closing"); } catch { /* closed */ } }
}
