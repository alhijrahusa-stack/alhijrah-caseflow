import handler from "vinext/server/fetch-handler";
import { runWithConnectorBinding } from "../lib/connector-context";
import type { ConnectorBinding } from "../lib/connector-contract.mjs";
import { runMaintenance } from "../lib/maintenance";
import { sendDailyBriefing } from "../lib/daily-briefing";
import { shadowOnce } from "../lib/case-engine";
import { SHADOW_CRON } from "../lib/engine-mode";
import { autoKillExpired } from "../lib/rbac";
import { dispatchLookupDeliveries } from "../lib/status-lookup";
import { dispatchOutbox } from "../lib/outbox";
import { runJobs, defaultHandlers } from "../lib/jobs";
import { refreshOverdue } from "../lib/billing";
import { scanExpiry } from "../lib/expiry";
import { getDb } from "../db";
import { operationLogs } from "../db/schema";

const SLOW_REQUEST_MS = 1500;
// Route shape only: identifiers, tokens and case references are removed so no personal data reaches the log.
const routeShape = (path: string) => path
  .replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(\.[a-f0-9]{64})?/gi, ":id")
  .replace(/\b[a-f0-9]{32,}\b/gi, ":token")
  .replace(/ALH-CA-[A-Z0-9-]+|CA-\d{4}-[A-Z0-9]+/gi, ":ref");

const worker = {
  async fetch(request: Request, env: Cloudflare.Env, ctx: ExecutionContext<{ CONNECTORS?: ConnectorBinding }>) {
    const started = Date.now();
    // Client domain (canada.*): its home page opens the client portal; staff use desk.* or /staff/login.
    { const u = new URL(request.url); if (u.hostname.startsWith('canada.') && u.pathname === '/') return Response.redirect(u.origin + '/client/account', 302); if (u.hostname === 'canada.careergate.us' && /^\/staff(\/|$)/.test(u.pathname)) return Response.redirect('https://desk.careergate.us' + u.pathname + u.search, 302); if (/(^|\.)alhijrah-usa\.com$/.test(u.hostname) && u.pathname.startsWith('/canada-assessment')) return Response.redirect('https://canada.careergate.us/apply', 302); }
    let binding = ctx.props?.CONNECTORS;
    // Local preview emulates the same request-scoped capability. This branch and
    // the auxiliary service binding are absent from production builds.
    if (import.meta.env.DEV && !binding && env.CONNECTORS) {
      const preview = env.CONNECTORS;
      const expiresAt = Date.now() + 60_000;
      binding = {
        async getContext() {
          if (Date.now() >= expiresAt) return { status: "request_context_expired" };
          return preview.getContext?.() ?? { status: "binding_unavailable" };
        },
        async invoke(connectorId, actionName, args) {
          if (Date.now() >= expiresAt) {
            return { status: "request_context_expired", message: "This request has expired. Please try again." };
          }
          return preview.invoke(connectorId, actionName, args);
        },
      };
    }
    const response = await runWithConnectorBinding(binding, () => handler.fetch(request, env, ctx));
    // v2.2 Gate 5: an accepted chat WebSocket upgrade (101 from CaseChatRoom) is passed through untouched.
    if (response.status === 101) return response;
    const headers = new Headers(response.headers);
    headers.set("X-Content-Type-Options", "nosniff");
    headers.set("Referrer-Policy", "same-origin");
    // Clickjacking protection for every page. Routes that already set their own policy
    // (private document previews: frame-ancestors 'self') keep it unchanged.
    if (!headers.has("X-Frame-Options")) headers.set("X-Frame-Options", "SAMEORIGIN");
    if (!headers.has("Content-Security-Policy")) {
      headers.set("Content-Security-Policy", "frame-ancestors 'self'; base-uri 'self'; object-src 'none'; form-action 'self'");
    }
    if (new URL(request.url).protocol === "https:") {
      headers.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
    }
    if(request.headers.has("oai-authenticated-user-id") || /^\/(api|candidates|intake)(\/|$)/.test(new URL(request.url).pathname)) {
      headers.set("Cache-Control", "private, no-store");
    }
    // Staff workspace and private routes are never indexed by search engines.
    { const u = new URL(request.url); if (u.hostname.startsWith('desk.') || /^\/(staff|api|candidates|intake|client)(\/|$)/.test(u.pathname)) headers.set('X-Robots-Tag', 'noindex, nofollow'); }
    const duration = Date.now() - started, url = new URL(request.url);
    headers.set("Server-Timing", `app;dur=${duration}`);
    if (duration >= SLOW_REQUEST_MS && url.pathname.startsWith("/api/")) {
      ctx.waitUntil(getDb().insert(operationLogs).values({
        id: crypto.randomUUID(), operation: "slow_request", actor: "system", result: String(response.status),
        code: `${request.method} ${routeShape(url.pathname)} ${duration}ms`, createdAt: new Date().toISOString(),
      }).then(() => {}).catch(() => {}));
    }
    return new Response(response.body, {status:response.status,statusText:response.statusText,headers});
  },
  // Daily silent maintenance (cron trigger configured in vite.config.ts and the deploy config).
  async scheduled(_controller: ScheduledController, _env: Cloudflare.Env, ctx: ExecutionContext) {
    // v2.2 Gate 2: SYSTEM closes an expired STAFF open switch (AUTO_KILL, deduplicated). Expiry itself does not depend on
    // this job: every protected access already treats the switch as inactive after Toronto midnight.
    ctx.waitUntil(autoKillExpired().then(() => {}).catch(error => {
      console.error("open_access_auto_kill_failed", error instanceof Error ? error.name : "unknown");
    }));
    // Production shadow (engine contract step 1): once per engine/rules version while SHADOW_ONLY is on.
    ctx.waitUntil(shadowOnce().then(() => {}).catch(error => {
      console.error("engine_shadow_failed", error instanceof Error ? error.name : "unknown");
    }));
    // v2.2 Gate 4: recover status-lookup OTP deliveries whose request-time dispatch was lost (lease expired).
    ctx.waitUntil(dispatchLookupDeliveries(25).then(() => {}).catch(error => {
      console.error("status_lookup_dispatch_failed", error instanceof Error ? error.name : "unknown");
    }));
    // v2.2 Gate 5: durable jobs and the delivery outbox progress on every tick (5-minute and daily). Each is a D1 row
    // with a lease/fence, so a lost tick or an evicted worker is recovered by the next one.
    ctx.waitUntil(runJobs(defaultHandlers(), 10).then(() => {}).catch(error => {
      console.error("durable_jobs_failed", error instanceof Error ? error.name : "unknown");
    }));
    ctx.waitUntil(dispatchOutbox(20).then(() => {}).catch(error => {
      console.error("outbox_dispatch_failed", error instanceof Error ? error.name : "unknown");
    }));
    // The extra shadow cron never runs the daily jobs.
    if (_controller.cron === SHADOW_CRON) return;
    // v2.2 Gate 5 (daily): SYSTEM marks unpaid invoices past their Toronto deadline OVERDUE (audited) and queues the
    // document-expiry milestones (90/30/0 days, most urgent missed milestone only).
    ctx.waitUntil(refreshOverdue().then(() => {}).catch(error => {
      console.error("overdue_refresh_failed", error instanceof Error ? error.name : "unknown");
    }));
    ctx.waitUntil(scanExpiry().then(() => {}).catch(error => {
      console.error("expiry_scan_failed", error instanceof Error ? error.name : "unknown");
    }));
    ctx.waitUntil(runMaintenance().then(() => {}).catch(error => {
      console.error("scheduled_maintenance_failed", error instanceof Error ? error.name : "unknown");
    }));
    // Daily office briefing email (counts only) to OFFICE_ADMIN_EMAIL when mail delivery is configured.
    const origin = (_env as unknown as { PUBLIC_ORIGIN?: string }).PUBLIC_ORIGIN || "https://alhijrah-canada-desk.alhijrahusa.workers.dev";
    ctx.waitUntil(sendDailyBriefing(origin).then(() => {}).catch(error => {
      console.error("daily_briefing_failed", error instanceof Error ? error.name : "unknown");
    }));
  },
};

export default worker;
// v2.2 Gate 5: WebSocket coordination for the case chat (optional CHAT_ROOMS binding; HTTP replay without it).
export { CaseChatRoom } from "./case-chat-room";
