# ALHIJRAH CANADA — Claude Code Execution v2.2

## 0. سلطة التنفيذ وحدود الإصدار

نفّذ هذه المواصفة داخل التطبيق القائم وحزمة v2.2، مع الحفاظ على الهوية الداكنة والزجاجية والذهب والفيروز والبيانات والمسارات والخدمات الحالية. الإصدار المستهدف للحزمة هو v2.2. لا تنشئ تطبيقاً أو مخزن حالات أو مصادقة أو محرك تقييم موازياً. يُمنع النشر على موقع حي ضمن هذه المهمة.

هذه المواصفة التشغيلية والمخطط التنفيذي الوحيد أدناه يتقدمان على أي نص متعارض في ملفات v2.1. الملحقان الحرفيان في نهاية الملف محفوظان للتدقيق فقط؛ ليسا تعليمات تنفيذ إضافية ولا migrations. يتضمن المصدر مخططين متكررين وموضع لصق إرشادياً؛ حُفظت ألفاظهما في الملحق، ووُحدت وظائفهما في المخطط التنفيذي، ولا ينفذ موضع اللصق باعتباره كوداً أو متطلباً مجهولاً.

المصدر الذي قُرئ سابقاً: مشروع Sites `appgprj_6af000ca8f588191b4b72d7d947942e3`، عند SHA `7c38ece8b40450dd62955c0aa18eb5e7ce58b95c`. أعد التحقق من الفرع والتعديلات وAGENTS.md وhistory قبل التنفيذ؛ هذه المعلومة ليست إثباتاً بأن المصدر الحالي أو قاعدة الإنتاج لم يتغيرا. لا تطبع قيم الأسرار ولا ترسل رسائل اختبار إلى عملاء حقيقيين.

الموارد القائمة هي `DB` و`BUCKET`. في التطبيق الحالي يقابل `case_id` المعرف `candidates.id`، وتبقى `client_cases` امتداد الملف الحالي. لا تنشئ جدول `cases` موازياً لإرضاء اسم ورد في مصدر مقترح. إذا كانت الجداول الجديدة موجودة فعلاً، اكتب forward migration من المخطط المثبت بدلاً من إعادة إنشائها أو استعمال `IF NOT EXISTS` لإخفاء اختلافها. لا تعدّل migration مطبقة ولا تطبق مخطط الإنشاء المرجعي العام على قاعدة قائمة.



### تنفيذ بست بوابات فقط

خطة الاعتماد الوحيدة هي `GATES_EXECUTION_PLAN.md`، وتتكون من Gate 1 إلى Gate 6 فقط. توصيف Packages 1–8 لا ينشئ بوابات اعتماد إضافية. التعليمات المؤرشفة لا تعيد أي بوابة قديمة.

كتلة SQL المعتمدة في القسم 9 تضم الآن محتوى 0017 ومحتوى `0018_v22_runtime.sql` كاملاً. مرآتها الموحدة `data/current-system/v2_2_canonical.sql`، وهي مرجع موحد وليست migration إضافية. بعد فحص history تطبق توسعات النظام مرة واحدة بالترتيب 0016 ثم 0017 ثم 0018؛ لا تجمع المرآة الموحدة مع ملفي 0017 و0018 في تطبيق واحد. العلامتان SQL `V2_2_RUNTIME_0018_BEGIN/END` تحددان حد الفصل فقط، ولا تنشئان بوابة أو جدولاً.

النظام التشغيلي Single-Office؛ لا Multi-tenancy أو tenantId أو عضوية مؤسسات كشرط تشغيل. تبقى ملكية العميل وتعيين الموظف وصلاحيات الحالة. تحفظ البيانات واللقطات والتوقيعات التاريخية دون تغيير بصماتها.

## 1. قرارات v2.2 الحاكمة

1. Cloudflare D1 SQLite فقط: جميع المبالغ بالسنتات `INTEGER`، وجميع JSON في `TEXT` مع `json_valid`، ودون نوعي REAL وJSONB أو خصائص PostgreSQL.
2. الأدوار الوحيدة: `CLIENT`, `STAFF`, `MANAGER`, `SYSTEM`. الاستقبال والمستشارون والمراجعون موظفون `STAFF` بصلاحيات، وليسوا أدواراً إضافية. `RULES_APPROVER` اسم قدرة قديمة يُطابق `MANAGER` ولا يبقى دوراً خامساً.
3. التوقيع ثابت: لا حالة STALE للتوقيع، ولا إبطال أو إعادة توقيع آلية عند تعديل بيانات العميل. يبقى الحبر ومعرفه وتاريخ الالتقاط ونص الإقرار وبصمة اللقطة الأصلية ثابتة. تعديل الملف ينشئ إصدار بيانات/تقييم جديداً ولا يغيّر اللقطة التي وُقعت ولا يدّعي أن توقيعاً قديماً وُقع على مستند جديد. المسح الصريح أو توقيع جديد بطلب المستخدم فعل مستقل مدقق، ولا يحدث تلقائياً.
4. قفل القواعد بموافقة واحدة من `MANAGER` فقط. يستطيع المدير إنشاء الحزمة وقفلها في إجراء واجهة واحد، ومن الحساب نفسه، دون مراجع خارجي أو شرط اختلاف المؤلف أو حساب ثانٍ. داخلياً يمر الإجراء بالتحقق وحالة BUILDING ثم SEALED في batch واحدة؛ يمنع إدخال SEALED مباشرة أو تجاوز فحص المصدر والحمولة والتداخل والتكامل. لا تُعاد تفعيل شروط الموافقتين من ملفات أقدم.
5. محوّل اقتراح NOC لا يحتاج موافقة عميل: احذف من مساره `consentId`, `approvedConsent` وأي رفض سببه غياب الموافقة، في API والعقود والوظائف والاختبارات. تبقى آلية المطابقة والنقل والمهل والمصادر والاستشهادات كما هي، مع RBAC ونطاق الحالة والمزود المهيأ وحماية الملفات. لا يتحول الاقتراح إلى حقيقة مهنية لمجرد إخراج AI. لا يعمم هذا التغيير على موافقات أو سجلات أخرى خارج محوّل NOC.
6. RCIP يعتمد تاريخ اعتماد الطلب للإرسال، الصادر من الخادم والمحوّل إلى `America/Toronto`، ومجموعة القواعد المفعلة والمعتمدة. في 2026 يختار Pilot؛ وفي 2027 يختار الدائم ويرفض توصية مؤرخة في 2026. لا grace periods ولا استثناء توصية سابقة ولا شاشة أو حالة انتقالية. توثق هذه قاعدة فرز تشغيلية معتمدة من المكتب، ولا تعرض كتقرير مستقل عن بطلان قانوني صادر من IRCC. تبقى المصادر القانونية وتواريخ البرامج الأخرى دون تغيير.
7. غياب نطاق قواعد معتمد يرد بالنتيجة القائمة `RULE_UNAVAILABLE`، وغياب حقيقة حاسمة يبقى UNKNOWN. لا يُخترع نطاق أو نص قانوني أو درجة CRS، ولا يضاف مسار مراجعة انتقالي جديد.
8. `assessment_history` append-only. تعديل الملف النشط يضيف إصداراً جديداً، ولا يستبدل التقييمات القديمة. لا تُستعاد تعليمات أقدم تسمح بتعديل صف التاريخ.

## 2. الحفاظ على الحزم 1–8 وترقية Client Portal

- P1: الهوية الحالية والحسابات والجلسات والوثائق والتدقيق والمخطط، مع طبقة الأدوار الأربعة الموحدة؛ لا IdP أو كلمات مرور موازية.
- P2: مصادر وقواعد مؤرخة ومجموعات نشر immutable، مع ختم مدير واحد وعزل سلطة AI عن القاعدة المنشورة.
- P3: CRS الحتمي ومكونات النقاط وLMIF بصيغة MAX وفق الحمولة المعتمدة؛ لا حساب درجات قانونية في النص الحر أو المتصفح.
- P4: شروط المسارات مجتمعة، والفصل بين الأهلية وCRS والترتيب؛ RCIP حسب قرار v2.2 أعلاه فقط.
- P5: اقتراح NOC بلا شرط موافقة، وCV/OCR والوظائف وأصحاب العمل وATS والفجوات والخدمات والصلاحية، دون اختلاق دليل أو شاغر أو نسبة نجاح.
- P6: الأحداث والوظائف الدائمة، snapshot وcanonical_input_hash، وCAS وoutbox والتقارير وإعادة المحاولة وإزالة التكرار.
- P7: اختبارات D1/R2 والصلاحيات والأداء والاستعادة والتشغيل؛ لا نشر حي في هذه المهمة.
- P8: Real-Time Chat & Rapid Assessment داخل نفس Client Portal وStaff Dashboard وCase Management؛ محادثة العميل والموظف والمساعد والتحويل البشري والرسائل والمرفقات والصوت والإشعارات. لا محرك تقييم أو هوية موازية.

تحفظ ترقية البوابة كاملة: مدخل «تقديم طلب جديد — التقييم والتقديم» بالاسم والبريد وOTP، وإنشاء/إعادة استخدام الحساب بعد التحقق، وترحيب شخصي، ونموذج مرتبط بالحساب وحفظ مسوداته؛ ومدخل «متابعة طلب سابق — الدخول إلى حسابك وإدارة ملفك» بالبريد وOTP أو كلمة مرور الحساب، دون توسيع كلمة مرور ملف قديم إلى ملفات أخرى.

يبقى OTP بست خانات زجاجية مع اللصق والانتقال والتصحيح والمهل وإعادة الإرسال والقفل الخادمي. يبقى Smart Path Selector مع fade وتوسيط المسار وعلامة التحقق وخياراته الفرعية وزري المتابعة والرجوع وحفظ الاختيارات وخيار عدم التأكد. تحفظ المسودات بحساب العميل مع CAS واستعادة انقطاع الاتصال، ولا يتحول الحفظ المحلي وحده إلى رسالة حفظ خادمي ناجح.

تبقى لوحة التوقيع بالإصبع والقلم والماوس والمسح والحفظ عبر التحجيم والخطوات. يتطلب الإرسال الأول توقيعاً محفوظاً والحقول والموافقات الإلزامية الحالية؛ لا يربط صلاحية التوقيع لاحقاً بمطابقة أحدث hash لبيانات قابلة للتحرير، ولا يعيد توقيع الملف آلياً. تبقى السجلات التاريخية بلا توقيع كما هي دون تصنيع توقيع بأثر رجعي.

يبقى مؤشر «متصل ومؤمن» مشروطاً بجلسة حساب/ملف كاملة صالحة وHTTPS، لا بجلسة استعلام الحالة المحدودة. يبقى زر Footer الواحد «متابعة حالة الملف — استعلام سريع دون تسجيل الدخول»، بحقل بريد/هاتف دولي/Case Number، ثم إثبات إلى اتصال مسجل، ثم إسقاط حالة محدود دون كشف وجود الملف مسبقاً أو منح حساب كامل أو مستندات أو توقيع.

احفظ RTL/LTR والهواتف والأجهزة اللوحية والحواسيب وخفض الحركة واستجابة الضغطة الأولى ومنع التكرار. لا تحذف معلومات التواصل أو CV analysis أو المحادثة أو التوجيه الحالي. تحديثات v2.1 الخاصة بإبطال التوقيع وحدها ملغاة؛ لا تستخدمها في helpers أو DTOs أو شروط submit أو tests.

## 3. Zero-Touch Ingestion وAuto-Recompute

1. رفع مستند أو صوت عبر خدمة الرفع الحالية يحفظ كائناً خاصاً، ثم يسجل حدثاً دائم الهوية مرتبطاً بالحالة وhash الكائن. webhook خارجي يثبت توقيعه ويمنع replay، وحدث Worker داخلي يثبت صلاحية المهمة. لا يقبل الخادم VERIFIED من المتصفح.
2. تتحقق الهوية والنطاق والحجم والنوع والفحص وبصمة الأصل قبل OCR/AI. لا يكون `waitUntil` وحده مصدر دوام المهمة؛ تستعيد الوظائف الدائمة العمل بعد التعطل.
3. يقرأ OCR/AI المستند ويستخرج الحقول ويقارنها بإصدارات NOC وRCIP المعتمدة. استخراج CV والصوت لا يكتب فوق حقيقة موثقة بصمت، والتعارض يظل ظاهراً في الملف.
4. ترقية «رفع المستند إلى VERIFIED» تخص سلامة الأصل الرقمي بعد الفحص: `document_integrity=VERIFIED`. الـhash يثبت سلامة البايتات ولا يثبت صحة اللغة أو الخبرة أو محتوى المستند؛ الحقول المستخرجة تبقى EXTRACTED_UNVERIFIED/REPORTED حتى تحقق مصدرها وقواعد إثباتها. يجوز التحقق الآلي عند تحقق دليل موثوق قابلاً للتحقق آلياً وفق السياسة المعتمدة، وإلا يستمر التقييم الأولي بالمجهول دون ادعاء نهائية.
5. ينشأ `canonical_input_hash` من JCS للحقائق وإصداراتها والأدلة والقرارات والبرامج وسياق التاريخ وحزمة القواعد والمحرك والغرض والوضع. لا يدخل زمن التشغيل أو locale أو HTTP headers. يتغير hash عند تغير مؤثر، ولا ينشأ سجل جديد للتكرار المطابق.
6. يستدعي المحرك نفسه recompute بعد المستند/الحقيقة الجديدة، مع زر موظف احتياطي. تحفظ النتيجة والتدقيق والأحداث ذرياً، مع فصل dataRevision عن publicationRevision ونسخة المحادثة.
7. RAPID_SCREENING عرض أولي من المحرك نفسه؛ لا يرقّي claims إلى VERIFIED ولا يستبدل مؤشر التقرير الموثق. التحويل البشري يوقف مخرجات المساعد المتأخرة باستعمال automationGeneration وCAS.
8. الإشعار الآلي بالنص «أنجزت X%. الخطوة التالية: [اسم الخدمة]» يستخدم فقط نسبة تقدم مستندة إلى متطلبات معلنة وحقائق متحققة، وخدمة موجودة فعلاً في الكتالوج. إذا تعذر المقام أو الخدمة فلا يخترع X أو اسماً؛ يسجل السبب ولا يرسل نصاً مضللاً. لا يمثل المؤشر احتمال قبول IRCC.
9. SMS/Email عبر القناة المعتمدة الموجودة وoutbox الحالي، مع إزالة التكرار وفحص صلاحية المستلم وقيود القنوات المطلوبة. لا يعلن دعم SMS غير مهيأ، ولا تضيف محاولات recompute المتكررة دفعات أو فواتير أو leads مكررة.

## 4. Single-Authority Manager Seal

`createAndSealRelease` إجراء مدير واحد: تحقق الجلسة وMANAGER من D1، تحقق المخطط والمصادر والـhash وشمول القواعد والفروع واختبارات الحدود، أنشئ BUILDING وجدول النطاقات ثم SEALED وفعّل الإصدار في batch محكومة. المؤلف والمدير الخاتم يمكن أن يكونا المستخدم نفسه. لا توضع قيمة SEALED في INSERT، ولا تُقبل state/actor/validationReport مقدمة من المتصفح كسلطة.

يمسك السجل `sealed_by`, `sealed_at`, `validation_report_hash`, `manifest_sha256`. لا ينشر AI أو SYSTEM قاعدة قانونية. الجداول الزمنية immutable؛ الخلف ينشئ release جديداً بنطاقاته كاملة بدلاً من تحرير release مختوم. يحل المحرك إصداراً واحداً مناسباً لكل family/dateBasis؛ التداخل أو الغياب يمنع النتيجة القانونية. لا تختلق موافقة حكومية أو بيانات رسمية من ختم المدير.

## 5. Enterprise RBAC والأدوار الأربعة

المصادقة الحالية تثبت الهوية؛ `users` هو ربط الدور والصلاحيات للهوية المثبتة، وليس نظام تسجيل دخول جديداً. ربط المدير الأول من إدارة المكتب المخولة يراجع في migration؛ لا يختار العميل دوره ولا يرتقي تلقائياً بسبب email أو JWT claim غير موثوق.

- CLIENT: ملفاته وفواتيره المسموح بها فقط عبر الإسقاطات الحالية، دون إحصاءات المكتب أو حقول موظفين.
- STAFF: الاستقبال والمستشارون، مع assignment/nطاق الحالة وصلاحيات فعالة من role_permissions وcustom_permissions.
- MANAGER: سلطات الإدارة والاعتماد والقفل داخل التطبيق؛ لا تقبل شاشة الصلاحيات تعديل صلاحياته أو صلاحيات SYSTEM.
- SYSTEM: مهام داخلية محددة: ingestion/recompute/outbox/تحديث التأخر وإغلاق فتح الصلاحيات، وليس مسار دخول أو هوية يمكن للعميل انتحالها.

الحد الأدنى المضاف لكتالوج STAFF: `view_crm`, `view_financials`, `create_invoice`, `edit_invoice`, `edit_discount`, `record_payment`, `send_payment_notice`, `export_invoice_pdf`. قدرات MANAGER المحجوزة: `manage_permissions`, `open_staff_access`, `seal_rules`, `approve_invoice`. تبقى قدرات الحالات والمستندات والمحادثة والتقييم الموجودة في كتالوج الخادم وتظهر Toggles لها وفق قابلية الإسناد الحالية؛ لا تستبدلها بهذه القائمة المالية ولا تضف أدواراً لتقسيم القدرات. الكتالوج موحد ومُحمّل من الخادم، وليس مدخلاً من الطلب.

واجهة المدير Toggles زجاجية فقط للصلاحيات؛ لا محرر JSON ولا أسماء قدرات حرة. إدخال اسم خدمة أو ملاحظة فاتورة لا يخضع لحظر النص الخاص بشاشة إدارة الصلاحيات. غياب المفتاح يعني الرفض؛ custom boolean صريح يتقدم على role boolean، ما لم يكن فتح STAFF المؤقت فعالاً. فتح STAFF يفتح قدرات STAFF فقط، ولا يمنح قدرات MANAGER المحجوزة أو يتجاوز نطاق الحالة.

أي تعديل: تحقق مدير ونطاق وexpectedEpoch/version → سجل permission_changes_audit وتحديث القيمة والنسخة العامة في D1 batch واحدة → حدث invalidation واستبعاد مفاتيح KV. تُرفض المحاولة المتعارضة، ولا يكتب نجاح إذا لم يتغير صف مستهدف.

KV تسريع فقط: المفتاح يشمل namespace البيئة والمستخدم ونسخة الصلاحيات. الحذف العالمي الفوري ليس ضماناً تقنياً لـKV؛ الأثر الأمني الفوري يأتي من مقارنة epoch/active/role بقراءة D1 متسقة قبل كل وصول محمي، وقراءة D1 مباشرة للعمليات المالية والاعتماد. لا تستخدم replica متأخرة لمراجعة الإلغاء؛ استعمل قراءة primary/session متحققة أو ارفض عند تعذر الاتساق. عند تعذر فحص السلطة يفشل الطلب مغلقاً، ولا تعاد صلاحية قديمة من KV.

## 6. فتح STAFF المؤقت وAuto-Kill

زر MANAGER واحد يمكّن الفتح لليوم الحالي في `America/Toronto` فقط. الخادم يحسب التاريخ ونهاية اليوم UTC، ولا يقبل مدة أو offset أو until من المتصفح. يحفظ localDate وuntilMs وإصدار السلطة. يصبح الفتح غير فعال عند منتصف الليل حتى إن تعطل cron أو بقي KV قديماً. scheduled handler يغلق العلم ويسجل AUTO_KILL ويمسح cache بإزالة تكرار، ولا يُمدد الفتح في اليوم التالي. SYSTEM يستطيع الإغلاق فقط ولا يستطيع التمكين.

لا تستخدم `now+24h` ولا offset ثابتاً؛ يلزم اختبار يومي 23 و25 ساعة عند DST وحدود السنة. تحمل العملية المالية authz_expires_at_ms لا يتجاوز انتهاء الجلسة أو صلاحية الفتح التي اعتمدت عليها؛ يفحصه SQL مجدداً عند commit لتفشل عملية عبرت منتصف الليل وتُلغى batch كاملة.

## 7. Accounting & Billing Core

### 7.1 نموذج موحد وتسميات

كل فاتورة مرتبطة بحالة واحدة موجودة. العملة تُحدد صراحة من إعداد معتمد ذي منزلتين عشريتين؛ لا تفترض CAD أو USD ولا تحويل عملة. المصدر يسمي القيم cents؛ لا تخلط عملتين ولا تضف ضريبة أو رسوم أو رصيداً أو استرداداً لم يُحدد.

المخطط التنفيذي أدناه يجمع نسختي المصدر: الحقول deadline/note/created_by من الترويسة الأشمل محفوظة؛ `method` هو الاسم الموحد لـpayment_method، و`paid_at` يقابل payment_date، وnotes وreceipt_r2_key محفوظان. تستقبل طبقة التوافق الاسم القديم عند الحاجة ثم تطبّعه مرة واحدة؛ لا تخزن عمودين متعارضين ولا صفين لنفس الدفعة.

تُجلب الخدمات من الكتالوج الموجود أو تضاف يدوياً مع is_custom=1. تحفظ أسماء وأسعار الخدمة وقت إنشاء البند، فلا يتغير مستند قديم عند تعديل الكتالوج. الخدمة المجانية is_free=1 وunit_price_cents=0 وتظهر معها «🎁 خدمة مجانية تقديراً لك». السعر المرجعي المشطوب snapshot من الكتالوج أو إدخال صريح؛ لا يصنع النظام سعراً سابقاً غير معروف.

### 7.2 الحسابات والحالات

الخادم وحده يحسب:

- subtotal_cents = مجموع unit_price_cents للبنود.
- discount_cents مبلغ صحيح مصرح به لا يتجاوز subtotal.
- total_cents = subtotal_cents - discount_cents.
- paid_cents = مجموع الدفعات المسجلة غير القابلة للتحرير.
- remaining_cents = total_cents - paid_cents.

لا يقبل API من الواجهة subtotal/total/paid/remaining أو status محسوبة. يقبل اختيار الخدمة والمدخلات المصرح بها للخدمة المخصصة والخصم وطريقة الدفع؛ يقرأ سعر الكتالوج خادمياً. التحويل من نص عشري إلى سنتات يكون خادمياً دون floating arithmetic، وجميع المجاميع safe integers مع BigInt داخلي عند الجمع. لا تقبل الكسور أو السالب أو تجاوز المجال أو دفعاً يزيد المتبقي؛ لا تحوله إلى منتج ائتمان غير محدد.

الحالات الوحيدة: DRAFT, PENDING_APPROVAL, PARTIAL, PAID, OVERDUE. بعد العملية: الإحالة المعلقة تبقي PENDING_APPROVAL؛ وإلا المتبقي صفر=>PAID، ثم المهلة الماضية مع متبقٍ=>OVERDUE، ثم مدفوع جزئي=>PARTIAL، وإلا DRAFT. deadline تاريخ محلي ISO؛ تتجاوز المهلة بعد انتهاء يومها في Toronto. فاتورة مجانية كلياً تعرض عدم وجود مستحق دون قسمة على صفر.

### 7.3 الدفعات والذرية

الطرق: CASH, CHEQUE, ZELLE, CASH_APP. التسجيل دفتر مكتب ولا يثبت إجراء تحويل مصرفي تلقائي. يرفع السند إلى Private R2 بالخدمة القائمة، ويثبت نطاقه ونوعه وhash، ثم يحل الخادم uploadId إلى receipt_r2_key؛ لا يقبل مفتاح R2 حراً من العميل. لا يضع سنداً في bucket عام.

المعاملة: أعد التفويض وقراءة invoice/version → حاسبة خادم ونطاق case/currency → INSERT financial_audit_logs كحارس expectedVersion/epoch/expiry/idempotency → INSERT payment → UPDATE invoice بالرصيد والحالة وversion+1 → أحداث outbox المطلوبة؛ الكل D1 batch واحدة. أي فشل يبطل الكل. لا تستخدم UPDATE مشروطة قد تؤثر صفراً ثم INSERT دفعة دون guard يثير خطأ.

idempotency_key فريد وإلزامي. تكرار الدفعة نفسها يعاد 409 PAYMENT_ALREADY_RECORDED بلا أثر جديد؛ اختلاف payload مع المفتاح نفسه=>409 IDEMPOTENCY_CONFLICT. لا ينشئ العميل مفتاحاً جديداً تلقائياً بعد ضياع ACK؛ يستعلم عن النتيجة المصرح بها. لا يكشف التصادم بيانات فاتورة أخرى. دفتر الدفعات وسجل التدقيق append-only؛ لا تعدل دفعة قديمة أو تحذفها.

R2 وD1 ليسا معاملة مشتركة: يسبق الكائن الخاص commit قاعدة البيانات، ولا يصبح قابلاً للوصول المالي قبل الربط؛ تنظف الأيتام وفق السياسة الحالية بعد مهلة إعادة المحاولة. فقد إقرار المزود لا يبرر إعادة إرسال إخطار بلا reconciliation/idempotency.

### 7.4 الإحالة والإشعار وPDF

«إحالة للمدير» تسجل REFER وتجعل PENDING_APPROVAL وتغلق البنود والخصومات والدفعات والترويسة. MANAGER وحده يعتمد، مع expectedVersion وaudit، ثم تُحسب الحالة دون تغيير المبالغ أثناء خطوة الاعتماد. لا موافقة ثانية ولا مراجع مستقل مفروض.

زر «إشعار العميل بالدفع» يحتاج view_financials وsend_payment_notice ونطاق الحالة، وينشئ رسالة واحدة في outbox القائم بمبلغ المتبقي وعملته والمهلة فقط، دون وعود أو ملاحظات داخلية. الوجهة اتصال مسجل والقناة SMS/Email مهيأة فعلاً؛ عدم جاهزيتها لا يسجل SENT وهمية. تكرار الضغط يعيد نفس مهمة الإرسال ولا يكررها.

تصدير PDF عربي/إنجليزي عبر المحرك الموجود وAPI فاتورة واحدة؛ يحافظ على الهوية الداكنة/الذهبية/الفيروزية مع نسخة طباعة مقروءة، واتجاه اللغة والخط العربي والأرقام. يعرض البنود والمجاني والخصم والمدفوع والمتبقي والمهلة ومراجع السندات المسموح بها، لا روابط R2 الخاصة. يثبت نسخة الفاتورة وقت التصدير ولا يعيد الحساب في المتصفح.

## 8. الشاشات وAPI

في ملف CLIENT بطاقة زجاجية واحدة: الفاتورة الحالية والمدفوع والمتبقي كشريط والمهلة وزر PDF المصرح به. عند وجود فواتير متعددة لا تجمع عملات مختلفة أو تختار فاتورة عشوائية؛ تعرض القائمة الحالية مع اختيار واضح. لا تظهر إحصاءات المكتب للعميل.

في STAFF/MANAGER بطاقات المحصّل والديون المتأخرة والفواتير المعلقة، وجدول مفهرس قابل للنقر للتفاصيل والسندات وPDF. أي بطاقة مالية بما فيها بطاقة تسمى «الأرباح» محمية؛ لا يسمى المحصل ربحاً صافياً دون بيانات تكلفة فعلية. غياب view_financials يخفي العناصر ويرد 403 من API حتى لو استدعي الرابط يدوياً.

ادمج في namespace ومسارات المشروع الفعلية. أضف قدرات الفوترة عند غيابها فقط، ولا تنشئ نسخة /v1 موازية. العقود التنفيذية:

- إنشاء فاتورة: caseId, currency, catalog/custom/free items, discountCents, deadline, note, requestKey؛ الخادم يرفض المجاميع والحالة المرسلة.
- تعديل/خصم/إحالة: invoiceId, expectedVersion, requestKey ومدخلات الفعل المسموح بها.
- دفعة: invoiceId, expectedVersion, amountCents أو نص مبلغ مضبوط يُحوّل خادمياً، method, paidAt, receiptUploadId اختياري, notes, idempotencyKey. لا caseId/currency/senderRole كسلطة من المتصفح؛ يستخرجها الخادم من الفاتورة والهوية.
- اعتماد: invoiceId, expectedVersion, requestKey؛ MANAGER فقط.
- إشعار: invoiceId, expectedVersion, channel المعتمد, requestKey؛ المبلغ والمستلم والنص من الخادم.
- PDF: invoiceId, locale؛ نطاق عميل مالك أو موظف مخول.
- Toggles: STAFF target أو targetUserId لموظف، وpermissionKey من الكتالوج، وboolean، وexpectedVersion/epoch، وrequestKey. لا JSON حر أو target MANAGER/SYSTEM.

جميع mutations تتحقق من الجلسة وOrigin والصلاحية ونطاق الحالة وschema/size وidempotency. الاستعلامات بمؤشرات محددة وkeyset pagination، بلا جلب كل السجلات للمتصفح. مجاميع المكتب تستعلم من D1 وتجمع حسب currency منفصلة. لا تتجاوز صلاحيات نسخة التطبيق أو عزل Career Gate الآخر.

## 9. المخطط التنفيذي الموحد D1 SQLite

هذا هو DDL التنفيذي الواحد للوحدات الجديدة في v2.2، بعد preflight على المخطط الحالي. يحتفظ بأسماء جداول المصدر مرة واحدة ويضيف حراس الإصدار والذرية اللازمة. جداول حالات التطبيق والمستندات وoutbox الحالية تظل موجودة ولا يعاد إنشاؤها. إصدارات SQL السابقة والـDDL المنقول في الملحق الحرفي ليست migrations إضافية لهذا الإصدار.

<!-- V2_2_CANONICAL_SQL_BEGIN -->

```sql
-- Canonical v2.2 extension for the existing application after verified history.
-- Existing cases are candidates.id. Do not create a parallel cases table.
PRAGMA foreign_keys=ON;

CREATE TABLE users (
 user_id TEXT PRIMARY KEY NOT NULL,
 role TEXT NOT NULL CHECK(role IN('CLIENT','STAFF','MANAGER','SYSTEM')),
 custom_permissions TEXT NOT NULL DEFAULT '{}' CHECK(json_valid(custom_permissions) AND json_type(custom_permissions)='object'),
 permission_version INTEGER NOT NULL DEFAULT 1 CHECK(permission_version>=1),
 active INTEGER NOT NULL DEFAULT 1 CHECK(active IN(0,1)),
 created_at TEXT NOT NULL,
 CHECK(role='STAFF' OR custom_permissions='{}')
);
CREATE INDEX users_role_active ON users(role,active,user_id);
CREATE TRIGGER users_role_immutable BEFORE UPDATE OF role ON users BEGIN SELECT RAISE(ABORT,'ROLE_CHANGE_NOT_ALLOWED'); END;
CREATE TRIGGER users_root_permissions BEFORE UPDATE OF custom_permissions ON users WHEN OLD.role IN('MANAGER','SYSTEM') BEGIN SELECT RAISE(ABORT,'ROOT_PERMISSIONS_IMMUTABLE'); END;

CREATE TABLE role_permissions (
 role TEXT PRIMARY KEY NOT NULL CHECK(role='STAFF'),
 permissions_json TEXT NOT NULL DEFAULT '{}' CHECK(json_valid(permissions_json) AND json_type(permissions_json)='object'),
 version INTEGER NOT NULL DEFAULT 1 CHECK(version>=1),
 updated_at TEXT NOT NULL
);
INSERT INTO role_permissions(role,permissions_json,updated_at) VALUES('STAFF','{}',strftime('%Y-%m-%dT%H:%M:%fZ','now'));

CREATE TABLE permission_runtime (
 singleton INTEGER PRIMARY KEY CHECK(singleton=1),
 version INTEGER NOT NULL DEFAULT 1 CHECK(version>=1),
 open_all_enabled INTEGER NOT NULL DEFAULT 0 CHECK(open_all_enabled IN(0,1)),
 open_all_local_date TEXT,
 open_until_ms INTEGER NOT NULL DEFAULT 0 CHECK(typeof(open_until_ms)='integer' AND open_until_ms>=0),
 CHECK(open_all_enabled=0 OR (open_all_local_date IS NOT NULL AND length(open_all_local_date)=10 AND open_until_ms>0))
);
INSERT INTO permission_runtime(singleton) VALUES(1);

CREATE TABLE permission_changes_audit (
 audit_id TEXT PRIMARY KEY NOT NULL,
 change_kind TEXT NOT NULL CHECK(change_kind IN('ROLE','USER','OPEN_ALL','AUTO_KILL')),
 target_user_id TEXT REFERENCES users(user_id),
 target_role TEXT CHECK(target_role IS NULL OR target_role='STAFF'),
 old_permissions TEXT NOT NULL CHECK(json_valid(old_permissions) AND json_type(old_permissions)='object'),
 new_permissions TEXT NOT NULL CHECK(json_valid(new_permissions) AND json_type(new_permissions)='object'),
 expected_version INTEGER NOT NULL CHECK(expected_version>=1),
 expected_epoch INTEGER NOT NULL CHECK(expected_epoch>=1),
 changed_by TEXT NOT NULL REFERENCES users(user_id),
 changed_at TEXT NOT NULL,
 CHECK((change_kind='USER' AND target_user_id IS NOT NULL AND target_role IS NULL) OR (change_kind<>'USER' AND target_user_id IS NULL AND target_role='STAFF'))
);
CREATE INDEX permission_audit_target ON permission_changes_audit(target_user_id,changed_at,audit_id);
CREATE INDEX permission_audit_epoch ON permission_changes_audit(expected_epoch,audit_id);
CREATE TRIGGER permission_change_guard BEFORE INSERT ON permission_changes_audit BEGIN
 SELECT CASE WHEN NEW.expected_epoch<>(SELECT version FROM permission_runtime WHERE singleton=1) THEN RAISE(ABORT,'PERMISSION_EPOCH_CONFLICT') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM users u WHERE u.user_id=NEW.changed_by AND u.active=1 AND (u.role='MANAGER' OR (u.role='SYSTEM' AND NEW.change_kind='AUTO_KILL'))) THEN RAISE(ABORT,'MANAGER_REQUIRED') END;
 SELECT CASE WHEN NEW.change_kind='USER' AND NOT EXISTS(SELECT 1 FROM users u WHERE u.user_id=NEW.target_user_id AND u.role='STAFF' AND u.permission_version=NEW.expected_version AND u.custom_permissions=NEW.old_permissions) THEN RAISE(ABORT,'INVALID_PERMISSION_TARGET') END;
 SELECT CASE WHEN NEW.change_kind='ROLE' AND NOT EXISTS(SELECT 1 FROM role_permissions r WHERE r.role='STAFF' AND r.version=NEW.expected_version AND r.permissions_json=NEW.old_permissions) THEN RAISE(ABORT,'ROLE_PERMISSION_CONFLICT') END;
 SELECT CASE WHEN NEW.change_kind IN('OPEN_ALL','AUTO_KILL') AND NEW.expected_version<>NEW.expected_epoch THEN RAISE(ABORT,'OPEN_ACCESS_VERSION_CONFLICT') END;
 SELECT CASE WHEN NEW.change_kind IN('ROLE','USER') AND EXISTS(SELECT 1 FROM json_each(NEW.new_permissions) WHERE type NOT IN('true','false') OR key IN('manage_permissions','open_staff_access','seal_rules','approve_invoice')) THEN RAISE(ABORT,'INVALID_PERMISSION_KEY_OR_TYPE') END;
 SELECT CASE WHEN NEW.change_kind IN('OPEN_ALL','AUTO_KILL') AND (COALESCE(json_type(NEW.new_permissions,'$.enabled'),'missing') NOT IN('true','false') OR COALESCE(json_type(NEW.new_permissions,'$.untilMs'),'missing')<>'integer') THEN RAISE(ABORT,'INVALID_OPEN_ACCESS_PAYLOAD') END;
 SELECT CASE WHEN NEW.change_kind IN('OPEN_ALL','AUTO_KILL') AND (json_extract(NEW.old_permissions,'$.enabled') IS NOT (SELECT open_all_enabled FROM permission_runtime WHERE singleton=1) OR json_extract(NEW.old_permissions,'$.localDate') IS NOT (SELECT open_all_local_date FROM permission_runtime WHERE singleton=1) OR json_extract(NEW.old_permissions,'$.untilMs') IS NOT (SELECT open_until_ms FROM permission_runtime WHERE singleton=1)) THEN RAISE(ABORT,'OPEN_ACCESS_SNAPSHOT_CONFLICT') END;
 SELECT CASE WHEN NEW.change_kind='AUTO_KILL' AND (json_extract(NEW.new_permissions,'$.enabled')<>0 OR json_extract(NEW.new_permissions,'$.untilMs')<>0) THEN RAISE(ABORT,'SYSTEM_CANNOT_ENABLE_ACCESS') END;
END;
CREATE TRIGGER permission_change_apply AFTER INSERT ON permission_changes_audit BEGIN
 UPDATE users SET custom_permissions=NEW.new_permissions,permission_version=permission_version+1 WHERE NEW.change_kind='USER' AND user_id=NEW.target_user_id;
 UPDATE role_permissions SET permissions_json=NEW.new_permissions,version=version+1,updated_at=NEW.changed_at WHERE NEW.change_kind='ROLE' AND role='STAFF';
 UPDATE permission_runtime SET version=version+1,
  open_all_enabled=CASE WHEN NEW.change_kind IN('OPEN_ALL','AUTO_KILL') THEN json_extract(NEW.new_permissions,'$.enabled') ELSE open_all_enabled END,
  open_all_local_date=CASE WHEN NEW.change_kind IN('OPEN_ALL','AUTO_KILL') THEN json_extract(NEW.new_permissions,'$.localDate') ELSE open_all_local_date END,
  open_until_ms=CASE WHEN NEW.change_kind IN('OPEN_ALL','AUTO_KILL') THEN json_extract(NEW.new_permissions,'$.untilMs') ELSE open_until_ms END
 WHERE singleton=1;
END;
CREATE TRIGGER permission_audit_no_update BEFORE UPDATE ON permission_changes_audit BEGIN SELECT RAISE(ABORT,'IMMUTABLE_PERMISSION_AUDIT'); END;
CREATE TRIGGER permission_audit_no_delete BEFORE DELETE ON permission_changes_audit BEGIN SELECT RAISE(ABORT,'IMMUTABLE_PERMISSION_AUDIT'); END;
CREATE TRIGGER user_permissions_audited BEFORE UPDATE OF custom_permissions,permission_version ON users WHEN OLD.role='STAFF' BEGIN
 SELECT CASE WHEN NEW.permission_version<>OLD.permission_version+1 OR NOT EXISTS(SELECT 1 FROM permission_changes_audit a WHERE a.change_kind='USER' AND a.target_user_id=OLD.user_id AND a.expected_version=OLD.permission_version AND a.old_permissions=OLD.custom_permissions AND a.new_permissions=NEW.custom_permissions AND a.expected_epoch=(SELECT version FROM permission_runtime WHERE singleton=1)) THEN RAISE(ABORT,'PERMISSION_AUDIT_REQUIRED') END;
END;
CREATE TRIGGER role_permissions_audited BEFORE UPDATE ON role_permissions BEGIN
 SELECT CASE WHEN NEW.role<>OLD.role OR NEW.version<>OLD.version+1 OR NOT EXISTS(SELECT 1 FROM permission_changes_audit a WHERE a.change_kind='ROLE' AND a.target_role='STAFF' AND a.expected_version=OLD.version AND a.old_permissions=OLD.permissions_json AND a.new_permissions=NEW.permissions_json AND a.expected_epoch=(SELECT version FROM permission_runtime WHERE singleton=1)) THEN RAISE(ABORT,'PERMISSION_AUDIT_REQUIRED') END;
END;
CREATE TRIGGER permission_runtime_audited BEFORE UPDATE ON permission_runtime BEGIN
 SELECT CASE WHEN NEW.version<>OLD.version+1 OR NOT EXISTS(SELECT 1 FROM permission_changes_audit a WHERE a.expected_epoch=OLD.version) THEN RAISE(ABORT,'PERMISSION_AUDIT_REQUIRED') END;
END;
CREATE TRIGGER role_permissions_no_delete BEFORE DELETE ON role_permissions BEGIN SELECT RAISE(ABORT,'PERMISSION_AUDIT_REQUIRED'); END;
CREATE TRIGGER permission_runtime_no_delete BEFORE DELETE ON permission_runtime BEGIN SELECT RAISE(ABORT,'PERMISSION_AUDIT_REQUIRED'); END;
CREATE TRIGGER root_user_no_delete BEFORE DELETE ON users WHEN OLD.role IN('MANAGER','SYSTEM') BEGIN SELECT RAISE(ABORT,'ROOT_PERMISSIONS_IMMUTABLE'); END;

CREATE TABLE assessment_history (
 history_id TEXT PRIMARY KEY NOT NULL,
 case_id TEXT NOT NULL REFERENCES candidates(id),
 case_revision INTEGER NOT NULL CHECK(case_revision>=0),
 canonical_input_hash TEXT NOT NULL CHECK(length(canonical_input_hash)=64),
 rule_bundle_hash TEXT NOT NULL CHECK(length(rule_bundle_hash)=64),
 engine_version TEXT NOT NULL,
 assessment_mode TEXT NOT NULL CHECK(assessment_mode IN('PRODUCTION','SHADOW')),
 assessment_purpose TEXT NOT NULL CHECK(assessment_purpose IN('RAPID_SCREENING','VERIFIED_SCREENING')),
 payload TEXT NOT NULL CHECK(json_valid(payload)),
 created_by TEXT NOT NULL REFERENCES users(user_id),
 created_at TEXT NOT NULL,
 UNIQUE(case_id,canonical_input_hash,rule_bundle_hash,engine_version,assessment_mode,assessment_purpose)
);
CREATE INDEX assessment_case_date ON assessment_history(case_id,created_at DESC,history_id);
CREATE TRIGGER assessment_history_no_update BEFORE UPDATE ON assessment_history BEGIN SELECT RAISE(ABORT,'IMMUTABLE_ASSESSMENT'); END;
CREATE TRIGGER assessment_history_no_delete BEFORE DELETE ON assessment_history BEGIN SELECT RAISE(ABORT,'IMMUTABLE_ASSESSMENT'); END;

CREATE TABLE source_snapshots (
 source_id TEXT PRIMARY KEY NOT NULL,
 official_url TEXT NOT NULL,
 object_key TEXT NOT NULL UNIQUE,
 content_sha256 TEXT NOT NULL CHECK(length(content_sha256)=64),
 fetched_at TEXT NOT NULL
);
CREATE TABLE rule_bundles (
 bundle_id TEXT PRIMARY KEY NOT NULL,
 payload TEXT NOT NULL CHECK(json_valid(payload)),
 payload_sha256 TEXT NOT NULL UNIQUE CHECK(length(payload_sha256)=64),
 source_id TEXT NOT NULL REFERENCES source_snapshots(source_id),
 created_by TEXT NOT NULL REFERENCES users(user_id),
 created_at TEXT NOT NULL
);
CREATE TABLE release_sets (
 release_id TEXT PRIMARY KEY NOT NULL,
 manifest_sha256 TEXT NOT NULL UNIQUE CHECK(length(manifest_sha256)=64),
 state TEXT NOT NULL DEFAULT 'BUILDING' CHECK(state IN('BUILDING','SEALED')),
 validation_report_hash TEXT,
 created_by TEXT NOT NULL REFERENCES users(user_id),
 sealed_by TEXT REFERENCES users(user_id),
 sealed_at TEXT,
 CHECK((state='BUILDING' AND sealed_by IS NULL AND sealed_at IS NULL) OR (state='SEALED' AND sealed_by IS NOT NULL AND sealed_at IS NOT NULL AND validation_report_hash IS NOT NULL AND length(validation_report_hash)=64))
);
CREATE TABLE release_intervals (
 release_id TEXT NOT NULL REFERENCES release_sets(release_id),
 program_id TEXT NOT NULL,
 family TEXT NOT NULL,
 phase TEXT NOT NULL,
 date_basis TEXT NOT NULL CHECK(date_basis IN('PROFILE','INVITATION','APPLICATION','RECOMMENDATION','APPROVAL_TORONTO')),
 effective_from TEXT NOT NULL,
 effective_to_exclusive TEXT,
 bundle_id TEXT NOT NULL REFERENCES rule_bundles(bundle_id),
 CHECK(length(effective_from)=10),
 CHECK(effective_to_exclusive IS NULL OR effective_to_exclusive>effective_from),
 CHECK(program_id NOT IN('RCIP_PILOT','RCIP_PERMANENT') OR date_basis='APPROVAL_TORONTO'),
 PRIMARY KEY(release_id,program_id,family,phase,date_basis,effective_from)
);
CREATE INDEX release_effective_lookup ON release_intervals(release_id,program_id,family,phase,date_basis,effective_from,effective_to_exclusive);
CREATE TRIGGER release_insert_guard BEFORE INSERT ON release_sets WHEN NEW.state<>'BUILDING' BEGIN SELECT RAISE(ABORT,'SEALED_MUST_BE_EARNED'); END;
CREATE TRIGGER release_interval_insert_guard BEFORE INSERT ON release_intervals BEGIN
 SELECT CASE WHEN (SELECT state FROM release_sets WHERE release_id=NEW.release_id)<>'BUILDING' THEN RAISE(ABORT,'SEALED_RELEASE') END;
 SELECT CASE WHEN EXISTS(SELECT 1 FROM release_intervals r WHERE r.release_id=NEW.release_id AND r.program_id=NEW.program_id AND r.family=NEW.family AND r.phase=NEW.phase AND r.date_basis=NEW.date_basis AND (r.effective_to_exclusive IS NULL OR NEW.effective_from<r.effective_to_exclusive) AND (NEW.effective_to_exclusive IS NULL OR r.effective_from<NEW.effective_to_exclusive)) THEN RAISE(ABORT,'RULE_INTERVAL_OVERLAP') END;
END;
CREATE TRIGGER release_seal_guard BEFORE UPDATE ON release_sets BEGIN
 SELECT CASE WHEN OLD.state<>'BUILDING' OR NEW.state<>'SEALED' OR NEW.release_id<>OLD.release_id OR NEW.manifest_sha256<>OLD.manifest_sha256 OR NEW.created_by<>OLD.created_by THEN RAISE(ABORT,'INVALID_RELEASE_TRANSITION') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM users WHERE user_id=NEW.sealed_by AND role='MANAGER' AND active=1) THEN RAISE(ABORT,'MANAGER_REQUIRED') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM release_intervals WHERE release_id=NEW.release_id) THEN RAISE(ABORT,'EMPTY_RELEASE') END;
END;
CREATE TABLE rule_activation (
 singleton INTEGER PRIMARY KEY CHECK(singleton=1),
 release_id TEXT REFERENCES release_sets(release_id),
 generation INTEGER NOT NULL DEFAULT 0 CHECK(generation>=0),
 changed_by TEXT REFERENCES users(user_id),
 changed_at TEXT
);
INSERT INTO rule_activation(singleton) VALUES(1);
CREATE TRIGGER activation_guard BEFORE UPDATE ON rule_activation BEGIN
 SELECT CASE WHEN NEW.generation<>OLD.generation+1 OR NOT EXISTS(SELECT 1 FROM users WHERE user_id=NEW.changed_by AND role='MANAGER' AND active=1) OR (NEW.release_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM release_sets WHERE release_id=NEW.release_id AND state='SEALED')) THEN RAISE(ABORT,'INVALID_RULE_ACTIVATION') END;
END;
CREATE TRIGGER release_intervals_no_update BEFORE UPDATE ON release_intervals BEGIN SELECT RAISE(ABORT,'IMMUTABLE_RELEASE_INTERVAL'); END;
CREATE TRIGGER release_intervals_no_delete BEFORE DELETE ON release_intervals BEGIN SELECT RAISE(ABORT,'IMMUTABLE_RELEASE_INTERVAL'); END;
CREATE TRIGGER rule_bundles_no_update BEFORE UPDATE ON rule_bundles BEGIN SELECT RAISE(ABORT,'IMMUTABLE_RULE_BUNDLE'); END;
CREATE TRIGGER rule_bundles_no_delete BEFORE DELETE ON rule_bundles BEGIN SELECT RAISE(ABORT,'IMMUTABLE_RULE_BUNDLE'); END;
CREATE TRIGGER source_snapshots_no_update BEFORE UPDATE ON source_snapshots BEGIN SELECT RAISE(ABORT,'IMMUTABLE_SOURCE'); END;
CREATE TRIGGER source_snapshots_no_delete BEFORE DELETE ON source_snapshots BEGIN SELECT RAISE(ABORT,'IMMUTABLE_SOURCE'); END;
CREATE TRIGGER release_sets_no_delete BEFORE DELETE ON release_sets BEGIN SELECT RAISE(ABORT,'IMMUTABLE_RELEASE'); END;

CREATE TABLE invoices (
 invoice_id TEXT PRIMARY KEY NOT NULL,
 case_id TEXT NOT NULL REFERENCES candidates(id),
 currency TEXT NOT NULL CHECK(length(currency)=3 AND currency NOT GLOB '*[^A-Z]*'),
 status TEXT NOT NULL DEFAULT 'DRAFT' CHECK(status IN('DRAFT','PENDING_APPROVAL','PARTIAL','PAID','OVERDUE')),
 subtotal_cents INTEGER NOT NULL DEFAULT 0 CHECK(typeof(subtotal_cents)='integer' AND subtotal_cents BETWEEN 0 AND 9007199254740991),
 discount_cents INTEGER NOT NULL DEFAULT 0 CHECK(typeof(discount_cents)='integer' AND discount_cents BETWEEN 0 AND subtotal_cents),
 total_cents INTEGER NOT NULL DEFAULT 0 CHECK(typeof(total_cents)='integer' AND total_cents=subtotal_cents-discount_cents),
 paid_cents INTEGER NOT NULL DEFAULT 0 CHECK(typeof(paid_cents)='integer' AND paid_cents BETWEEN 0 AND total_cents),
 remaining_cents INTEGER NOT NULL DEFAULT 0 CHECK(typeof(remaining_cents)='integer' AND remaining_cents=total_cents-paid_cents),
 deadline TEXT,
 note TEXT,
 version INTEGER NOT NULL DEFAULT 0 CHECK(version>=0),
 last_operation_id TEXT REFERENCES financial_audit_logs(log_id),
 approval_requested_at TEXT,
 approved_by TEXT REFERENCES users(user_id),
 approved_at TEXT,
 created_by TEXT NOT NULL REFERENCES users(user_id),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 UNIQUE(invoice_id,case_id,currency)
);
CREATE INDEX invoices_case_date ON invoices(case_id,created_at DESC,invoice_id);
CREATE INDEX invoices_status_deadline ON invoices(status,deadline,invoice_id);
CREATE INDEX invoices_created_by ON invoices(created_by,created_at DESC,invoice_id);

CREATE TABLE financial_audit_logs (
 log_id TEXT PRIMARY KEY NOT NULL,
 invoice_id TEXT NOT NULL REFERENCES invoices(invoice_id),
 modified_by TEXT NOT NULL REFERENCES users(user_id),
 action_type TEXT NOT NULL CHECK(action_type IN('CREATE','EDIT','DISCOUNT','PAYMENT','REFER','APPROVE','OVERDUE_REFRESH')),
 old_value TEXT NOT NULL CHECK(json_valid(old_value) AND json_type(old_value)='object'),
 new_value TEXT NOT NULL CHECK(json_valid(new_value) AND json_type(new_value)='object'),
 expected_version INTEGER NOT NULL CHECK(expected_version>=0),
 permissions_epoch INTEGER NOT NULL CHECK(permissions_epoch>=1),
 authz_expires_at_ms INTEGER NOT NULL CHECK(typeof(authz_expires_at_ms)='integer'),
 request_hash TEXT NOT NULL CHECK(length(request_hash)=64),
 idempotency_key TEXT NOT NULL UNIQUE,
 timestamp TEXT NOT NULL
);
CREATE INDEX financial_audit_invoice ON financial_audit_logs(invoice_id,timestamp,log_id);
CREATE INDEX financial_audit_actor ON financial_audit_logs(modified_by,timestamp,log_id);
CREATE TRIGGER financial_operation_guard BEFORE INSERT ON financial_audit_logs BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM invoices WHERE invoice_id=NEW.invoice_id AND version=NEW.expected_version) THEN RAISE(ABORT,'INVOICE_REVISION_CONFLICT') END;
 SELECT CASE WHEN COALESCE(json_type(NEW.old_value,'$.subtotal_cents'),'missing')<>'integer' OR COALESCE(json_type(NEW.new_value,'$.subtotal_cents'),'missing')<>'integer' THEN RAISE(ABORT,'AUDIT_SNAPSHOT_REQUIRED') END;
 SELECT CASE WHEN json_extract(NEW.old_value,'$.subtotal_cents') IS NOT (SELECT subtotal_cents FROM invoices WHERE invoice_id=NEW.invoice_id) THEN RAISE(ABORT,'AUDIT_OLD_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN COALESCE(json_type(NEW.old_value,'$.discount_cents'),'missing')<>'integer' OR COALESCE(json_type(NEW.new_value,'$.discount_cents'),'missing')<>'integer' THEN RAISE(ABORT,'AUDIT_SNAPSHOT_REQUIRED') END;
 SELECT CASE WHEN json_extract(NEW.old_value,'$.discount_cents') IS NOT (SELECT discount_cents FROM invoices WHERE invoice_id=NEW.invoice_id) THEN RAISE(ABORT,'AUDIT_OLD_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN COALESCE(json_type(NEW.old_value,'$.total_cents'),'missing')<>'integer' OR COALESCE(json_type(NEW.new_value,'$.total_cents'),'missing')<>'integer' THEN RAISE(ABORT,'AUDIT_SNAPSHOT_REQUIRED') END;
 SELECT CASE WHEN json_extract(NEW.old_value,'$.total_cents') IS NOT (SELECT total_cents FROM invoices WHERE invoice_id=NEW.invoice_id) THEN RAISE(ABORT,'AUDIT_OLD_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN COALESCE(json_type(NEW.old_value,'$.paid_cents'),'missing')<>'integer' OR COALESCE(json_type(NEW.new_value,'$.paid_cents'),'missing')<>'integer' THEN RAISE(ABORT,'AUDIT_SNAPSHOT_REQUIRED') END;
 SELECT CASE WHEN json_extract(NEW.old_value,'$.paid_cents') IS NOT (SELECT paid_cents FROM invoices WHERE invoice_id=NEW.invoice_id) THEN RAISE(ABORT,'AUDIT_OLD_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN COALESCE(json_type(NEW.old_value,'$.remaining_cents'),'missing')<>'integer' OR COALESCE(json_type(NEW.new_value,'$.remaining_cents'),'missing')<>'integer' THEN RAISE(ABORT,'AUDIT_SNAPSHOT_REQUIRED') END;
 SELECT CASE WHEN json_extract(NEW.old_value,'$.remaining_cents') IS NOT (SELECT remaining_cents FROM invoices WHERE invoice_id=NEW.invoice_id) THEN RAISE(ABORT,'AUDIT_OLD_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN COALESCE(json_type(NEW.old_value,'$.version'),'missing')<>'integer' OR COALESCE(json_type(NEW.new_value,'$.version'),'missing')<>'integer' THEN RAISE(ABORT,'AUDIT_SNAPSHOT_REQUIRED') END;
 SELECT CASE WHEN json_extract(NEW.old_value,'$.version') IS NOT (SELECT version FROM invoices WHERE invoice_id=NEW.invoice_id) THEN RAISE(ABORT,'AUDIT_OLD_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN json_extract(NEW.old_value,'$.status') IS NOT (SELECT status FROM invoices WHERE invoice_id=NEW.invoice_id) OR COALESCE(json_type(NEW.new_value,'$.status'),'missing')<>'text' THEN RAISE(ABORT,'AUDIT_STATUS_SNAPSHOT_REQUIRED') END;
 SELECT CASE WHEN NEW.permissions_epoch<>(SELECT version FROM permission_runtime WHERE singleton=1) THEN RAISE(ABORT,'PERMISSION_EPOCH_CONFLICT') END;
 SELECT CASE WHEN NEW.authz_expires_at_ms<=(CAST(strftime('%s','now') AS INTEGER)*1000+CAST(substr(strftime('%f','now'),4,3) AS INTEGER)) THEN RAISE(ABORT,'AUTHORIZATION_EXPIRED') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM users WHERE user_id=NEW.modified_by AND active=1 AND (role IN('MANAGER','STAFF') OR (role='SYSTEM' AND NEW.action_type='OVERDUE_REFRESH'))) THEN RAISE(ABORT,'FINANCIAL_WRITE_DENIED') END;
 SELECT CASE WHEN EXISTS(SELECT 1 FROM users u WHERE u.user_id=NEW.modified_by AND u.role='STAFF' AND NOT (
  ((SELECT open_all_enabled FROM permission_runtime WHERE singleton=1)=1 AND (SELECT open_until_ms FROM permission_runtime WHERE singleton=1)>(CAST(strftime('%s','now') AS INTEGER)*1000+CAST(substr(strftime('%f','now'),4,3) AS INTEGER))) OR
  (COALESCE(json_extract(u.custom_permissions,'$.view_financials'),(SELECT json_extract(permissions_json,'$.view_financials') FROM role_permissions WHERE role='STAFF'),0)=1 AND
   COALESCE(json_extract(u.custom_permissions,CASE NEW.action_type WHEN 'CREATE' THEN '$.create_invoice' WHEN 'EDIT' THEN '$.edit_invoice' WHEN 'DISCOUNT' THEN '$.edit_discount' WHEN 'PAYMENT' THEN '$.record_payment' WHEN 'REFER' THEN '$.edit_invoice' ELSE '$.__reserved' END),
    (SELECT json_extract(permissions_json,CASE NEW.action_type WHEN 'CREATE' THEN '$.create_invoice' WHEN 'EDIT' THEN '$.edit_invoice' WHEN 'DISCOUNT' THEN '$.edit_discount' WHEN 'PAYMENT' THEN '$.record_payment' WHEN 'REFER' THEN '$.edit_invoice' ELSE '$.__reserved' END) FROM role_permissions WHERE role='STAFF'),0)=1)
 )) THEN RAISE(ABORT,'FINANCIAL_PERMISSION_REQUIRED') END;
 SELECT CASE WHEN json_extract(NEW.new_value,'$.discount_cents')<>json_extract(NEW.old_value,'$.discount_cents') AND EXISTS(SELECT 1 FROM users u WHERE u.user_id=NEW.modified_by AND u.role='STAFF' AND NOT (((SELECT open_all_enabled FROM permission_runtime WHERE singleton=1)=1 AND (SELECT open_until_ms FROM permission_runtime WHERE singleton=1)>(CAST(strftime('%s','now') AS INTEGER)*1000+CAST(substr(strftime('%f','now'),4,3) AS INTEGER))) OR COALESCE(json_extract(u.custom_permissions,'$.edit_discount'),(SELECT json_extract(permissions_json,'$.edit_discount') FROM role_permissions WHERE role='STAFF'),0)=1)) THEN RAISE(ABORT,'DISCOUNT_PERMISSION_REQUIRED') END;
 SELECT CASE WHEN (SELECT status FROM invoices WHERE invoice_id=NEW.invoice_id)='PENDING_APPROVAL' AND NEW.action_type<>'APPROVE' THEN RAISE(ABORT,'INVOICE_LOCKED') END;
 SELECT CASE WHEN NEW.action_type='APPROVE' AND (NOT EXISTS(SELECT 1 FROM users WHERE user_id=NEW.modified_by AND active=1 AND role='MANAGER') OR (SELECT status FROM invoices WHERE invoice_id=NEW.invoice_id)<>'PENDING_APPROVAL') THEN RAISE(ABORT,'MANAGER_APPROVAL_REQUIRED') END;
END;

CREATE TABLE invoice_items (
 item_id TEXT PRIMARY KEY NOT NULL,
 invoice_id TEXT NOT NULL REFERENCES invoices(invoice_id) ON DELETE CASCADE,
 service_id TEXT,
 service_name TEXT NOT NULL,
 is_custom INTEGER NOT NULL DEFAULT 0 CHECK(is_custom IN(0,1)),
 is_free INTEGER NOT NULL DEFAULT 0 CHECK(is_free IN(0,1)),
 unit_price_cents INTEGER NOT NULL DEFAULT 0 CHECK(typeof(unit_price_cents)='integer' AND unit_price_cents BETWEEN 0 AND 9007199254740991),
 reference_price_cents INTEGER CHECK(reference_price_cents IS NULL OR (typeof(reference_price_cents)='integer' AND reference_price_cents BETWEEN 0 AND 9007199254740991)),
 last_operation_id TEXT NOT NULL REFERENCES financial_audit_logs(log_id),
 CHECK(is_free=0 OR unit_price_cents=0)
);
CREATE INDEX invoice_items_invoice ON invoice_items(invoice_id,item_id);
CREATE TRIGGER invoice_item_insert_guard BEFORE INSERT ON invoice_items BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM invoices i JOIN financial_audit_logs a ON a.invoice_id=i.invoice_id WHERE i.invoice_id=NEW.invoice_id AND i.status<>'PENDING_APPROVAL' AND a.log_id=NEW.last_operation_id AND a.expected_version=i.version AND a.action_type IN('CREATE','EDIT')) THEN RAISE(ABORT,'INVOICE_ITEM_WRITE_DENIED') END;
END;
CREATE TRIGGER invoice_item_update_guard BEFORE UPDATE ON invoice_items BEGIN
 SELECT CASE WHEN NEW.item_id<>OLD.item_id OR NEW.invoice_id<>OLD.invoice_id OR NOT EXISTS(SELECT 1 FROM invoices i JOIN financial_audit_logs a ON a.invoice_id=i.invoice_id WHERE i.invoice_id=NEW.invoice_id AND i.status<>'PENDING_APPROVAL' AND a.log_id=NEW.last_operation_id AND a.expected_version=i.version AND a.action_type='EDIT') THEN RAISE(ABORT,'INVOICE_ITEM_WRITE_DENIED') END;
END;
CREATE TRIGGER invoice_item_delete_guard BEFORE DELETE ON invoice_items BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM invoices i JOIN financial_audit_logs a ON a.invoice_id=i.invoice_id WHERE i.invoice_id=OLD.invoice_id AND i.status<>'PENDING_APPROVAL' AND a.expected_version=i.version AND a.action_type='EDIT') THEN RAISE(ABORT,'INVOICE_ITEM_WRITE_DENIED') END;
END;

CREATE TABLE payments_ledger (
 payment_id TEXT PRIMARY KEY NOT NULL,
 invoice_id TEXT NOT NULL,
 case_id TEXT NOT NULL,
 currency TEXT NOT NULL,
 amount_cents INTEGER NOT NULL CHECK(typeof(amount_cents)='integer' AND amount_cents BETWEEN 1 AND 9007199254740991),
 method TEXT NOT NULL CHECK(method IN('CASH','CHEQUE','ZELLE','CASH_APP')),
 paid_at TEXT NOT NULL,
 receipt_r2_key TEXT,
 receipt_sha256 TEXT CHECK(receipt_sha256 IS NULL OR length(receipt_sha256)=64),
 notes TEXT,
 idempotency_key TEXT NOT NULL UNIQUE,
 operation_id TEXT NOT NULL UNIQUE REFERENCES financial_audit_logs(log_id),
 created_by TEXT NOT NULL REFERENCES users(user_id),
 created_at TEXT NOT NULL,
 CHECK((receipt_r2_key IS NULL AND receipt_sha256 IS NULL) OR (receipt_r2_key IS NOT NULL AND receipt_sha256 IS NOT NULL)),
 FOREIGN KEY(invoice_id,case_id,currency) REFERENCES invoices(invoice_id,case_id,currency)
);
CREATE INDEX payments_invoice_date ON payments_ledger(invoice_id,paid_at,payment_id);
CREATE INDEX payments_case_date ON payments_ledger(case_id,paid_at,payment_id);
CREATE TRIGGER payment_insert_guard BEFORE INSERT ON payments_ledger BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM invoices i JOIN financial_audit_logs a ON a.invoice_id=i.invoice_id WHERE i.invoice_id=NEW.invoice_id AND i.case_id=NEW.case_id AND i.currency=NEW.currency AND i.status<>'PENDING_APPROVAL' AND NEW.amount_cents<=i.remaining_cents AND a.log_id=NEW.operation_id AND a.idempotency_key=NEW.idempotency_key AND a.modified_by=NEW.created_by AND a.expected_version=i.version AND a.action_type='PAYMENT') THEN RAISE(ABORT,'PAYMENT_NOT_AUTHORIZED') END;
END;
CREATE TRIGGER invoice_insert_guard BEFORE INSERT ON invoices BEGIN
 SELECT CASE WHEN NEW.version<>0 OR NEW.status<>'DRAFT' OR NEW.subtotal_cents<>0 OR NEW.discount_cents<>0 OR NEW.total_cents<>0 OR NEW.paid_cents<>0 OR NEW.remaining_cents<>0 OR NEW.last_operation_id IS NOT NULL THEN RAISE(ABORT,'SERVER_TOTALS_REQUIRED') END;
END;
CREATE TRIGGER invoice_update_guard BEFORE UPDATE ON invoices BEGIN
 SELECT CASE WHEN NEW.invoice_id<>OLD.invoice_id OR NEW.case_id<>OLD.case_id OR NEW.currency<>OLD.currency OR NEW.created_by<>OLD.created_by OR NEW.created_at<>OLD.created_at OR NEW.version<>OLD.version+1 THEN RAISE(ABORT,'INVALID_INVOICE_UPDATE') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM financial_audit_logs a WHERE a.log_id=NEW.last_operation_id AND a.invoice_id=OLD.invoice_id AND a.expected_version=OLD.version AND a.permissions_epoch=(SELECT version FROM permission_runtime WHERE singleton=1) AND a.authz_expires_at_ms>(CAST(strftime('%s','now') AS INTEGER)*1000+CAST(substr(strftime('%f','now'),4,3) AS INTEGER))) THEN RAISE(ABORT,'AUDITED_OPERATION_REQUIRED') END;
 SELECT CASE WHEN OLD.status='PENDING_APPROVAL' AND NOT EXISTS(SELECT 1 FROM financial_audit_logs a JOIN users u ON u.user_id=a.modified_by WHERE a.log_id=NEW.last_operation_id AND a.action_type='APPROVE' AND u.role='MANAGER' AND u.active=1) THEN RAISE(ABORT,'INVOICE_LOCKED') END;
 SELECT CASE WHEN OLD.status='PENDING_APPROVAL' AND (NEW.subtotal_cents<>OLD.subtotal_cents OR NEW.discount_cents<>OLD.discount_cents OR NEW.total_cents<>OLD.total_cents OR NEW.paid_cents<>OLD.paid_cents OR NEW.remaining_cents<>OLD.remaining_cents OR NEW.deadline IS NOT OLD.deadline OR NEW.note IS NOT OLD.note) THEN RAISE(ABORT,'APPROVE_WITHOUT_EDITING_LOCKED_INVOICE') END;
 SELECT CASE WHEN (SELECT action_type FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) IN('PAYMENT','REFER','OVERDUE_REFRESH') AND (NEW.subtotal_cents<>OLD.subtotal_cents OR NEW.discount_cents<>OLD.discount_cents OR NEW.total_cents<>OLD.total_cents OR NEW.deadline IS NOT OLD.deadline OR NEW.note IS NOT OLD.note) THEN RAISE(ABORT,'ACTION_CANNOT_EDIT_INVOICE_TERMS') END;
 SELECT CASE WHEN (SELECT action_type FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) IN('REFER','OVERDUE_REFRESH') AND (NEW.paid_cents<>OLD.paid_cents OR NEW.remaining_cents<>OLD.remaining_cents) THEN RAISE(ABORT,'ACTION_CANNOT_EDIT_INVOICE_BALANCE') END;
 SELECT CASE WHEN NEW.subtotal_cents<>(SELECT COALESCE(SUM(unit_price_cents),0) FROM invoice_items WHERE invoice_id=OLD.invoice_id) OR NEW.paid_cents<>(SELECT COALESCE(SUM(amount_cents),0) FROM payments_ledger WHERE invoice_id=OLD.invoice_id) THEN RAISE(ABORT,'FINANCIAL_SUM_MISMATCH') END;
 SELECT CASE WHEN NEW.subtotal_cents IS NOT (SELECT json_extract(new_value,'$.subtotal_cents') FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) THEN RAISE(ABORT,'AUDIT_NEW_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN NEW.discount_cents IS NOT (SELECT json_extract(new_value,'$.discount_cents') FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) THEN RAISE(ABORT,'AUDIT_NEW_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN NEW.total_cents IS NOT (SELECT json_extract(new_value,'$.total_cents') FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) THEN RAISE(ABORT,'AUDIT_NEW_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN NEW.paid_cents IS NOT (SELECT json_extract(new_value,'$.paid_cents') FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) THEN RAISE(ABORT,'AUDIT_NEW_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN NEW.remaining_cents IS NOT (SELECT json_extract(new_value,'$.remaining_cents') FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) THEN RAISE(ABORT,'AUDIT_NEW_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN NEW.version IS NOT (SELECT json_extract(new_value,'$.version') FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) THEN RAISE(ABORT,'AUDIT_NEW_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN NEW.status IS NOT (SELECT json_extract(new_value,'$.status') FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) THEN RAISE(ABORT,'AUDIT_NEW_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN (SELECT action_type FROM financial_audit_logs WHERE log_id=NEW.last_operation_id)='REFER' AND NEW.status<>'PENDING_APPROVAL' THEN RAISE(ABORT,'REFERRAL_MUST_LOCK') END;
 SELECT CASE WHEN NEW.status='PENDING_APPROVAL' AND (SELECT action_type FROM financial_audit_logs WHERE log_id=NEW.last_operation_id)<>'REFER' THEN RAISE(ABORT,'INVALID_APPROVAL_STATE') END;
 SELECT CASE WHEN NEW.status='PAID' AND NEW.remaining_cents<>0 THEN RAISE(ABORT,'INVALID_PAID_STATE') END;
 SELECT CASE WHEN NEW.status='PARTIAL' AND NOT(NEW.paid_cents>0 AND NEW.remaining_cents>0) THEN RAISE(ABORT,'INVALID_PARTIAL_STATE') END;
END;
CREATE TRIGGER payments_no_update BEFORE UPDATE ON payments_ledger BEGIN SELECT RAISE(ABORT,'IMMUTABLE_PAYMENT'); END;
CREATE TRIGGER payments_no_delete BEFORE DELETE ON payments_ledger BEGIN SELECT RAISE(ABORT,'IMMUTABLE_PAYMENT'); END;
CREATE TRIGGER financial_audit_no_update BEFORE UPDATE ON financial_audit_logs BEGIN SELECT RAISE(ABORT,'IMMUTABLE_FINANCIAL_AUDIT'); END;
CREATE TRIGGER financial_audit_no_delete BEFORE DELETE ON financial_audit_logs BEGIN SELECT RAISE(ABORT,'IMMUTABLE_FINANCIAL_AUDIT'); END;
CREATE TRIGGER invoices_no_delete BEFORE DELETE ON invoices BEGIN SELECT RAISE(ABORT,'INVOICE_HISTORY_REQUIRED'); END;

-- V2_2_RUNTIME_0018_BEGIN
-- Single-office runtime extensions. Existing candidates.id remains the case key.
PRAGMA foreign_keys=ON;
INSERT INTO users(user_id,role,created_at)
 SELECT primary_owner_id,'MANAGER',strftime('%Y-%m-%dT%H:%M:%fZ','now')
 FROM office_settings WHERE id='office' AND primary_owner_id<>'';
INSERT INTO users(user_id,role,active,created_at)
 SELECT 'staff:'||lower(trim(email)),'STAFF',active,created_at FROM office_members
 WHERE 'staff:'||lower(trim(email)) NOT IN(SELECT user_id FROM users);
INSERT INTO users(user_id,role,created_at) VALUES('system:v2.2','SYSTEM',strftime('%Y-%m-%dT%H:%M:%fZ','now'));
-- Explicitly preserve legacy staff CRM capabilities; new financial powers stay denied.
INSERT INTO permission_changes_audit(audit_id,change_kind,target_role,old_permissions,new_permissions,expected_version,expected_epoch,changed_by,changed_at)
 SELECT 'v22:legacy-staff-policy','ROLE','STAFF','{}',
 '{"view_crm":true,"edit_case":true,"review_case":true,"view_documents":true,"upload_documents":true,"chat":true,"request_assessment":true}',1,1,user_id,strftime('%Y-%m-%dT%H:%M:%fZ','now')
 FROM users WHERE role='MANAGER' AND active=1 ORDER BY user_id LIMIT 1;

CREATE TABLE case_access(
 case_id TEXT NOT NULL REFERENCES candidates(id),user_id TEXT NOT NULL REFERENCES users(user_id),
 granted_by TEXT NOT NULL REFERENCES users(user_id),created_at TEXT NOT NULL,
 PRIMARY KEY(case_id,user_id)
);
CREATE INDEX case_access_user ON case_access(user_id,case_id);
INSERT INTO case_access(case_id,user_id,granted_by,created_at)
 SELECT c.id,u.user_id,m.user_id,strftime('%Y-%m-%dT%H:%M:%fZ','now')
 FROM candidates c JOIN users u ON u.user_id='staff:'||lower(trim(c.assigned_to))
 JOIN users m ON m.user_id=(SELECT user_id FROM users WHERE role='MANAGER' AND active=1 ORDER BY user_id LIMIT 1);

ALTER TABLE candidates ADD COLUMN data_revision INTEGER NOT NULL DEFAULT 0 CHECK(data_revision>=0);
ALTER TABLE candidates ADD COLUMN publication_revision INTEGER NOT NULL DEFAULT 0 CHECK(publication_revision>=0);
ALTER TABLE candidates ADD COLUMN latest_verified_assessment_id TEXT REFERENCES assessment_history(history_id);
ALTER TABLE candidates ADD COLUMN latest_rapid_assessment_id TEXT REFERENCES assessment_history(history_id);
ALTER TABLE candidates ADD COLUMN approval_for_submission_at TEXT;
CREATE TRIGGER v22_profile_revision AFTER UPDATE OF profile,approval_for_submission_at ON candidates
 WHEN NEW.profile<>OLD.profile OR NEW.approval_for_submission_at IS NOT OLD.approval_for_submission_at
 BEGIN UPDATE candidates SET data_revision=data_revision+1 WHERE id=NEW.id; END;
CREATE TRIGGER v22_evidence_insert AFTER INSERT ON documents BEGIN UPDATE candidates SET data_revision=data_revision+1 WHERE id=NEW.candidate_id; END;
CREATE TRIGGER v22_evidence_update AFTER UPDATE OF verified ON documents WHEN NEW.verified<>OLD.verified BEGIN UPDATE candidates SET data_revision=data_revision+1 WHERE id=NEW.candidate_id; END;

CREATE TABLE case_fact_revisions(
 fact_id TEXT PRIMARY KEY NOT NULL,case_id TEXT NOT NULL REFERENCES candidates(id),
 fact_key TEXT NOT NULL,subject_id TEXT NOT NULL,value_json TEXT NOT NULL CHECK(json_valid(value_json)),
 state TEXT NOT NULL CHECK(state IN('REPORTED','EXTRACTED_UNVERIFIED','VERIFIED','REJECTED')),
 evidence_ids TEXT NOT NULL DEFAULT '[]' CHECK(json_valid(evidence_ids) AND json_type(evidence_ids)='array'),
 source_hash TEXT NOT NULL CHECK(length(source_hash)=64),created_by TEXT NOT NULL REFERENCES users(user_id),
 review_note TEXT,created_at TEXT NOT NULL,UNIQUE(case_id,fact_id)
);
CREATE INDEX facts_case_subject ON case_fact_revisions(case_id,subject_id,fact_key,created_at DESC,fact_id);
CREATE TABLE case_fact_heads(
 case_id TEXT NOT NULL REFERENCES candidates(id),subject_id TEXT NOT NULL,fact_key TEXT NOT NULL,
 fact_id TEXT NOT NULL,PRIMARY KEY(case_id,subject_id,fact_key),
 FOREIGN KEY(case_id,fact_id) REFERENCES case_fact_revisions(case_id,fact_id)
);
CREATE TRIGGER fact_history_no_update BEFORE UPDATE ON case_fact_revisions BEGIN SELECT RAISE(ABORT,'IMMUTABLE_FACT_REVISION'); END;
CREATE TRIGGER fact_history_no_delete BEFORE DELETE ON case_fact_revisions BEGIN SELECT RAISE(ABORT,'IMMUTABLE_FACT_REVISION'); END;

CREATE TABLE durable_jobs(
 job_id TEXT PRIMARY KEY NOT NULL,case_id TEXT REFERENCES candidates(id),
 kind TEXT NOT NULL CHECK(kind IN('ASSESSMENT','INGESTION','TRANSCRIPTION','ASSISTANT')),
 request_key TEXT NOT NULL UNIQUE,request_hash TEXT NOT NULL CHECK(length(request_hash)=64),
 payload TEXT NOT NULL CHECK(json_valid(payload)),
 state TEXT NOT NULL DEFAULT 'PENDING' CHECK(state IN('PENDING','RUNNING','RETRY','SUCCEEDED','FAILED','CANCELLED','DEAD_LETTER')),
 attempts INTEGER NOT NULL DEFAULT 0,lease_until_ms INTEGER NOT NULL DEFAULT 0,fence INTEGER NOT NULL DEFAULT 0,
 next_at_ms INTEGER NOT NULL,created_by TEXT NOT NULL REFERENCES users(user_id),created_at TEXT NOT NULL,updated_at TEXT NOT NULL,
 result_ref TEXT,error_code TEXT
);
CREATE INDEX durable_jobs_due ON durable_jobs(state,next_at_ms,lease_until_ms,job_id);
CREATE INDEX durable_jobs_case ON durable_jobs(case_id,created_at DESC,job_id);
CREATE TABLE delivery_outbox(
 event_id TEXT PRIMARY KEY NOT NULL,case_id TEXT NOT NULL REFERENCES candidates(id),
 kind TEXT NOT NULL CHECK(kind IN('PAYMENT_NOTICE','CHAT_NOTICE','PROGRESS_NOTICE','EXPIRY_NOTICE')),
 business_key TEXT NOT NULL UNIQUE,payload_encrypted TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'PENDING' CHECK(state IN('PENDING','LEASED','RETRY','DELIVERED','AMBIGUOUS','CANCELLED','DEAD_LETTER')),
 attempts INTEGER NOT NULL DEFAULT 0,fence INTEGER NOT NULL DEFAULT 0,lease_until_ms INTEGER NOT NULL DEFAULT 0,
 next_at_ms INTEGER NOT NULL,provider_reference TEXT,error_code TEXT,created_at TEXT NOT NULL
);
CREATE INDEX delivery_outbox_due ON delivery_outbox(state,next_at_ms,lease_until_ms,event_id);

CREATE TABLE case_conversations(
 conversation_id TEXT PRIMARY KEY NOT NULL,case_id TEXT NOT NULL UNIQUE REFERENCES candidates(id),
 state TEXT NOT NULL DEFAULT 'BOT_ACTIVE' CHECK(state IN('BOT_ACTIVE','HANDOFF_PENDING','HUMAN_ACTIVE','CLOSED')),
 assigned_to TEXT REFERENCES users(user_id),revision INTEGER NOT NULL DEFAULT 0,
 automation_generation INTEGER NOT NULL DEFAULT 0,last_sequence INTEGER NOT NULL DEFAULT 0,last_client_sequence INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(conversation_id,case_id)
);
CREATE INDEX chat_triage ON case_conversations(state,updated_at,conversation_id);
CREATE TABLE case_chat_messages(
 message_id TEXT PRIMARY KEY NOT NULL,conversation_id TEXT NOT NULL,case_id TEXT NOT NULL,
 sequence INTEGER NOT NULL CHECK(sequence>0),sender_id TEXT NOT NULL REFERENCES users(user_id),
 actor_type TEXT NOT NULL CHECK(actor_type IN('CLIENT','STAFF','ASSISTANT','SYSTEM')),
 client_message_id TEXT NOT NULL,payload_hash TEXT NOT NULL CHECK(length(payload_hash)=64),
 kind TEXT NOT NULL CHECK(kind IN('TEXT','ATTACHMENT','VOICE','ASSESSMENT')),
 body_encrypted TEXT NOT NULL,evidence_id TEXT REFERENCES documents(id),
 automation_generation INTEGER,context_data_revision INTEGER,context_rule_generation INTEGER,in_reply_to_sequence INTEGER,
 created_at TEXT NOT NULL,UNIQUE(conversation_id,sequence),UNIQUE(conversation_id,sender_id,client_message_id),
 FOREIGN KEY(conversation_id,case_id) REFERENCES case_conversations(conversation_id,case_id)
);
CREATE INDEX chat_replay ON case_chat_messages(conversation_id,sequence,message_id);
CREATE TRIGGER chat_message_guard BEFORE INSERT ON case_chat_messages BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM case_conversations r WHERE r.conversation_id=NEW.conversation_id AND r.case_id=NEW.case_id AND r.state<>'CLOSED' AND r.last_sequence+1=NEW.sequence) THEN RAISE(ABORT,'CHAT_SEQUENCE_CONFLICT') END;
 SELECT CASE WHEN NEW.evidence_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM documents WHERE id=NEW.evidence_id AND candidate_id=NEW.case_id) THEN RAISE(ABORT,'CHAT_ATTACHMENT_SCOPE') END;
 SELECT CASE WHEN NEW.actor_type='ASSISTANT' AND NOT EXISTS(SELECT 1 FROM case_conversations r JOIN candidates c ON c.id=r.case_id WHERE r.conversation_id=NEW.conversation_id AND r.state='BOT_ACTIVE' AND r.automation_generation=NEW.automation_generation AND r.last_client_sequence=NEW.in_reply_to_sequence AND c.data_revision=NEW.context_data_revision AND (SELECT generation FROM rule_activation WHERE singleton=1)=NEW.context_rule_generation) THEN RAISE(ABORT,'ASSISTANT_FENCED') END;
END;
CREATE TRIGGER chat_message_apply AFTER INSERT ON case_chat_messages BEGIN
 UPDATE case_conversations SET last_sequence=NEW.sequence,last_client_sequence=CASE WHEN NEW.actor_type='CLIENT' THEN NEW.sequence ELSE last_client_sequence END,updated_at=NEW.created_at WHERE conversation_id=NEW.conversation_id;
END;
CREATE TRIGGER chat_message_immutable BEFORE UPDATE ON case_chat_messages BEGIN SELECT RAISE(ABORT,'IMMUTABLE_CHAT_MESSAGE'); END;
CREATE TRIGGER chat_message_no_delete BEFORE DELETE ON case_chat_messages BEGIN SELECT RAISE(ABORT,'IMMUTABLE_CHAT_MESSAGE'); END;
CREATE TABLE case_chat_receipts(
 conversation_id TEXT NOT NULL REFERENCES case_conversations(conversation_id),user_id TEXT NOT NULL REFERENCES users(user_id),
 delivered_sequence INTEGER NOT NULL DEFAULT 0,read_sequence INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL,
 CHECK(read_sequence>=0 AND read_sequence<=delivered_sequence),PRIMARY KEY(conversation_id,user_id)
);
CREATE TRIGGER chat_receipt_insert_guard BEFORE INSERT ON case_chat_receipts WHEN NEW.delivered_sequence>(SELECT last_sequence FROM case_conversations WHERE conversation_id=NEW.conversation_id) BEGIN SELECT RAISE(ABORT,'INVALID_CHAT_RECEIPT'); END;
CREATE TRIGGER chat_receipt_update_guard BEFORE UPDATE ON case_chat_receipts WHEN NEW.conversation_id<>OLD.conversation_id OR NEW.user_id<>OLD.user_id OR NEW.delivered_sequence<OLD.delivered_sequence OR NEW.read_sequence<OLD.read_sequence OR NEW.delivered_sequence>(SELECT last_sequence FROM case_conversations WHERE conversation_id=NEW.conversation_id) BEGIN SELECT RAISE(ABORT,'INVALID_CHAT_RECEIPT'); END;
CREATE TABLE case_in_app_notifications(
 notification_id TEXT PRIMARY KEY NOT NULL,user_id TEXT NOT NULL REFERENCES users(user_id),case_id TEXT NOT NULL REFERENCES candidates(id),
 kind TEXT NOT NULL,resource_id TEXT NOT NULL,business_key TEXT NOT NULL UNIQUE,created_at TEXT NOT NULL,read_at TEXT
);
CREATE INDEX notification_unread ON case_in_app_notifications(user_id,read_at,created_at DESC,notification_id);
CREATE TABLE case_chat_transitions(
 transition_id TEXT PRIMARY KEY NOT NULL,conversation_id TEXT NOT NULL REFERENCES case_conversations(conversation_id),
 request_key TEXT NOT NULL UNIQUE,request_hash TEXT NOT NULL CHECK(length(request_hash)=64),
 expected_revision INTEGER NOT NULL,old_state TEXT NOT NULL,new_state TEXT NOT NULL,
 assigned_to TEXT REFERENCES users(user_id),actor_id TEXT NOT NULL REFERENCES users(user_id),created_at TEXT NOT NULL
);
CREATE TRIGGER chat_transition_guard BEFORE INSERT ON case_chat_transitions BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM case_conversations r WHERE r.conversation_id=NEW.conversation_id AND r.revision=NEW.expected_revision AND r.state=NEW.old_state AND ((NEW.old_state='BOT_ACTIVE' AND NEW.new_state IN('HANDOFF_PENDING','CLOSED')) OR (NEW.old_state='HANDOFF_PENDING' AND NEW.new_state IN('HUMAN_ACTIVE','CLOSED')) OR (NEW.old_state='HUMAN_ACTIVE' AND NEW.new_state IN('HANDOFF_PENDING','BOT_ACTIVE','CLOSED')) OR (NEW.old_state='CLOSED' AND NEW.new_state='HANDOFF_PENDING'))) THEN RAISE(ABORT,'CHAT_TRANSITION_CONFLICT') END;
 SELECT CASE WHEN NEW.new_state='HUMAN_ACTIVE' AND NEW.assigned_to IS NULL THEN RAISE(ABORT,'CHAT_OWNER_REQUIRED') END;
END;
CREATE TRIGGER chat_transition_apply AFTER INSERT ON case_chat_transitions BEGIN UPDATE case_conversations SET state=NEW.new_state,assigned_to=NEW.assigned_to,revision=revision+1,automation_generation=automation_generation+1,updated_at=NEW.created_at WHERE conversation_id=NEW.conversation_id; END;
CREATE TRIGGER chat_transition_no_update BEFORE UPDATE ON case_chat_transitions BEGIN SELECT RAISE(ABORT,'IMMUTABLE_CHAT_TRANSITION'); END;
CREATE TRIGGER chat_transition_no_delete BEFORE DELETE ON case_chat_transitions BEGIN SELECT RAISE(ABORT,'IMMUTABLE_CHAT_TRANSITION'); END;

CREATE TABLE office_billing_settings(
 singleton INTEGER PRIMARY KEY CHECK(singleton=1),currency TEXT CHECK(currency IS NULL OR(length(currency)=3 AND currency NOT GLOB '*[^A-Z]*')),
 updated_by TEXT REFERENCES users(user_id),updated_at TEXT NOT NULL
);
INSERT INTO office_billing_settings VALUES(1,NULL,NULL,strftime('%Y-%m-%dT%H:%M:%fZ','now'));
CREATE TABLE office_service_catalog(
 service_id TEXT PRIMARY KEY NOT NULL,name_ar TEXT NOT NULL,name_en TEXT NOT NULL,
 price_cents INTEGER NOT NULL CHECK(typeof(price_cents)='integer' AND price_cents BETWEEN 0 AND 9007199254740991),
 currency TEXT NOT NULL CHECK(length(currency)=3 AND currency NOT GLOB '*[^A-Z]*'),active INTEGER NOT NULL CHECK(active IN(0,1)),
 version INTEGER NOT NULL DEFAULT 1,updated_by TEXT NOT NULL REFERENCES users(user_id),updated_at TEXT NOT NULL
);
-- V2_2_RUNTIME_0018_END
```

<!-- V2_2_CANONICAL_SQL_END -->

## 10. مراجع التنفيذ الحتمية

هذه الدوال تعمل في طبقة الخادم/الاختبارات. لا تنقل تسعير الفاتورة إلى المتصفح. catalog الصلاحيات معامل خادمي موثوق يضم قدرات المنتج الحالية، ولا يُبنى من request body. حساب بداية/نهاية يوم Toronto أدناه مستقل عن offset ثابت ويختبر DST.

<!-- V2_2_CONTROLS_BEGIN -->

```javascript
const zone='America/Toronto';
const dayFormat=new Intl.DateTimeFormat('en-CA',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit'});
export function torontoDate(epochMs){
 if(!Number.isSafeInteger(epochMs))throw new Error('INVALID_TIMESTAMP');
 const p=Object.fromEntries(dayFormat.formatToParts(new Date(epochMs)).map(x=>[x.type,x.value]));
 return `${p.year}-${p.month}-${p.day}`;
}
export function nextTorontoMidnightMs(epochMs){
 const day=torontoDate(epochMs);let lo=epochMs,hi=epochMs+36*60*60*1000;
 while(hi-lo>1){const mid=lo+Math.floor((hi-lo)/2);if(torontoDate(mid)===day)lo=mid;else hi=mid;}
 return hi;
}
export function openAllActive(state,now){return state.enabled===true&&torontoDate(now)===state.localDate&&now<state.untilMs;}
const staffCaps=new Set(['view_crm','view_financials','create_invoice','edit_invoice','edit_discount','record_payment','send_payment_notice','export_invoice_pdf']);
const managerCaps=new Set([...staffCaps,'manage_permissions','open_staff_access','seal_rules','approve_invoice']);
const systemCaps=new Set(['process_ingestion','recompute_assessment','dispatch_outbox','refresh_overdue','expire_staff_access']);
const baseCatalog=Object.fromEntries([...new Set([...managerCaps,...systemCaps])].map(k=>[k,{staffAssignable:staffCaps.has(k),systemAssignable:systemCaps.has(k)}]));
export function effectivePermission(actor,cap,rolePermissions,customPermissions,openState,now,catalog=baseCatalog){
 if(actor.active!==true||!Object.hasOwn(catalog,cap))return false;
 if(actor.role==='MANAGER')return true;
 if(actor.role==='SYSTEM')return catalog[cap].systemAssignable===true;
 if(actor.role!=='STAFF'||catalog[cap].staffAssignable!==true)return false;
 if(openAllActive(openState,now))return true;
 if(Object.hasOwn(customPermissions,cap))return customPermissions[cap]===true;
 return rolePermissions[cap]===true;
}
const max=9007199254740991n;
function cents(value){if(!Number.isSafeInteger(value)||value<0)throw new Error('INTEGER_CENTS_REQUIRED');return BigInt(value);}
export function parseCents(value){
 if(typeof value!=='string'||!/^\d+(\.\d{1,2})?$/.test(value))throw new Error('INVALID_MONEY_INPUT');
 const [whole,fraction='']=value.split('.'),result=BigInt(whole)*100n+BigInt(fraction.padEnd(2,'0'));
 if(result>max)throw new Error('MONEY_LIMIT_EXCEEDED');return Number(result);
}
export function invoiceTotals(items,discountCents,payments){
 const subtotal=items.reduce((n,item)=>{const value=cents(item.unitPriceCents);if(item.isFree&&value!==0n)throw new Error('FREE_ITEM_MUST_BE_ZERO');return n+value;},0n);
 const discount=cents(discountCents),paid=payments.reduce((n,v)=>n+cents(v),0n);
 if(subtotal>max||discount>subtotal)throw new Error('INVALID_DISCOUNT_OR_TOTAL');
 const total=subtotal-discount;if(paid>total)throw new Error('OVERPAYMENT_NOT_SUPPORTED');
 return {subtotal_cents:Number(subtotal),discount_cents:Number(discount),total_cents:Number(total),paid_cents:Number(paid),remaining_cents:Number(total-paid)};
}
export function invoiceStatus(totals,deadline,pending,now){
 if(pending)return 'PENDING_APPROVAL';if(totals.remaining_cents===0)return 'PAID';
 if(deadline&&deadline<torontoDate(now))return 'OVERDUE';
 return totals.paid_cents>0?'PARTIAL':'DRAFT';
}
export function signatureStatus(signature){return signature?'SIGNED':'EMPTY';}
export function rcipPolicy({approvedAtMs,recommendationIssuedOn,ranges}){
 const date=torontoDate(approvedAtMs),matches=ranges.filter(r=>r.from<=date&&(r.to===null||date<r.to));
 if(matches.length!==1)return {status:'RULE_UNAVAILABLE',date};
 const year=Number(date.slice(0,4)),program=year===2026?'RCIP_PILOT':year>=2027?'RCIP_PERMANENT':null;
 if(!program||matches[0].program!==program)return {status:'RULE_UNAVAILABLE',date};
 if(program==='RCIP_PERMANENT'&&recommendationIssuedOn?.startsWith('2026-'))return {status:'FAIL',code:'RECOMMENDATION_OUTSIDE_APPROVED_POLICY',date,program};
 return {status:'RESOLVED',date,program,ruleId:matches[0].ruleId};
}
```

<!-- V2_2_CONTROLS_END -->

## 11. الملفات المرتبطة والترقية دون تكرار

عقود الفوترة والصلاحيات الآلية في `contracts/v2_2.schema.json`. المعايير AC-51–AC-60 تضاف إلى AC-01–AC-50 دون استبدال الحزم السابقة. changing discount يتطلب `edit_discount` حتى إذا جاء ضمن CREATE أو EDIT؛ PAYMENT وREFER وOVERDUE_REFRESH لا تعدل شروط الفاتورة، والـaudit يحفظ اللقطة الكاملة للبنود والترويسة والأرصدة قبل/بعد العملية. جميع الحالات الفعلية تبقى NOT_RUN حتى أدلتها.


- حدّث 00_START_HERE و01–10 والـchangelog وDELIVERY_MANIFEST لتشير إلى v2.2 وإلى سلطة هذا الملف؛ لا تعيد شروط STALE أو موافقتين أو consent لمحوّل NOC أو RCIP grace من ملف قديم.
- وحّد الأدوار في middleware وsession projections وDB وUI والاختبارات إلى الأربع. احتفظ بتسجيل الدخول الحالي؛ اربط actor/user_id بهويته الموثقة. لا تعِد استعمال أدوار قديمة كقدرة خامسة.
- حدّث schema وعقود SignatureRecord وhelpers وtests إلى توقيع ثابت مع حفظ snapshot الأصلي، واحذف auto-invalidation وحظر submit المعتمد على STALE. لا تمسح توقيعاً أو لقطة تاريخية أو موافقة محفوظة لتطبيق هذا التغيير.
- أزل consentId/approvedConsent من NocSuggestionRequest والمحول والـjob ومسار الرفض والاختبارات، دون تغيير آلية التوليد والاستشهادات والمراجعة المهنية أو حذف سجلات خارج النطاق.
- استبدل اختبار RCIP الانتقالي بمعيار تاريخ اعتماد الإرسال Toronto والنسخة المعتمدة ورفض توصية 2026 للمسار الدائم. احذف branch/grace/states/screens الانتقالية، لا المصادر أو التاريخ السابق.
- حدّث حراس BUILDING→SEALED وDTOs والـledger إلى مدير واحد؛ احذف count>=2 واختلاف المؤلف كشروط للنشر. أبقِ منع INSERT SEALED وقفل الحمولة بعد الختم وفحوص الـhash والشمول وعدم التداخل.
- migration الجديدة توسعة للمخطط الفعلي. لا تطبقها قبل فحص الأسماء والتاريخ والفهارس والصفوف القديمة، ولا تنشئ users أو assessment_history مرة ثانية إذا كانا موجودين. وحّد أعمدة الدفعات القديمة في طبقة توافق ومهمة forward موثقة، لا بتكرار الجداول أو إسقاط البيانات.
- حدّث contracts الخاصة بالفوترة والصلاحيات: amounts أعداد صحيحة safe وغير سالبة، عملة صريحة، requestKey/expectedVersion/epoch، وحظر totals/roles/private keys من واجهة العميل. JSON يبقى TEXT في D1.
- استخدم outbox/وظائف الإرسال الحالية، ومكتبة PDF والخطوط والـR2 الحالي؛ لا payment gateway أو عملة مفترضة أو مزود SMS صوري أو مخزن أسرار موازياً.
- الملفات القديمة والنصوص الخام التي تحفظ للتدقيق توسم مصادر غير تنفيذية. فهرس migrations لا يضم نسخ SQL التاريخية/الأمثلة، وفهرس schema التنفيذي يضم كل جدول مرة واحدة.

## 12. اختبارات القبول وبوابة الجودة

اختبارات الفوترة الإلزامية، دون إسقاط أي حالة:

1. إنشاء فاتورة تضم خدمة كتالوج وخدمة مخصصة وخدمة مجانية مع خصم؛ تطابق مجموع البنود والحساب الخادمي، وصحة عرض المجاني والسعر المرجعي.
2. تسجيل Cash جزئية مع مهلة غير منتهية=>PARTIAL ورصيد متبقٍ صحيح.
3. تسجيل Zelle مع سند R2 خاص=>PAID عندما يغطي المتبقي، مع رابط سند محمي.
4. تكرار idempotency_key للدفعة=>رفض دون سجل دفعة أو audit/إشعار مكرر؛ اختلاف payload يرد conflict، وضياع ACK لا يضاعف الدفع.
5. الإحالة=>PENDING_APPROVAL، ومحاولات تعديل بند أو خصم أو دفعة أثناء القفل ترفض؛ STAFF لا يعتمد؛ MANAGER يعتمد وحده ثم تستعاد الحالة المحسوبة.
6. زر الإشعار يرسل عبر مزود اختبار معتمد النص المالي المحدود، وتصدر نسخة PDF عربية وإنجليزية من نفس بيانات الخادم مع نطاق وصول صحيح.
7. موظف بلا view_financials لا يرى بطاقات المال، ويرفض API طلبه 403؛ يستطيع CLIENT رؤية فاتورته المصرح بها فقط دون إحصاءات المكتب أو سندات حالة أخرى.

اختبارات v2.2 الإضافية:

- محاولة INSERT SEALED ترفض؛ مدير واحد ينشئ ويختم حزمته بنفسه بعد التحقق؛ ناقص المصدر/الحمولة/المدى يرفض؛ المختوم لا يعدل، والتداخل يمنع الختم/النشر.
- NOC Adapter يعمل بلا معرّف موافقة أو guard موافقة، ويظل رافضاً لغياب RBAC أو حالة أخرى أو مصدر NOC/اقتباس غير صحيح؛ لا تتغير خوارزميته.
- تعديل اسم/بيانات/مستند بعد التوقيع لا يزيله أو يحوله إلى STALE ولا يولد وقت توقيع جديداً؛ يبقى hash اللقطة الأصلية مع تاريخ تعديل الملف منفصلاً.
- تاريخ اعتماد UTC قرب رأس السنة يتحول إلى Toronto أولاً؛ 2026 Pilot و2027 دائم بحسب نطاق المدير، وتوصية 2026 في الدائم ترفض، ولا branch/grace/شاشة انتقالية.
- تبديل STAFF permissions يغير D1 والـaudit والـepoch ذرياً؛ KV قديم لا يمنح الصلاحية الملغاة؛ المدير وSYSTEM محميان؛ CLIENT لا يعدل Toggles.
- فتح STAFF يتوقف عند منتصف الليل مع KV قديم وcron متوقف؛ اختبر يومي DST بطولي 23 و25 ساعة، وقفل صلاحيات مالية أثناء طلب قيد التنفيذ.
- إرسالان متزامنان لنفس دفعة/فاتورة، stale version، amount كسري/سالب/زائد، discount أكبر من subtotal، خلط case أو currency، R2 سند غير مصرح، وفشل عند كل خطوة batch: لا فقد ولا صفوف جزئية.
- JSON فاسد أو role خارج الأربع أو مبلغ مخزن بغير INTEGER يرفض؛ جميع الجداول والفهارس وFK/quick_check وappend-only تعمل على baseline ومهمة upgrade الفعلية.
- فحص التسجيل وOTP/password والمسودة والرجوع والتوقيع الثابت والإرسال والاستعلام المحدود والمحادثة والتحويل وRAPID_SCREENING، مع RTL/LTR والأجهزة وانقطاع الاتصال ومحاولات الوصول غير المخولة.
- فحص Query Plans/pagination والتحميل المتزامن ومهلة queue وفشل provider وbackup/restore ضمن ملف السعة المعتمد. لا يدعي benchmark لم ينفذ ولا يعطل ميزات سابقة للحصول على test أخضر.

تحقق آلياً من أن المخطط التنفيذي لا يكرر CREATE TABLE، وأن جميع `_cents` من نوع INTEGER مع حدود صحيحة، وكل JSON من TEXT، وأن عملية الدفع والتفويض والتدقيق batch ذرية. سجّل command وexit code وrepo SHA وبيئة التشغيل والمخرجات الخام. الحالات PASS/FAIL/BLOCKED/NOT_RUN منفصلة؛ اختبار مرجع SQLite أو helper ليس اختبار API أو E2E أو دليلاً على نشر حي. لا تستعمل TODO أو no-op أو مزود وهمي خارج اختبارات معلنة، ولا تختلق SHA أو موافقة أو نجاح استعادة/إرسال.

هذه المهمة لا تنشر موقعاً حياً. اكتب الملفات وراجعها واختبرها محلياً وفي بيئة اختبار مصرح بها، وحدّث الأرشيف ببصمة محسوبة من بايتاته. وجود مدخل خارجي ناقص يسجل عائقاً دقيقاً للقدرة التابعة فقط؛ لا يخترع بديلاً ولا يخفي الاختبار الناقص. لا تعلن الجاهزية التنفيذية الكاملة حتى تنجح اختبارات التطبيق المطلوبة فعلياً.

## 13. النص المصدري الحرفي غير التنفيذي

المحتوى التالي من المرفق الحالي محفوظ كاملاً دون إسقاط ألفاظه. تكرارات DDL وموضع اللصق داخل الاقتباس سجلات مصدرية فقط؛ المخطط التنفيذي الوحيد هو القسم 9، وقرارات الأقسام 0–12 تحسم التعارض. لا ينسخ هذا الملحق إلى migrations ولا ينفذ كمهمة ثانية.

```text
@context: Principal Systems Architect & Lead Integration Engineer
⛔ ZERO-TOLERANCE. تنفيذ صارم. لا شرح، لا تحليل، لا حوار.

🎯 المهمة: ادمج النصوص اصافات للنظام   (الإضافات الجديدة) بدقة متناهية داخل حزمة المعمارية الأساسية (v2.1).

━━━ قواعد الدمج الإلزامية ━━━
1. التوافق التقني: ألزم النظام ببيئة Cloudflare D1 SQLite (استخدام INTEGER حصراً للمبالغ المالية، وTEXT للـ JSON، ومنع استخدام REAL أو JSONB).
2. حل التناقضات: افحص النصوص جرفيا المرفق وأزل أي تعارض منطقي أو برمجي مع الهيكل الأساسي (مثل الصلاحيات، الجداول، أو قواعد الأعمال).
3. الدقة العالية: لا تحذف أي عنصر جوهري، ولا تخترع قواعد غير موجودة، واضمن تطابق المنطق 100%.
4. الأداء والسرعة: حسّن الاستعلامات (Queries)، أضف الفهارس (Indexes) اللازمة للجداول، واضمن استخدام (Transactions/Batch) في العمليات الحساسة لضمان أقصى سرعة واستجابة.
5. المخرجات: أخرج النص النهائي الموحد فقط (بدون أي مقدمات أو شروحات أو علامات Markdown إضافية غير ضرورية)، جاهزاً للنسخ المباشر وتسليمه إلى Claude Code.

━━━ النصوص المرفقه هنا  كلها(    @context: كبير مهندسي الأنظمة ومهندس الإنتاج الرئيسي
⛔ سياسة عدم التسامح مطلقاً (Zero-Tolerance). إسكات أي نص حواري. ممنوع الشرح. تنفيذ فقط.

🎯 المهمة: دمج التعديلات النصية المرفقة في ملف `09_CLAUDE_CODE_EXECUTION.md` والملفات المرتبطة بها، مع ضمان التوافق التام مع بيئة Cloudflare D1 (ممنوع استخدام JSONB أو خصائص PostgreSQL). تحديث الأرشيف، وإخراج الملفات المطلوبة.

━━━ التعديلات النصية المدخلة ━━━
[قم بلصق النص الفعلي للتعديلات هنا — مثل قسم Enterprise RBAC والـ 4 Roles]

━━━ خطوات التنفيذ ━━━

1. الدمج والإصلاح:
- تطبيق التعديلات بدقة داخل ملف `09_CLAUDE_CODE_EXECUTION.md` والملفات المرتبطة بها.
- ضمان الالتزام بقاعدة (Zero-Guesswork) وحل أي تناقضات منطقية.
- الجودة الصارمة: يُمنع منعاً باتاً استخدام `// TODO` أو أي كود وهمي أو افتراضات برمجية.

2. صيغة المخرجات (صارمة):
لا تُخرج أي نص حواري، تحيات، أو شروحات. أخرج فقط الكتلتين التاليتين:

=== الكتلة 1: 09_CLAUDE_CODE_EXECUTION.md ===
[المحتوى النهائي الكامل بصيغة Markdown لملف 09_CLAUDE_CODE_EXECUTION.md هنا]

=== الكتلة 2: أوامر تحديث الأرشيف (Bash Script) ===
[أخرج فقط كود Bash جاهز للتشغيل على Terminal يقوم بضغط المجلد، ثم حساب بصمة SHA-256 الحقيقية للأرشيف، وطباعة المسار والبصمة. لا تختلق بصمة أو مسار من عندك.]

━━━ القيود ━━━
- يُمنع النشر على أي موقع حي.
- يُمنع كتابة أي نص خارج الكتلتين المطلوبتين.
- يُمنع اختراع قواعد أو تجاوز القرارات المعمارية المتفق عليها.



​قاعدة اعتماد وقفل القواعد القانونية (Single-Authority Manager Seal):
«يجب أن ينتج استيراد القواعد حمولة (Payload) متكاملة، وتُعتمد وتُقفل القاعدة (SEALED) بموافقة واحدة من المدير (MANAGER / RULES_APPROVER) فقط؛ مع السماح للمدير بإنشاء القاعدة وقفلها مباشرة في خطوة واحدة دون اشتراط مراجع خارجي أو تعدد حسابات.»



محوّل اقتراح رمز المهنة (Internal NOC Suggestion Adapter): يُحذف شرط الموافقة تماماً، ويستمر عمل المحوّل كما هو دون أي تغيير في آليته التشغيلية.



[RCIP Transitional Rule — Zero-Tolerance]

في نظام التقييم، ألغِ تماماً أي منطق (Logic) يتعامل مع التواريخ الانتقالية أو فترات الصلاحية (Grace Periods) لبرنامج RCIP. 
يعتمد النظام حصراً على تاريخ اعتماد الطلب للإرسال (بتوقيت كندا) ومطابقته مع نطاق التواريخ المفعّل في سجل القواعد المعتمد من المدير: 
- في 2026 يُطبّق قواعد Pilot.
- في 2027 يُطبّق قواعد البرنامج الدائم ويرفض تلقائياً أي توصية صادرة في 2026. 

يُمنع إضافة أي حالات (States) أو شاشات مراجعة لهذا الغرض.




> إلغاء إبطال التوقيع التلقائي:
> أُلغي هذا الشرط بالكامل. التوقيع يبقى ثابتاً ولا يتحول إلى حالة (STALE) عند تعديل بيانات العميل، ولن يطالب النظام بإعادة التوقيع تلقائياً لتجنب أي تعقيد أو تعطيل لعمل المكتب.


هذا قسم جديد حديث ذكي الي مؤتمت سلس بلا تعقيدات 
@context: Principal Systems Architect & Lead Production Engineer (Opus 5)
⛔ Zero-Tolerance. إسكات كامل لأي حشو أو سرد نظري. تنفيذ جراحي مؤتمت ونظيف.

🎯 المهمة: هندسة محرك التنفيذ الآلي المتكامل لإدارة المستندات، المدفوعات، والصلاحيات (Zero-Touch Workflow Engine)، متوافق كلياً مع Cloudflare D1 و Private R2.

━━━ 1. هندسة تدفق العمل الآلي واستخراج البيانات (Zero-Touch Ingestion Engine) ━━━
- المدخلات المباشرة: رفع المستند أو الملف الصوتي للعميل يُطلق الحدث برمجياً (Event-Driven Webhook).
- الاستخراج والتنظيف: محرك AI يقرأ المستند ويستخرج الحقول، ويقارنها مع قواعد النظام (NOC & RCIP).
- التحديث الفوري (Auto-Recompute): رفع المستند يرقي الحالة إلى `VERIFIED`، يستدعي `canonical_input_hash` لمنع التكرار، ويحفظ النسخة في `assessment_history` (Append-Only).
- التوجيه التلقائي: يرسل إشعاراً مؤتمتاً بالصيغة: "أنجزت X%. الخطوة التالية: [اسم الخدمة]" عبر Outbox (SMS/Email).

━━━ 2. محرك الفواتير والمدفوعات الآمن (Billing & Payments Core) ━━━
- الربط الإلزامي: كل فاتورة مرتبطة بـ `case_id` حصراً. تُحسب الإجماليات في الخادم (Server-Side) وتُحفظ في D1 (يُمنع حسابها في المتصفح).
- دفتر الدفعات وسندات R2: طرق الدفع (Cash, Check, Zelle, Cash App). تُرفع السندات إلى `Private R2` وتُربط بالدفعة.
- حماية التكرار: إلزامية وجود `idempotency_key` فريد لكل عملية دفع.
- الموافقة الإدارية: خيار الإحالة يحول الفاتورة إلى `PENDING_APPROVAL` ويغلقها حتى يعتمدها المدير (MANAGER).
- سجل التدقيق المالي: أي تعديل على الفواتير أو الخصومات يُسجل في جدول تدقيق مستقل.

━━━ 3. نظام الصلاحيات الديناميكي المتقدم (UI-Driven Dynamic RBAC) ━━━
- الأدوار الأربعة الصارمة: `CLIENT`, `STAFF` (يشمل الاستقبال والمستشارين), `MANAGER`, `SYSTEM`. يُمنع إنشاء أدوار جديدة.
- إدارة بلا نصوص (Zero-Text-Input UI): يدير المدير الصلاحيات حصراً عبر مفاتيح تبديل زجاجية (Toggles) لتحديث `role_permissions` أو `custom_permissions`.
- الدرع التقني KV Cache: تُخزن الصلاحيات في Cloudflare KV لتسريع الاستجابة وتُمسح لحظياً عند أي تعديل.
- الوضع المفتوح الشامل: مفتاح واحد لفتح الصلاحيات مؤقتاً لموظفي `STAFF`، مرتبط بتوقيت كندا `America/Toronto` مع إغلاق إجباري تلقائي (Auto-Kill Switch) منتصف الليل.
- حماية الجذر: حراسة برمجية تمنع تعديل صلاحيات `MANAGER` أو `SYSTEM`. كل تغيير يُسجل في `permission_changes_audit` عبر Transaction/Batch واحدة.

━━━ 4. مخطط قاعدة البيانات المعتمد (Cloudflare D1 SQLite Schema) ━━━
(تنفيذ حرفي، يمنع استخدام REAL للمبالغ المالية)

PRAGMA foreign_keys = ON;

-- جدول المستخدمين والصلاحيات المخصصة
CREATE TABLE users (
    user_id TEXT PRIMARY KEY,
    role TEXT NOT NULL CHECK (role IN ('CLIENT', 'STAFF', 'MANAGER', 'SYSTEM')),
    custom_permissions TEXT DEFAULT '{}', -- JSON string
    created_at TEXT NOT NULL
);

CREATE TABLE role_permissions (
    role TEXT PRIMARY KEY CHECK (role IN ('STAFF')), -- فقط STAFF لأن MANAGER و SYSTEM محميان
    permissions_json TEXT NOT NULL, -- {"view_crm": true, "view_financials": false}
    updated_at TEXT NOT NULL
);

CREATE TABLE permission_changes_audit (
    audit_id TEXT PRIMARY KEY,
    target_user_id TEXT, -- null إذا كان التعديل على role_permissions
    target_role TEXT,
    old_permissions TEXT NOT NULL,
    new_permissions TEXT NOT NULL,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL
);

-- سجل التقييمات (Append-Only)
CREATE TABLE assessment_history (
    history_id TEXT PRIMARY KEY,
    case_id TEXT NOT NULL,
    canonical_input_hash TEXT NOT NULL,
    payload TEXT NOT NULL,
    created_at TEXT NOT NULL
);

-- الفواتير
CREATE TABLE invoices (
    invoice_id TEXT PRIMARY KEY,
    case_id TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('DRAFT', 'PENDING_APPROVAL', 'PARTIAL', 'PAID', 'OVERDUE')),
    subtotal_cents INTEGER NOT NULL DEFAULT 0,
    discount_cents INTEGER DEFAULT 0,
    total_cents INTEGER NOT NULL DEFAULT 0,
    paid_cents INTEGER DEFAULT 0,
    remaining_cents INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- بنود الفاتورة (جديد)
CREATE TABLE invoice_items (
    item_id TEXT PRIMARY KEY,
    invoice_id TEXT NOT NULL,
    service_name TEXT NOT NULL,
    is_custom INTEGER DEFAULT 0,
    is_free INTEGER DEFAULT 0,
    unit_price_cents INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id) ON DELETE CASCADE
);

-- سجل الدفعات
CREATE TABLE payments_ledger (
    payment_id TEXT PRIMARY KEY,
    invoice_id TEXT NOT NULL,
    case_id TEXT NOT NULL,
    amount_cents INTEGER NOT NULL,
    payment_method TEXT NOT NULL CHECK (payment_method IN ('CASH', 'CHEQUE', 'ZELLE', 'CASH_APP')),
    payment_date TEXT NOT NULL,
    receipt_r2_key TEXT,
    idempotency_key TEXT UNIQUE NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id)
);

-- سجل التدقيق المالي
CREATE TABLE financial_audit_logs (
    log_id TEXT PRIMARY KEY,
    invoice_id TEXT NOT NULL,
    modified_by TEXT NOT NULL,
    action_type TEXT NOT NULL,
    old_value TEXT,
    new_value TEXT,
    timestamp TEXT NOT NULL
);
> 



@context: Principal Systems Engineer & Lead Production Engineer
⛔ ZERO-TOLERANCE. تنفيذ صارم فقط. يُمنع الشرح أو التحليل. تسليم الكود والمواصفات النهائية فقط.

🎯 المهمة: بناء "قسم الحسابات والفوترة" (Accounting & Billing Module) كاملاً، والمتوافق 100% مع Cloudflare D1 و R2، ومربوط بملفات العملاء ونظام الصلاحيات الديناميكي.

━━━ 1. مخطط قاعدة البيانات (D1 SQLite Migration) ━━━
(نفّذ هذا المخطط بالحرف. يُمنع استخدام REAL للمبالغ لتجنب أخطاء الفواصل العشرية. استخدم INTEGER لحفظ السنتات).

PRAGMA foreign_keys = ON;

-- 1. الفواتير (ترويسة الفاتورة)
CREATE TABLE invoices (
    invoice_id TEXT PRIMARY KEY,
    case_id TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('DRAFT', 'PENDING_APPROVAL', 'PARTIAL', 'PAID', 'OVERDUE')),
    subtotal_cents INTEGER NOT NULL DEFAULT 0,
    discount_cents INTEGER NOT NULL DEFAULT 0,
    total_cents INTEGER NOT NULL DEFAULT 0,
    paid_cents INTEGER NOT NULL DEFAULT 0,
    remaining_cents INTEGER NOT NULL DEFAULT 0,
    deadline TEXT,
    note TEXT,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (case_id) REFERENCES cases(case_id)
);

-- 2. بنود الفاتورة (الخدمات، الخصومات، والمجانية)
CREATE TABLE invoice_items (
    item_id TEXT PRIMARY KEY,
    invoice_id TEXT NOT NULL,
    service_name TEXT NOT NULL,
    is_custom INTEGER DEFAULT 0,  -- 1 إذا كانت خدمة مضافة يدوياً
    is_free INTEGER DEFAULT 0,    -- 1 إذا كانت خدمة مجانية
    unit_price_cents INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id) ON DELETE CASCADE
);

-- 3. سجل الدفعات (المدفوعات الجزئية والكاملة)
CREATE TABLE payments_ledger (
    payment_id TEXT PRIMARY KEY,
    invoice_id TEXT NOT NULL,
    case_id TEXT NOT NULL,
    amount_cents INTEGER NOT NULL,
    method TEXT NOT NULL CHECK (method IN ('CASH', 'CHEQUE', 'ZELLE', 'CASH_APP')),
    paid_at TEXT NOT NULL,
    receipt_r2_key TEXT,
    notes TEXT,
    idempotency_key TEXT UNIQUE NOT NULL, -- لحماية النظام من التكرار
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id)
);

-- 4. سجل التدقيق المالي
CREATE TABLE financial_audit_logs (
    log_id TEXT PRIMARY KEY,
    invoice_id TEXT NOT NULL,
    modified_by TEXT NOT NULL,
    action_type TEXT NOT NULL,
    old_value TEXT,
    new_value TEXT,
    timestamp TEXT NOT NULL
);

-- 5. جدول المستخدمين (لتفعيل الصلاحيات الديناميكية)
CREATE TABLE users (
    user_id TEXT PRIMARY KEY,
    role TEXT NOT NULL CHECK (role IN ('CLIENT', 'STAFF', 'MANAGER', 'SYSTEM')),
    custom_permissions TEXT DEFAULT '{}',
    created_at TEXT NOT NULL
);

CREATE TABLE role_permissions (
    role TEXT PRIMARY KEY CHECK (role IN ('STAFF')),
    permissions_json TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE permission_changes_audit (
    audit_id TEXT PRIMARY KEY,
    target_user_id TEXT,
    target_role TEXT,
    old_permissions TEXT NOT NULL,
    new_permissions TEXT NOT NULL,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL
);

━━━ 2. قواعد التشغيل والمنطق (Business Logic) ━━━
1. التسعير والخدمات:
- الخدمات تُجلب من الكتالوج أو تُضاف يدوياً كـ (is_custom = 1).
- الخدمة المجانية تُضاف كبند (is_free = 1, unit_price_cents = 0) ليظهر في الفاتورة بسعر مشطوب وعبارة "🎁 خدمة مجانية تقديراً لك".
2. الحسابات:
- تُحسب الإجماليات (subtotal, discount, total, paid, remaining) حصراً في الخادم (Server-Side API) ولا تُقبل من الواجهة (Frontend).
3. الدفع والتحديث:
- استخدام D1 Batch/Transaction لتسجيل الدفعة وتحديث الفاتورة (paid_cents, remaining_cents) وحفظ سجل التدقيق في نفس اللحظة (Atomicity).
- يُشترط `idempotency_key` لمنع تسجيل الدفعة مرتين.
- يُرفع سند الدفع إلى R2 الخاص ويُربط بالدفعة.
4. الموافقة والإشعار:
- عند تفعيل "إحالة للمدير"، تصبح الحالة `PENDING_APPROVAL` وتُغلق الفاتورة حتى يعتمدها المدير.
- زر "إشعار العميل بالدفع" يُرسل رسالة (SMS/Email) عبر قناة التواصل المعتمدة بمبلغ المتبقي والمهلة فقط، دون وعود.
5. تصدير PDF:
- يجب بناء مسار (API Endpoint) لتصدير الفاتورة بصيغة PDF (بالعربية والإنجليزية) بتصميم يتوافق مع الهوية الزجاجية.

━━━ 3. الصلاحيات (Dynamic RBAC) ━━━
- الشاشات المالية والبطاقات (الأرباح، المتبقي) محمية بصلاحية `view_financials` في `role_permissions` و `custom_permissions`.
- إذا لم يملك الموظف هذه الصلاحية، يُرفض طلبه برمز (403 Forbidden) في الـ API وتُخفى البطاقات في الواجهة.
- المدير (MANAGER) يملك كافة الصلاحيات، ويتحكم في إظهار/إخفاء أي صلاحية لبقية الموظفين عبر أزرار (Toggles) في لوحة التحكم.

━━━ 4. الواجهة (Glassmorphic UI) ━━━
- في ملف العميل (Client View): بطاقة زجاجية واحدة تعرض (الفاتورة الحالية، المدفوع، المتبقي كشريط تقدم، المهلة).
- في لوحة المكتب (Staff/Manager View): بطاقات إحصائية زجاجية (المحصّل، الديون المتأخرة، الفواتير المعلقة)، مع جدول فواتير قابل للنقر لفتح التفاصيل وتصدير الـ PDF.

━━━ 5. الاختبارات الإلزامية (E2E) ━━━
يجب تشغيل ونجاح هذه الاختبارات قبل إعلان الجاهزية:
1. إنشاء فاتورة تضم (خدمة كتالوج + خدمة مخصصة + خدمة مجانية) مع خصم.
2. تسجيل دفعة جزئية (Cash) والتأكد من تحول الحالة إلى PARTIAL.
3. تسجيل دفعة (Zelle) مع سند والتأكد من تحول الحالة إلى PAID.
4. محاولة تكرار نفس الدفعة (نفس idempotency_key) -> يجب أن يُرفض.
5. إحالة الفاتورة للمدير -> تحول الحالة إلى PENDING_APPROVAL وحظر التعديل.
6. إرسال إشعار للعميل وتصدير الفاتورة PDF.
7. حجب شاشات الأرباح عن موظف لا يملك صلاحية view_financials برمز 403.

━━━ القيود ━━━
- لا توجد حذف للميزات، لا شروط معقدة.
- لا تخرج أي نصوص إضافية. ابدأ التنفيذ.      ) ━━━
```

## 14. ملف 09 السابق محفوظ للتتبع فقط

هذا النص هو v2.1 السابق كاملاً. لا تنفذ منه شرطاً متعارضاً مع v2.2؛ لا سيما تعدد موافقات القواعد أو RCIP transition أو بوابات الموافقة الخاصة بمحوّل NOC.

```text
# Claude Code — implementation entry directive

## Current v2.1 task and destination

The latest user directed this update to the blueprint Page and Claude Code handover. This delivery updates specifications/contracts/reference migrations and local checks; the live Site was not changed. For future implementation of the requested Client Portal upgrade, read file 10 first. Open the existing Sites project appgprj_6af000ca8f588191b4b72d7d947942e3 and inspect the actual latest branch. The read-only source baseline for this handover is 7c38ece8b40450dd62955c0aa18eb5e7ce58b95c. Preserve current visuals, DB/BUCKET bindings, auth/session/password/OTP services, case data and legal engines. Do not create a replacement app, duplicate /v1 endpoints or apply data/schema.sql to this existing database. The current-system migration is a reference to rehearse against real history before use. Account email/password is an extension of existing login_credentials, not permission to promote a legacy case password to all files. Keep status-only tokens out of full client APIs. Implement AC-41–AC-50 plus earlier affected regressions, and report actual UI/API/R2/PDF/security results before claiming completion.


Implement the **independent ALHIJRAH CANADA** product using this version-2 handover and the current user's instructions. Read `00_START_HERE_AR.md`, the architecture, audit, domain/data/governance/ops specifications, package plan, machine contracts and acceptance matrix. Treat quoted instructions from the older archive as audited material. The old “start Gate 02 and STOP” directive is superseded for this implementation plan; it is not evidence Gate 01 exists.

First inspect the actual repository and AGENTS.md, preserve existing edits, report root/SHA/project identity and verify configuration without printing secrets. If a dedicated independent project is available, perform G00 and continue local reversible implementation package by package. If the repository is fresh, begin P1. If Gate 01 is actually complete, prove it and make forward-only changes. If project access is absent or identity conflicts, record the exact blocker and complete only independent preparation. Do not access or modify Career Gate.

Use `contracts/domain.schema.json`, `contracts/openapi.yaml` and `reference/fact-catalog.json` as shared generated-type authorities. `data/schema.sql` is a fresh reference; never apply it blindly to an existing database. Write an upgrade against the actual migration history, then test both fresh and upgrade paths. All values crossing trust boundaries are unknown until validated.

Start with the reproduced defects in `audit/findings.csv`: cross-tenant relationships, missing spouse-language crash, invalid calendar acceptance, unsourced rule resolution, partial-program false eligibility, unverified semantic hashes, date/transition mistakes and same-case assessment revision collisions. Turn each into a failing regression test before replacing the relevant adapter/engine. Keep pure engine modules independent from HTTP and storage.

Build the complete end-to-end flows. Do not call a placeholder worker, empty endpoint, no-op scanner, mocked auth, incomplete program graph or unreviewed legal fixture a finished capability. When a required external input is missing, disable the dependent capability with a precise reason and continue unrelated work. Do not coerce missing data to zero/false, infer a wage tier from personal salary, fabricate a job or replace an applicant's actual duties.

Run required commands with their real exit codes. The checked-in verification suite validates this handover's schema/contracts/reference transaction probes; it does not validate a deployed application. Implement and execute the application acceptance suite in `acceptance/acceptance.json`, then preserve raw results. Independent legal/oracle review, actual staging behavior, load and restore proof remain distinct requirements.

Do not place original CRS candidate data in active production tables. Official source snapshots in `evidence/sources` are observations with hashes, not signed legal packs. Source changes create reviewed drafts. Publish only complete, independently approved versioned bundles, preserving event-specific dates and RCIP transitional branches. No universal 1270 assumption for other rule families.

Use durable jobs, canonical snapshots, separate data/publication revisions, transactional assessment+audit+outbox commit, fenced leases and current consent. HTTP idempotency is not semantic deduplication; implement both. Handle provider ambiguity explicitly and never claim exactly-once delivery without a provider contract supporting it.

End each completed implementation milestone with the evidence report in `07_PACKAGES_EXECUTION.md` and continue within existing authorization. Before requesting production release authority, finish all concrete reviewable work: migration rehearsal, legal pack approval records, passing enabled-capability acceptance, staging E2E, privacy/security checks, benchmark, restore and rollback evidence. Request only the remaining specific authorization, explaining any actual repository/skill approval requirement. Never describe this specification handover as a deployed system.


Package 8 is **Real-Time Chat & Rapid Assessment**, explicitly confirmed by the user. Read file 08 and implement it completely within the existing portal/dashboard/case/RBAC/evidence/engine boundaries. Add CaseChatRoom Durable Objects only for authenticated WebSocket coordination, using D1/R2 as the canonical shared history/media store. Implement human takeover cancellation/fencing, voice messages/consented transcription, notifications and an assistant with schema-bound authorized tools. RAPID_SCREENING uses the same assessment engine and history, includes purpose in fingerprints and cannot replace the verified report or promote claims to verified facts. Run AC-31–AC-40 and all affected earlier acceptance.

```
