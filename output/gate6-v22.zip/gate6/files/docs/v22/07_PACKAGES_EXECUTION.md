> خطة الاعتماد الحاكمة هي GATES_EXECUTION_PLAN.md بست بوابات فقط. أي توجيه G00 أدناه وصف تاريخي غير تنفيذي، وليس بوابة إضافية.

> v2.2 — المرجع الحاكم: `09_CLAUDE_CODE_EXECUTION.md`. لا نشر حي؛ النصوص المصدرية التاريخية غير تنفيذية.

# Implementation packages and dependency plan

The eight packages below are implementation work, not completed application features. Their acceptance IDs are in `acceptance/acceptance.json`. G00 is an entry audit and is not a disguised additional product package. Local reversible work continues under the current user authorization; no per-package generic stop is inherited from the supplied Gate-02-only prompt. Production and legal activation require their specific real authority.

| Package | Objective / deliverables | Depends on | Acceptance / recovery |
|---|---|---|---|
| P1 Data, Identity and Evidence Foundation | scoped migrations, membership/case access, session identity boundary, typed facts/heads, review records, private uploads/scan state, audits, test fixtures; adapter interfaces | G00, real bindings only for remote tests | AC-01–AC-05; expand/contract forward migration and verified restore |
| P2 Rule Governance and Normalization Contracts | immutable sources, bundle schema/coverage, single MANAGER seal, dated release schedules, activation CAS, normalization evidence policy, official catalogs and draft import tools | P1; signed sources to activate | AC-06–AC-09; revoke affected activation, preserve old schedule, block unsupported legal results |
| P3 CRS and Independent Oracle | pure score evaluator, input normalizer for date/language/education/work/offer factors, full component trace, approved data loader, independent fixtures | P2; complete CRS source pack and independent approvals for COMPLETE production scores | AC-10–AC-12; feature-disable scores, maintain valid rules/date semantics |
| P4 Program/Stream Pathway Engine | obligation graph interpreter, FSW/FST/CEC separation, AIP/RCIP/FCIP and named PNP models, event-date/phase handling; RCIP APPROVAL_TORONTO without transition branches, optional approved ranking | P2 and relevant normalizers; P3 only where CRS used as separate result | AC-13–AC-14, AC-16; disable only affected model, return RULE_UNAVAILABLE |
| P5 Advisory and Operations Modules | evidence-bound NOC review, pivot/pitfall/vulnerability policy, employer designations+vacancies, ATS rubric, expiry scheduler, optional services/internal CRM, NOC suggestion adapter without consent gate | P1/P2; P4 predicate references for legal gap mapping | AC-15–AC-16, AC-21–AC-23; disable adapter, keep human workflow and canonical facts |
| P6 Durable Recompute and Reporting | jobs, snapshot+JCS fingerprint, D1 atomic publication, idempotency, outbox/reconciliation, client/staff DTO projections and AR/EN report content | P1–P4 plus supported P5 result refs | AC-17–AC-20, AC-24; pause publication/dispatch, reconcile orphan objects and stale jobs |
| P7 Deployment and Production Operations | CI lockfile/scripts, actual Workers staging setup, AuthZ/security tests, backup/restore, observability/load, feature disable and compatible rollback | P1/P6, real provider/resource inputs; can scaffold CI earlier | AC-25–AC-28; tested Worker rollback or forward DB repair/restore |
| **P8 Real-Time Chat & Rapid Assessment — user-confirmed functional scope** | integrated client/staff case conversation; governed assistant; human handoff; messages, existing-pipeline attachments and voice; notifications; purpose-aware preliminary assessment using P6 and the same engine | P1 identity/evidence; P5 governed AI/media; P6 jobs/outbox/assessments; P7 DO binding/staging; build HTTP/chat shell after P1 | AC-31–AC-40 plus shared integration AC-29/30; disable AI or socket separately, keep authorized HTTP history/human workflow, reconcile committed messages |

## Repository checks within Gate 1

1. Read current user task, this handover, actual repository AGENTS.md and repository status. Report root, branch/SHA, dirty changes, project identity and whether this is a fresh or existing independent application. Do not search or clone an unrelated product.
2. Inventory actual Worker entrypoint, D1/R2/session bindings, migration history, package manager/lockfile, scripts, CI and current tests. Inspect credentials by names/presence only, never print values. List DEV/STAGING/PROD scope from authorized configuration.
3. Verify claimed Gate 01 artifacts with real schema and isolation tests. If complete, implement only required forward changes. If fresh, implement P1 locally. If repository identity/access is missing, produce `DELIVERY_G00_ENTRY.md` with attempted checks and remaining input; continue preparation that does not depend on access.
4. Record current provider/plan limits and architecture choices in ADR. The supplied `wrangler.toml.example` references missing worker.ts and no real bindings; do not deploy it or invent UUIDs.
5. Install supported exact tool versions within the dedicated project, commit reviewed lockfile and scripts, run existing tests and preserve raw outputs before edits. No claim that old 20/20 establishes production readiness.

## Practical task sequence within packages

P1: failing case-scope link and current-head tests → tables/migration → server AuthZ/query helpers → claim+review commands → uploads/scan lifecycle → session route shell. Implement portal navigation/form persistence in the same phase so API contracts are exercised early.

P2: real-calendar/overlap/hash/missing-source tests → bundle schema and source store → coverage validator → approval service → release schedule and CAS → normalizer contracts → staged official imports. A lack of legal signatures blocks activation, not building the validator or test-only math.

P3/P4: write independent boundary cases first → pure deterministic evaluators → validation adapter → legal parity review → required failure statuses → fixture trace. Do not copy a partial program and set a completeness boolean.

P5: build manual NOC review first → exact span/hash validation → catalog/governance policies → employer/ATS/services/expiry → NOC adapter only after real provider input and RBAC; no NOC consent gate; separate assistant/transcription consent remains scoped to those features. The LLM is a suggestion tool; evaluation doesn't wait on it.

P6: durable enqueue → snapshot consistency → JCS → R2 staging → commit guard → projections → dedup/retry/fencing → side-effect ambiguity/reconciliation. Test concurrent old/new revisions and lost acknowledgement.

P7: CI and staging through real interfaces → telemetry and abuse tests → backup+restore drill → workload benchmark → deploy artifact evidence. P8 runs complete journeys and capability coverage with a real staging environment, then records UAT. No live deployment is authorized by this v2.2 handover.

## Shared product integration and release definition of done

- No unresolved UI-only mocks for advertised capabilities. Every route contract has a consumer and an E2E test that traverses portal → authenticated API → durable data/job → projected response.
- SALAH starts with incomplete facts and no official language test: preliminary report, null CRS, NOC alternatives unverified, no invented dates/ATS/percentages/jobs or guaranteed paths. AIP TEER5 is an explicit exclusion only when the decisive TEER fact and rule are verified; an unknown offer is not falsely failed.
- A fully sourced synthetic case produces the approved independent CRS breakdown and correct path predicates; enabling final wording also requires required professional review. Test source/claim revision changes after publication and currentness badges.
- RCIP selects Pilot in 2026 and Permanent in 2027 from server approval-for-submission date converted to Toronto and approved ranges; a 2026 recommendation is rejected for Permanent. No grace or transition screen/state exists. Missing approved rules return RULE_UNAVAILABLE.
- Client cannot retrieve staff contact/evidence fields through JSON, HTML, print/download, jobs, caches, logs or alternative locale. Role revocation and cross-case/cross-owner IDs are tested.
- Document upload→scan→extract→review→recompute, optional service request→internal CRM, expiry opt-in→single milestone→withdrawal cancellation, rule activation→affected re-evaluation and LLM outage→manual review all run against staging adapters or explicit test-provider environments. Disabled optional integrations are shown as disabled and excluded from release claims.
- Arabic RTL/English LTR, mobile widths, keyboard/focus, error handling, duplicate submission, retry and job progress pass UAT. No false success before durable acceptance.
- Release dossier lists every enabled capability and AC evidence, outstanding defects, rollback/restore observations, privacy/governance owners and authorized release decision. All mandatory acceptance statuses PASS; BLOCKED or NOT_RUN cannot be re-labeled PASS.

## Gate report format

`gateId, repoRoot, commitSHA, environmentId, enabledCapabilities, filesChanged, sourceSnapshotHashes, legalApprovals, migrationImpact, commandsAndExitCodes, rawOutputPaths, acceptanceResults, rollbackOrRestoreEvidence, unresolvedInputs, nextIndependentWork, releaseDecision`.

Authority-sensitive actions (production writes, vendor data transfer, source activation, outbound messages) require their actual task-specific permission. Do not ask repeatedly when it is already granted. No fabricated owner signature or automatic legal approval follows from a passing build.


## P8 functional implementation

Use `08_PACKAGE_8_REALTIME_CHAT_RAPID_ASSESSMENT.md` as the normative P8 specification, supplied from the user’s confirmed scope. Implement shared-schema HTTP persistence first, then authenticated DO WebSocket/hibernation and replay, handoff/assignment with assistant fencing, existing-pipeline voice/attachments, consented assistant tools and purpose-aware rapid assessment. Keep P1–P7 deliverables and execute their integration regressions. P8 is not renamed to an acceptance-only package; its functional acceptance is AC-31–AC-40.


## Client Portal v2.1 cross-package extension

File 10 is a targeted extension across P1 identity/drafts/signature metadata, P6 durable save/submit/status projection, P7 migration/security/performance and P8 portal experience. Preserve all eight original functional packages. AC-41–AC-50 add the new acceptance requirements. Current-project route contracts and migration references take precedence over fresh-system examples for this upgrade; no new product or parallel case store is authorized.

## v2.2 cross-package work

P1 owns the four roles, manager Toggles, D1 permission epochs and KV acceleration; P5/P6 own case-linked integer invoices, immutable payment ledger, private R2 receipts, financial audit and existing outbox/PDF integration; P6 owns zero-touch ingestion and append-only assessment_history; P7 owns AC-51–AC-60. These are extensions of Packages 1–8, not a ninth package or a new app. Follow file 09 for the only authoritative v2.2 extension SQL.
