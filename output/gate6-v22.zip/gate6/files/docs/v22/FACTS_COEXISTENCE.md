# case_facts ↔ case_fact_revisions — coexistence, single writer, source of truth

Scope: Gate 1 creates the canonical tables `case_fact_revisions` and `case_fact_heads` (0026, guarded by 0027) next to
the legacy `case_facts` table (0023). This file fixes which table is authoritative in each phase and forbids dual-write.

## Phase A — from Gate 1 until the Gate 3 cutover

| Item | Rule |
|---|---|
| Source of truth | `case_facts` only. |
| Only writer | `lib/facts.ts` (`recordSkillsNote`, `reviewFact`), called by `app/api/client/route.ts`, `app/api/intake/route.ts` and `app/api/candidates/[id]/facts/route.ts`. |
| Readers | `lib/facts.ts` (`factHistory`, `latestFacts`) → `lib/case-engine.ts` / `lib/preliminary.ts`. |
| `case_fact_revisions` / `case_fact_heads` | Schema only. No application, worker or scheduled code reads or writes them. Empty in every environment. |
| Dual-write | Forbidden. Enforced by `tests/v22/database.test.mjs` (static test): outside `db/schema.ts`, no file under `lib/`, `app/`, `worker/` references `caseFactRevisions`, `caseFactHeads`, `case_fact_revisions` or `case_fact_heads`. |

## Phase B — Gate 3 cutover (one release, one direction)

1. Forward migration (new number, never an edit of 0023–0027) copies each `case_facts` row into
   `case_fact_revisions` with `fact_id` = legacy `id` (deterministic, re-runnable without duplicates), `case_id` =
   `candidate_id`, `fact_key`, `value_json`, `source_hash`, `created_by`, `created_at` = `recorded_at`, evidence id
   into `evidence_ids`.
   Two legacy attributes have no lossless equivalent. They are carried forward without guessing:

   **A. Missing `subject_id` — treated as UNKNOWN, never as the principal applicant.**
   - `case_facts` records no subject. No legacy row is attributed to the principal applicant, a spouse or any other
     person by assumption (not even `additional_skills`, which the client typed on their own form).
   - Copied revisions carry the reserved value `subject_id = 'UNKNOWN'`. Gate 3 must reserve this value in the subject
     catalog so that no real subject can use it.
   - The engine reads only heads of known subjects. A fact under `UNKNOWN` therefore contributes nothing, and the
     corresponding factor stays UNKNOWN in the assessment (consistent with v2.2 decision 7).
   - Attribution happens only through a new, audited revision. A STAFF user with review capability, or the client for
     their own facts, records the value again under an explicit subject, citing the same evidence when it exists. The
     `UNKNOWN` revision stays in history unchanged (append-only). The migration never infers a subject from documents,
     names or values. Documents also carry no subject column, so no automatic inference is possible.
   - Acceptance: after cutover, the number of revisions with `subject_id='UNKNOWN'` equals the number of copied legacy
     rows; no head exists for `UNKNOWN`. Because unattributed facts stop contributing, an assessment may change at
     cutover. The cutover report lists, per case, each fact key that changed from counted to UNKNOWN (counts and keys,
     no values), and the recompute records a new assessment_history row instead of overwriting the old one.

   **B. `CONFLICTED` — never resolved automatically.**
   - In v2.2, a conflict is a situation (competing values awaiting review), not a fact value. The canonical states
     REPORTED, EXTRACTED_UNVERIFIED, VERIFIED and REJECTED cannot express it, and mapping it to any of them would
     change its meaning.
   - Legacy `CONFLICTED` rows are not copied as revisions. They remain in the frozen `case_facts` archive, unchanged and
     readable.
   - If the latest legacy version of a (case, key) is `CONFLICTED`, no head is created for that key, even when an earlier
     version was REPORTED or VERIFIED. This prevents reviving a value that the conflict superseded; the factor stays
     UNKNOWN. Earlier non-conflicted versions are still copied as history revisions (under `UNKNOWN` subject, rule A).
   - For each such key, the cutover migration creates one open staff task (existing `tasks` table, deterministic id
     `legacy-conflict:<case_id>:<fact_key>`, so it is re-runnable without duplicates). It records counts only in
     `operation_logs`, with no values.
   - Resolution is a new canonical revision (VERIFIED, REPORTED or REJECTED) recorded by an authorized reviewer under an
     explicit subject. The head is created only then.
   - Acceptance: the number of legacy keys whose latest version is `CONFLICTED` equals the number of tasks created and
     the number of keys without a head; no `CONFLICTED` value appears in any canonical revision.

   `UNKNOWN` legacy rows are not copied: absence of a fact means UNKNOWN.

2. `case_fact_heads` is built in the same migration only for subjects other than `UNKNOWN`. Under rule A every copied
   row is `UNKNOWN`, so the cutover creates no legacy heads; heads appear only through new attributed revisions. The 0027 guards reject
   any head pointing to another subject or key.
3. In the same release, `lib/facts.ts` switches every read and write to the canonical tables. There is no period in which
   both tables receive writes.
4. The same migration freezes `case_facts` with BEFORE INSERT/UPDATE/DELETE triggers (`LEGACY_FACTS_FROZEN`). The table
   is kept (no DROP) as an audit archive.
5. Acceptance for the cutover: the count of copied rows equals the count of legacy rows whose status is neither UNKNOWN nor
   CONFLICTED; no head exists for `UNKNOWN`; conflict tasks match rule B; `foreign_key_check` is empty; `quick_check` returns ok; any write to `case_facts` is
   rejected.

## Gate 3 execution record (migration 0029, lib/facts.ts)

| Item | Implemented |
|---|---|
| Copy | `case_facts` rows with status REPORTED or VERIFIED → `case_fact_revisions`, `fact_id` = legacy `id`, `subject_id='UNKNOWN'`, `created_by='system:v2.2'`, evidence id in `evidence_ids`, legacy id/version/status/source/recorder kept in `review_note`. Re-runnable (NOT EXISTS on `fact_id`). |
| `source_hash` | The legacy table recorded no source hash. Copied rows carry the all-zero sentinel `LEGACY_NO_SOURCE_HASH`; it is never presented as a content hash. New revisions carry the SHA-256 of the JCS of case, key, subject, value, evidence and source. |
| Heads | None created for `UNKNOWN`. Triggers reserve `UNKNOWN`: no new revision (`UNKNOWN_SUBJECT_RESERVED`) and no head (`UNKNOWN_SUBJECT_HAS_NO_HEAD`). New writes use the explicit subject `PRINCIPAL`. |
| Rule B | Keys whose latest legacy version is CONFLICTED get one open task `legacy-conflict:<case_id>:<fact_key>`. |
| CONFIRMED_ABSENT | Correction to the plan above: this legacy state was not covered. It has no lossless canonical state and no application writer ever produced it, so it is handled like CONFLICTED (not copied, review task). Acceptance: copied rows = rows with status REPORTED or VERIFIED. |
| Counts | `operation_logs` id `v22-facts-cutover`: legacyRows, copied, notCopiedUnknown, notCopiedConflicted, notCopiedConfirmedAbsent, reviewTasks, heads. No values. |
| Freeze | `LEGACY_FACTS_FROZEN` on INSERT/UPDATE/DELETE of `case_facts`; table kept. |
| Writer | `lib/facts.ts` only, same public API. Head moves are compare-and-swap in the same batch as the revision. A document that contradicts a reported value is a canonical `REJECTED` revision with that evidence (shown as CONFLICTED); clearing the skills card is an empty REPORTED revision (shown as UNKNOWN). Client-entered facts are written by SYSTEM with the client recorded in `review_note` (client user rows arrive with Gate 4). |
| Tests | `tests/v22/database.test.mjs` upgrade path (legacy rows of every status, acceptance counts, freeze, reservation, re-run) and the Phase C static test; `tests/gate2-api.mjs` skills-card and evidence flow on the canonical tables. Environment: Workers/D1 محلية عبر Miniflare. |

## Phase C — after Gate 3

| Item | Rule |
|---|---|
| Source of truth | `case_fact_revisions` (append-only) + `case_fact_heads` (current pointer). |
| `case_facts` | Read-only archive, never consulted by the engine. |
| Rollback | Before the freeze migration: revert code only (canonical tables still empty). After it: forward fix only; no write path back into `case_facts`. |

Production `case_facts` row count was 0 at the last verified read (Gate 2 production verification). It was not
re-read for Gate 3 (no production access in this gate): غير متحقق. 0029 is not applied to production.
