> v2.2 — المرجع الحاكم: `09_CLAUDE_CODE_EXECUTION.md`. لا نشر حي؛ النصوص المصدرية التاريخية غير تنفيذية.

# Data model, migration and atomicity

`data/schema.sql` is an executable **fresh isolated reference schema**, not a migration against the user's unknown production database. Its relational constraints have local SQLite probes. D1 behavior, query plan and crash tests are separate acceptance gates. Keep API JSON-schema validation even where SQL checks exist. No SQLite extension or unsupported `BEGIN` call is assumed in Worker code.

## Model ownership

| Aggregate | Tables | Invariant |
|---|---|---|
| Identity and access | users, role_permissions, permission_runtime, permission_changes_audit, case_access (Single-Office) | existing authentication identity mapped to one of four roles; case ownership plus staff case grant |
| Cases | cases, fact_revisions, fact_heads, fact_evidence | separate data/publication revisions; scoped current heads |
| Evidence | evidence, evidence_segments, review_decisions | quarantine lifecycle; immutable clean bytes; hash-bound review |
| Governance | source_snapshots, rule_bundles, release_sets, release_intervals, rule_activation | immutable content and schedules; atomic active pointer |
| Decisions | noc_decisions, assessments | episode-scoped NOC; immutable result metadata |
| Orchestration | jobs, idempotency_requests, outbox, delivery_attempts | leased, fenced, retry-safe state transitions |
| Product operations | consents, service_catalog, service_requests, crm_events, expiry_watches, employer_designations, employer_contacts, vacancies, ats_artifacts | separate business identities, consent purposes and sources |
| Accountability | audit_events, privacy_requests | minimal append-only audit plus controlled erasure workflow |

All case-owned children reference `case_id` (= `candidates.id`). All evidence relations reference `(case_id,evidence_id)`. Fact supersession cannot cross case/subject/key: the service verifies key equality and the DB trigger verifies scope. `fact_heads` points to a revision of the same subject/key. Reviews reference current fact/evidence hashes; application validation enforces allowed reviewer capability, distinct author and current CLEAN evidence. SQL integrity complements authorization; it does not grant a caller access.

The reference schema intentionally does not persist profile JSON inside `cases`; facts are the source of truth. Assessment results and high-risk extracted text reside in private R2, keyed by opaque IDs and encrypted according to approved key management. Relational fields store references, hashes and review metadata. D1 at-rest encryption does not replace access controls or a retention/deletion design. Employer contacts are encrypted with a dedicated application key/version if stored. No key material belongs in D1.

## Rule publication

Bundles and release schedules are content immutable. Publishing requires complete validator output and one active MANAGER approval bound to the exact payload and manifest hashes. The same manager may author, validate and seal in one UI operation; no second account or author-separation gate applies. Internally use BUILDING then SEALED in an atomic D1 batch; direct INSERT SEALED is rejected. References bind source snapshots, obligations, NOC/wage/conversion tables and required tests. RCIP uses APPROVAL_TORONTO and no transition/grace branch. A successor is a complete new immutable schedule; old releases are never edited.

Overlap trigger keys: `(release_id, program_id, family, phase, date_basis)`. Interval `[a,b)` overlaps `[c,d)` iff a < d and c < b, with null=+infinity. Empty/invalid calendar intervals are rejected by schema/service validation. `date_basis` is not a free way to create multiple simultaneous legal answers: the obligation manifest declares which basis applies to each family. Activation is one compare-and-swap of the singleton active release pointer after full validation; a trigger rejects an unsealed release. Revocation marks an activation unavailable through a new audited activation event; it never rewrites historical bytes. Each computation pins the release and activation generation.

## Recompute and publication algorithm

1. Authorize operation and mode; parse strict request. SHADOW is staff-only and requires isolated resource configuration. `SHADOW_ONLY=true` is enforced at every publication and external dispatch path, not just in a router.
2. Claim the HTTP key with unique constraint and hash. Recheck authorization before replaying a stored response. Record the durable job and key association in the same D1 `batch`.
3. Build an internally consistent snapshot. Use a D1 session/primary-consistent reads if supported and verified, or read `data_revision` before/after bounded reads on primary and retry when unequal. All assessment-relevant case writes MUST increment data_revision in their atomic batch. Capture the active rule generation as well. Do not combine arbitrary stale replica reads into a snapshot. SHA every object and validate its schema; inability to read evidence makes dependent predicates UNKNOWN.
4. Compute `sha256(JCS({schemaVersion,caseId,dataRevision,factRevisionIds,evidenceHashes,reviewDecisionIds,nocDecisionIds,selectedProgramsSorted,assessmentPurpose,eventContext,ruleReleaseHash,engineVersion,normalizerVersion,rankingPolicyHash,advisoryPolicyHash,mode}))`. Include sorted stable sets, not arbitrary DB row order. Exclude job ID, execution timestamp, locale, HTTP headers and raw JWT. Every external semantic decision used has already been reviewed and versioned.
5. Look up an existing canonical assessment under `(case,mode,fingerprint)`. If it exists, return that resource without moving the current pointer backwards or emitting side effects. Currentness is a separate field evaluated against current revisions/release.
6. Write the new encrypted result R2 object under a deterministic opaque assessment object key, validating size/hash. DB+R2 have no shared transaction. This object remains unreachable until DB commit; failed DB writes leave an orphan collected only after a configured grace period exceeding job retry horizon.
7. Commit with one D1 transactional `batch`, sequential prepared statements: INSERT assessment metadata (trigger checks expected dataRevision and rule generation); UPDATE the appropriate verified/rapid case pointer and shared publication revision for PRODUCTION only; INSERT audit event; INSERT outbox event(s); finalize job and HTTP key. A failing guard raises ABORT so the entire batch rolls back. **Do not use `UPDATE ... WHERE revision=?` followed by unconditional INSERT**; zero updates are not an SQL failure. The included trigger rejects the stale assessment insert before any publication. SHADOW insert is guarded by the same input/release checks but never increments publication revision.
8. Uniqueness collision: retrieve exact canonical assessment by scoped fingerprint; do not return an unrelated latest result. CAS conflict: mark job stale/retry a fresh snapshot at most the configured count. A repeated HTTP key still resolves to the original job; a new request can explicitly request a new revision.

`data_revision` changes only with case-affecting facts, evidence status/validity, NOC reviews, relevant consent or selected case configuration. Recompute itself increments only `publication_revision` on a successful new PRODUCTION publication. RAPID_SCREENING updates latest_rapid_assessment_id and VERIFIED_SCREENING updates latest_assessment_id; both reference the same assessments table and cannot replace each other’s pointer. A legal release change creates a different fingerprint even for unchanged data. A new rules release doesn't mutate old assessments; currentness and retrieval show superseded/stale status alongside immutable result metadata.

## Outbox and jobs

Claim due work with UPDATE ... RETURNING and a predicate checking state+lease expiry. An atomic increment supplies a fencing token. Finalize using `WHERE id=? AND fencing_token=? AND lease_owner=?`; a stale worker cannot overwrite a recovered lease. Attempts carry start/end/provider reference/error class, never message PII. Lease duration exceeds task timeout plus safety margin. Claim batches are bounded and indexed; no scan of all cases per minute.

Default **engineering configuration**, not an observed provider SLA: dispatch at minute granularity; claim<=50 jobs/tick; process<=5 in parallel; timeout<=30s per provider request; attempts<=8; exponential full jitter bounded 30s–6h; exhausted=>DEAD_LETTER. Tune only after measured plan capacity. New jobs may run immediately after the durable commit; cron provides recovery. Long OCR/scan calls use provider job IDs and polling jobs instead of holding a request open. Source snapshots never enter external LLM processing.

Business dedup keys are distinct: assessment event = case/assessmentId/type; service CRM = serviceRequestId/type; expiry = evidenceId/validityRevision/milestone/recipient/channel. Recomputing a report never creates a paid-service lead. A service request explicitly records offer version, price/currency if applicable, and consent. CRM stays internal initially; an external CRM adapter is disabled until a provider and idempotency/reconciliation contract exist.

Notifications, chat assistant and transcription consult their scoped current consent at execution. The NOC suggestion adapter has no consent/approval gate; its RBAC, provider and citation checks remain required. Cancel pending work after withdrawal. For external side effects, stable provider idempotency keys plus receipt storage are required where available. A crash after provider success and before DB acknowledgement must be tested. Without provider idempotency, an ambiguous response goes to AMBIGUOUS for reconciliation. There is no universal exactly-once guarantee. At-least-once delivery must not be sold as one.

## Migration and recovery

G00 inspects actual schema/migration history before choosing fresh install or forward migration. Never edit applied migrations. Run fresh install, upgrade-from-actual-schema, scoped-FK negative probes, quick_check, foreign_key_check and backup/restore. The original SQL can accept incorrect tenant links while both PRAGMAs report healthy; those checks alone do not prove isolation.

Upgrade order: inventory duplicate/broken links → quarantine report → add scoped uniqueness/relations in forward migration → backfill verified scope with explicit mappings → reject unresolved rows → switch reads/writes → validate counts/hashes and authorization. No automatic inference of ownership. Rehearse D1-supported table rebuild semantics and constraints on staging; local SQLite behavior is not enough. No migration `--down` is assumed.

Erasure: append-only events contain pseudonymous IDs and technical metadata, while personal bytes use deletable protected objects. A controlled privacy job removes personal R2 artifacts and dependent extracts under approved policy, invalidates heads/results, removes private contacts, and writes a non-identifying tombstone. Immutable hashes/IDs can still be personal data; legal review determines whether exceptional deletion/redaction of audit/history is required. An authorized retention migration can implement that policy and preserve a separate proof without silently disabling triggers. Backup retention, restore re-erasure and legal holds are part of the same policy. Never claim compliance merely because the audit is immutable.


## Package 8 metadata and ordering

The same schema additionally owns conversations, chat_messages, chat_attachments, chat_receipts and in_app_notifications. Scoped composite FKs prevent cross-case message attachments. A message insert trigger rejects stale/noncontiguous sequence, then advances the canonical last_sequence atomically. Assistant inserts additionally require BOT_ACTIVE, matching automation_generation, latest client input boundary, case data revision and current rule generation. Handoff changes state/revision/generation atomically. A provider response arriving afterwards is rejected before publication. Receipt high-watermarks are monotonic and bounded by committed history. Message identity is immutable; private bodies follow the existing R2/erasure policy. DO memory is never the authoritative history or idempotency ledger.


## Existing application integration for Client Portal v2.1

For the user’s current application, use data/current-system/0016_client_portal_upgrade.sql only after checking actual deployed history. Its source baseline is recorded under evidence/current-project. It extends candidates/client_cases/auth_challenges/client_sessions/login_credentials/application_authorizations rather than introducing the fresh reference tables above. client_account_profiles is metadata, client_application_drafts is pre-submission input state, and client_contact_lookup is a maintained HMAC contact index; none replaces identity, OTP, the official case or the engine. Historical authorizations retain null signature fields. Account draft mutation rows guard revisions and replay; actual D1 upgrade/restore/authorization tests remain required.
