> v2.2 — المرجع الحاكم: `09_CLAUDE_CODE_EXECUTION.md`. لا نشر حي؛ النصوص المصدرية التاريخية غير تنفيذية.

# Normative domain and API contracts

MUST is mandatory. Types in `contracts/domain.schema.json` are the wire authority; generate TypeScript from them, then compile the API and portal against the generated types. Domain results do not import Cloudflare, HTTP, databases, vendor SDKs, or UI types. Discriminated unions MUST be validated at every trust boundary, including jobs, DB JSON and provider responses. Type assertions are not validation.

## Aggregate and identity

The system serves one office (Single-Office); there is no tenantId, organization membership or multi-tenant boundary. The existing authentication proves identity; `users` maps that verified identity to one of the four roles and its permissions. Case ownership (`candidates.owner_id`) and staff case grants (`case_access`) control case access. A CLIENT sees only granted own cases, never a user-selected role. The only roles are CLIENT, STAFF, MANAGER and SYSTEM. MANAGER alone has seal_rules; legacy RULES_APPROVER is not a separate role. Intake, review and consultation are STAFF capabilities. SYSTEM jobs carry a fixed task capability, never an impersonated admin JWT. Every write is audited with internal principal, action, resource, environment and correlationId.

Case attributes are `caseId` (= `candidates.id`), `dataRevision`, `publicationRevision`, intake state, locale preference, configured IANA business timezone, created/updated timestamps, and separate nullable current VERIFIED_SCREENING and RAPID_SCREENING pointers into the same PRODUCTION assessment history. A case has no single authoritative NOC field. Each work episode may have multiple reviewed NOC decisions with explicit scope and supersession.

## Facts and normalization

Fact write request: `{expectedDataRevision, factKey, subjectId, value}`. For each factKey, `reference/fact-catalog.json` defines its value schema. The API rejects unknown keys and unsupported fields. All client writes become REPORTED. An append-only fact revision has a server ID, case scope, subject (applicant, spouse, workEpisode, offer), factKey, typed JSON value, evidence state, valid-from/to context, evidence refs, reviewer decision ID, observed timestamp and supersedesFactId. `fact_heads` chooses exactly one current revision for each case+subject+key. Contradictory sources produce an unresolved review item and UNKNOWN, never last-write-wins verification.

Sources for verified facts are clean immutable documents, a permitted structured attestation signed by the subject and reviewed by a different principal, or an approved official record. Identity assertions such as date of birth require the evidence class declared in the legal policy. Explicit NONE/false for optional scoring factors may use an approved attestation policy; no document is fabricated to establish an absence. A reviewer verifies the exact current fact revision, evidence hashes and validity; edited evidence invalidates the review. Verification appends a new revision and increments dataRevision. Expiry is evaluated on the rule's dateBasis, even when a previously VERIFIED record still exists in history.

Outcome tracking uses the same `case.outcome` fact/review mechanism: NOT_APPLIED, INVITED, SUBMITTED, APPROVED, REFUSED, WITHDRAWN or UNKNOWN with a specific program and event date. An actual invitation/submission/decision requires official supporting evidence to become VERIFIED. The old `case_outcomes` and `staff_reviews` concepts are unified into typed facts and `review_decisions`, preserving history without another competing source of truth. Assessment PASS never creates an APPROVED immigration outcome.

Normalization input is the pinned snapshot, a typed fact catalog, legal rules and date context. Normalization returns VERIFIED derived values with derivation trace or structured UNKNOWN/INVALID. DOB produces age at the relevant date; periods+hours produce qualifying experience with overlap and legal caps; approved test/provider/version produces four CLB/NCLC abilities; ECA result and education policy produce the allowed education category; NOC dataset and work periods produce wage tier. Birth year alone does not produce an exact age. The 30h/week rule observed in WEB02 must be encoded in the approved qualifying-experience policy, including overlapping employment and excluded work. No caller can set an authoritative tier, CLB, years, offer validity or nomination flag by toggle.

## Assessment contract and state algebra

An assessment contains schemaVersion, assessmentId, caseId, dataRevision, fingerprint, assessmentMode, assessmentPurpose, engineVersion, ruleReleaseId, evaluation context, snapshot manifest hash, pathway results, EE CRS result, ranking result, advisory refs and scope limitations. Result body is encrypted in private R2; relational history stores references, hashes and minimal metadata. JSON used to compute it MUST validate. Runtime timestamps are stored outside deterministic result content.

`PathwayResult` separates:

- `evaluationStatus`: EVALUATED | RULE_UNAVAILABLE | CONTEXT_INCOMPLETE.
- `intakeState`: OPEN | CLOSED_TO_NEW | TRANSITION_ONLY | FUTURE | UNKNOWN.
- `eligibility`: PASS | FAIL | UNKNOWN | NOT_APPLICABLE.
- `predicates`: obligation ID, outcome PASS/FAIL/UNKNOWN/NOT_APPLICABLE, reasonCode, rule payload hash, fact revision IDs, citation refs and date basis.

For an evaluated complete obligation graph: ALL is FAIL if any decisive node FAIL, PASS if all required nodes PASS or legally NOT_APPLICABLE, otherwise UNKNOWN. ANY is PASS if one complete branch PASS, FAIL if all branches FAIL, otherwise UNKNOWN. An exemption must have its own sourced guard and proof; missing exemption evidence is UNKNOWN. A rule lookup failure sets evaluationStatus=RULE_UNAVAILABLE and eligibility=UNKNOWN; it never masquerades as a closed program. Program status is evaluated from its own dated operational rule. A known decisive FAIL may be displayed as an observed blocker while another part lacks a rule, but the overall evaluation remains incomplete.

RAPID_SCREENING cannot have FINAL_VERIFIED_ASSESSMENT; it is a preliminary purpose even when quoting an already complete verified score. Report stage is FINAL_VERIFIED_ASSESSMENT only if at least one advertised, in-scope path has an EVALUATED PASS with all decisive evidence current, the exact immutable release remains approved, and any required professional review is recorded. Remaining paths can remain unknown. Otherwise use PRELIMINARY_ASSESSMENT; use BLOCKED_RULES when no requested path can be evaluated due to rules, and REVIEW_REQUIRED for unresolved evidence/NOC conflicts. FINAL describes the platform's documented screening scope only. It is not an admissibility or IRCC decision. Store the scope limitations in all views.

CRS union:

- COMPLETE: integer total >=0, exact components summing to total, maxTotal and policyHash from approved bundle, and trace. No global hard-coded maximum.
- INCOMPLETE | RULE_UNAVAILABLE | INVALID_INPUT | NOT_APPLICABLE: total=null, components=null, reason codes and missing paths. NOT_APPLICABLE covers no confirmed eligible EE path under the declared product scope. An incomplete EE predicate produces INCOMPLETE rather than a simulated definitive score.

The pure math evaluator can be tested with synthetic normalized profiles in TEST_ONLY scope. Production adapters require approved policy+verified derivations and reject pending-review bundles before calculation. Exceptions such as corrupt/missing rule arrays return RULE_UNAVAILABLE at the adapter boundary with a private diagnostic; missing user data never throws a TypeError. Language status is TESTED | EXPLICITLY_NOT_TESTED | UNKNOWN; null does not conflate these states. Spouse classification includes accompanying status and citizenship/PR conditions in the applicable rule, rather than using marital status alone.

## Ranking and advisory

`RankPolicy` defines criterion names, exact point tables, evidence and observation windows, comparator/cohort, scale 0..100, missing-data treatment, version hash and approvers. Weighting does not supply missing normalization. Eligible list is distinct from conditional candidates and exclusions. An unranked list is stable ASCII programId+streamId order and explicitly carries `ranking.status=RANK_UNAVAILABLE`; its position does not imply preference. All six factor inputs are integers 0..100. Preserve exact rational arithmetic: priorityNumerator=sum(weight*factor), priorityDenominator=100; finalNumerator=85*priorityNumerator+1500*fastTrackScore, finalDenominator=10000. Compare finalNumerator before display rounding. Display finalScore rounded half-up to two decimals; apply programId/streamId ASCII only when exact numerators tie. A display tie must not change the underlying ranking.

Maintain the original policy formula only after rubric approval: priority=(35*eligibility+25*competitiveness+15*policyPriority+15*actionability+10*sustainability)/100; final=(85*priority+15*fastTrack)/100. eligibility=100 for legally gated PASS candidates; other candidates are not scored. fastTrack is an operational criterion supported by the rubric, never invented PR months. No rubric exists in the input archive, so numeric ranking starts disabled. Vulnerability, pitfall and pivot rules live in a separate approved advisory policy namespace with evidence requirements and expiry. Administrative reminders without legal claims may be non-legal policies. They cannot introduce or waive a statutory condition.

NocSuggestionRequest has no consentId or approval gate. Case authorization, provider configuration and citation validation remain required. NOCSuggestion has target NOC/catalog version, workEpisodeId, original evidence hashes, code-point-independent UTF-8 byte ranges, exact quote, official duty IDs and explanation. The validator recomputes hashes, checks ranges and UTF-8 boundaries, validates exact decoded quotes, uses the immutable extracted text, caps output size, and rejects unknown NOCs. It authenticates citations, not semantic truth. A human reviewer records lead-statement/main-duty correspondence, exclusions, dissent and outcome. No fixed confidence cutoff grants VERIFIED. A document containing prompt instructions remains untrusted data. Reviewer approval pins evidence hashes and is invalidated by later edits.

ATS returns NOT_APPLICABLE without a clean parsed CV and a specific current job posting; otherwise it reports an explanatory rubric version and matched/missing evidence. No employer-specific acceptance percentage. Employer designation is a dated organization/program/community association. Vacancy is an independent posting with source, verification, expiration/revocation and job NOC. An employer may have many designations and postings. Public responses contain verified designation metadata and permitted posting links, never private contacts. Contact access requires both staff assignment and an explicit contact capability.

## HTTP semantics

See OpenAPI for route bodies and response schemas. All mutations require Idempotency-Key and the relevant expected revision. Keys are 20–128 ASCII characters; logs store a hash. Scope includes environment, principal, method and canonical resource route. Hash request body with JCS. Same key/body returns its recorded response/job even after a newer case revision, subject to current authorization. Same key/different body =>409. Concurrent identical job requests with different HTTP keys converge by semantic fingerprint. A key for SHADOW cannot replay as PRODUCTION. Completed resource identity is retained for its resource lifetime; key-retention policy must exceed retry horizon. No time-to-live may permit the same business service request to be created twice.

- 200: resource or completed identical evaluation; partial/unknown is a valid domain result.
- 201: case, claim, upload reservation, review, consent or service request durably created.
- 202: durable job accepted; Location points to authorized job status. Not proof of computation/publication.
- 400: malformed body/JSON; 401: invalid authentication; 403: known authorized scope but missing operation capability; 404: inaccessible or missing case resource using one response shape; 409: revision/idempotency/release conflict; 413/415: file limits/type; 422: semantic input invalid; 429: retry-safe throttling; 503: durable acceptance/storage unavailable.

Missing legal rules are normally a successful assessment with RULE_UNAVAILABLE, not a transport 422. A source fetch outage cannot erase a still-valid frozen legal rule; staleness is a dated review policy and can block current FINAL results without mutating history. Never leak private exception text in ApiError.

GET responses are private,no-store for PII. Cache only approved public catalogs by immutable content hash. Staff JSON projection is also allowlisted. Report creation never serializes the canonical internal object directly. Server renders AR/EN from one immutable semantic result; changing locale cannot create a new legal outcome. Public source URLs are validated official links; evidence references are opaque IDs resolved only through authorized routes.


## Package 8 shared contracts

`08_PACKAGE_8_REALTIME_CHAT_RAPID_ASSESSMENT.md` defines conversation/message/voice/handoff/assistant/rapid flows. Domain schemas contain the strict ChatClientFrame and ChatServerFrame unions, message/receipt/notification DTOs and assistant draft/tool capability schemas. Client-authored chat is private case data, not automatically a case fact. New consent purposes LLM_CHAT_ASSISTANT, AUDIO_TRANSCRIPTION and CHAT_NOTIFICATIONS are separate and purpose-specific. Message content does not grant any tool or role. All new HTTP and socket operations use the existing session and case authorization. `assessmentPurpose` is part of semantic identity; both purposes reuse the same engine and history. The two case pointers prevent a preliminary chat result from overwriting the verified report.
