# GATES_EXECUTION_PLAN.md — ست بوابات رئيسية لتنفيذ v2.2

## قواعد التنفيذ الحاكمة

- المرجع: قرارات المستخدم الحالية، ثم الأقسام التنفيذية من `09_CLAUDE_CODE_EXECUTION.md` إصدار v2.2. النصوص المؤرشفة ليست تعليمات تنفيذ.
- النظام لمكتب واحد: إزالة Multi-tenancy من العقود والمنطق التشغيلي، مع إبقاء ملكية العميل وتعيين الموظف وصلاحيات الحالة. لا حذف لبيانات العملاء أو تغيير للقطات والتوقيعات التاريخية.
- `A/` جذر التطبيق الحالي؛ `H/` جذر حزمة v2.2. المسارات التالية نسبية إلى هذين الجذرين. الملفات الجديدة مقترحات تنفيذ محددة؛ لا يُنشأ ملف جديد إذا كانت وظيفته موجودة فعلياً، ويُثبت مسار إعادة الاستخدام في `A/execution/V22_FILE_MAP.json` قبل التعديل.
- ستة اعتمادات فقط. تُنفذ المهام الداخلية على دفعات تحت رقم البوابة نفسه، دون إنشاء بوابات إضافية.
- كل بوابة تقرأ ملفاتها المحددة وسجل البوابة السابقة فقط. لا إعادة تحميل للأرشيف كله، ولا تثبيت أدوات كهدف مستقل، ولا إعادة بناء للنظام.
- الأدوار: CLIENT وSTAFF وMANAGER وSYSTEM فقط. الأموال INTEGER بالسنتات؛ JSON في TEXT؛ يُمنع REAL وJSONB. لا مخزن حالات أو هوية أو محرك تقييم أو Outbox موازٍ.
- حالة البوابات عند إصدار الخطة: NOT_RUN. الاختبارات المذكورة شروط قبول وليست نتائج منفذة.
- تقرير كل بوابة: الملفات المعدلة، SHA المصدر، أوامر الاختبار وexit codes، المخرجات الخام، المعايير المغطاة، العوائق. اعتماد البوابة بعد اختبار نطاقها فعلياً؛ لا تحويل BLOCKED أو NOT_RUN إلى PASS.
- عند غياب معلومة لازمة: «ابحث وتحقق». إذا لم تُثبت، يُسجل العائق للقدرة التابعة دون اختلاق بديل.
- لا نشر حي، ولا ترحيل قاعدة الإنتاج، ولا رسائل اختبار لعملاء حقيقيين.

## Gate 1 — قاعدة البيانات والعقود وإزالة Multi-tenancy

**الهدف:** مخطط Single-Office متسق يحفظ البيانات ويخدم الحزم 1–8 وترقيات v2.2.

**الملفات الدقيقة:**

- قراءة: `H/09_CLAUDE_CODE_EXECUTION.md`، `H/contracts/v2_2.schema.json`، `A/db/index.ts`، `A/drizzle/meta/_journal.json`.
- تعديل: `A/db/schema.ts`، `A/drizzle/0016_client_portal_upgrade.sql`، `A/drizzle/0017_v2_2_controls_billing.sql`، `A/drizzle/0018_v22_runtime.sql`، `A/lib/v22-db.ts`، `A/lib/v22-core.ts`.
- مواءمة العقود: `H/contracts/domain.schema.json`، `H/contracts/openapi.yaml`، `H/contracts/chat-protocol.schema.json`، `H/contracts/client-portal-upgrade.schema.json`، `H/contracts/client-portal-openapi.yaml`، `H/contracts/v2_2.schema.json`، `H/03_DOMAIN_CONTRACTS.md`، `H/04_DATA_AND_ATOMICITY.md`، `H/07_PACKAGES_EXECUTION.md`، `H/acceptance/acceptance.json`، `H/acceptance/acceptance.csv`.
- إنشاء سجل الربط: `A/execution/V22_FILE_MAP.json`.
- اختبار: `A/tests/v22/database.test.mjs`.

**التنفيذ الملزم:**

1. التحقق من history الفعلي قبل اعتماد أرقام migrations؛ لا تعديل لملف سبق تطبيقه.
2. إزالة tenantId والجداول والعلاقات والفلاتر الخاصة بتعدد المؤسسات من العقود والتشغيل. لا حذف لملكية الحالة أو grants الموظفين.
3. إبقاء `candidates.id` معرف الحالة؛ عدم إنشاء `cases` بديلة. معالجة أي تصادم معرفات بخريطة ترحيل موثقة دون فقد بيانات.
4. مطابقة ORM وSQL والـFK والفهارس والحراس وappend-only. لا إنشاء جدول مرتين أو استخدام IF NOT EXISTS لإخفاء اختلاف مخطط.
5. مراجعة mapping المدير والموظفين من السجلات الموثوقة، وعدم اعتبار email أو role مرسل من العميل سلطة.
6. تصحيح AC-46 إلى توقيع ثابت على لقطته الأصلية، وAC-22 باستثناء NOC فقط، وAC-30 لتغطية AC-01–AC-60، وإزالة وصف الموافقتين من المواصفات الفعالة.

**معايير القبول:**

- Fresh وUpgrade على نسخة معزولة؛ foreign_key_check فارغ وquick_check ناجح.
- ثبات عدد السجلات القديمة وبصمات اللقطات والمرفقات قبل الترحيل وبعده.
- جميع حقول المال INTEGER مع رفض الكسور والسالب والتجاوز؛ JSON صالح في TEXT.
- لا Multi-tenancy فعال، ولا تكرار جداول، مع استمرار رفض الوصول إلى حالة أو ملف لا يملكه المستخدم.
- فشل خطوة داخل batch لا يترك آثاراً جزئية؛ رفض تعديل history والدفعات والتوقيع الأصلي.
- المعايير: AC-03، AC-05، AC-18، AC-46، AC-51، AC-58.

**البرومبت الجاهز:**

```text
نفّذ Gate 1 فقط من GATES_EXECUTION_PLAN.md. وحّد قاعدة البيانات والعقود على Single-Office، وأزل Multi-tenancy التشغيلي دون المساس بملكية العملاء وصلاحيات الحالات أو التاريخ. طابق migrations مع history الفعلي، ووحّد ORM وSQL والفهارس والحراس، وصحح تعارضات القبول المحددة. لا تطبق ترحيلاً على الإنتاج. نفّذ اختبارات Fresh/Upgrade وسلامة البيانات والنوع والذرية، ثم سلّم الملفات المعدلة ونتائجها والعوائق.
ممنوع العودة للحزم السابقة، وممنوع حذف الكود العامل، التزم حرفياً بقرارات v2.2. الأموال INTEGER وJSON TEXT حصراً؛ ممنوع REAL وJSONB. لا تبدأ من الصفر، ولا تنشئ أنظمة موازية، ولا تنشر على الموقع الحي.
```

## Gate 2 — الهوية والصلاحيات والحماية

**الاعتمادية:** Gate 1.

**الهدف:** مصادقة واحدة وأربعة أدوار وصلاحيات خادمية نافذة فوراً.

**الملفات الدقيقة:**

- قراءة: `H/09_CLAUDE_CODE_EXECUTION.md`، `H/contracts/v2_2.schema.json`، `A/lib/staff-auth.ts`، `A/lib/client-account.ts`، `A/lib/client-access.ts`، `A/app/chatgpt-auth.ts`.
- تعديل الخدمات: `A/lib/server.ts`، `A/lib/rbac.ts`، `A/lib/v22-core.ts`، `A/lib/applicants.ts`، `A/lib/business-clock.ts`، `A/app/api/office/route.ts`، `A/app/api/office/permissions/route.ts`.
- تعديل مستهلكي الدور والنطاق: `A/app/page.tsx`، `A/app/intake/page.tsx`، `A/app/api/operations/route.ts`، `A/app/api/candidates/route.ts`، `A/app/api/candidates/[id]/route.ts`، `A/app/api/candidates/import/route.ts`، `A/app/api/tasks/route.ts`، `A/app/api/tasks/[id]/route.ts`، `A/app/api/new-clients/route.ts`، `A/app/api/team-review/route.ts`، `A/app/api/documents/[id]/route.ts`، `A/app/api/candidates/[id]/generate/route.ts`.
- الواجهة: `A/components/operations/permissions.tsx`، `A/components/operations/clients.tsx`، `A/components/operations/channels.tsx`، `A/components/operations/professional-settings.tsx`، `A/components/operations/career-documents.tsx`، `A/app/desk.tsx`.
- الربط: `A/cloudflare-env.d.ts`، `A/vite.config.ts`، ونقطة التشغيل المثبتة في `A/execution/V22_FILE_MAP.json`.
- اختبار: `A/tests/v22/access.test.mjs`.

**التنفيذ الملزم:**

1. تحويل استعمالات admin/staff إلى الأدوار الأربعة دون IdP أو جلسات موازية.
2. فرض grants الحالة في التفاصيل والقوائم والمجاميع والبحث والتصدير والوثائق والمهام؛ ownerId المكتبي ليس تصريحاً عاماً للموظف.
3. Toggles من كتالوج خادمي، مع custom override مدقق؛ حماية MANAGER وSYSTEM من تعديل الصلاحيات.
4. audit والتعديل وepoch داخل batch واحدة. KV للتسريع؛ D1 المتسقة مصدر السلطة عند كل وصول محمي.
5. فتح STAFF بمفتاح واحد حتى منتصف ليل America/Toronto؛ SYSTEM يغلق فقط. فحص expiry مجدداً داخل المعاملة الحساسة.

**معايير القبول:**

- تزوير الدور والجلسة وscope والحالة يفشل؛ الإلغاء نافذ مع KV قديم.
- STAFF غير المعيّن لا يقرأ الحالة أو يتعرف عليها عبر list/count/search/export.
- تعديل متزامن للصلاحيات ينتج تعارضاً دون audit جزئي؛ لا تعديل لصلاحيات الجذر.
- أيام DST بطولي 23 و25 ساعة، ورأس السنة، وcron متوقف؛ لا تمديد تلقائي لليوم التالي.
- معاملة تعبر expiry تتراجع كاملة؛ الفتح المؤقت لا يمنح سلطات MANAGER.
- المعايير: AC-02، AC-03، AC-32، AC-57، AC-58، AC-59.

**البرومبت الجاهز:**

```text
نفّذ Gate 2 فقط بعد قبول Gate 1. وحّد المصادقة الحالية والأدوار الأربعة، وطبّق صلاحيات الحالة على كل مسارات القراءة والكتابة والقوائم. نفّذ Toggles وaudit/epoch ذرية وKV تابعاً لـD1، وفتح STAFF المنتهي عند منتصف ليل Toronto دون منح سلطات المدير. حافظ على تسجيل الدخول العامل وامنع أي bypass. سلّم اختبارات التزوير والإلغاء والتزامن وDST وانتهاء التفويض مع الملفات المعدلة.
ممنوع العودة للحزم السابقة، وممنوع حذف الكود العامل، التزم حرفياً بقرارات v2.2. الأموال INTEGER وJSON TEXT حصراً؛ ممنوع REAL وJSONB. لا تبدأ من الصفر، ولا تنشئ أنظمة موازية، ولا تنشر على الموقع الحي.
```

## Gate 3 — القواعد والمحركات والتقييم الموحد

**الاعتمادية:** Gate 1 وGate 2.

**الهدف:** مصادر وقواعد مختومة ومحرك تقييم واحد حتمي دون تناقضات v2.2.

**الملفات الدقيقة:**

- قراءة: `H/09_CLAUDE_CODE_EXECUTION.md`، `H/contracts/domain.schema.json`، `H/reference/fact-catalog.json`، `H/05_ENGINES_AND_GOVERNANCE.md`، `H/inputs/decision-register.json`.
- تعديل/استكمال: `A/lib/crs.ts`، `A/lib/eligibility.ts`، `A/lib/assessment.ts`، `A/lib/screening.ts`، `A/lib/intelligence.ts`، `A/lib/professional-ai.ts`، `A/lib/reviews.ts`، `A/lib/v22-core.ts`.
- إنشاء عند غياب المكافئ: `A/lib/rule-import.ts`، `A/lib/rule-release.ts`، `A/lib/rule-resolver.ts`، `A/lib/normalization.ts`، `A/lib/pathways.ts`، `A/lib/noc.ts`، `A/lib/assessment-store.ts`.
- التكامل: `A/app/api/office/rules/import/route.ts`، `A/app/api/office/rules/releases/route.ts`، `A/app/api/candidates/[id]/analysis/route.ts`، `A/app/api/candidates/[id]/crs/route.ts`، `A/app/api/candidates/[id]/eligibility/route.ts`، `A/app/api/candidates/[id]/review/route.ts`، `A/components/operations/rules.tsx`، `A/app/desk.tsx`.
- اختبار: `A/tests/v22/engines.test.mjs`.

**التنفيذ الملزم:**

1. استيراد payload كامل، وفحص المصدر والـhash والتغطية والتواريخ والحدود؛ ختم MANAGER واحد ولو كان المؤلف. BUILDING ثم SEALED ذرياً؛ منع INSERT SEALED المباشر.
2. Resolver يحل نطاقاً واحداً معتمداً لكل family/dateBasis؛ غياب القاعدة RULE_UNAVAILABLE، والحقيقة الناقصة UNKNOWN.
3. RCIP بتاريخ اعتماد الإرسال الصادر خادمياً والمحوّل إلى Toronto؛ 2026 Pilot و2027 دائم مع رفض توصية 2026؛ لا grace أو state أو شاشة انتقالية.
4. حذف consent guard من NOC Adapter وحده، مع بقاء آليته والمزود وRBAC والاستشهادات والمراجعة المهنية.
5. تطبيع العمر واللغة والتعليم والزوج والخبرة والأجور والعرض من حقائق وسياسات موثقة؛ فصل FSW selection وCRS وأهلية المسارات والترتيب.
6. إكمال المكونات والـcaps وLMIF بطريقة MAX، وALL/ANY والاستثناءات لكل برنامج/stream معتمد؛ لا اختراع streams أو بيانات قانونية.
7. canonical_input_hash وتاريخ append-only، وفصل data/publication revisions وRAPID_SCREENING/VERIFIED_SCREENING وSHADOW، مع CAS وcommit ذري.

**معايير القبول:**

- مدير واحد يختم حزمته؛ التداخل أو المصدر/الحمولة الناقصان يمنعان الختم أو التفعيل.
- حدود التواريخ وToronto ورأس السنة وإعادة عرض نسخة تاريخية بالقواعد نفسها.
- NOC يعمل دون consentId ويرفض الاستشهاد المزور والوصول غير المخول؛ لا إلغاء لموافقات الميزات الأخرى.
- مدخلات ناقصة أو مصفوفة فاسدة لا crash ولا درجة مختلقة؛ مجموع المكونات والـcaps وMAX مطابق للسياسة.
- إزالة شرط/فرع لازم تمنع PASS؛ لا ranking رقمي دون rubric، ولا COMPLETE قانونية دون الأدلة المطلوبة.
- 100 طلب مطابق يتقارب إلى نتيجة canonical واحدة؛ اختلاف payload مع المفتاح نفسه 409؛ فشل batch أو تغير المدخل/القواعد يمنع النشر الجزئي.
- المعايير: AC-04، AC-06–AC-18، AC-24، AC-37.

**البرومبت الجاهز:**

```text
نفّذ Gate 3 فقط بعد قبول Gate 1 وGate 2. صحح محركات النظام الحالية وفق v2.2: مصادر وحمولات كاملة، ختم MANAGER واحد، Resolver مؤرخ، RCIP بتاريخ اعتماد الإرسال في Toronto بلا انتقال، وNOC بلا شرط موافقة. وحّد التطبيع وCRS والمسارات والترتيب والتقييم السريع والموثق في المحرك والتاريخ نفسيهما، مع canonical dedup وCAS وcommit ذري. لا تستبدل نقص القاعدة أو الدليل بقيمة مختلقة، ولا تضع fixtures اصطناعية في قواعد الإنتاج. سلّم الاختبارات والملفات والعوائق المحددة.
ممنوع العودة للحزم السابقة، وممنوع حذف الكود العامل، التزم حرفياً بقرارات v2.2. الأموال INTEGER وJSON TEXT حصراً؛ ممنوع REAL وJSONB. لا تبدأ من الصفر، ولا تنشئ أنظمة موازية، ولا تنشر على الموقع الحي.
```

## Gate 4 — حساب العميل والبوابة والتوقيع والاستعلام

**الاعتمادية:** Gate 1 وGate 2؛ ربط نتائج التقييم من Gate 3.

**الهدف:** رحلة عميل موحدة تحفظ المسودة والتوقيع وتفصل الحساب الكامل عن استعلام الحالة.

**الملفات الدقيقة:**

- قراءة: `H/09_CLAUDE_CODE_EXECUTION.md`، `H/10_CLIENT_PORTAL_UPGRADE_AR.md`، `H/contracts/client-portal-upgrade.schema.json`، `H/contracts/client-portal-openapi.yaml`، `A/lib/legal.ts`.
- الخدمات: `A/lib/client-account.ts`، `A/lib/client-access.ts`، `A/lib/otp.ts`، `A/lib/otp-delivery.ts`، `A/lib/password.ts`، `A/lib/intake.ts`، `A/lib/authorization.ts`، `A/lib/application-pdf.ts`، `A/lib/application-drafts.ts`، `A/lib/signature.ts`، `A/lib/status-lookup.ts`.
- API: `A/app/api/client/account/route.ts`، `A/app/api/client/otp/request/route.ts`، `A/app/api/client/otp/verify/route.ts`، `A/app/api/client/password/route.ts`، `A/app/api/client/password/login/route.ts`، `A/app/api/intake/route.ts`، `A/app/api/intake/drafts/route.ts`، `A/app/api/intake/drafts/[id]/route.ts`، `A/app/api/intake/drafts/[id]/signature/route.ts`، `A/app/api/client/status-lookup/route.ts`، `A/app/api/client/status-lookup/verify/route.ts`.
- الواجهة: `A/components/client/portal.tsx`، `A/components/client/account.tsx`، `A/components/client/login.tsx`، `A/components/client/application.tsx`، `A/components/client/fields.tsx`، `A/components/client/draft.ts`، `A/components/client/chrome.tsx`، `A/components/client/status-lookup.tsx`، `A/components/auth/controls.tsx`، `A/app/vision.css`، `A/app/auth.css`، `A/app/refinement.css`.
- اختبار: `A/tests/v22/portal.e2e.spec.ts`.

**التنفيذ الملزم:**

1. مدخلان فقط: تقديم جديد بالاسم والبريد وOTP، ومتابعة سابقة بالبريد وOTP أو كلمة المرور؛ إعادة استخدام الحساب بعد proof دون تكراره.
2. OTP ست خانات، paste والتنقل والأخطاء والمهل وإعادة الإرسال ومنع التكرار؛ ترحيب بالاسم المثبت.
3. مسودات حسابية CAS/idempotency وحفظ تلقائي واستعادة انقطاع الاتصال؛ الرجوع وتحديث الصفحة لا يفقدان البيانات.
4. Smart Path Selector من الكتالوج الحالي؛ تركيز المختار وخياراته والرجوع وخيار عدم التأكد دون تغيير الأهلية.
5. توقيع واحد بالإصبع والقلم والماوس؛ حفظ خاص للّقطة والإقرار والهوية والوقت والـhash. لا STALE ولا إعادة توقيع آلية بعد تعديل البيانات.
6. ربط التوقيع بالإرسال والإقرار/PDF ذرياً، مع حفظ replay والتاريخ القديم دون تصنيع توقيع.
7. Header للجلسة الكاملة الصالحة وHTTPS؛ Footer بزر استعلام واحد، ثم إثبات اتصال مسجل وscope محدود لخمس دقائق دون كشف وجود الملف مسبقاً.

**معايير القبول:**

- تسجيل/verify متزامن لا يكرر الحساب؛ legacy case password لا يفتح ملفات أخرى.
- حفظ من تبويبين وضياع ACK وoffline/reload/back دون فقد أو saved وهمية.
- التوقيع يصمد أمام التحجيم والخطوات وتعديل البيانات؛ لقطة ووقت التوقيع الأصليان لا يتغيران.
- الإرسال المزور أو المكرر أو الفاشل لا ينشئ طلباً أو إقراراً جزئياً.
- استعلام matched/unmatched/failure لا يكشف وجود الملف؛ token المحدود لا يقرأ الحساب أو الوثائق أو التوقيع.
- RTL/LTR و360/768/1440 وkeyboard/focus وخفض الحركة؛ لا أزرار أو نماذج مكررة.
- المعايير: AC-01، AC-24، AC-41–AC-50.

**البرومبت الجاهز:**

```text
نفّذ Gate 4 فقط. حدّث البوابة الحالية بمدخلي التقديم والمتابعة، والمصادقة القائمة، والحفظ الحسابي، واختيار المسار، والتوقيع الثابت، والإرسال الذري، ومؤشر الجلسة واستعلام الحالة المحدود. حافظ على الهوية الداكنة والزجاجية والذهب والفيروز، والبيانات والخدمات الحالية. لا تبطل التوقيع عند تعديل الملف، ولا تمنح جلسة حساب من استعلام الحالة، ولا توسّع كلمة مرور ملف إلى ملفات أخرى. اختبر الرحلة والأخطاء والتزامن والانقطاع والصلاحيات والأجهزة، وسلّم الأدلة والعوائق.
ممنوع العودة للحزم السابقة، وممنوع حذف الكود العامل، التزم حرفياً بقرارات v2.2. الأموال INTEGER وJSON TEXT حصراً؛ ممنوع REAL وJSONB. لا تبدأ من الصفر، ولا تنشئ أنظمة موازية، ولا تنشر على الموقع الحي.
```

## Gate 5 — الفوترة وPackage 8 والأتمتة التشغيلية

**الاعتمادية:** Gates 1–4.

**الهدف:** ربط الفوترة والمحادثة والمساعد والعمليات بنفس الحالة والهوية والمحرك والتخزين.

**الملفات الدقيقة:**

- قراءة: `H/09_CLAUDE_CODE_EXECUTION.md`، `H/08_PACKAGE_8_REALTIME_CHAT_RAPID_ASSESSMENT.md`، `H/contracts/v2_2.schema.json`، `H/contracts/chat-protocol.schema.json`، `H/06_WORKFLOWS_SECURITY_OPS.md`.
- المال: `A/lib/billing.ts`، `A/lib/invoice-pdf.ts`، `A/app/api/candidates/[id]/invoices/route.ts`، `A/app/api/invoices/[id]/route.ts`، `A/app/api/invoices/[id]/payments/route.ts`، `A/app/api/invoices/[id]/approval/route.ts`، `A/app/api/invoices/[id]/pdf/route.ts`، `A/app/api/invoices/[id]/notice/route.ts`، `A/components/client/billing.tsx`، `A/components/operations/billing.tsx`.
- المحادثة: `A/lib/case-chat.ts`، `A/lib/chat-transport.ts`، `A/lib/case-assistant.ts`، `A/lib/transcription.ts`، `A/worker/case-chat-room.ts`، `A/app/api/client/chat/route.ts`، `A/app/api/candidates/[id]/chat/route.ts`، `A/app/api/client/advisor/route.ts`، `A/components/client/case-chat.tsx`، `A/components/operations/case-chat.tsx`، `A/components/client/workspace-tools.tsx`، `A/components/client/voice-entry.tsx`.
- الأتمتة والعمليات: `A/lib/jobs.ts`، `A/lib/outbox.ts`، `A/lib/evidence-processing.ts`، `A/lib/facts.ts`، `A/lib/upload.ts`، `A/lib/document-preparation.ts`، `A/lib/status-notifications.ts`، `A/lib/expiry.ts`، `A/lib/services.ts`، `A/lib/employer-ats.ts`، `A/lib/advisory.ts`، `A/app/api/client/services/route.ts`، `A/app/api/public-services/route.ts`، `A/app/api/office/employers/route.ts`.
- دمج العرض: `A/components/client/account.tsx`، `A/components/client/portal.tsx`، `A/components/operations/intelligence.tsx`، `A/app/desk.tsx`، `A/lib/client-view.ts`، `A/app/api/client/route.ts`، `A/app/candidates/[id]/report/page.tsx`، `A/app/candidates/[id]/report/print.tsx`، `A/app/vision.css`.
- الربط: `A/vite.config.ts`، `A/cloudflare-env.d.ts`، ونقطة التشغيل المثبتة في `A/execution/V22_FILE_MAP.json`.
- اختبارات: `A/tests/v22/billing.test.mjs`، `A/tests/v22/chat.test.mjs`، `A/tests/v22/automation.test.mjs`، `A/tests/v22/operations.e2e.spec.ts`.

**التنفيذ الملزم:**

1. فواتير case-linked وخدمات كتالوج/مخصصة/مجانية وخصم ومهلة وعملة معتمدة صراحة؛ مجاميع خادمية وسجل مالي append-only.
2. CASH/CHEQUE/ZELLE/CASH_APP وسندات R2 خاصة؛ audit+payment+invoice+outbox داخل batch مع version/epoch/expiry/idempotency. لا بوابة تحويل أو ضريبة أو عملة مفترضة.
3. إحالة PENDING_APPROVAL تقفل الفاتورة حتى MANAGER واحد؛ بطاقات المال وAPI محمية بـview_financials والصلاحية الخاصة. PDF AR/EN وإخطار مالي محدود عبر القناة المهيأة.
4. Case chat canonical على D1/R2؛ Durable Object لتنسيق WebSocket فقط، وHTTP fallback وreplay وتسلسل وdedup. حفظ البريد الحالي دون تحويله إلى سجل محادثة بديل.
5. تحويل بشري وclaim واحد وautomationGeneration/CAS يمنعان رد AI المتأخر؛ صوت ومرفقات عبر pipeline الرفع والفحص نفسها.
6. مساعد واحد بأدوات مصرح بها، وموافقات chat/transcription النطاقية؛ Rapid Assessment من المحرك والتاريخ نفسيهما دون FINAL أو استبدال التقرير الموثق.
7. Jobs/leases/fencing/retry/DLQ وOutbox واحدة؛ waitUntil ليس مصدر الدوام. معالجة AMBIGUOUS قبل إعادة إرسال غير مؤكدة.
8. Zero-Touch: رفع وفحص واستخراج وحقائق وتقييم وإشعار صادق؛ hash يثبت سلامة البايتات ولا يجعل الاستنتاج حقيقة موثقة.
9. Receipts وإشعارات بلا محتوى محمي، وصلاحية مستندات وتجديد وcatch-up، وطلب خدمة صريح فقط ينشئ CRM event.
10. جهات العمل والشواغر وATS والترتيب الإرشادي من مصادر وسياسات فعلية؛ لا vacancy أو نسبة قبول أو سعر مرجعي أو progress مختلق.

**معايير القبول:**

- اختبارات الفوترة السبعة: إنشاء البنود والخصم؛ Cash جزئي؛ Zelle كامل مع سند؛ رفض التكرار؛ قفل الإحالة؛ إشعار وPDF؛ 403 وإخفاء المال لغير المخول.
- منع bypass الخصم عبر EDIT، وoverpayment وخلط case/currency؛ فشل batch لا يترك صفاً جزئياً.
- HTTP/WS: ترتيب وdedup وreconnect وفقد ACK وeviction؛ لا فقد أو تسرب لرسالة معتمدة؛ revocation نافذة.
- claim متزامن ينتج موظفاً واحداً؛ رد AI بعد handoff أو تغير السياق لا ينشر.
- لا تشغيل ملف غير نظيف أو transcript VERIFIED؛ لا اتصال خارجي دون موافقته المطلوبة.
- RAPID_SCREENING لا يستبدل verified pointer؛ recompute لا يكرر history أو leads أو فواتير أو إشعارات.
- تعطل cron والمزود والعامل يستعاد دون نجاح صوري؛ الجهات/ATS/الخدمات والتقارير تحافظ على scope والدليل.
- المعايير: AC-19–AC-24، AC-31–AC-40، AC-51–AC-60.

**البرومبت الجاهز:**

```text
نفّذ Gate 5 فقط بعد قبول Gates 1–4. أكمل الفوترة وPackage 8 والأتمتة ضمن التطبيق الحالي: معاملات مالية ذرية وسندات خاصة وصلاحيات وPDF وإشعارات؛ محادثة موحدة ومساعد وتحويل بشري وصوت ومرفقات وRapid Assessment من المحرك نفسه؛ Jobs وOutbox واستعادة وإزالة تكرار؛ ingestion وصلاحية مستندات وخدمات وCRM وجهات عمل وATS موثقة. أنجزها على دفعات داخل Gate 5 دون بوابات اعتماد إضافية أو أنظمة موازية. حافظ على البيانات والواجهات العاملة، واختبر كل تدفق وفشله وصلاحياته قبل التقرير النهائي للبوابة.
ممنوع العودة للحزم السابقة، وممنوع حذف الكود العامل، التزم حرفياً بقرارات v2.2. الأموال INTEGER وJSON TEXT حصراً؛ ممنوع REAL وJSONB. لا تبدأ من الصفر، ولا تنشئ أنظمة موازية، ولا تنشر على الموقع الحي.
```

## Gate 6 — التحقق المتكامل والأداء والاستعادة والتسليم

**الاعتمادية:** Gates 1–5.

**الهدف:** تسليم قابل للمراجعة بأدلة فعلية لكل قدرة مفعلة، دون نشر حي.

**الملفات الدقيقة:**

- قراءة: `H/acceptance/acceptance.json`، `H/09_CLAUDE_CODE_EXECUTION.md`، `H/inputs/decision-register.json`، `A/package.json`، `A/pnpm-lock.yaml`، `A/execution/V22_FILE_MAP.json`.
- اختبارات: `A/tests/v22/database.test.mjs`، `A/tests/v22/access.test.mjs`، `A/tests/v22/engines.test.mjs`، `A/tests/v22/portal.e2e.spec.ts`، `A/tests/v22/billing.test.mjs`، `A/tests/v22/chat.test.mjs`، `A/tests/v22/automation.test.mjs`، `A/tests/v22/operations.e2e.spec.ts`، `A/tests/v22/security.test.mjs`، `A/tests/v22/load.mjs`، `A/tests/v22/restore.test.mjs`.
- الخصوصية والاستعادة: `A/lib/privacy.ts`، `A/scripts/restore-drill.mjs`.
- التسليم: `A/execution/FINAL_ACCEPTANCE.md`، `H/DELIVERY_MANIFEST.json`، `H/acceptance/acceptance.json`، `H/acceptance/acceptance.csv`، `H/SHA256SUMS.txt`، `H/GATES_EXECUTION_PLAN.md`.

**معايير القبول:**

1. تشغيل أوامر المشروع الفعلية للوحدة والتكامل والمتصفح وTypeScript وbuild، وتسجيل الأوامر وexit codes والمخرجات؛ لا ادعاء باختبار لم ينفذ.
2. رحلة التسجيل→OTP→مسودة→مسار→توقيع→إرسال→محادثة→تحويل→تقييم→فاتورة→دفع→PDF→استعلام، وregressions الحزم 1–8.
3. اختبارات CSRF/Origin/IDOR/تجاوز scope/تزوير الدور/سحب الجلسة/SSRF/حقن النموذج/الملفات الخبيثة/تسرب JSON وHTML وPDF وlogs.
4. RTL/LTR والأجهزة والوصول وخفض الحركة والانقطاع والتزامن وإعادة المحاولة دون فقد بيانات.
5. حمل موثق وفق profile معتمد، يشمل HTTP وD1 و100 socket عبر 20 غرفة وreconnect؛ الأهداف من المواصفة، والنتيجة من القياس الفعلي.
6. استعادة D1/R2 والمفاتيح في بيئة معزولة، وقياس RPO/RTO، وإعادة تطبيق المحو ومنع إعادة الإرسال، وrollback متوافق أو forward fix.
7. ربط AC-01–AC-60 بأدلة أو FAIL/BLOCKED/NOT_RUN؛ نقص اعتماد قانوني أو مزود أو سياسة أو بيئة اختبار لا يختفي من التقرير.
8. الأرشيف النهائي يتضمن الملفات المعدلة والعقود وmigrations والتقارير والمخرجات؛ عدد الملفات وSHA-256 محسوبان من البايتات الفعلية.
9. لا نشر حي أو workflow نشر أو تعديل موارد الإنتاج. إغلاق الخطة ليس تصريح نشر.

**البرومبت الجاهز:**

```text
نفّذ Gate 6 فقط بعد قبول Gates 1–5. شغّل التحقق المتكامل والأمان والأجهزة والأداء والاستعادة على البيئات المصرح بها، واربط معايير AC-01–AC-60 بالأدلة الحقيقية. سلّم الملفات المعدلة والأوامر وexit codes والمخرجات والعوائق والأرشيف وبصمته المحسوبة. إذا نقصت معلومة: ابحث وتحقق؛ إن لم تثبت فوسم القدرة التابعة BLOCKED. لا تخفِ NOT_RUN ولا تعتبر اختبار SQLite أو مرجع عقد بديلاً عن E2E أو D1 الفعلية. أصلح العيب داخل نطاق بوابته وأعد الاختبارات المتأثرة دون إنشاء بوابات جديدة.
ممنوع العودة للحزم السابقة، وممنوع حذف الكود العامل، التزم حرفياً بقرارات v2.2. الأموال INTEGER وJSON TEXT حصراً؛ ممنوع REAL وJSONB. لا تبدأ من الصفر، ولا تنشئ أنظمة موازية، ولا تنشر على الموقع الحي.
```

## حالة التنفيذ (سجل)

- Gate 1–5: معتمدة من المالك (آخرها Gate 5 في `44fd112`).
- Gate 6: منفذة محلياً وبانتظار الاعتماد النهائي؛ الأدلة في `execution/FINAL_ACCEPTANCE.md`. لا نشر ولا migration على الإنتاج. إغلاق الخطة ليس تصريح نشر.
