'use client';
// v2.2 Gate 5 — the client's own invoices (read-only): the same server figures the office sees, in the invoice currency.
// No payment gateway: the office records cash, cheque, Zelle and Cash App payments.
import { Receipt } from 'lucide-react';
import { usePortal } from './chrome';
export type ClientInvoice={invoiceId:string;currency:string;status:'DRAFT'|'PENDING_APPROVAL'|'PARTIAL'|'PAID'|'OVERDUE';subtotalCents:number;discountCents:number;totalCents:number;paidCents:number;remainingCents:number;deadline:string|null;note:string|null;version:number;items:{serviceName:string;isFree:boolean;unitPriceCents:number;referencePriceCents:number|null}[];payments:{amountCents:number;method:string;paidAt:string}[]};
const fmt=(c:number,cur:string)=>{const s=String(c).padStart(3,'0');return s.slice(0,-2).replace(/\B(?=(\d{3})+(?!\d))/g,',')+'.'+s.slice(-2)+' '+cur;};
const STATUS:Record<ClientInvoice['status'],[string,string]>={DRAFT:['مستحقة','Due'],PENDING_APPROVAL:['قيد مراجعة المكتب','Under office review'],PARTIAL:['مدفوعة جزئيًا','Partially paid'],PAID:['مدفوعة','Paid'],OVERDUE:['متأخرة','Overdue']};
const METHOD:Record<string,[string,string]>={CASH:['نقدًا','Cash'],CHEQUE:['شيك','Cheque'],ZELLE:['Zelle','Zelle'],CASH_APP:['Cash App','Cash App']};
export function ClientBilling({invoices}:{invoices:ClientInvoice[]|undefined}){
 const {lang}=usePortal(),ar=lang==='ar',L=(a:string,e:string)=>ar?a:e;
 if(!invoices?.length)return null;
 return <section className="panel client-billing" aria-label={L('الفواتير','Invoices')}><header><span className="workspace-icon"><Receipt size={20}/></span><h2>{L('الفواتير والمدفوعات','Invoices & payments')}</h2></header>
  {invoices.map(i=><details key={i.invoiceId} className={'client-invoice '+i.status.toLowerCase()}><summary><span className="status-chip">{STATUS[i.status][ar?0:1]}</span><strong dir="ltr">{fmt(i.totalCents,i.currency)}</strong><span>{L('المتبقي','Balance')} <b dir="ltr">{fmt(i.remainingCents,i.currency)}</b></span>{i.deadline&&<small>{L('الاستحقاق','Due')} {i.deadline}</small>}</summary>
   <table><tbody>{i.items.map((x,n)=><tr key={n}><td>{x.serviceName}</td><td dir="ltr">{x.isFree?L('مجانًا','Free'):fmt(x.unitPriceCents,i.currency)}</td></tr>)}{i.discountCents>0&&<tr><td>{L('الخصم','Discount')}</td><td dir="ltr">- {fmt(i.discountCents,i.currency)}</td></tr>}<tr><td>{L('المدفوع','Paid')}</td><td dir="ltr">{fmt(i.paidCents,i.currency)}</td></tr></tbody></table>
   {i.payments.length>0&&<ul>{i.payments.map((p,n)=><li key={n}>{p.paidAt.slice(0,10)} · {(METHOD[p.method]||[p.method,p.method])[ar?0:1]} · <span dir="ltr">{fmt(p.amountCents,i.currency)}</span></li>)}</ul>}
   {i.note&&<p className="muted">{i.note}</p>}<p className="fine-print">{L('طرق الدفع لدى المكتب: نقدًا، شيك، Zelle، Cash App.','Office payment methods: cash, cheque, Zelle, Cash App.')}</p></details>)}
 </section>;
}
