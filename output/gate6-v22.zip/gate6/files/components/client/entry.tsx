'use client';
import { ShieldCheck } from 'lucide-react';
import { usePortal } from './chrome';
// Brand header of the unified client entry. The two entry actions live in ClientAccount (one account flow with the
// START_NEW / RETURN intent), so this header carries no second set of buttons or forms.
export function ClientEntry(){
 const {lang}=usePortal(),ar=lang==='ar';
 return <section className="client-entry" aria-label={ar?'بوابة العملاء':'Client portal'}>
  <span className="entry-badge"><ShieldCheck size={15}/>{ar?'منصة معتمدة وآمنة':'Verified & Secure Portal'}</span>
  <img className="entry-logo" src="/brand/alhijrah-services.jpg" width={84} height={84} alt="ALHIJRAH Services"/>
  {ar?<><h1>مكتب الهجرة – عبدالله المريسي</h1><p>خدمات إدارية متخصصة في ملفات الهجرة والتوظيف في كندا وأمريكا.</p></>:<><h1>ALHIJRAH SERVICES</h1><p>Specialized Administrative Services for Canadian &amp; U.S. Immigration and Employment Applications.</p><small>Professional Application Preparation &amp; Case Management.</small></>}
 </section>;
}
