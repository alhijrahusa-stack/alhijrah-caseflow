'use client';
import { useEffect,useRef,useState } from 'react';
import { LoaderCircle,UserRound,ArrowLeft,ArrowRight,Sparkles } from 'lucide-react';
import { api } from '@/lib/client';
import { PortalFrame,usePortal,displayError } from './chrome';
import { ApplicationForm } from './application';
import { ClientTrackerBody } from './tracker';
import { ClientIntakeBanner } from './intake-banner';
import { ClientAccount } from './account';
export { PortalHeader } from './chrome';
type Me={authenticated:boolean;email?:string;displayName?:string|null};
// v2.2 Gate 4 — /apply is the START_NEW entry. Without an account session it shows the unified account entry; an
// existing case or account is never a reason to redirect a new application to an old file. A verified account without
// a profile name is asked for it once (no default name is invented), then greeted and taken to its account draft.
function Welcome({name}:{name:string}){const {lang}=usePortal(),ar=lang==='ar';return <section className="account-welcome" role="status"><Sparkles size={20}/><div><strong>{ar?`أهلًا بك، ${name}`:`Welcome, ${name}`}</strong><span>{ar?'مسودتك محفوظة في حسابك ويمكنك المتابعة في أي وقت.':'Your draft is saved in your account; continue any time.'}</span></div></section>;}
function NameStep({onSaved}:{onSaved:(name:string)=>void}){const {lang}=usePortal(),ar=lang==='ar',Arrow=ar?ArrowLeft:ArrowRight;const [name,setName]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(''),lock=useRef(false);
 async function save(){if(lock.current)return;lock.current=true;setBusy(true);setError('');try{const r=await api<{displayName:string}>('/api/client/account',{method:'POST',body:JSON.stringify({action:'profile',name})});onSaved(r.displayName);}catch(e){setError((e as Error).message);}finally{lock.current=false;setBusy(false);}}
 return <main className="portal-wrap account-page"><article className="panel account-card"><span className="account-emblem"><UserRound size={26}/></span><h2>{ar?'ما اسمك الكامل؟':'What is your full name?'}</h2><form onSubmit={e=>{e.preventDefault();void save();}}><label className="field"><span>{ar?'الاسم الكامل':'Full name'}</span><input autoFocus autoComplete="name" required minLength={2} maxLength={150} value={name} onChange={e=>setName(e.target.value)}/></label><button className="button gold" disabled={busy}>{busy?<LoaderCircle className="spin" size={17}/>:<Arrow size={17}/>}{ar?'متابعة':'Continue'}</button>{error&&<div className="error-banner" role="alert">{displayError(error,lang)}</div>}</form></article></main>;}
function IntakeEntry(){
 const [me,setMe]=useState<Me|null>(null);
 useEffect(()=>{let live=true;api<Me>('/api/client/account').then(r=>{if(live)setMe(r);}).catch(()=>{if(live)setMe({authenticated:false});});return()=>{live=false;};},[]);
 if(!me)return <main className="portal-wrap"><div className="loading-state"><LoaderCircle className="spin"/></div></main>;
 if(!me.authenticated||!me.email)return <ClientAccount initialIntent="START_NEW"/>;
 if(!me.displayName)return <NameStep onSaved={displayName=>setMe({...me,displayName})}/>;
 return <><Welcome name={me.displayName}/><ClientIntakeBanner/><ApplicationForm accountEmail={me.email}/></>;
}
export function ApplicationIntake(){return <PortalFrame><IntakeEntry/></PortalFrame>;}
export function ClientTracker(){return <PortalFrame tracking><ClientTrackerBody/></PortalFrame>;}
