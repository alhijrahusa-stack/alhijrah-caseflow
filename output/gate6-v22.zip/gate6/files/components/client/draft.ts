'use client';
import { useEffect,useRef,useState,useCallback } from 'react';
import { z } from 'zod';
import { blankProfile,profileSchema } from '@/lib/model';
import type { Profile } from '@/lib/model';
import { detailsSchema } from '@/lib/intake';
import type { IntakeDetails } from '@/lib/intake';
import { ClientApiError,api,makeRequestId } from '@/lib/client';
import { sha256Hex,jcs } from '@/lib/v22-core';
const KEY='alh.intake.draft.v2';
const draftSchema=z.object({version:z.literal(2),savedAt:z.number(),expiresAt:z.number(),profile:profileSchema.omit({consent:true}).extend({fullName:z.string().max(150),email:z.string().max(254),phone:z.string().max(40),noc:z.string().max(5)}),details:detailsSchema,step:z.number().int().min(1).max(4).default(1)});
export function useIntakeDraft(profile:Profile,details:IntakeDetails,restore:(p:Profile,d:IntakeDetails,step:number)=>void,active:boolean,step=1){
 const [enabled,setEnabled]=useState(true),[status,setStatus]=useState<'loading'|'saving'|'saved'|'off'|'error'>('loading'),[restored,setRestored]=useState(false),[ready,setReady]=useState(false);const latest=useRef({profile,details,active,ready,enabled,step});latest.current={profile,details,active,ready,enabled,step};
 const flush=useCallback(()=>{const current=latest.current;if(!current.active||!current.ready||!current.enabled||closed.current)return;try{const {consent,...data}=current.profile;localStorage.setItem(KEY,JSON.stringify({version:2,savedAt:Date.now(),expiresAt:Date.now()+86400000,profile:data,details:current.details,step:current.step}));setStatus('saved');}catch{setStatus('error');}},[]);
 const closed=useRef(false),restoreRef=useRef(restore);restoreRef.current=restore;
 useEffect(()=>{if(!active){setReady(true);return;}try{const on=localStorage.getItem('alh.intake.draft.enabled')!=='false';setEnabled(on);if(on){const raw=localStorage.getItem(KEY);if(raw&&raw.length<150000){const result=draftSchema.safeParse(JSON.parse(raw));if(result.success&&result.data.expiresAt>Date.now()){restoreRef.current({...blankProfile,...result.data.profile,consent:true},result.data.details,result.data.step);setRestored(true);}else localStorage.removeItem(KEY);}}setStatus(on?'saved':'off');}catch{setStatus('error');}setReady(true);},[active]);
 useEffect(()=>{if(!active||!ready||closed.current)return;if(!enabled){try{localStorage.removeItem(KEY);setStatus('off');}catch{setStatus('error');}return;}setStatus('saving');const timer=setTimeout(()=>{try{const {consent,...data}=profile;localStorage.setItem(KEY,JSON.stringify({version:2,savedAt:Date.now(),expiresAt:Date.now()+24*60*60*1000,profile:data,details,step}));setStatus('saved');}catch{setStatus('error');}},450);return()=>clearTimeout(timer);},[profile,details,step,enabled,ready,active]);
 useEffect(()=>{const visibility=()=>{if(document.visibilityState==='hidden')flush();};window.addEventListener('pagehide',flush);document.addEventListener('visibilitychange',visibility);return()=>{window.removeEventListener('pagehide',flush);document.removeEventListener('visibilitychange',visibility);};},[flush]);
 function toggle(){const next=!enabled;setEnabled(next);try{localStorage.setItem('alh.intake.draft.enabled',String(next));if(!next)localStorage.removeItem(KEY);}catch{setStatus('error');}}
 function clear(){try{localStorage.removeItem(KEY);}catch{}setRestored(false);}
 function finish(){closed.current=true;clear();}
 return {enabled,status,restored,toggle,clear,finish,flush};
}

// ---- v2.2 Gate 4: account drafts. The server (client_application_drafts) is the source of truth; "محفوظ" is shown only
// after the server confirms a revision. Each pending payload keeps one mutationId until acknowledged, so a lost ACK
// replays instead of duplicating. A stale revision surfaces a conflict (two tabs) instead of overwriting. Pending edits
// are kept in localStorage under an opaque account tag (never the email) for pagehide/offline and cleared on finish.
export type PathSelection={selectedPathId:'work'|'immigration'|'study'|'other'|'unsure'|null;focused:boolean;needsGuidance:boolean;subOptions:{key:string;value:string|number|boolean|null}[]};
export type DraftPayload={profile:Omit<Profile,'consent'>;details:IntakeDetails;pathSelection:PathSelection;step:number};
export type SignatureRecord={signatureId:string;draftRevision:number;state:'SIGNED';signedPayloadHash:string;legalVersion:string;signedAt:string;imageHash:string};
export type DraftResource={draftId:string;revision:number;state:'DRAFT'|'SUBMITTED';payload:DraftPayload;signature:SignatureRecord|null};
export type AccountDraftStatus='loading'|'saving'|'saved'|'offline'|'conflict'|'error';
type Pending={draftId:string;baseRevision:number;mutationId:string;payload:DraftPayload};
const pendingKey=(tag:string)=>'alh.account.draft.pending.'+tag,createKey=(tag:string)=>'alh.account.draft.create.'+tag;
const read=<T,>(k:string):T|null=>{try{const v=localStorage.getItem(k);return v&&v.length<200000?JSON.parse(v) as T:null;}catch{return null;}};
const write=(k:string,v:unknown)=>{try{localStorage.setItem(k,JSON.stringify(v));}catch{}};
const drop=(k:string)=>{try{localStorage.removeItem(k);}catch{}};
export function useAccountDraft(email:string,payload:DraftPayload,restore:(p:DraftPayload)=>void,active:boolean){
 const [status,setStatus]=useState<AccountDraftStatus>('loading'),[draft,setDraft]=useState<{draftId:string;revision:number;signature:SignatureRecord|null}|null>(null),[conflict,setConflict]=useState<DraftResource|null>(null),[message,setMessage]=useState('');
 const tag=useRef(''),state=useRef({payload,draft:null as typeof draft,saving:null as Promise<number>|null,lastSaved:'',pending:null as Pending|null,closed:false});
 const restoreRef=useRef(restore);
 useEffect(()=>{state.current.payload=payload;state.current.draft=draft;restoreRef.current=restore;});
 const persistPending=useCallback(()=>{const s=state.current;if(!tag.current||!s.draft||s.closed)return;const body=jcs(s.payload);if(body===s.lastSaved){drop(pendingKey(tag.current));return;}const p:Pending=s.pending&&jcs(s.pending.payload)===body?s.pending:{draftId:s.draft.draftId,baseRevision:s.draft.revision,mutationId:makeRequestId(),payload:s.payload};s.pending=p;write(pendingKey(tag.current),p);},[]);
 const save=useCallback(async():Promise<number>=>{
  const s=state.current;if(!s.draft)throw new Error('DRAFT_NOT_READY');if(s.saving)return s.saving;
  const body=jcs(s.payload);if(body===s.lastSaved)return s.draft.revision;
  persistPending();const p=s.pending!;setStatus('saving');
  s.saving=(async()=>{try{
   const r=await api<{revision:number}>('/api/intake/drafts/'+p.draftId,{method:'PUT',body:JSON.stringify({expectedRevision:p.baseRevision,mutationId:p.mutationId,payload:p.payload})});
   s.lastSaved=jcs(p.payload);const next={...s.draft!,revision:r.revision};s.draft=next;setDraft(next);s.pending=null;
   if(jcs(s.payload)===s.lastSaved){drop(pendingKey(tag.current));setStatus('saved');}else{persistPending();}
   return r.revision;
  }catch(e){
   if(e instanceof ClientApiError&&e.status===409&&e.code==='MUTATION_REUSED'){s.pending=null;persistPending();throw e;}
   if(e instanceof ClientApiError&&e.status===409){const server=await api<DraftResource>('/api/intake/drafts/'+p.draftId).catch(()=>null);if(server)setConflict(server);setStatus('conflict');throw e;}
   if(e instanceof ClientApiError&&e.status===401){setStatus('error');setMessage('انتهت الجلسة. أكّد بريدك من جديد؛ تعديلاتك محفوظة على هذا الجهاز.');throw e;}
   if(e instanceof ClientApiError){setStatus('error');setMessage(e.message);throw e;}
   setStatus('offline');throw e;
  }finally{s.saving=null;}})();
  return s.saving;
 },[persistPending]);
 useEffect(()=>{if(!active||!email)return;let live=true;void(async()=>{try{
  tag.current=(await sha256Hex('alh-device:'+email.trim().toLowerCase())).slice(0,24);
  const list=await api<{items:{draftId:string;state:string}[]}>('/api/intake/drafts');
  let id=list.items.find(i=>i.state==='DRAFT')?.draftId;
  if(!id){const requestKey=read<string>(createKey(tag.current))||makeRequestId();write(createKey(tag.current),requestKey);id=(await api<DraftResource>('/api/intake/drafts',{method:'POST',body:JSON.stringify({requestKey})})).draftId;}
  const server=await api<DraftResource>('/api/intake/drafts/'+id);if(!live)return;
  const local=read<Pending>(pendingKey(tag.current));
  state.current.lastSaved=jcs(server.payload);const d={draftId:server.draftId,revision:server.revision,signature:server.signature};state.current.draft=d;setDraft(d);
  if(local&&local.draftId===server.draftId&&local.baseRevision===server.revision){state.current.pending=local;restoreRef.current(local.payload);setStatus('saving');}
  else if(local&&local.draftId===server.draftId&&local.baseRevision<server.revision){restoreRef.current(local.payload);setConflict(server);setStatus('conflict');}
  else{restoreRef.current(server.payload);setStatus('saved');drop(pendingKey(tag.current));}
 }catch(e){if(live){setStatus(e instanceof ClientApiError?'error':'offline');setMessage((e as Error).message);}}})();return()=>{live=false;};},[active,email]);
 // Debounced autosave (500 ms after the last edit); retry when the connection returns.
 useEffect(()=>{if(!draft||state.current.closed||status==='conflict')return;if(jcs(payload)===state.current.lastSaved)return;persistPending();const t=setTimeout(()=>{void save().catch(()=>{});},500);return()=>clearTimeout(t);},[payload,draft,status,save,persistPending]);
 useEffect(()=>{const online=()=>{if(state.current.draft&&status!=='conflict')void save().catch(()=>{});};const hide=()=>persistPending();window.addEventListener('online',online);window.addEventListener('pagehide',hide);document.addEventListener('visibilitychange',hide);return()=>{window.removeEventListener('online',online);window.removeEventListener('pagehide',hide);document.removeEventListener('visibilitychange',hide);};},[save,persistPending,status]);
 // Conflict resolution: take the server copy, or keep mine on top of the latest server revision (explicit choice).
 function resolve(choice:'server'|'mine'){if(!conflict)return;const s=state.current;
  if(choice==='server'){api<DraftResource>('/api/intake/drafts/'+conflict.draftId).then(server=>{s.lastSaved=jcs(server.payload);s.pending=null;drop(pendingKey(tag.current));const d={draftId:server.draftId,revision:server.revision,signature:server.signature};s.draft=d;setDraft(d);restoreRef.current(server.payload);setConflict(null);setStatus('saved');}).catch(e=>setMessage((e as Error).message));return;}
  api<DraftResource>('/api/intake/drafts/'+conflict.draftId).then(server=>{s.lastSaved=jcs(server.payload);s.pending=null;const d={draftId:server.draftId,revision:server.revision,signature:server.signature};s.draft=d;setDraft(d);setConflict(null);setStatus('saving');}).catch(e=>setMessage((e as Error).message));
 }
 const flush=useCallback(async()=>{for(let i=0;i<3;i++){const rev=await save();if(jcs(state.current.payload)===state.current.lastSaved)return rev;}return save();},[save]);
 function setSignature(signature:SignatureRecord|null,revision:number){const s=state.current;if(!s.draft)return;const d={...s.draft,signature,revision};s.draft=d;setDraft(d);}
 function finish(){state.current.closed=true;if(tag.current){drop(pendingKey(tag.current));drop(createKey(tag.current));}}
 return {status,draft,conflict,message,flush,resolve,setSignature,finish,accountKey:async()=>sha256Hex('client-account:v1:'+email.trim().toLowerCase())};
}
