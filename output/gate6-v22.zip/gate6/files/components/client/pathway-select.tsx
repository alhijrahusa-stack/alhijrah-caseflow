'use client';
import { useEffect,useRef,useState } from 'react';
import type { KeyboardEvent } from 'react';
import { Landmark,Briefcase,GraduationCap,Plane,Wrench,Compass,Check,ArrowLeft,ArrowRight,CircleCheck } from 'lucide-react';
import { categories,pathwaysOf,pathwayById,suggestPathways,guideComplete,blankGuide } from '@/lib/pathways';
import type { CategoryId,Guide } from '@/lib/pathways';
// First intake stage: five pathway cards (radio semantics, arrow-key navigation), the chosen card expands its
// sub-pathways; "not sure" opens a short plain-language guide whose fixed rules suggest pathways.
// v2.2 Gate 4 (Smart Path Selector): choosing a card enters FOCUSED — the other cards fade (<=160 ms), then become inert
// and leave the layout; the chosen card is centered with its gold frame and check, and only its options show, with
// «متابعة التقييم والتقديم» and «رجوع للخلف». Back returns to BROWSING without touching the selection or any field.
// Focus state is owned by the form (saved in the account draft); the catalog is the existing one.
const icons:Record<CategoryId,typeof Landmark>={pr:Landmark,work:Briefcase,study:GraduationCap,visit:Plane,trades:Wrench};
type Value={category:string;pathway:string;guide:Guide};
const Q:{key:keyof Guide;ar:string;en:string;options:[string,string,string][];show:(g:Guide)=>boolean}[]=[
 {key:'goal',ar:'ما هدفك الأساسي من كندا؟',en:'What is your main goal in Canada?',options:[['settle','الاستقرار الدائم','Settle permanently'],['work','العمل','Work'],['study','الدراسة','Study'],['visit','الزيارة','Visit']],show:()=>true},
 {key:'offer',ar:'هل لديك عرض عمل كندي مكتوب؟',en:'Do you have a written Canadian job offer?',options:[['yes','نعم','Yes'],['no','لا','No']],show:g=>g.goal==='settle'||g.goal==='work'},
 {key:'trade',ar:'هل لديك سنتان فأكثر من خبرة حرفية أو ميدانية أو زراعية؟',en:'Do you have 2+ years of trade, field or agricultural experience?',options:[['yes','نعم','Yes'],['no','لا','No']],show:g=>g.goal==='settle'||g.goal==='work'},
 {key:'degree',ar:'هل لديك مؤهل بعد الثانوية (دبلوم أو جامعة)؟',en:'Do you have a post-secondary credential (diploma or degree)?',options:[['yes','نعم','Yes'],['no','لا','No']],show:g=>g.goal==='settle'||g.goal==='work'},
 {key:'french',ar:'هل تتحدث الفرنسية بمستوى جيد؟',en:'Do you speak French well?',options:[['yes','نعم','Yes'],['no','لا','No']],show:g=>g.goal==='settle'||g.goal==='work'},
];
export function PathwaySelect({value,onChange,onContinue,ar,focused=false,onFocusChange}:{value:Value;onChange:(v:Value)=>void;onContinue:()=>void;ar:boolean;focused?:boolean;onFocusChange?:(v:boolean)=>void}){
 const cards=useRef<(HTMLButtonElement|null)[]>([]),notSure=value.category==='not_sure',ready=!!value.pathway&&!!pathwayById(value.pathway);
 const isFocused=focused&&!!value.category&&!notSure,[settledFor,setSettledFor]=useState<string|null>(null),settled=isFocused&&settledFor===value.category;
 useEffect(()=>{if(!isFocused)return;const t=setTimeout(()=>setSettledFor(value.category),160);return()=>clearTimeout(t);},[isFocused,value.category]);
 function pick(category:string,focus=true){if(category!==value.category){const keep=pathwayById(value.pathway)?.category===category?value.pathway:'';onChange({...value,category,pathway:keep});}if(focus)onFocusChange?.(true);}
 function back(){onFocusChange?.(false);const i=categories.findIndex(c=>c.id===value.category);requestAnimationFrame(()=>cards.current[i]?.focus());}
 function keys(e:KeyboardEvent<HTMLButtonElement>,i:number){if(isFocused)return;const n=categories.length;const step=e.key==='ArrowDown'||e.key===(ar?'ArrowLeft':'ArrowRight')?1:e.key==='ArrowUp'||e.key===(ar?'ArrowRight':'ArrowLeft')?-1:0;if(!step)return;e.preventDefault();const next=(i+step+n)%n;cards.current[next]?.focus();pick(categories[next].id,false);}
 const guide={...blankGuide,...value.guide},suggestions=guideComplete(guide)?suggestPathways(guide):[];
 return <section className="pw-select" aria-labelledby="pw-title">
  <header className="pw-head"><span className="pw-eyebrow">{ar?'الخطوة 1 من 5':'Step 1 of 5'}</span><h2 id="pw-title">{ar?'اختر مسار طلبك':'Choose Your Application Pathway'}</h2><p>{ar?'ماذا ترغب أن تفعل في كندا؟ اختر الخدمة المناسبة، وسنوجّهك إلى خطوات التقييم.':'What would you like to do in Canada? Choose the right service and we will guide you through the assessment steps.'}</p></header>
  <div className={'pw-grid'+(isFocused?' focused':'')+(settled?' settled':'')} role="radiogroup" aria-labelledby="pw-title">{categories.map((c,i)=>{const Icon=icons[c.id],on=value.category===c.id,subs=pathwaysOf(c.id),hidden=isFocused&&!on;return <div key={c.id} className={'pw-card'+(on?' on':'')+(hidden?' off':'')+(c.id==='trades'?' wide':'')} inert={hidden&&settled?true:undefined} aria-hidden={hidden||undefined}>
   <button type="button" ref={el=>{cards.current[i]=el;}} role="radio" aria-checked={on} tabIndex={on||(!value.category&&i===0)||(notSure&&i===0)?0:-1} className="pw-card-head" onClick={()=>pick(c.id)} onKeyDown={e=>keys(e,i)}>
    <span className="pw-icon"><Icon size={22}/></span><span className="pw-copy"><strong>{ar?c.ar:c.en}</strong><small>{ar?c.en:c.ar}</small><em>{ar?c.descAr:c.descEn}</em></span><span className="pw-tick" aria-hidden="true">{on&&<Check size={15}/>}</span></button>
   {on&&<div className="pw-subs" role="radiogroup" aria-label={ar?'اختر الخيار الفرعي':'Choose a sub-option'}>{subs.map(s=>{const sel=value.pathway===s.id;return <button type="button" key={s.id} role="radio" aria-checked={sel} className={'pw-sub'+(sel?' on':'')} onClick={()=>onChange({...value,pathway:s.id})}><span className="pw-dot" aria-hidden="true">{sel&&<Check size={12}/>}</span><span>{ar?s.ar:s.en}</span></button>;})}</div>}
  </div>;})}</div>
  {!isFocused&&<div className={'pw-unsure'+(notSure?' on':'')}><button type="button" aria-expanded={notSure} className="pw-unsure-head" onClick={()=>onChange({...value,category:notSure?'':'not_sure',pathway:notSure?'':value.pathway})}><Compass size={19}/><span><strong>{ar?'لست متأكداً من المسار المناسب':'Not Sure Which Pathway?'}</strong><small>{ar?'أجب عن أسئلة قصيرة، دون الحاجة لمعرفة أسماء البرامج.':'Answer a few short questions; no program names needed.'}</small></span></button>
   {notSure&&<div className="pw-guide">{Q.filter(q=>q.show(guide)).map(q=><fieldset key={q.key} className="pw-q"><legend>{ar?q.ar:q.en}</legend><div>{q.options.map(([v,a,e])=><button type="button" key={v} aria-pressed={guide[q.key]===v} className={guide[q.key]===v?'on':''} onClick={()=>onChange({...value,pathway:'',guide:{...guide,[q.key]:v}})}>{ar?a:e}</button>)}</div></fieldset>)}
    {suggestions.length>0&&<div className="pw-suggest" aria-live="polite"><strong>{ar?'مسارات محتملة لك — اختر واحدًا للمتابعة':'Possible pathways — choose one to continue'}</strong>{suggestions.map(s=>{const pw=pathwayById(s.id)!,sel=value.pathway===s.id;return <button type="button" key={s.id} aria-pressed={sel} className={'pw-sub'+(sel?' on':'')} onClick={()=>onChange({...value,pathway:s.id})}><span className="pw-dot" aria-hidden="true">{sel&&<Check size={12}/>}</span><span><b>{ar?pw.ar:pw.en}</b><small>{ar?s.ar:s.en}</small></span></button>;})}<p className="pw-note">{ar?'اقتراحات استرشادية وفق قواعد ثابتة، وليست قرار أهلية.':'Guidance from fixed rules, not an eligibility decision.'}</p></div>}
   </div>}</div>}
  <div className="pw-foot">{ready&&<span className="pw-chosen"><CircleCheck size={16}/>{ar?pathwayById(value.pathway)!.ar:pathwayById(value.pathway)!.en}</span>}<button type="button" className="button gold pw-cta" disabled={!ready} onClick={onContinue}>{ar?'متابعة التقييم والتقديم':'Continue assessment & application'}{ar?<ArrowLeft size={17}/>:<ArrowRight size={17}/>}</button>{isFocused&&<button type="button" className="button subtle pw-back" onClick={back}>{ar?<ArrowRight size={17}/>:<ArrowLeft size={17}/>}{ar?'رجوع للخلف':'Back'}</button>}</div>
 </section>;
}
