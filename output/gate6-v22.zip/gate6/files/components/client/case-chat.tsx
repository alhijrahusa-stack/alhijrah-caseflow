'use client';
// v2.2 Gate 5 — client case chat on the canonical conversation (/api/client/chat). Messages are written over HTTPS with a
// client message id (a lost reply is retried with the same id and never duplicated); updates arrive over the case
// WebSocket when available, otherwise by keyset replay (afterSequence). Purpose consents (assistant, notifications,
// voice transcription) are explicit toggles; attachments and voice notes go through the normal upload and scan and are
// playable only once clean. Rapid Assessment runs only after the client confirms it.
import { useCallback,useEffect,useRef,useState } from 'react';
import { Send,LoaderCircle,UserRound,Gauge,ShieldCheck,Clock3 } from 'lucide-react';
import { api,makeRequestId } from '@/lib/client';
import { usePortal,displayError } from './chrome';
import { ChatMediaControls } from '../chat-media';

export type ChatAttachment={evidenceId:string;mediaKind:'DOCUMENT'|'IMAGE'|'VOICE_NOTE';state:'PROCESSING'|'AVAILABLE'|'REJECTED'|'ERASED';mimeType:string;byteLength:number|null;durationMs:number|null;transcriptState:string};
export type ChatMessage={messageId:string;sequence:number;clientMessageId:string;senderDisplayRef:string;actorType:'CLIENT'|'STAFF'|'ASSISTANT'|'SYSTEM';kind:'TEXT'|'ATTACHMENT'|'VOICE_NOTE'|'ASSESSMENT_LINK'|'SYSTEM';text:string|null;attachments:ChatAttachment[];assessmentId:string|null;createdAt:string;pending?:boolean};
export type Conversation={conversationId:string;caseId:string;state:'BOT_ACTIVE'|'HANDOFF_PENDING'|'HUMAN_ACTIVE'|'CLOSED';assignedStaffId:string|null;conversationRevision:number;automationGeneration:number;lastSequence:number;assistantAvailability:'READY'|'UNCONFIGURED'|'CONSENT_REQUIRED'|'UNAVAILABLE';presence:string};
type Page={items:ChatMessage[];nextAfterSequence:number|null;lastSequence:number;conversation:Conversation;consents?:Record<string,boolean>;consentNoticeVersion?:string;transport:'WEBSOCKET'|'HTTP_POLL';me?:string};
/** Shared engine for the client and staff chat views: replay + WebSocket push + receipts + idempotent sends. */
export function useCaseChat(endpoint:string,self:'CLIENT'|'STAFF'='CLIENT'){
 const [items,setItems]=useState<ChatMessage[]>([]),[conversation,setConversation]=useState<Conversation|null>(null),[meta,setMeta]=useState<Omit<Page,'items'|'nextAfterSequence'|'lastSequence'|'conversation'>|null>(null),[socket,setSocket]=useState(false),[error,setError]=useState('');
 const last=useRef(0),readSent=useRef(0);
 const merge=useCallback((incoming:ChatMessage[])=>{if(!incoming.length)return;setItems(prev=>{const map=new Map(prev.filter(m=>!m.pending||!incoming.some(i=>i.clientMessageId===m.clientMessageId)).map(m=>[m.pending?'p:'+m.clientMessageId:'s:'+m.sequence,m]));for(const m of incoming)map.set('s:'+m.sequence,m);return [...map.values()].sort((a,b)=>(a.pending?1e12:a.sequence)-(b.pending?1e12:b.sequence));});last.current=Math.max(last.current,...incoming.map(m=>m.sequence));},[]);
 const pull=useCallback(async()=>{let after=last.current;for(let i=0;i<20;i++){const p=await api<Page>(`${endpoint}${endpoint.includes('?')?'&':'?'}after=${after}&limit=100`);merge(p.items);setConversation(p.conversation);const {items:_i,nextAfterSequence:_n,lastSequence:_l,conversation:_c,...rest}=p;void _i;void _n;void _l;void _c;setMeta(rest);if(p.nextAfterSequence===null)break;after=p.nextAfterSequence;}},[endpoint,merge]);
 useEffect(()=>{let live=true,ws:WebSocket|null=null,beat=0,poll=0;
  const start=()=>{pull().catch(e=>live&&setError((e as Error).message));};start();
  poll=window.setInterval(()=>{if(!document.hidden&&!ws)start();},4000);
  // WebSocket only when the server reports the room binding; any failure falls back to replay polling.
  api<Page>(`${endpoint}${endpoint.includes('?')?'&':'?'}after=0&limit=1`).then(p=>{if(!live||p.transport!=='WEBSOCKET')return;const url=new URL(endpoint,window.location.href);url.protocol=url.protocol==='https:'?'wss:':'ws:';url.searchParams.set('socket','1');
   ws=new WebSocket(url.href);ws.onopen=()=>{setSocket(true);start();beat=window.setInterval(()=>ws?.send(JSON.stringify({protocolVersion:'2.0.0',type:'HEARTBEAT',commandId:makeRequestId()})),25000);};
   ws.onmessage=e=>{try{const f=JSON.parse(e.data);if(f.type==='MESSAGE_COMMITTED'){if(f.message.sequence>last.current+1)start();else merge([f.message]);}else if(f.type==='CONVERSATION_STATE')setConversation(f.conversation);else if(f.type==='RESYNC_REQUIRED')start();}catch{/* ignore malformed frame */}};
   ws.onclose=()=>{setSocket(false);window.clearInterval(beat);ws=null;};}).catch(()=>{});
  return()=>{live=false;window.clearInterval(poll);window.clearInterval(beat);ws?.close(1000);};},[endpoint,pull,merge]);
 // Read receipts for what is visible (monotonic on the server).
 useEffect(()=>{const top=items.filter(m=>!m.pending).at(-1)?.sequence??0;if(!top||top<=readSent.current||document.hidden)return;readSent.current=top;api(endpoint.split('?')[0],{method:'POST',body:JSON.stringify({action:'receipt',deliveredSequence:top,readSequence:top})}).catch(()=>{readSent.current=0;});},[items,endpoint]);
 const post=useCallback(async(body:Record<string,unknown>)=>api<Record<string,unknown>>(endpoint.split('?')[0],{method:'POST',body:JSON.stringify(body)}),[endpoint]);
 /** Idempotent send: optimistic bubble, one automatic retry with the same client message id on a lost reply. */
 const send=useCallback(async(message:Record<string,unknown>,extra:Record<string,unknown>={})=>{const clientMessageId=makeRequestId(),full={clientMessageId,repliedToMessageId:null,...message};
  setItems(prev=>[...prev,{messageId:'pending:'+clientMessageId,sequence:0,clientMessageId,senderDisplayRef:'me',actorType:self,kind:(message.kind==='VOICE_NOTE'?'VOICE_NOTE':message.kind) as ChatMessage['kind'],text:(message.text as string)??null,attachments:[],assessmentId:null,createdAt:new Date().toISOString(),pending:true}]);
  try{try{await post({action:'send',message:full,...extra});}catch(e){if((e as {status?:number}).status)throw e;await post({action:'send',message:full,...extra});}await pull();}
  catch(e){setItems(prev=>prev.filter(m=>m.clientMessageId!==clientMessageId||!m.pending));throw e;}},[post,pull,self]);
 const upload=useCallback(async(file:Blob,name:string)=>{const voice=file.type.startsWith('audio/'),form=new FormData();form.append('file',file,name);if(!voice)form.append('category','other');
  const r=await api<{evidenceId:string}>(endpoint.split('?')[0]+'?upload='+(voice?'voice':'file'),{method:'POST',body:form});
  await send(voice?{kind:'VOICE_NOTE',evidenceId:r.evidenceId}:{kind:'ATTACHMENT',evidenceIds:[r.evidenceId]});},[endpoint,send]);
 return {items,conversation,meta,socket,error,setError,send,upload,post,pull};
}
export function AttachmentChip({a,base,ar}:{a:ChatAttachment;base:string;ar:boolean}){
 if(a.state!=='AVAILABLE')return <span className={'chat-attachment '+a.state.toLowerCase()}><Clock3 size={14}/>{a.state==='REJECTED'?(ar?'رُفض الملف في الفحص':'File rejected by the scan'):(ar?(a.mediaKind==='VOICE_NOTE'?'رسالة صوتية قيد الفحص':'مرفق قيد الفحص'):(a.mediaKind==='VOICE_NOTE'?'Voice note being scanned':'Attachment being scanned'))}</span>;
 const src=base+'?media='+encodeURIComponent(a.evidenceId);
 return a.mediaKind==='VOICE_NOTE'?<audio controls preload="none" src={src}/>:a.mediaKind==='IMAGE'?<a href={src} target="_blank" rel="noreferrer">{ar?'عرض الصورة':'View image'}</a>:<a href={src} target="_blank" rel="noreferrer">{ar?'فتح المرفق':'Open attachment'}</a>;
}
const CONSENTS:[string,string,string][]=[['LLM_CHAT_ASSISTANT','السماح للمساعد الرقمي بالرد باستخدام مزود ذكاء اصطناعي خارجي','Allow the digital assistant to reply using an external AI provider'],['CHAT_NOTIFICATIONS','إشعار بالبريد عند وصول رد جديد (دون نص الرسالة)','Email me when a new reply arrives (no message text)'],['AUDIO_TRANSCRIPTION','تفريغ رسائلي الصوتية نصيًا (عند توفر الخدمة)','Transcribe my voice notes (when available)'],['EXPIRY_NOTIFICATIONS','تذكير بالبريد قبل انتهاء صلاحية مستنداتي','Email reminders before my documents expire']];
export function CaseChat(){
 const {lang}=usePortal(),ar=lang==='ar',chat=useCaseChat('/api/client/chat'),[text,setText]=useState(''),[busy,setBusy]=useState(false),[confirmRapid,setConfirmRapid]=useState(false),[showConsents,setShowConsents]=useState(false),end=useRef<HTMLDivElement>(null);
 const c=chat.conversation,withStaff=c?.state==='HANDOFF_PENDING'||c?.state==='HUMAN_ACTIVE';
 useEffect(()=>{const el=end.current?.parentElement;if(el)el.scrollTop=el.scrollHeight;},[chat.items.length]);
 async function act(task:()=>Promise<unknown>){if(busy)return;setBusy(true);chat.setError('');try{await task();}catch(e){chat.setError(displayError((e as Error).message,lang));}finally{setBusy(false);}}
 const sendText=()=>act(async()=>{const t=text.trim();if(!t)return;setText('');await chat.send({kind:'TEXT',text:t});});
 const human=()=>act(async()=>{await chat.send({kind:'TEXT',text:ar?'أرغب في التحدث مع موظف.':'I would like to speak with a staff member.'},{wantsHuman:true});});
 const consent=(purpose:string,granted:boolean)=>act(async()=>{await chat.post({action:'consent',consent:{purpose,granted,noticeVersion:chat.meta?.consentNoticeVersion}});await chat.pull();});
 const rapid=()=>act(async()=>{setConfirmRapid(false);await chat.post({action:'rapid_assessment',requestKey:makeRequestId(),confirmed:true});await chat.pull();});
 const time=(iso:string)=>new Date(iso).toLocaleTimeString(ar?'ar':'en',{hour:'2-digit',minute:'2-digit'});
 const who=(m:ChatMessage)=>m.actorType==='STAFF'?(ar?'فريق المكتب':'Office team'):m.actorType==='ASSISTANT'?(ar?'المساعد الرقمي':'Digital assistant'):m.actorType==='SYSTEM'?(ar?'النظام':'System'):'';
 return <section className="glass-chat case-chat" aria-label={ar?'محادثة ملفك مع المكتب':'Your file conversation'}>
  <header className="gc-head"><span className="gc-avatar"><img src="/brand/alhijrah-services.jpg" width={40} height={40} alt=""/><i/></span><div><strong>{withStaff?(ar?'فريق مكتب الهجرة':'ALHIJRAH Office team'):(ar?'المساعد الرقمي':'Digital assistant')}</strong><small>{c?.state==='HANDOFF_PENDING'?(ar?'بانتظار موظف':'Waiting for a staff member'):c?.state==='HUMAN_ACTIVE'?(ar?'موظف المكتب في المحادثة':'A staff member is in the chat'):c?.state==='CLOSED'?(ar?'المحادثة مغلقة — اكتب لإعادة فتحها':'Closed — write to reopen'):c?.assistantAvailability==='READY'?(ar?'المساعد متاح':'Assistant available'):(ar?'سيرد عليك فريق المكتب':'The office team will reply')}{chat.socket?' · ●':''}</small></div>
   {c?.state==='BOT_ACTIVE'&&<button type="button" className="gc-human" disabled={busy} onClick={()=>void human()}><UserRound size={14}/>{ar?'التحدث مع موظف':'Talk to staff'}</button>}</header>
  <div className="gc-thread" aria-live="polite">
   {!chat.items.length&&<div className="gc-bubble ai"><p>{ar?'مرحبًا بك. اكتب سؤالك عن ملفك وسيصلك الرد هنا.':'Welcome. Ask about your file and the reply will appear here.'}</p></div>}
   {chat.items.map(m=><div key={m.pending?'p'+m.clientMessageId:m.sequence} className={'gc-row '+(m.actorType==='CLIENT'?'client':m.actorType==='STAFF'?'staff':'ai')+(m.pending?' pending':'')}><div className={'gc-bubble '+(m.actorType==='CLIENT'?'client':m.actorType==='STAFF'?'staff':'ai')}>{who(m)&&<small>{who(m)}</small>}
    {m.kind==='ASSESSMENT_LINK'?<p><Gauge size={14}/> {ar?'نتيجة فحص سريع أولية (ليست قرارًا نهائيًا) — تظهر تفاصيلها في ملفك بعد مراجعة المكتب.':'Preliminary rapid screening result (not a final decision) — details appear in your file after office review.'}</p>:m.text?<p dir="auto">{m.text}</p>:null}
    {m.attachments.map(a=><AttachmentChip key={a.evidenceId} a={a} base="/api/client/chat" ar={ar}/>)}</div><time dateTime={m.createdAt}>{m.pending?(ar?'جارٍ الإرسال…':'Sending…'):time(m.createdAt)}</time></div>)}
   <div ref={end}/></div>
  {chat.error&&<div className="error-banner" role="alert">{chat.error}</div>}
  <div className="case-chat-tools">
   <button type="button" className="text-button" onClick={()=>setShowConsents(v=>!v)}><ShieldCheck size={14}/>{ar?'خيارات الخصوصية':'Privacy options'}</button>
   {confirmRapid?<span className="rapid-confirm">{ar?'تشغيل فحص سريع أولي من بيانات ملفك الحالية؟ لا يغيّر التقرير المعتمد.':'Run a preliminary rapid screening from your current file data? It does not change the reviewed report.'}<button type="button" className="button gold small-button" disabled={busy} onClick={()=>void rapid()}>{ar?'نعم، شغّل':'Yes, run it'}</button><button type="button" className="text-button" onClick={()=>setConfirmRapid(false)}>{ar?'إلغاء':'Cancel'}</button></span>
    :<button type="button" className="text-button" disabled={busy} onClick={()=>setConfirmRapid(true)}><Gauge size={14}/>{ar?'فحص سريع':'Rapid screening'}</button>}
  </div>
  {showConsents&&chat.meta?.consents&&<fieldset className="chat-consents"><legend>{ar?'موافقاتك (يمكن سحبها في أي وقت)':'Your consents (you can withdraw any time)'}</legend>{CONSENTS.map(([k,a,e])=><label key={k} className="check-inline"><input type="checkbox" disabled={busy} checked={!!chat.meta?.consents?.[k]} onChange={ev=>void consent(k,ev.target.checked)}/>{ar?a:e}</label>)}</fieldset>}
  <form className="gc-input" onSubmit={e=>{e.preventDefault();void sendText();}}><ChatMediaControls ar={ar} disabled={busy} upload={(f,n)=>chat.upload(f,n)} onError={m=>chat.setError(displayError(m,lang))}/><input value={text} maxLength={4000} onChange={e=>setText(e.target.value)} placeholder={ar?'اكتب رسالتك هنا…':'Type your message…'} aria-label={ar?'رسالتك':'Your message'}/><button disabled={busy||!text.trim()} aria-label={ar?'إرسال':'Send'}>{busy?<LoaderCircle size={17} className="spin"/>:<Send size={17}/>}</button></form>
 </section>;
}
