'use client';
// v2.2 Gate 4 — one account flow, two glass entries: START_NEW («تقديم طلب جديد — التقييم والتقديم»: name + email +
// OTP) and RETURN («متابعة طلب سابق — الدخول إلى حسابك وإدارة ملفك»: email + OTP or email + password). The server sets
// the destination; START_NEW never opens an old file and several files are never auto-opened. The OTP verifies once
// automatically when six digits are present (a verify button stays), with a synchronous lock against double taps.
import { useCallback,useEffect,useRef,useState } from 'react';
import { ArrowLeft,ArrowRight,Mail,KeyRound,LoaderCircle,RefreshCw,ShieldCheck,FilePlus2,FolderSearch,UserRound,LockKeyhole,Check } from 'lucide-react';
import { api,makeRequestId } from '@/lib/client';
import { usePortal,displayError } from './chrome';
import { ClientEntry } from './entry';
import { OtpPin,CodeClock,useCodeClock,PasswordInput } from '@/components/auth/controls';
type Intent='START_NEW'|'RETURN';
type OwnCase={reference:string;name:string};
type Me={authenticated:boolean;email?:string;displayName?:string|null;cases?:OwnCase[]};
type AccountResult={authenticated:true;displayName:string|null;intent:Intent;destination:'/apply'|'/client'|'/client/account';caseReferences:string[]};
type Challenge={requestId:string;expiresAt:number;ticket:string;resendAfter:number};
export function ClientAccount({initialIntent=null}:{initialIntent?:Intent|null}){
 const {lang}=usePortal(),ar=lang==='ar',Arrow=ar?ArrowLeft:ArrowRight;
 const [me,setMe]=useState<Me|null>(null),[intent,setIntent]=useState<Intent|null>(initialIntent),[method,setMethod]=useState<'otp'|'password'>('otp');
 const [name,setName]=useState(''),[email,setEmail]=useState(''),[code,setCode]=useState(''),[password,setPassword]=useState('');
 const [challenge,setChallenge]=useState<Challenge|null>(null),[resendAt,setResendAt]=useState(0),[busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const [newPassword,setNewPassword]=useState(''),[confirm,setConfirm]=useState(''),[settingPassword,setSettingPassword]=useState(false);
 const lock=useRef(false),key=useRef(''),clock=useCodeClock(challenge,resendAt),form=useRef<HTMLFormElement>(null);
 const load=useCallback(async()=>{try{setMe(await api<Me>('/api/client/account'));}catch{setMe({authenticated:false});}},[]);
 useEffect(()=>{let live=true;api<Me>('/api/client/account').then(r=>{if(live)setMe(r);}).catch(()=>{if(live)setMe({authenticated:false});});return()=>{live=false;};},[]);
 async function run(task:()=>Promise<void>){if(lock.current)return;lock.current=true;setBusy(true);setError('');setNotice('');try{await task();}catch(e){setError((e as Error).message);}finally{lock.current=false;setBusy(false);}}
 function choose(next:Intent){setIntent(next);setChallenge(null);setCode('');setError('');key.current='';requestAnimationFrame(()=>form.current?.querySelector<HTMLInputElement>('input')?.focus());}
 const send=(resend=false)=>run(async()=>{if(resend||!key.current)key.current=makeRequestId();const r=await api<Challenge>('/api/client/account',{method:'POST',body:JSON.stringify({action:'request',email,intent,...(intent==='START_NEW'?{name}:{}),requestKey:key.current,locale:lang})});setChallenge(r);setCode('');setResendAt(Date.now()+r.resendAfter*1000);});
 const finish=async(r:AccountResult)=>{if(r.destination==='/client/account'&&window.location.pathname==='/client/account'){setChallenge(null);await load();return;}window.location.assign(r.destination);};
 const verify=(value:string)=>run(async()=>{if(!challenge)return;await finish(await api<AccountResult>('/api/client/account',{method:'POST',body:JSON.stringify({action:'verify',ticket:challenge.ticket,code:value})}));});
 const loginPassword=()=>run(async()=>{await finish(await api<AccountResult>('/api/client/password/login',{method:'POST',body:JSON.stringify({email,password})}));});
 const open=(reference:string)=>run(async()=>{await api('/api/client/account',{method:'POST',body:JSON.stringify({action:'open',reference})});window.location.assign('/client');});
 const savePassword=()=>run(async()=>{if(newPassword!==confirm)throw new Error(ar?'كلمتا المرور غير متطابقتين.':'Passwords do not match.');await api('/api/client/password',{method:'POST',body:JSON.stringify({scope:'account',password:newPassword})});setSettingPassword(false);setNewPassword('');setConfirm('');setNotice(ar?'حُفظت كلمة مرور الحساب.':'Account password saved.');});
 const signOut=()=>run(async()=>{await api('/api/client/account',{method:'DELETE'});setMe({authenticated:false});setIntent(null);setEmail('');key.current='';});
 if(!me)return <main className="portal-wrap account-page"><div className="loading-state"><LoaderCircle className="spin"/></div></main>;
 if(me.authenticated)return <main className="portal-wrap account-page"><article className="panel account-card account-signed-in" aria-live="polite">
  <span className="account-emblem"><ShieldCheck size={26}/></span><h2>{me.displayName?(ar?`أهلًا بك، ${me.displayName}`:`Welcome, ${me.displayName}`):(ar?'أهلًا بك':'Welcome')}</h2><p dir="ltr">{me.email}</p>
  {(me.cases||[]).length>0&&<div className="account-cases" role="list" aria-label={ar?'ملفاتك':'Your files'}>{me.cases!.map(c=><button key={c.reference} role="listitem" className="account-case-option" disabled={busy} onClick={()=>void open(c.reference)}><strong>{c.name}</strong><bdi>{c.reference}</bdi><Arrow size={18}/></button>)}</div>}
  <a className="button gold" href="/apply"><FilePlus2 size={17}/>{ar?'تقديم طلب جديد':'Start a new application'}</a>
  {settingPassword?<form className="account-password-form" onSubmit={e=>{e.preventDefault();void savePassword();}}><PasswordInput value={newPassword} onChange={setNewPassword} label={ar?'كلمة مرور جديدة للحساب':'New account password'} ar={ar} newPassword disabled={busy}/><PasswordInput value={confirm} onChange={setConfirm} label={ar?'تأكيد كلمة المرور':'Confirm password'} ar={ar} newPassword disabled={busy}/><p className="fine-print">{ar?'يتطلب رمز تحقق حديثًا بالبريد (خلال 10 دقائق).':'Requires a recent email code (within 10 minutes).'}</p><button className="button gold" disabled={busy}><LockKeyhole size={17}/>{ar?'حفظ كلمة المرور':'Save password'}</button></form>
   :<button type="button" className="text-button" disabled={busy} onClick={()=>setSettingPassword(true)}><LockKeyhole size={15}/>{ar?'تعيين كلمة مرور للحساب':'Set an account password'}</button>}
  <button type="button" className="text-button" disabled={busy} onClick={()=>void signOut()}>{ar?'تبديل الحساب':'Switch account'}</button>
  {notice&&<div className="notice" role="status"><Check size={16}/>{notice}</div>}{error&&<div className="error-banner" role="alert">{displayError(error,lang)}</div>}
 </article></main>;
 return <main className="portal-wrap account-page account-entry">
  <ClientEntry/>
  <div className="account-intents" role="radiogroup" aria-label={ar?'اختر طريقة البدء':'Choose how to start'}>
   <button type="button" role="radio" aria-checked={intent==='START_NEW'} className={'account-intent'+(intent==='START_NEW'?' on':'')} onClick={()=>choose('START_NEW')}><span className="entry-btn-icon"><FilePlus2 size={22}/></span><span><strong>{ar?'تقديم طلب جديد':'Start a new application'}</strong><small>{ar?'التقييم والتقديم':'Assessment & application'}</small></span><Arrow size={18}/></button>
   <button type="button" role="radio" aria-checked={intent==='RETURN'} className={'account-intent'+(intent==='RETURN'?' on':'')} onClick={()=>choose('RETURN')}><span className="entry-btn-icon"><FolderSearch size={22}/></span><span><strong>{ar?'متابعة طلب سابق':'Continue an existing application'}</strong><small>{ar?'الدخول إلى حسابك وإدارة ملفك':'Sign in to your account and manage your file'}</small></span><Arrow size={18}/></button>
  </div>
  {intent&&<article className="panel account-card" id="client-account-login">
   <span className="account-emblem">{challenge?<ShieldCheck size={26}/>:<KeyRound size={26}/>}</span>
   <h2>{challenge?(ar?'تأكيد البريد الإلكتروني':'Verify your email'):intent==='START_NEW'?(ar?'حساب سريع للبدء':'Quick account to start'):(ar?'الدخول إلى حسابك':'Sign in to your account')}</h2>
   {intent==='RETURN'&&!challenge&&<div className="auth-method-tabs" role="group" aria-label={ar?'طريقة الدخول':'Sign-in method'}><button type="button" className={method==='otp'?'active':''} aria-pressed={method==='otp'} onClick={()=>{setMethod('otp');setError('');}}><KeyRound size={16}/>{ar?'رمز بالبريد':'Email code'}</button><button type="button" className={method==='password'?'active':''} aria-pressed={method==='password'} onClick={()=>{setMethod('password');setError('');}}><LockKeyhole size={16}/>{ar?'كلمة المرور':'Password'}</button></div>}
   <form ref={form} onSubmit={e=>{e.preventDefault();void(challenge?verify(code):intent==='RETURN'&&method==='password'?loginPassword():send());}}>
    {challenge?<><p className="account-address" dir="ltr">{email}</p><OtpPin value={code} onChange={setCode} ar={ar} disabled={busy} onComplete={value=>void verify(value)}/><CodeClock remaining={clock.remaining} ar={ar}/><div aria-live="polite" className="sr-only">{busy?(ar?'جارٍ التحقق':'Verifying'):''}</div>
     <button className="button gold" disabled={busy||!/^\d{6}$/.test(code)||!clock.remaining}>{busy?<LoaderCircle className="spin" size={17}/>:<ShieldCheck size={18}/>} {ar?'تأكيد والمتابعة':'Verify & continue'}</button>
     <div className="otp-secondary-actions"><button type="button" disabled={busy||clock.resend>0} onClick={()=>void send(true)}><RefreshCw size={14}/>{ar?'إعادة الإرسال':'Resend'}{clock.resend?' · '+clock.resend+'s':''}</button><button type="button" disabled={busy} onClick={()=>{setChallenge(null);setCode('');key.current='';}}>{ar?'تغيير البريد':'Change email'}</button></div></>
    :<>{intent==='START_NEW'&&<label className="field"><span>{ar?'الاسم الكامل':'Full name'}</span><div className="enterprise-input-icon"><UserRound size={18}/><input autoComplete="name" required minLength={2} maxLength={150} value={name} onChange={e=>{setName(e.target.value);key.current='';}}/></div></label>}
     <label className="field"><span>{ar?'البريد الإلكتروني':'Email address'}</span><div className="enterprise-input-icon"><Mail size={18}/><input type="email" dir="ltr" autoComplete="email" required maxLength={254} value={email} onChange={e=>{setEmail(e.target.value.replace(/\s+/g,''));key.current='';}}/></div></label>
     {intent==='RETURN'&&method==='password'&&<PasswordInput value={password} onChange={setPassword} label={ar?'كلمة مرور الحساب':'Account password'} ar={ar} disabled={busy}/>}
     <button className="button gold" disabled={busy}>{busy?<LoaderCircle className="spin" size={18}/>:<Arrow size={18}/>} {intent==='RETURN'&&method==='password'?(ar?'الدخول':'Sign in'):(ar?'إرسال رمز التحقق':'Send verification code')}</button>
     <p className="fine-print">{ar?'إن كان البريد مسجّلًا ستصلك رسالة برمز من 6 أرقام صالح 10 دقائق.':'If the email can be used, you will receive a 6-digit code valid for 10 minutes.'}</p></>}
    {error&&<div className="error-banner" role="alert">{displayError(error,lang)}</div>}
   </form>
  </article>}
 </main>;
}
