'use client';
import { useEffect,useId,useMemo,useRef,useState } from 'react';
import { HelpCircle,Eraser,Save,CheckCircle2,LoaderCircle,PenLine } from 'lucide-react';
import { countryOptions } from '@/lib/intake-options';
import type { Choice } from '@/lib/intake-options';
import { usePortal } from './chrome';
export function Help({children}:{children:React.ReactNode}){const {lang}=usePortal();return <details className="field-help"><summary aria-label={lang==='ar'?'توضيح الحقل':'Field help'}><HelpCircle size={15}/></summary><div>{children}</div></details>}
export function Field({label,children,hint,help,required=false}:{label:string;children:React.ReactNode;hint?:string;help?:React.ReactNode;required?:boolean}){return <div className="vision-field"><label className="field"><span>{label}{required&&<b className="required-star" aria-hidden="true"> *</b>}</span>{children}{hint&&<small>{hint}</small>}</label>{help&&<Help>{help}</Help>}</div>}
export function ChoiceField({label,value,onChange,options,hint,help,emptyValue='unknown'}:{label:string;value:string;onChange:(v:string)=>void;options:Choice[];hint?:string;help?:React.ReactNode;emptyValue?:string}){const {lang}=usePortal(),ar=lang==='ar';return <Field label={label} hint={hint} help={help}><select value={value} onChange={e=>onChange(e.target.value)}><option value={emptyValue}>{ar?'غير محدد':'Not provided'}</option>{options.map(([value,arabic,english])=><option key={value} value={value}>{ar?arabic:english}</option>)}</select></Field>}
export function CountryField({label,value,onChange}:{label:string;value:string;onChange:(v:string)=>void}){const {lang}=usePortal(),options=useMemo(()=>countryOptions(lang),[lang]),id=useId();return <Field label={label}><input list={id} value={value} maxLength={80} onChange={e=>onChange(e.target.value)} placeholder={lang==='ar'?'اسم البلد':'Country name'} autoComplete="off"/><datalist id={id}>{options.map(o=><option key={o.code} value={o.value}>{o.label}</option>)}</datalist></Field>}
export function MonthCount({label,value,onChange,max=120}:{label:string;value:number|null;onChange:(n:number|null)=>void;max?:number}){const {lang}=usePortal();return <Field label={label}><select value={value??''} onChange={e=>onChange(e.target.value===''?null:Number(e.target.value))}><option value="">{lang==='ar'?'غير محدد':'Not provided'}</option>{value!==null&&value>max&&<option value={value}>{value}</option>}{Array.from({length:max+1},(_,n)=><option key={n} value={n}>{lang==='ar'?`${n} شهرًا${n&&n%12===0?' ('+n/12+' سنة)':''}`:`${n} months${n&&n%12===0?' ('+n/12+' years)':''}`}</option>)}</select></Field>}

// ---- v2.2 Gate 4: the single signature pad (finger, pen, mouse via Pointer Events + pointer capture). Points are kept
// normalized (0..1) so resizing, step changes or rotation redraw the same ink; the backing store follows
// devicePixelRatio. Drawing does not re-render React per point (requestAnimationFrame). The exported PNG is rendered
// from the vectors on a fixed 600x200 transparent canvas. A saved signature is shown from the server (private image)
// and stays SIGNED after later edits; only the explicit clear action removes it.
type Stroke={x:number;y:number}[];
export type PadState='EMPTY'|'DRAWING'|'SAVING'|'SIGNED'|'ERROR';
export function SignaturePad({signed,imageUrl,signedAt,onSave,onClear,disabled=false,ar=true,initialStrokes=[],onStrokes}:{signed:boolean;imageUrl:string|null;signedAt:string|null;onSave:(png:Blob)=>Promise<void>;onClear:()=>Promise<void>;disabled?:boolean;ar?:boolean;initialStrokes?:readonly Stroke[];onStrokes?:(s:Stroke[])=>void}){
 const canvas=useRef<HTMLCanvasElement>(null),strokes=useRef<Stroke[]>(initialStrokes.map(s=>[...s])),active=useRef<Stroke|null>(null),frame=useRef(0);
 const [local,setState]=useState<PadState>(initialStrokes.some(x=>x.length>1)?'DRAWING':'EMPTY'),[error,setError]=useState('');
 // Server truth wins: a saved signature shows SIGNED until the explicit clear; otherwise the local drawing state.
 const state:PadState=local==='SAVING'||local==='ERROR'?local:signed?'SIGNED':local==='SIGNED'?'EMPTY':local;
 const ink=()=>strokes.current.some(s=>s.length>1);
 function paint(target:HTMLCanvasElement,width:number,height:number,scale:number){const g=target.getContext('2d');if(!g)return;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,target.width,target.height);g.setTransform(scale,0,0,scale,0,0);g.lineCap='round';g.lineJoin='round';g.strokeStyle='#14283c';g.lineWidth=Math.max(2,width/220);for(const s of strokes.current){if(s.length<2)continue;g.beginPath();g.moveTo(s[0].x*width,s[0].y*height);for(const p of s.slice(1))g.lineTo(p.x*width,p.y*height);g.stroke();}}
 function redraw(){const c=canvas.current;if(!c)return;const r=c.getBoundingClientRect(),dpr=Math.min(3,window.devicePixelRatio||1);if(c.width!==Math.round(r.width*dpr)||c.height!==Math.round(r.height*dpr)){c.width=Math.round(r.width*dpr);c.height=Math.round(r.height*dpr);}paint(c,r.width,r.height,dpr);}
 useEffect(()=>{if(state==='SIGNED')return;const c=canvas.current;if(!c)return;redraw();const ro=new ResizeObserver(()=>redraw());ro.observe(c);return()=>{ro.disconnect();cancelAnimationFrame(frame.current);};},[state]); // eslint-disable-line react-hooks/exhaustive-deps
 function point(e:React.PointerEvent<HTMLCanvasElement>|PointerEvent){const r=canvas.current!.getBoundingClientRect();return {x:Math.min(1,Math.max(0,(e.clientX-r.left)/r.width)),y:Math.min(1,Math.max(0,(e.clientY-r.top)/r.height))};}
 function down(e:React.PointerEvent<HTMLCanvasElement>){if(disabled||state==='SAVING')return;e.preventDefault();canvas.current!.setPointerCapture(e.pointerId);active.current=[point(e)];strokes.current.push(active.current);setState('DRAWING');setError('');}
 function move(e:React.PointerEvent<HTMLCanvasElement>){if(!active.current)return;const list=(e.nativeEvent.getCoalescedEvents?.()??[e.nativeEvent]) as PointerEvent[];for(const p of list)active.current.push(point(p));cancelAnimationFrame(frame.current);frame.current=requestAnimationFrame(redraw);}
 function up(e:React.PointerEvent<HTMLCanvasElement>){if(!active.current)return;active.current=null;try{canvas.current!.releasePointerCapture(e.pointerId);}catch{}redraw();onStrokes?.(strokes.current.map(s=>[...s]));}
 function clearInk(){strokes.current=[];active.current=null;setState('EMPTY');redraw();onStrokes?.([]);}
 async function save(){if(!ink()){setError(ar?'ارسم توقيعك أولًا.':'Draw your signature first.');return;}setState('SAVING');setError('');try{const out=document.createElement('canvas');out.width=600;out.height=200;paint(out,600,200,1);const blob=await new Promise<Blob|null>(r=>out.toBlob(r,'image/png'));if(!blob)throw new Error(ar?'تعذّر تجهيز صورة التوقيع.':'Could not prepare the signature image.');await onSave(blob);strokes.current=[];onStrokes?.([]);setState('SIGNED');}catch(e){setState('ERROR');setError((e as Error).message);}}
 async function clearSaved(){setState('SAVING');setError('');try{await onClear();strokes.current=[];onStrokes?.([]);setState('EMPTY');}catch(e){setState('EMPTY');setError((e as Error).message);}}
 return <section className="signature-pad" aria-labelledby="signature-title">
  <header><PenLine size={18}/><h3 id="signature-title">{ar?'التوقيع الإلكتروني':'Electronic signature'}</h3>{state==='SIGNED'&&<span className="signature-status signed" role="status"><CheckCircle2 size={16}/>{ar?'تم التوقيع':'Signed'}</span>}</header>
  {state==='SIGNED'&&imageUrl?<figure className="signature-saved"><img src={imageUrl} alt={ar?'التوقيع المحفوظ':'Saved signature'}/>{signedAt&&<figcaption dir="ltr">{signedAt}</figcaption>}</figure>
   :<canvas ref={canvas} className="signature-canvas" role="img" aria-label={ar?'مساحة التوقيع: ارسم بالإصبع أو القلم أو الفأرة':'Signature area: draw with finger, pen or mouse'} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up}/>}
  <div className="signature-actions" aria-live="polite">
   {state==='SIGNED'?<button type="button" className="button subtle" disabled={disabled} onClick={()=>void clearSaved()}><Eraser size={16}/>{ar?'مسح التوقيع':'Clear signature'}</button>
    :<><button type="button" className="button subtle" disabled={disabled||state==='SAVING'} onClick={clearInk}><Eraser size={16}/>{ar?'مسح':'Clear'}</button><button type="button" className="button gold" disabled={disabled||state==='SAVING'} onClick={()=>void save()}>{state==='SAVING'?<LoaderCircle className="spin" size={16}/>:<Save size={16}/>}{ar?'حفظ التوقيع':'Save signature'}</button></>}
  </div>
  <p className="fine-print">{ar?'التوقيع قرينة قبول داخل خدمة المكتب، وليس توقيعًا حكوميًا معتمدًا. تعديل بياناتك لاحقًا لا يلغي التوقيع المحفوظ.':'The signature records your acceptance within the office service; it is not a government signature. Later edits do not cancel the saved signature.'}</p>
  {error&&<div className="error-banner" role="alert">{error}</div>}
 </section>;
}
