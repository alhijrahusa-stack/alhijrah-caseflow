'use client';
// v2.2 Gate 2 — MANAGER permission Toggles (glass switches only; no JSON editor, no free capability names) and the
// single STAFF open switch that the server closes at the next America/Toronto midnight.
import { useCallback, useEffect, useState } from 'react';
import { ShieldCheck, Unlock, Lock, AlertCircle } from 'lucide-react';
import { api, makeRequestId } from '@/lib/client';

type Perms = Record<string, boolean>;
type State = {
  epoch: number; catalog: string[];
  role: { version: number; permissions: Perms };
  staff: { userId: string; email: string; name: string; active: boolean; version: number; permissions: Perms }[];
  openAll: { enabled: boolean; localDate: string | null; untilMs: number; active: boolean };
};
const LABELS: Record<string, string> = {
  view_crm: 'عرض الملفات', edit_case: 'تعديل الملفات', review_case: 'المراجعة المهنية', view_documents: 'عرض المستندات',
  upload_documents: 'رفع المستندات', chat: 'محادثة العملاء', request_assessment: 'طلب التقييم', view_financials: 'عرض البيانات المالية',
  create_invoice: 'إنشاء فاتورة', edit_invoice: 'تعديل فاتورة', edit_discount: 'تعديل الخصم', record_payment: 'تسجيل دفعة',
  send_payment_notice: 'إشعار العميل بالدفع', export_invoice_pdf: 'تصدير PDF للفاتورة',
};

function Switch({ on, label, disabled, onChange }: { on: boolean; label: string; disabled?: boolean; onChange: (v: boolean) => void }) {
  return <button type="button" role="switch" aria-checked={on} aria-label={label} disabled={disabled} className={'perm-switch' + (on ? ' on' : '')} onClick={() => onChange(!on)}><span /></button>;
}

export function PermissionToggles() {
  const [state, setState] = useState<State | null>(null), [error, setError] = useState(''), [busy, setBusy] = useState('');
  const load = useCallback(async () => { try { setState(await api<State>('/api/office/permissions')); setError(''); } catch (e) { setError(e instanceof Error ? e.message : 'تعذر تحميل الصلاحيات'); } }, []);
  useEffect(() => { let live = true; api<State>('/api/office/permissions').then(d => { if (live) setState(d); }).catch(e => { if (live) setError(e instanceof Error ? e.message : 'تعذر تحميل الصلاحيات'); }); return () => { live = false; }; }, []);
  async function send(id: string, body: Record<string, unknown>) {
    if (busy) return; setBusy(id); setError('');
    try { setState(await api<State>('/api/office/permissions', { method: 'POST', body: JSON.stringify({ ...body, requestKey: makeRequestId() }) })); }
    catch (e) { setError(e instanceof Error ? e.message : 'تعذر الحفظ'); await load(); }
    finally { setBusy(''); }
  }
  if (!state) return <section className="panel perm-panel"><h2>صلاحيات الموظفين</h2><p>{error || 'جارٍ التحميل…'}</p></section>;
  const until = state.openAll.active ? new Date(state.openAll.untilMs).toLocaleString('ar', { timeZone: 'America/Toronto', hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'long' }) : '';
  return <section className="panel perm-panel" aria-busy={!!busy}>
    <div className="perm-head"><ShieldCheck size={22} /><div><h2>صلاحيات الموظفين</h2><p>تُطبَّق فورًا من الخادم. صلاحيات المدير والنظام محمية ولا تظهر هنا.</p></div></div>
    {error && <div className="error-banner" role="alert"><AlertCircle size={17} />{error}</div>}
    <div className={'perm-open' + (state.openAll.active ? ' active' : '')}>
      {state.openAll.active ? <Unlock size={20} /> : <Lock size={20} />}
      <div><strong>فتح صلاحيات الموظفين لليوم</strong><p>{state.openAll.active ? `مفتوح حتى منتصف ليل تورونتو (${until}). لا يمنح سلطات المدير.` : 'مغلق. يُغلق تلقائيًا عند منتصف ليل تورونتو ولا يُمدّد.'}</p></div>
      <Switch on={state.openAll.active} label="فتح صلاحيات الموظفين لليوم" disabled={!!busy} onChange={v => send('open', { action: 'open_all', enabled: v, expectedEpoch: state.epoch })} />
    </div>
    <div className="perm-table" role="table" aria-label="صلاحيات الموظفين">
      <div className="perm-row perm-row-head" role="row"><span role="columnheader">الصلاحية</span><span role="columnheader">كل الموظفين</span>{state.staff.map(m => <span role="columnheader" key={m.userId} title={m.email}>{m.name || m.email}{!m.active && ' (موقوف)'}</span>)}</div>
      {state.catalog.map(key => <div className="perm-row" role="row" key={key}>
        <span role="cell">{LABELS[key] || key}</span>
        <span role="cell"><Switch on={state.role.permissions[key] === true} label={`${LABELS[key] || key} — كل الموظفين`} disabled={!!busy} onChange={v => send('role:' + key, { action: 'toggle', target: 'ROLE', key, value: v, expectedVersion: state.role.version, expectedEpoch: state.epoch })} /></span>
        {state.staff.map(m => { const own = Object.hasOwn(m.permissions, key), on = own ? m.permissions[key] === true : state.role.permissions[key] === true;
          return <span role="cell" key={m.userId} className={own ? 'perm-custom' : ''}><Switch on={on} label={`${LABELS[key] || key} — ${m.name || m.email}`} disabled={!!busy || !m.active} onChange={v => send(m.userId + key, { action: 'toggle', target: 'USER', targetUserId: m.userId, key, value: v, expectedVersion: m.version, expectedEpoch: state.epoch })} /></span>; })}
      </div>)}
    </div>
  </section>;
}
