'use client';
// v2.2 Gate 3 — rule sources, payloads, releases and readiness. Staff see readiness (NOT_CONFIGURED stays visible and is
// never shown as evaluated coverage). The MANAGER imports official source bytes and complete payload files, previews
// the exact release manifest, then creates and seals it in one action (optionally activating it). The server
// recomputes every hash and validates; the browser supplies no state, actor or validation report.
import { useCallback, useEffect, useState } from 'react';
import { ScrollText, Upload, Lock, Power, AlertCircle, CheckCircle2, Plus, Trash2 } from 'lucide-react';
import { api, makeRequestId } from '@/lib/client';
import { jcsHash } from '@/lib/v22-core';

type Interval = { programId: string; family: string; phase: 'PROFILE' | 'APPLICATION' | 'PROCESSING'; dateBasis: 'PROFILE' | 'INVITATION' | 'APPLICATION' | 'RECOMMENDATION' | 'APPROVAL_TORONTO'; effectiveFrom: string; effectiveToExclusive: string | null; bundleId: string };
type State = {
  activation: { releaseId: string | null; generation: number; activatedAt: string | null; effective: boolean };
  activeIntervals: Interval[]; readiness: { programId: string; status: 'CONFIGURED' | 'NOT_CONFIGURED' }[];
  releases: { releaseId: string; manifestSha256: string; state: string; sealedBy: string | null; sealedAt: string | null }[];
  bundles: { bundleId: string; payloadSha256: string; createdAt: string }[];
  sources: { sourceId: string; officialUrl: string; contentSha256: string; fetchedAt: string }[];
};
const blank = (): Interval => ({ programId: '', family: 'ELIGIBILITY', phase: 'PROFILE', dateBasis: 'PROFILE', effectiveFrom: '', effectiveToExclusive: null, bundleId: '' });
const short = (h: string) => h.slice(0, 12) + '…';
async function fileBase64(f: File) { const bytes = new Uint8Array(await f.arrayBuffer()); let bin = ''; for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000)); return btoa(bin); }

export function RulesPanel({ role }: { role: 'MANAGER' | 'STAFF' }) {
  const [state, setState] = useState<State | null>(null), [error, setError] = useState(''), [notice, setNotice] = useState(''), [busy, setBusy] = useState(false);
  const [src, setSrc] = useState({ sourceId: '', officialUrl: '', authority: '' }), [srcFile, setSrcFile] = useState<File | null>(null), [bundleFile, setBundleFile] = useState<File | null>(null);
  const [rows, setRows] = useState<Interval[]>([blank()]), [preview, setPreview] = useState<{ manifestHash: string; validationCodes: string[] } | null>(null), [activate, setActivate] = useState(true);
  const load = useCallback(async () => { try { setState(await api<State>('/api/office/rules/releases')); } catch (e) { setError(e instanceof Error ? e.message : 'تعذر تحميل القواعد'); } }, []);
  useEffect(() => { let live = true; api<State>('/api/office/rules/releases').then(d => { if (live) setState(d); }).catch(e => { if (live) setError(e instanceof Error ? e.message : 'تعذر تحميل القواعد'); }); return () => { live = false; }; }, []);
  async function run(task: () => Promise<string>) {
    if (busy) return; setBusy(true); setError(''); setNotice('');
    try { setNotice(await task()); await load(); } catch (e) { setError(e instanceof Error ? e.message : 'تعذر التنفيذ'); } finally { setBusy(false); }
  }
  const post = (url: string, body: unknown) => api<Record<string, unknown>>(url, { method: 'POST', body: JSON.stringify(body) });
  const intervals = () => rows.map(r => ({ ...r, effectiveToExclusive: r.effectiveToExclusive || null }));
  const setRow = (i: number, patch: Partial<Interval>) => { setPreview(null); setRows(rs => rs.map((r, k) => k === i ? { ...r, ...patch } : r)); };
  if (!state) return <section className="panel rules-panel"><h2>القواعد المختومة</h2><p>{error || 'جارٍ التحميل…'}</p></section>;
  return <section className="panel rules-panel" aria-busy={busy}>
    <div className="perm-head"><ScrollText size={22} /><div><h2>القواعد المختومة والجاهزية</h2><p>التقييم يستخدم إصدارًا واحدًا مختومًا ومفعّلًا. غياب القاعدة يظهر «غير مهيأ» ولا يُحسب تقييمًا.</p></div></div>
    {error && <div className="error-banner" role="alert"><AlertCircle size={17} />{error}</div>}
    {notice && <div className="notice" role="status"><CheckCircle2 size={17} />{notice}</div>}
    <div className="rules-status"><strong>{state.activation.effective ? 'إصدار مفعّل' : 'لا يوجد إصدار مفعّل'}</strong><span dir="ltr">{state.activation.releaseId ?? '—'}</span><small>الجيل {state.activation.generation}</small></div>
    <ul className="rules-readiness" aria-label="جاهزية البرامج">{state.readiness.map(r => <li key={r.programId} className={r.status === 'CONFIGURED' ? 'ok' : 'off'}><span dir="ltr">{r.programId}</span><b>{r.status === 'CONFIGURED' ? 'مهيأ' : 'غير مهيأ'}</b></li>)}</ul>
    {role === 'MANAGER' && <>
      <form className="rules-form" onSubmit={e => { e.preventDefault(); void run(async () => { if (!srcFile) throw new Error('اختر ملف المصدر'); const r = await post('/api/office/rules/import', { action: 'source', ...src, contentBase64: await fileBase64(srcFile) }); return 'حُفظ المصدر ' + String(r.sourceId) + ' · ' + short(String(r.contentSha256)); }); }}>
        <h3><Upload size={17} />مصدر رسمي</h3>
        <label className="field"><span>معرّف المصدر</span><input required dir="ltr" pattern="[A-Za-z0-9][A-Za-z0-9_.:\-]{0,127}" value={src.sourceId} onChange={e => setSrc({ ...src, sourceId: e.target.value })} /></label>
        <label className="field"><span>الرابط الرسمي (HTTPS حكومي كندي)</span><input required type="url" dir="ltr" value={src.officialUrl} onChange={e => setSrc({ ...src, officialUrl: e.target.value })} /></label>
        <label className="field"><span>الجهة</span><input required maxLength={200} value={src.authority} onChange={e => setSrc({ ...src, authority: e.target.value })} /></label>
        <label className="field"><span>نسخة المصدر المحفوظة (ملف)</span><input required type="file" onChange={e => setSrcFile(e.target.files?.[0] ?? null)} /></label>
        <button className="button gold" disabled={busy}>حفظ المصدر</button>
      </form>
      <form className="rules-form" onSubmit={e => { e.preventDefault(); void run(async () => { if (!bundleFile) throw new Error('اختر ملف الحمولة'); let payload: unknown; try { payload = JSON.parse(await bundleFile.text()); } catch { throw new Error('ملف الحمولة ليس JSON صالحًا'); } const r = await post('/api/office/rules/import', { action: 'bundle', payload, payloadHash: await jcsHash(payload) }); return 'حُفظت الحمولة ' + String(r.bundleId); }); }}>
        <h3><Upload size={17} />حمولة قواعد كاملة</h3>
        <label className="field"><span>ملف RuleBundle (JSON)</span><input required type="file" accept="application/json,.json" onChange={e => setBundleFile(e.target.files?.[0] ?? null)} /></label>
        <button className="button gold" disabled={busy}>تحقق وحفظ</button>
      </form>
      <div className="rules-form">
        <h3><Lock size={17} />إنشاء إصدار وختمه</h3>
        {rows.map((r, i) => <div className="rules-interval" key={i}>
          <input aria-label="البرنامج" placeholder="programId" dir="ltr" value={r.programId} onChange={e => setRow(i, { programId: e.target.value })} />
          <input aria-label="العائلة" placeholder="family" dir="ltr" value={r.family} onChange={e => setRow(i, { family: e.target.value })} />
          <select aria-label="المرحلة" value={r.phase} onChange={e => setRow(i, { phase: e.target.value as Interval['phase'] })}>{['PROFILE', 'APPLICATION', 'PROCESSING'].map(v => <option key={v}>{v}</option>)}</select>
          <select aria-label="أساس التاريخ" value={r.dateBasis} onChange={e => setRow(i, { dateBasis: e.target.value as Interval['dateBasis'] })}>{['PROFILE', 'INVITATION', 'APPLICATION', 'RECOMMENDATION', 'APPROVAL_TORONTO'].map(v => <option key={v}>{v}</option>)}</select>
          <input aria-label="من" type="date" value={r.effectiveFrom} onChange={e => setRow(i, { effectiveFrom: e.target.value })} />
          <input aria-label="حتى (غير شامل)" type="date" value={r.effectiveToExclusive ?? ''} onChange={e => setRow(i, { effectiveToExclusive: e.target.value || null })} />
          <select aria-label="الحمولة" value={r.bundleId} onChange={e => setRow(i, { bundleId: e.target.value })}><option value="">—</option>{state.bundles.map(b => <option key={b.bundleId} value={b.bundleId}>{b.bundleId}</option>)}</select>
          <button type="button" className="icon-button" aria-label="حذف السطر" onClick={() => { setPreview(null); setRows(rs => rs.length > 1 ? rs.filter((_, k) => k !== i) : rs); }}><Trash2 size={16} /></button>
        </div>)}
        <div className="inline-actions">
          <button type="button" className="button subtle" onClick={() => { setPreview(null); setRows(rs => [...rs, blank()]); }}><Plus size={16} />سطر</button>
          <button type="button" className="button subtle" disabled={busy} onClick={() => void run(async () => { const r = await post('/api/office/rules/releases', { action: 'preview', intervals: intervals() }) as { manifestHash: string; validationCodes: string[] }; setPreview(r); return r.validationCodes.length ? 'المعاينة رصدت مشكلات؛ لا يمكن الختم.' : 'المعاينة سليمة. راجع البصمة ثم اختم.'; })}>معاينة</button>
        </div>
        {preview && <div className={preview.validationCodes.length ? 'error-banner' : 'notice'}><span dir="ltr">manifest {preview.manifestHash}</span>{preview.validationCodes.map(c => <div key={c} dir="ltr">{c}</div>)}</div>}
        <label className="consent"><input type="checkbox" checked={activate} onChange={e => setActivate(e.target.checked)} /><span>تفعيل الإصدار فور ختمه</span></label>
        <button className="button gold" disabled={busy || !preview || preview.validationCodes.length > 0} onClick={() => void run(async () => { const r = await post('/api/office/rules/releases', { action: 'seal', intervals: intervals(), manifestHash: preview!.manifestHash, activate: activate ? { expectedGeneration: state.activation.generation, reasonCode: 'manager-seal:' + makeRequestId().slice(0, 12) } : null }); setPreview(null); return 'خُتم الإصدار ' + String(r.releaseId); })}><Lock size={16} />إنشاء وختم</button>
      </div>
      <div className="rules-form">
        <h3><Power size={17} />الإصدارات</h3>
        {state.releases.map(r => <article key={r.releaseId} className="rules-release"><div><strong dir="ltr">{r.releaseId}</strong><small dir="ltr">{short(r.manifestSha256)} · {r.state} · {r.sealedAt?.slice(0, 16) ?? ''}</small></div>
          {r.state === 'SEALED' && r.releaseId !== state.activation.releaseId && <button className="button subtle small-button" disabled={busy} onClick={() => void run(async () => { await post('/api/office/rules/releases', { action: 'activate', expectedGeneration: state.activation.generation, releaseId: r.releaseId, reasonCode: 'manager-activate' }); return 'فُعّل الإصدار'; })}>تفعيل</button>}
          {r.releaseId === state.activation.releaseId && <button className="button subtle small-button" disabled={busy} onClick={() => void run(async () => { await post('/api/office/rules/releases', { action: 'activate', expectedGeneration: state.activation.generation, releaseId: null, reasonCode: 'manager-deactivate' }); return 'أُوقف التفعيل'; })}>إيقاف التفعيل</button>}
        </article>)}
        {!state.releases.length && <p className="fine-print">لا توجد إصدارات مختومة بعد.</p>}
      </div>
    </>}
    <p className="fine-print">ختم المدير سلطة برمجية للمكتب على الحمولة المستوردة، وليس اعتمادًا حكوميًا أو قانونيًا مستقلًا. توجيه RCIP سياسة مكتب معتمدة بتاريخ اعتماد الإرسال بتوقيت تورونتو.</p>
  </section>;
}
