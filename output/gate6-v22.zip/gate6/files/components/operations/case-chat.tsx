'use client';
// v2.2 Gate 5 — staff side of the canonical case chat: triage queue (waiting first), one-winner claim, release /
// return to the assistant / close, replies with files and voice notes (scan-gated playback), drafted replies, and the
// case's real job/outbox states (no invented progress). Office policy: every staff member with `chat` sees every case.
import { useEffect,useRef,useState } from 'react';
import { MessagesSquare,Send,LoaderCircle,Sparkles,Bot,UserRound,CheckCircle2,ArrowUpLeft,Undo2,Gauge } from 'lucide-react';
import { api,makeRequestId } from '@/lib/client';
import { staffChime } from './notifications';
import { ChatMediaControls } from '../chat-media';
import { useCaseChat,AttachmentChip } from '@/components/client/case-chat';
type Row={candidateId:string;state:'BOT_ACTIVE'|'HANDOFF_PENDING'|'HUMAN_ACTIVE'|'CLOSED';assignedTo:string;lastMessageAt:string;reference:string;name:string;conversationRevision:number};
const STATE_AR:Record<Row['state'],string>={BOT_ACTIVE:'المساعد',HANDOFF_PENDING:'بانتظار موظف',HUMAN_ACTIVE:'مع موظف',CLOSED:'مغلقة'};
type Meta={jobs?:{jobId:string;kind:string;state:string;errorCode:string|null}[];outbox?:{eventId:string;kind:string;state:string;errorCode:string|null}[];me?:string;consents?:Record<string,boolean>};
export function StaffCaseChat({candidateId,notify,openCandidate}:{candidateId:string;notify:(m:string)=>void;openCandidate?:(id:string)=>void}){
 const endpoint=`/api/candidates/${candidateId}/chat`,chat=useCaseChat(endpoint,'STAFF'),[text,setText]=useState(''),[busy,setBusy]=useState(''),end=useRef<HTMLDivElement>(null);
 const c=chat.conversation,meta=chat.meta as Meta|null,me=meta?.me??'',mine=c?.state==='HUMAN_ACTIVE'&&c.assignedStaffId===me,heldByOther=c?.state==='HUMAN_ACTIVE'&&!!c.assignedStaffId&&c.assignedStaffId!==me;
 useEffect(()=>{end.current?.scrollIntoView({block:'end'});},[chat.items.length]);
 async function run(label:string,task:()=>Promise<unknown>,ok=''){setBusy(label);try{await task();if(ok)notify(ok);await chat.pull();}catch(e){notify((e as Error).message);}finally{setBusy('');}}
 const transition=(action:string,ok:string)=>run(action,async()=>{let rev=c!.conversationRevision;if(action==='claim'&&(c!.state==='BOT_ACTIVE'||c!.state==='CLOSED')){const r=await chat.post({action:'transition',transition:{action:c!.state==='CLOSED'?'reopen':'handoff',expectedRevision:rev,requestKey:makeRequestId()}}) as {conversation:{conversationRevision:number}};rev=r.conversation.conversationRevision;}await chat.post({action:'transition',transition:{action,expectedRevision:rev,requestKey:makeRequestId()}});},ok);
 const reply=()=>run('send',async()=>{const t=text.trim();if(!t)return;await chat.send({kind:'TEXT',text:t});setText('');});
 const draft=()=>run('draft',async()=>{const r=await api<{draft:string}>(`/api/support/${candidateId}/draft`,{method:'POST',timeoutMs:90000});setText(r.draft);});
 return <div className="support-pane case-chat-staff">
  <header><div><small>الحالة: <span className={'chat-state '+(c?.state??'')}>{c?STATE_AR[c.state]:'…'}</span>{c?.assignedStaffId?<> · المسؤول: <bdi>{c.assignedStaffId}</bdi></>:null}{chat.socket?' · متصل مباشرة':' · تحديث دوري'}</small></div>
   <div className="inline-actions">{openCandidate&&<button type="button" className="text-button" onClick={()=>openCandidate(candidateId)}>فتح الملف<ArrowUpLeft size={14}/></button>}
    {c&&!mine&&!heldByOther&&<button type="button" className="button gold small-button" disabled={!!busy} onClick={()=>void transition('claim','استلمت المحادثة.')}><UserRound size={14}/>استلام</button>}
    {mine&&<button type="button" className="button subtle small-button" disabled={!!busy} onClick={()=>void transition('release','أُعيدت المحادثة إلى قائمة الانتظار.')}><Undo2 size={14}/>تحرير</button>}
    {mine&&<button type="button" className="button subtle small-button" disabled={!!busy} onClick={()=>void transition('resume_bot','أُعيدت المحادثة إلى المساعد.')}><Bot size={14}/>إعادة للمساعد</button>}
    {c&&c.state!=='CLOSED'&&!heldByOther&&<button type="button" className="button subtle small-button" disabled={!!busy} onClick={()=>void transition('close','أُغلقت المحادثة.')}><CheckCircle2 size={14}/>إغلاق</button>}
    <button type="button" className="button subtle small-button" disabled={!!busy} onClick={()=>void run('rapid',()=>chat.post({action:'rapid_assessment',requestKey:makeRequestId()}),'أُنشئ فحص سريع (RAPID_SCREENING).')}><Gauge size={14}/>فحص سريع</button></div></header>
  <div className="support-thread staff">{chat.items.map(m=><div key={m.pending?'p'+m.clientMessageId:m.sequence} className={'support-msg '+(m.actorType==='CLIENT'?'client':m.actorType==='STAFF'?'staff':'ai')}><small>{m.actorType==='CLIENT'?'العميل':m.actorType==='ASSISTANT'?'المساعد':m.actorType==='SYSTEM'?'النظام':<bdi>{m.senderDisplayRef===me?'أنت':m.senderDisplayRef}</bdi>} · #{m.sequence||'…'}</small>{m.kind==='ASSESSMENT_LINK'?<p><Gauge size={13}/> فحص سريع RAPID_SCREENING: <bdi>{m.assessmentId}</bdi></p>:m.text?<p dir="auto">{m.text}</p>:null}{m.attachments.map(a=><AttachmentChip key={a.evidenceId} a={a} base={endpoint} ar/>)}<time dateTime={m.createdAt}>{new Date(m.createdAt).toLocaleString('ar',{hour:'2-digit',minute:'2-digit',day:'numeric',month:'short'})}</time></div>)}<div ref={end}/></div>
  {(meta?.jobs?.length||meta?.outbox?.length)?<details className="chat-ops"><summary>المعالجة والإشعارات الفعلية</summary><ul>{meta?.jobs?.slice(-8).map(j=><li key={j.jobId}>{j.kind}: {j.state}{j.errorCode?' · '+j.errorCode:''}</li>)}{meta?.outbox?.slice(-8).map(o=><li key={o.eventId}>{o.kind}: {o.state}{o.errorCode?' · '+o.errorCode:''}</li>)}</ul></details>:null}
  {heldByOther?<p className="chat-held">هذه المحادثة مستلمة من <bdi>{c?.assignedStaffId}</bdi>.</p>:<form className="support-input" onSubmit={e=>{e.preventDefault();void reply();}}><ChatMediaControls disabled={!!busy} upload={(f,n)=>chat.upload(f,n)} onError={notify}/><button type="button" className="icon-button" aria-label="اقتراح رد" title="اقتراح رد" disabled={!!busy} onClick={()=>void draft()}>{busy==='draft'?<LoaderCircle size={16} className="spin"/>:<Sparkles size={16}/>}</button><textarea rows={2} value={text} maxLength={4000} onChange={e=>setText(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();void reply();}}} placeholder={mine?'اكتب ردك للعميل… (Enter للإرسال)':'الإرسال يستلم المحادثة باسمك'} aria-label="الرد"/><button className="button emerald" disabled={!!busy||!text.trim()} aria-label="إرسال">{busy==='send'?<LoaderCircle size={16} className="spin"/>:<Send size={16}/>}</button></form>}
  {chat.error&&<div className="error-banner" role="alert">{chat.error}</div>}
 </div>;
}
export function CaseChatInbox({openCandidate,notify,initial=''}:{openCandidate:(id:string)=>void;notify:(m:string)=>void;initial?:string}){
 // A notification target (initial) opens that thread until the user picks another one.
 const [rows,setRows]=useState<Row[]>([]),[picked,setActive]=useState(''),[error,setError]=useState(''),waiting=useRef(-1),active=picked||initial;
 useEffect(()=>{let live=true;const load=()=>{if(document.hidden)return;api<{items:Row[]}>('/api/support').then(r=>{if(!live)return;const n=r.items.filter(i=>i.state==='HANDOFF_PENDING').length;if(waiting.current>=0&&n>waiting.current)staffChime();waiting.current=n;setRows(r.items);}).catch(e=>live&&setError((e as Error).message));};load();const t=window.setInterval(load,5000);return()=>{live=false;window.clearInterval(t);};},[]);
 const current=rows.find(r=>r.candidateId===active);
 return <section className="support-inbox">
  <aside className="support-list" aria-label="المحادثات">{error&&<div className="error-banner" role="alert">{error}</div>}{!rows.length&&<p className="cc-empty">لا توجد محادثات بعد.</p>}
   {rows.map(r=><button type="button" key={r.candidateId} className={'support-row'+(r.candidateId===active?' active':'')} onClick={()=>setActive(r.candidateId)}><span className="support-row-copy"><strong><bdi>{r.name}</bdi></strong><small><bdi>{r.reference}</bdi> · <span className={'chat-state '+r.state}>{STATE_AR[r.state]}</span>{r.assignedTo?<> · <bdi>{r.assignedTo.replace(/^staff:/,'').split('@')[0]}</bdi></>:null}</small></span>{r.state==='HANDOFF_PENDING'&&<span className="notify-badge static">!</span>}</button>)}</aside>
  {!active?<div className="support-pane"><div className="support-placeholder"><MessagesSquare size={34}/><p>اختر محادثة من القائمة.</p></div></div>:<div className="case-chat-pane"><h3><bdi>{current?.name||'—'}</bdi> <small><bdi>{current?.reference}</bdi></small></h3><StaffCaseChat key={active} candidateId={active} notify={notify} openCandidate={openCandidate}/></div>}
 </section>;
}
