# v2.2 Gate 6 — builds execution/FINAL_ACCEPTANCE.md and the per-criterion status in docs/v22/acceptance/acceptance.{json,csv}
# from the evidence table below plus the measured load/restore reports. Statuses are deliberately conservative:
#   PASS_LOCAL  the criterion's condition was executed and passed on the built Worker with local Workers/D1/R2/DO/KV
#               emulation (Miniflare) or Chromium; actual Cloudflare D1/staging was NOT run for it.
#   PARTIAL     some sub-conditions PASS_LOCAL, the listed remainder BLOCKED or NOT_RUN.
#   BLOCKED     needs an approval, provider, policy or environment that does not exist here (named).
#   NOT_RUN     not executed.
# No criterion is marked PASS: no staging/production evidence exists, and AC-25/27/29/30/39/40/50 require it.
import csv, json, sys
args = dict(a.split('=', 1) for a in sys.argv[1:])
HEAD, LOAD, RESTORE, RESULTS = args['head'], json.load(open(args['load'])), json.load(open(args['restore'])), args['results']
L = LOAD
load_line = (f"LOCAL Miniflare evidence only (not Cloudflare staging): {L['profile']['seconds']} s, {L['profile']['sockets']} sockets/{L['profile']['rooms']} rooms, {L['profile']['rateMsgPerSec']} msg/s: "
             f"commit p95 {L['commitMs']['p95']} ms, fan-out p95 {L['fanoutMs']['p95']} ms, rapid enqueue p95 {L['rapidEnqueueMs']['p95']} ms (target ≤800), rapid result max {L['rapidResultMs']['max']} ms (target ≤5000), "
             f"sender distribution client {L['senderDistribution']['client']} : staff {L['senderDistribution']['staff']} (D1 {L['senderDistribution']['dbClientMessages']}:{L['senderDistribution']['dbStaffMessages']}, ratio 1:{L['senderDistribution']['ratioStaffPerClient']}), "
             f"HTTP read p95 {L['httpReadMs']['p95']} ms, committed {L['messages']['committed']}/{L['messages']['attempted']}, lost {L['lostCommitted']}, leaked {L['leakedFrames']}")
R = RESTORE
restore_line = (f"backup {R['backupDurationMs']} ms ({R['tables']} tables, {R['rows']} rows, {R['r2Objects']} R2 objects), restore {R['restoreDurationMs']} ms, "
                f"RTO (restore→first authorized read) {R['rtoMs']} ms, drill RPO {R['rpoMs']} ms (= age of the backup at failure), re-erasure {R['reErasure']['reapplied']}, "
                f"outbox→AMBIGUOUS {R['postRestore']['outboxMarkedAmbiguous']}, rollback {R['rollback']}")
T = {  # test file → short label used in evidence cells
 'db': 'tests/v22/database.test.mjs', 'acc': 'tests/v22/access.test.mjs', 'eng': 'tests/v22/engines.test.mjs', 'portal': 'tests/v22/portal.test.mjs',
 'pe2e': 'tests/v22/portal.e2e.spec.ts', 'bill': 'tests/v22/billing.test.mjs', 'chat': 'tests/v22/chat.test.mjs', 'auto': 'tests/v22/automation.test.mjs',
 'oe2e': 'tests/v22/operations.e2e.spec.ts', 'sec': 'tests/v22/security.test.mjs', 'load': 'tests/v22/load.mjs', 'rest': 'tests/v22/restore.test.mjs',
 'cas': 'tests/v22/outbox-cas.test.mjs', 'reg': 'tests/v22/registry-coexistence.test.mjs', 'unit': 'tests/*.test.mjs (129)', 'api': 'tests/*-api.mjs + auth/intake/legal/portal-security scripts',
}
E = lambda *k: '; '.join(T[x] for x in k)
rows = [
 ('AC-01','PASS_LOCAL',E('api','portal'),'intake-api/portal drafts: partial/empty saves, 400/422 on syntax; actual D1 NOT_RUN'),
 ('AC-02','PARTIAL',E('acc','sec','portal'),'four roles, case scope, spoof/revoked/cross-case deny without existence leak PASS_LOCAL; JWT issuer/aud/alg/key rotation belong to the hosting identity provider (identity headers) — BLOCKED: not verifiable locally'),
 ('AC-03','PARTIAL',E('db'),'SQLite reference + Miniflare D1 negative probes PASS_LOCAL; actual Cloudflare D1 NOT_RUN'),
 ('AC-04','PASS_LOCAL',E('eng','unit'),'malformed nested rules/dates/language never throw or fabricate'),
 ('AC-05','PASS_LOCAL',E('db','api'),'single head per key/subject, canonical writer lib/facts.ts, static no-dual-write'),
 ('AC-06','PASS_LOCAL',E('eng'),'one applicable payload per date; invalid date/url/hash/overlap rejected'),
 ('AC-07','PASS_LOCAL',E('eng'),'one MANAGER authors+seals in one action; direct SEALED insert and STAFF seal refused; CAS activation'),
 ('AC-08','PASS_LOCAL',E('eng'),'missing event date → CONTEXT_INCOMPLETE; historic replay uses exact release'),
 ('AC-09','PARTIAL',E('eng','reg'),'Toronto approval-date routing PASS_LOCAL on TEST_ONLY fixtures; approved legal fixtures BLOCKED (legal pack not approved)'),
 ('AC-10','BLOCKED','—','official CRS tables and independently reviewed GM fixtures are not approved/SHA-pinned; only TEST_ONLY bundles exist, which cannot yield COMPLETE in production'),
 ('AC-11','PASS_LOCAL',E('eng'),'normalization trace incl. wage tier only from sealed dataset'),
 ('AC-12','PASS_LOCAL',E('eng','unit'),'600-profile differential, caps, MAX route, corruption → RULE_UNAVAILABLE'),
 ('AC-13','PASS_LOCAL',E('eng'),'ALL/ANY/UNKNOWN algebra; Gate 3 mutations caught'),
 ('AC-14','BLOCKED','—','program models need sourced legal requirements approval (FSW67/FST/CEC/AIP/RCIP/FCIP/PNP streams)'),
 ('AC-15','PARTIAL',E('eng'),'NOC adapter contract and forged code/quote rejection PASS_LOCAL; human review record BLOCKED'),
 ('AC-16','PARTIAL',E('eng','auto'),'no rubric ⇒ RANK_UNAVAILABLE PASS_LOCAL; numeric rank BLOCKED (I10: no approved ranking policy)'),
 ('AC-17','PARTIAL',E('eng'),'100 concurrent identical requests converge, same key/other body 409 — PASS_LOCAL on Miniflare D1; actual D1 NOT_RUN'),
 ('AC-18','PARTIAL',E('eng','bill','auto'),'stale publication blocked; failed batches leave no pointer/audit/outbox half-write — PASS_LOCAL; actual D1+R2 NOT_RUN'),
 ('AC-19','PASS_LOCAL',E('auto','sec'),'only an explicit client service request creates the event+task; idempotent'),
 ('AC-20','PARTIAL',E('auto','cas','rest'),'lease/fence (CAS proven with forced interleaving), AMBIGUOUS same-key resend, DLQ, restored rows not resent — PASS_LOCAL with a provider test double; real provider sandbox NOT_RUN'),
 ('AC-21','PARTIAL',E('auto','acc'),'0/30/90, catch-up, dedup, consent withdrawal PASS_LOCAL; leap-year/renewal-revision clock matrix NOT_RUN'),
 ('AC-22','PARTIAL',E('chat','sec'),'opt-in consent, identifier masking, outages → human handoff PASS_LOCAL with an LLM test double; vendor approval/allowlist policy BLOCKED'),
 ('AC-23','PASS_LOCAL',E('auto'),'separate employers/vacancies, https source + checked date, encrypted private contacts, RANK_UNAVAILABLE'),
 ('AC-24','PARTIAL',E('bill','sec','oe2e'),'AR/EN PDFs from the same server data, no private fields in JSON/HTML/PDF/logs PASS_LOCAL; schema-wide AR/EN projection review NOT_RUN'),
 ('AC-25','BLOCKED','build + tsc evidence only','no CI pipeline, staging Worker, real bindings or health evidence in this environment; local build/tsc pass'),
 ('AC-26','BLOCKED',E('rest'),'BLOCKED: access/erasure/hold/backup re-erasure implemented and tested locally; approved retention/lawful-use/vendor/key policy missing (PRIVACY_POLICY_APPROVED=false; immutable records reported RETAINED_PENDING_POLICY)'),
 ('AC-27','NOT_RUN',E('load'),'staging load NOT_RUN; local measurement only: ' + load_line),
 ('AC-28','BLOCKED',E('rest'),'isolated restore with keys fingerprint, verification, re-erasure, no resend, capability disable, rollback to 44fd112 PASS_LOCAL: ' + restore_line + '; BLOCKED: accepted RPO/RTO targets not specified by the owner and the drill ran on local Miniflare, not an isolated Cloudflare environment'),
 ('AC-29','PARTIAL',E('portal','pe2e','oe2e'),'integrated journey registration→OTP→draft→path→signature→submit→chat→handoff→rapid→invoice→payments→PDF→notice→lookup PASS_LOCAL; staging browser UAT NOT_RUN'),
 ('AC-30','BLOCKED','execution/FINAL_ACCEPTANCE.md','dossier prepared; owner release review and authorized release decision pending'),
 ('AC-31','PASS_LOCAL',E('chat','load'),'one message per sender/clientMessageId, contiguous sequences under concurrency, ACK after durable batch, changed hash 409'),
 ('AC-32','PASS_LOCAL',E('chat','sec'),'same session/role/case policy for socket/history/media; cookie only; Origin enforced; revocation on every inbound/fan-out; idle close by DO alarm ≤30 s; no staff identity to clients'),
 ('AC-33','PARTIAL',E('chat','load'),'replay after reconnect/network loss, HTTP fallback, dedup PASS_LOCAL; real DO eviction on Cloudflare NOT_RUN'),
 ('AC-34','PASS_LOCAL',E('chat'),'one claim winner; human state and new client input fence the assistant; late output discarded'),
 ('AC-35','BLOCKED',E('chat','auto'),'same evidence/scan/auth pipeline and no playback until CLEAN PASS_LOCAL (scanner test double); media duration adapter, real scanner and transcription provider missing (I07/I15)'),
 ('AC-36','PARTIAL',E('chat','sec'),'consented provider, authorized read-only context, injection cannot change state/roles/facts PASS_LOCAL; human review of grounding BLOCKED'),
 ('AC-37','PASS_LOCAL',E('chat','eng','portal'),'same engine/history with RAPID_SCREENING; verified pointer untouched; no FINAL'),
 ('AC-38','PASS_LOCAL',E('chat','auto'),'monotonic bounded receipts, consented content-free notices, one per unread window, consent revocation cancels'),
 ('AC-39','NOT_RUN',E('load'),'Cloudflare staging NOT_RUN; local measurement: ' + load_line),
 ('AC-40','PARTIAL',E('oe2e','chat'),'client/staff shared chat, handoff, assistant (test double), consents in Chromium PASS_LOCAL; clean attachment playback BLOCKED (no scanner); staging UAT NOT_RUN'),
 ('AC-41','PASS_LOCAL',E('portal','pe2e'),'two entry cards, account after OTP only, intent routing'),
 ('AC-42','PASS_LOCAL',E('portal'),'account password vs case-only legacy password'),
 ('AC-43','PASS_LOCAL',E('pe2e'),'path selector focus/back/unsure'),
 ('AC-44','PASS_LOCAL',E('portal','pe2e'),'server drafts CAS+idempotency, offline queue, two-tab conflict'),
 ('AC-45','PARTIAL',E('pe2e','portal'),'single pad, resize/DPR, fixed hash PASS_LOCAL in Chromium emulation; real pen/touch devices NOT_RUN'),
 ('AC-46','PASS_LOCAL',E('portal'),'owner-bound signature verified server-side and bound atomically; no STALE/re-sign'),
 ('AC-47','PASS_LOCAL',E('portal','pe2e'),'indicator only for full/account session over HTTPS'),
 ('AC-48','PASS_LOCAL',E('portal'),'identical 202, registered contact only, no destination accepted'),
 ('AC-49','PASS_LOCAL',E('portal'),'5-min case_status scope, minimal answer, no escalation'),
 ('AC-50','PARTIAL',E('pe2e','portal','api'),'RTL/LTR at 360/768/1440, flows and regressions PASS_LOCAL; staging E2E/UAT/performance NOT_RUN'),
 ('AC-51','PASS_LOCAL',E('bill','oe2e'),'catalog/custom/free items, discount, explicit currency, server integer cents'),
 ('AC-52','PARTIAL',E('bill'),'partial CASH atomic — PASS_LOCAL on Miniflare D1; actual D1 NOT_RUN'),
 ('AC-53','PASS_LOCAL',E('bill','sec'),'ZELLE full with private R2 receipt; no cross-case/public access'),
 ('AC-54','PARTIAL',E('bill'),'repeated key replays, changed payload 409, lost ACK reconciled — PASS_LOCAL; actual D1 NOT_RUN'),
 ('AC-55','PASS_LOCAL',E('bill','sec'),'REFER locks until one MANAGER approves without changing amounts'),
 ('AC-56','PARTIAL',E('bill','auto','portal'),'notice once with remaining/currency/deadline via the outbox, AR/EN PDFs from the server snapshot PASS_LOCAL; provider sandbox NOT_RUN'),
 ('AC-57','PASS_LOCAL',E('bill','sec','oe2e'),'no view_financials ⇒ 403 and hidden cards; client sees own projection only'),
 ('AC-58','PASS_LOCAL',E('acc'),'four roles, atomic Toggles/audit/epoch, stale KV cannot restore access'),
 ('AC-59','PASS_LOCAL',E('acc'),'Toronto midnight expiry without cron/KV, no MANAGER authority, crossing transaction rolls back'),
 ('AC-60','BLOCKED',E('auto','chat'),'integrity scan (scanner double), shared-engine recompute, dedup, append-only history, truthful job states PASS_LOCAL; typed extraction adapter and real scanner missing (I07/I15)'),
]
assert len(rows) == 60 and [r[0] for r in rows] == [f'AC-{i:02d}' for i in range(1, 61)]
acc = json.load(open('docs/v22/acceptance/acceptance.json'))
for c, (cid, status, ev, note) in zip(acc['criteria'], rows):
    assert c['id'] == cid
    c['implementationStatus'] = status
    c['evidence'] = {'repoSha': HEAD, 'environment': 'local Miniflare (Workers/D1/R2/DO/KV) + Chromium; no Cloudflare staging', 'tests': ev, 'note': note, 'results': RESULTS}
json.dump(acc, open('docs/v22/acceptance/acceptance.json', 'w'), ensure_ascii=False, indent=2)
with open('docs/v22/acceptance/acceptance.csv', newline='') as f: rd = list(csv.reader(f))
hdr = rd[0]; extra = [h for h in ['implementationStatus', 'evidenceTests', 'evidenceNote'] if h not in hdr]; hdr = hdr + extra
out = [hdr]
for r, (cid, status, ev, note) in zip(rd[1:], rows):
    r = r + [''] * (len(hdr) - len(r)); d = dict(zip(hdr, r)); d['implementationStatus'] = status; d['evidenceTests'] = ev; d['evidenceNote'] = note
    out.append([d[h] for h in hdr])
with open('docs/v22/acceptance/acceptance.csv', 'w', newline='') as f: csv.writer(f).writerows(out)
count = {}
for _, s, _, _ in rows: count[s] = count.get(s, 0) + 1
md = [f'# FINAL_ACCEPTANCE — ALHIJRAH Canada Desk v2.2 (Gate 6)', '',
      f'- Repository commit: `{HEAD}`; environment: local Miniflare (Workers/D1/R2/Durable Objects/KV) and Chromium via Playwright behind a local self-signed HTTPS server.',
      '- **No deployment, no production migration, no production resource change.** Closing this plan is not a release authorization.',
      f'- Status totals: ' + ', '.join(f'{k} {v}' for k, v in sorted(count.items())) + '. No criterion is marked PASS without staging/production evidence.',
      f'- Raw results: `{RESULTS}` (commands, exit codes, outputs). Load: {load_line}. Restore: {restore_line}.', '',
      '| AC | Status | Evidence | Note / remaining gap |', '|---|---|---|---|']
for cid, status, ev, note in rows: md.append(f'| {cid} | {status} | {ev} | {note} |')
md += ['', '## Blockers that stay open', '',
       '- Legal: approved official rule packs and reviewed fixtures (AC-09/10/14/15/36).',
       '- Providers: malware scanner, typed extractor, media duration, speech-to-text (I07/I15 → AC-35/60); email provider sandbox (AC-20/56); approved LLM vendor/allowlist (AC-22).',
       '- Policy: retention/lawful-use/vendor/key policy (AC-26 BLOCKED); accepted RPO/RTO targets and an isolated Cloudflare restore (AC-28 BLOCKED); ranking rubric (I10 → AC-16).',
       '- Load evidence (AC-27/AC-39) comes from LOCAL Miniflare (one process); it is not a staging measurement and both stay NOT_RUN.',
       '- Environment: Cloudflare staging/CI with real bindings (AC-25/27/29/33/39/40/50) and actual D1 runs for D1-specific criteria.',
       '- Owner release review (AC-30).']
open('execution/FINAL_ACCEPTANCE.md', 'w').write('\n'.join(md) + '\n')
print(json.dumps(count))
