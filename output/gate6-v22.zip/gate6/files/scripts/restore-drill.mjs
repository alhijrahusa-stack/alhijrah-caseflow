// v2.2 Gate 6 — restore drill for an ISOLATED environment (never production). Library + CLI.
// backup(): logical D1 snapshot (schema objects in creation order + every row) and R2 objects (bytes + SHA-256) plus
//           the SHA-256 fingerprint of each encryption secret (never the secret itself).
// restore(): rebuild into an empty D1/R2: tables → rows (inside one batch with deferred foreign keys; guards are created
//           afterwards so restored history is not re-judged as new writes) → indexes → triggers; then verify
//           quick_check, foreign_key_check, per-table row counts and content hashes, R2 bytes.
// postRestore(): no double delivery — non-terminal outbox rows become AMBIGUOUS (re-sent only with the same provider
//           Idempotency-Key = event id); RUNNING jobs return to RETRY; the external erasure journal is re-applied.
// CLI (local Miniflare state directories only): node scripts/restore-drill.mjs <snapshot.json> is reserved for an
// isolated drill run by tests/v22/restore.test.mjs; it refuses any argument that looks like a production identifier.
import { createHash } from 'node:crypto';

const sha = b => createHash('sha256').update(b).digest('hex');
const SKIP = n => /^(sqlite_|_cf_|d1_)/.test(n);
const canon = rows => sha(JSON.stringify(rows.map(r => Object.keys(r).sort().map(k => [k, r[k]]))));

export async function backup({ db, bucket, secrets = {} }) {
  const startedAt = Date.now();
  const objects = (await db.prepare("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY rowid").all()).results.filter(o => !SKIP(o.name) && !SKIP(o.tbl_name));
  const tables = {};
  for (const t of objects.filter(o => o.type === 'table')) {
    const rows = (await db.prepare(`SELECT * FROM "${t.name}" ORDER BY rowid`).all()).results;
    tables[t.name] = { rows, count: rows.length, hash: canon(rows) };
  }
  const r2 = [];
  if (bucket) {
    let cursor;
    do {
      const page = await bucket.list({ cursor, limit: 1000 });
      for (const o of page.objects) {
        const obj = await bucket.get(o.key); const bytes = Buffer.from(await obj.arrayBuffer());
        r2.push({ key: o.key, sha256: sha(bytes), size: bytes.length, contentType: obj.httpMetadata?.contentType ?? null, customMetadata: obj.customMetadata ?? {}, base64: bytes.toString('base64') });
      }
      cursor = page.truncated ? page.cursor : undefined;
    } while (cursor);
  }
  const keyFingerprints = Object.fromEntries(Object.entries(secrets).map(([k, v]) => [k, sha(String(v))]));
  const snapshot = { kind: 'alhijrah-canada-desk/logical-backup', version: 1, takenAtMs: startedAt, objects, tables, r2, keyFingerprints };
  return { snapshot, durationMs: Date.now() - startedAt, sha256: sha(JSON.stringify(snapshot)) };
}

export async function restore({ db, bucket, secrets = {} }, snapshot) {
  const startedAt = Date.now();
  if (snapshot.kind !== 'alhijrah-canada-desk/logical-backup') throw new Error('NOT_A_SNAPSHOT');
  for (const [k, fp] of Object.entries(snapshot.keyFingerprints)) if (secrets[k] === undefined || sha(String(secrets[k])) !== fp) throw new Error('KEY_FINGERPRINT_MISMATCH:' + k);
  const existing = (await db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all()).results.filter(t => !SKIP(t.name));
  if (existing.length) throw new Error('TARGET_NOT_EMPTY');
  const byType = t => snapshot.objects.filter(o => o.type === t);
  for (const t of byType('table')) await db.prepare(t.sql).run();
  const inserts = [db.prepare('PRAGMA defer_foreign_keys = ON')];
  for (const [name, t] of Object.entries(snapshot.tables)) for (const row of t.rows) {
    const cols = Object.keys(row); if (!cols.length) continue;
    inserts.push(db.prepare(`INSERT INTO "${name}"(${cols.map(c => `"${c}"`).join(',')}) VALUES(${cols.map(() => '?').join(',')})`).bind(...cols.map(c => row[c])));
  }
  if (inserts.length > 1) await db.batch(inserts);
  for (const t of [...byType('index'), ...byType('trigger'), ...byType('view')]) await db.prepare(t.sql).run();
  for (const o of snapshot.r2) await bucket.put(o.key, Buffer.from(o.base64, 'base64'), { httpMetadata: o.contentType ? { contentType: o.contentType } : undefined, customMetadata: o.customMetadata });
  return { durationMs: Date.now() - startedAt, verification: await verify({ db, bucket }, snapshot) };
}

export async function verify({ db, bucket }, snapshot) {
  const quick = (await db.prepare('PRAGMA quick_check').all()).results.map(r => Object.values(r)[0]);
  const fk = (await db.prepare('PRAGMA foreign_key_check').all()).results;
  const tables = {};
  for (const [name, t] of Object.entries(snapshot.tables)) {
    const rows = (await db.prepare(`SELECT * FROM "${name}" ORDER BY rowid`).all()).results;
    tables[name] = { count: rows.length, countOk: rows.length === t.count, hashOk: canon(rows) === t.hash };
  }
  let r2Ok = 0; const r2Bad = [];
  for (const o of snapshot.r2) { const obj = await bucket.get(o.key); const bytes = obj ? Buffer.from(await obj.arrayBuffer()) : null; if (bytes && sha(bytes) === o.sha256) r2Ok++; else r2Bad.push(o.key); }
  const objects = (await db.prepare("SELECT type,name FROM sqlite_master WHERE sql IS NOT NULL").all()).results.filter(o => !SKIP(o.name));
  return { quickCheck: quick, foreignKeyViolations: fk.length, tables, allTablesOk: Object.values(tables).every(t => t.countOk && t.hashOk), r2Ok, r2Bad, schemaObjects: objects.length, schemaObjectsExpected: snapshot.objects.length };
}

/** Post-restore safety: no unconfirmed resend, no stale leases; then the erasure journal is re-applied by the caller. */
export async function postRestore({ db }) {
  const now = Date.now();
  const outbox = await db.prepare("UPDATE delivery_outbox SET state='AMBIGUOUS',error_code='RESTORED_UNCONFIRMED',lease_until_ms=0,next_at_ms=? WHERE state IN('PENDING','RETRY','LEASED')").bind(now).run();
  const jobs = await db.prepare("UPDATE durable_jobs SET state='RETRY',error_code='RESTORED',lease_until_ms=0,next_at_ms=? WHERE state='RUNNING'").bind(now).run();
  return { outboxMarkedAmbiguous: outbox.meta.changes, jobsReturnedToRetry: jobs.meta.changes };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  console.error('restore-drill is a library for isolated drills (see tests/v22/restore.test.mjs); it has no production mode.');
  process.exit(2);
}
