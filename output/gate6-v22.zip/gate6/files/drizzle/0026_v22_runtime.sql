-- v2.2 Gate 1 (package file 0018_v22_runtime.sql). Numbered 0026. Single-office runtime; candidates.id stays the case key.
-- Manager/staff mapping comes only from trusted server records: office_settings.primary_owner_id (written by the
-- authenticated OFFICE_ADMIN_EMAIL session in lib/server.ts) and office_members (managed by the manager).
-- The package's audited 'legacy STAFF policy' statement is removed: 0025 already seeds the all-allowed STAFF policy
-- (owner decision), and narrowing it here would contradict that decision.
INSERT INTO users(user_id,role,created_at)
 SELECT primary_owner_id,'MANAGER',strftime('%Y-%m-%dT%H:%M:%fZ','now')
 FROM office_settings WHERE id='office' AND primary_owner_id<>'';
--> statement-breakpoint
INSERT INTO users(user_id,role,active,created_at)
 SELECT 'staff:'||lower(trim(email)),'STAFF',active,created_at FROM office_members
 WHERE 'staff:'||lower(trim(email)) NOT IN(SELECT user_id FROM users);
--> statement-breakpoint
INSERT INTO users(user_id,role,created_at) VALUES('system:v2.2','SYSTEM',strftime('%Y-%m-%dT%H:%M:%fZ','now'));
--> statement-breakpoint
CREATE TABLE case_access(
 case_id TEXT NOT NULL REFERENCES candidates(id),user_id TEXT NOT NULL REFERENCES users(user_id),
 granted_by TEXT NOT NULL REFERENCES users(user_id),created_at TEXT NOT NULL,
 PRIMARY KEY(case_id,user_id)
);
--> statement-breakpoint
CREATE INDEX case_access_user ON case_access(user_id,case_id);
--> statement-breakpoint
INSERT INTO case_access(case_id,user_id,granted_by,created_at)
 SELECT c.id,u.user_id,m.user_id,strftime('%Y-%m-%dT%H:%M:%fZ','now')
 FROM candidates c JOIN users u ON u.user_id='staff:'||lower(trim(c.assigned_to))
 JOIN users m ON m.user_id=(SELECT user_id FROM users WHERE role='MANAGER' AND active=1 ORDER BY user_id LIMIT 1);
--> statement-breakpoint
ALTER TABLE candidates ADD COLUMN data_revision INTEGER NOT NULL DEFAULT 0 CHECK(data_revision>=0);
--> statement-breakpoint
ALTER TABLE candidates ADD COLUMN publication_revision INTEGER NOT NULL DEFAULT 0 CHECK(publication_revision>=0);
--> statement-breakpoint
ALTER TABLE candidates ADD COLUMN latest_verified_assessment_id TEXT REFERENCES assessment_history(id);
--> statement-breakpoint
ALTER TABLE candidates ADD COLUMN latest_rapid_assessment_id TEXT REFERENCES assessment_history(id);
--> statement-breakpoint
ALTER TABLE candidates ADD COLUMN approval_for_submission_at TEXT;
--> statement-breakpoint
CREATE TRIGGER v22_profile_revision AFTER UPDATE OF profile,approval_for_submission_at ON candidates
 WHEN NEW.profile<>OLD.profile OR NEW.approval_for_submission_at IS NOT OLD.approval_for_submission_at
 BEGIN UPDATE candidates SET data_revision=data_revision+1 WHERE id=NEW.id; END;
--> statement-breakpoint
CREATE TRIGGER v22_evidence_insert AFTER INSERT ON documents BEGIN UPDATE candidates SET data_revision=data_revision+1 WHERE id=NEW.candidate_id; END;
--> statement-breakpoint
CREATE TRIGGER v22_evidence_update AFTER UPDATE OF verified ON documents WHEN NEW.verified<>OLD.verified BEGIN UPDATE candidates SET data_revision=data_revision+1 WHERE id=NEW.candidate_id; END;
--> statement-breakpoint
CREATE TABLE case_fact_revisions(
 fact_id TEXT PRIMARY KEY NOT NULL,case_id TEXT NOT NULL REFERENCES candidates(id),
 fact_key TEXT NOT NULL,subject_id TEXT NOT NULL,value_json TEXT NOT NULL CHECK(json_valid(value_json)),
 state TEXT NOT NULL CHECK(state IN('REPORTED','EXTRACTED_UNVERIFIED','VERIFIED','REJECTED')),
 evidence_ids TEXT NOT NULL DEFAULT '[]' CHECK(json_valid(evidence_ids) AND json_type(evidence_ids)='array'),
 source_hash TEXT NOT NULL CHECK(length(source_hash)=64),created_by TEXT NOT NULL REFERENCES users(user_id),
 review_note TEXT,created_at TEXT NOT NULL,UNIQUE(case_id,fact_id)
);
--> statement-breakpoint
CREATE INDEX facts_case_subject ON case_fact_revisions(case_id,subject_id,fact_key,created_at DESC,fact_id);
--> statement-breakpoint
CREATE TABLE case_fact_heads(
 case_id TEXT NOT NULL REFERENCES candidates(id),subject_id TEXT NOT NULL,fact_key TEXT NOT NULL,
 fact_id TEXT NOT NULL,PRIMARY KEY(case_id,subject_id,fact_key),
 FOREIGN KEY(case_id,fact_id) REFERENCES case_fact_revisions(case_id,fact_id)
);
--> statement-breakpoint
CREATE TRIGGER fact_history_no_update BEFORE UPDATE ON case_fact_revisions BEGIN SELECT RAISE(ABORT,'IMMUTABLE_FACT_REVISION'); END;
--> statement-breakpoint
CREATE TRIGGER fact_history_no_delete BEFORE DELETE ON case_fact_revisions BEGIN SELECT RAISE(ABORT,'IMMUTABLE_FACT_REVISION'); END;
--> statement-breakpoint
CREATE TABLE durable_jobs(
 job_id TEXT PRIMARY KEY NOT NULL,case_id TEXT REFERENCES candidates(id),
 kind TEXT NOT NULL CHECK(kind IN('ASSESSMENT','INGESTION','TRANSCRIPTION','ASSISTANT')),
 request_key TEXT NOT NULL UNIQUE,request_hash TEXT NOT NULL CHECK(length(request_hash)=64),
 payload TEXT NOT NULL CHECK(json_valid(payload)),
 state TEXT NOT NULL DEFAULT 'PENDING' CHECK(state IN('PENDING','RUNNING','RETRY','SUCCEEDED','FAILED','CANCELLED','DEAD_LETTER')),
 attempts INTEGER NOT NULL DEFAULT 0,lease_until_ms INTEGER NOT NULL DEFAULT 0,fence INTEGER NOT NULL DEFAULT 0,
 next_at_ms INTEGER NOT NULL,created_by TEXT NOT NULL REFERENCES users(user_id),created_at TEXT NOT NULL,updated_at TEXT NOT NULL,
 result_ref TEXT,error_code TEXT
);
--> statement-breakpoint
CREATE INDEX durable_jobs_due ON durable_jobs(state,next_at_ms,lease_until_ms,job_id);
--> statement-breakpoint
CREATE INDEX durable_jobs_case ON durable_jobs(case_id,created_at DESC,job_id);
--> statement-breakpoint
CREATE TABLE delivery_outbox(
 event_id TEXT PRIMARY KEY NOT NULL,case_id TEXT NOT NULL REFERENCES candidates(id),
 kind TEXT NOT NULL CHECK(kind IN('PAYMENT_NOTICE','CHAT_NOTICE','PROGRESS_NOTICE','EXPIRY_NOTICE')),
 business_key TEXT NOT NULL UNIQUE,payload_encrypted TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'PENDING' CHECK(state IN('PENDING','LEASED','RETRY','DELIVERED','AMBIGUOUS','CANCELLED','DEAD_LETTER')),
 attempts INTEGER NOT NULL DEFAULT 0,fence INTEGER NOT NULL DEFAULT 0,lease_until_ms INTEGER NOT NULL DEFAULT 0,
 next_at_ms INTEGER NOT NULL,provider_reference TEXT,error_code TEXT,created_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE INDEX delivery_outbox_due ON delivery_outbox(state,next_at_ms,lease_until_ms,event_id);
--> statement-breakpoint
CREATE TABLE case_conversations(
 conversation_id TEXT PRIMARY KEY NOT NULL,case_id TEXT NOT NULL UNIQUE REFERENCES candidates(id),
 state TEXT NOT NULL DEFAULT 'BOT_ACTIVE' CHECK(state IN('BOT_ACTIVE','HANDOFF_PENDING','HUMAN_ACTIVE','CLOSED')),
 assigned_to TEXT REFERENCES users(user_id),revision INTEGER NOT NULL DEFAULT 0,
 automation_generation INTEGER NOT NULL DEFAULT 0,last_sequence INTEGER NOT NULL DEFAULT 0,last_client_sequence INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(conversation_id,case_id)
);
--> statement-breakpoint
CREATE INDEX chat_triage ON case_conversations(state,updated_at,conversation_id);
--> statement-breakpoint
CREATE TABLE case_chat_messages(
 message_id TEXT PRIMARY KEY NOT NULL,conversation_id TEXT NOT NULL,case_id TEXT NOT NULL,
 sequence INTEGER NOT NULL CHECK(sequence>0),sender_id TEXT NOT NULL REFERENCES users(user_id),
 actor_type TEXT NOT NULL CHECK(actor_type IN('CLIENT','STAFF','ASSISTANT','SYSTEM')),
 client_message_id TEXT NOT NULL,payload_hash TEXT NOT NULL CHECK(length(payload_hash)=64),
 kind TEXT NOT NULL CHECK(kind IN('TEXT','ATTACHMENT','VOICE','ASSESSMENT')),
 body_encrypted TEXT NOT NULL,evidence_id TEXT REFERENCES documents(id),
 automation_generation INTEGER,context_data_revision INTEGER,context_rule_generation INTEGER,in_reply_to_sequence INTEGER,
 created_at TEXT NOT NULL,UNIQUE(conversation_id,sequence),UNIQUE(conversation_id,sender_id,client_message_id),
 FOREIGN KEY(conversation_id,case_id) REFERENCES case_conversations(conversation_id,case_id)
);
--> statement-breakpoint
CREATE INDEX chat_replay ON case_chat_messages(conversation_id,sequence,message_id);
--> statement-breakpoint
CREATE TRIGGER chat_message_guard BEFORE INSERT ON case_chat_messages BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM case_conversations r WHERE r.conversation_id=NEW.conversation_id AND r.case_id=NEW.case_id AND r.state<>'CLOSED' AND r.last_sequence+1=NEW.sequence) THEN RAISE(ABORT,'CHAT_SEQUENCE_CONFLICT') END;
 SELECT CASE WHEN NEW.evidence_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM documents WHERE id=NEW.evidence_id AND candidate_id=NEW.case_id) THEN RAISE(ABORT,'CHAT_ATTACHMENT_SCOPE') END;
 SELECT CASE WHEN NEW.actor_type='ASSISTANT' AND NOT EXISTS(SELECT 1 FROM case_conversations r JOIN candidates c ON c.id=r.case_id WHERE r.conversation_id=NEW.conversation_id AND r.state='BOT_ACTIVE' AND r.automation_generation=NEW.automation_generation AND r.last_client_sequence=NEW.in_reply_to_sequence AND c.data_revision=NEW.context_data_revision AND (SELECT generation FROM rule_activation WHERE singleton=1)=NEW.context_rule_generation) THEN RAISE(ABORT,'ASSISTANT_FENCED') END;
END;
--> statement-breakpoint
CREATE TRIGGER chat_message_apply AFTER INSERT ON case_chat_messages BEGIN
 UPDATE case_conversations SET last_sequence=NEW.sequence,last_client_sequence=CASE WHEN NEW.actor_type='CLIENT' THEN NEW.sequence ELSE last_client_sequence END,updated_at=NEW.created_at WHERE conversation_id=NEW.conversation_id;
END;
--> statement-breakpoint
CREATE TRIGGER chat_message_immutable BEFORE UPDATE ON case_chat_messages BEGIN SELECT RAISE(ABORT,'IMMUTABLE_CHAT_MESSAGE'); END;
--> statement-breakpoint
CREATE TRIGGER chat_message_no_delete BEFORE DELETE ON case_chat_messages BEGIN SELECT RAISE(ABORT,'IMMUTABLE_CHAT_MESSAGE'); END;
--> statement-breakpoint
CREATE TABLE case_chat_receipts(
 conversation_id TEXT NOT NULL REFERENCES case_conversations(conversation_id),user_id TEXT NOT NULL REFERENCES users(user_id),
 delivered_sequence INTEGER NOT NULL DEFAULT 0,read_sequence INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL,
 CHECK(read_sequence>=0 AND read_sequence<=delivered_sequence),PRIMARY KEY(conversation_id,user_id)
);
--> statement-breakpoint
CREATE TRIGGER chat_receipt_insert_guard BEFORE INSERT ON case_chat_receipts WHEN NEW.delivered_sequence>(SELECT last_sequence FROM case_conversations WHERE conversation_id=NEW.conversation_id) BEGIN SELECT RAISE(ABORT,'INVALID_CHAT_RECEIPT'); END;
--> statement-breakpoint
CREATE TRIGGER chat_receipt_update_guard BEFORE UPDATE ON case_chat_receipts WHEN NEW.conversation_id<>OLD.conversation_id OR NEW.user_id<>OLD.user_id OR NEW.delivered_sequence<OLD.delivered_sequence OR NEW.read_sequence<OLD.read_sequence OR NEW.delivered_sequence>(SELECT last_sequence FROM case_conversations WHERE conversation_id=NEW.conversation_id) BEGIN SELECT RAISE(ABORT,'INVALID_CHAT_RECEIPT'); END;
--> statement-breakpoint
CREATE TABLE case_in_app_notifications(
 notification_id TEXT PRIMARY KEY NOT NULL,user_id TEXT NOT NULL REFERENCES users(user_id),case_id TEXT NOT NULL REFERENCES candidates(id),
 kind TEXT NOT NULL,resource_id TEXT NOT NULL,business_key TEXT NOT NULL UNIQUE,created_at TEXT NOT NULL,read_at TEXT
);
--> statement-breakpoint
CREATE INDEX notification_unread ON case_in_app_notifications(user_id,read_at,created_at DESC,notification_id);
--> statement-breakpoint
CREATE TABLE case_chat_transitions(
 transition_id TEXT PRIMARY KEY NOT NULL,conversation_id TEXT NOT NULL REFERENCES case_conversations(conversation_id),
 request_key TEXT NOT NULL UNIQUE,request_hash TEXT NOT NULL CHECK(length(request_hash)=64),
 expected_revision INTEGER NOT NULL,old_state TEXT NOT NULL,new_state TEXT NOT NULL,
 assigned_to TEXT REFERENCES users(user_id),actor_id TEXT NOT NULL REFERENCES users(user_id),created_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE TRIGGER chat_transition_guard BEFORE INSERT ON case_chat_transitions BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM case_conversations r WHERE r.conversation_id=NEW.conversation_id AND r.revision=NEW.expected_revision AND r.state=NEW.old_state AND ((NEW.old_state='BOT_ACTIVE' AND NEW.new_state IN('HANDOFF_PENDING','CLOSED')) OR (NEW.old_state='HANDOFF_PENDING' AND NEW.new_state IN('HUMAN_ACTIVE','CLOSED')) OR (NEW.old_state='HUMAN_ACTIVE' AND NEW.new_state IN('HANDOFF_PENDING','BOT_ACTIVE','CLOSED')) OR (NEW.old_state='CLOSED' AND NEW.new_state='HANDOFF_PENDING'))) THEN RAISE(ABORT,'CHAT_TRANSITION_CONFLICT') END;
 SELECT CASE WHEN NEW.new_state='HUMAN_ACTIVE' AND NEW.assigned_to IS NULL THEN RAISE(ABORT,'CHAT_OWNER_REQUIRED') END;
END;
--> statement-breakpoint
CREATE TRIGGER chat_transition_apply AFTER INSERT ON case_chat_transitions BEGIN UPDATE case_conversations SET state=NEW.new_state,assigned_to=NEW.assigned_to,revision=revision+1,automation_generation=automation_generation+1,updated_at=NEW.created_at WHERE conversation_id=NEW.conversation_id; END;
--> statement-breakpoint
CREATE TRIGGER chat_transition_no_update BEFORE UPDATE ON case_chat_transitions BEGIN SELECT RAISE(ABORT,'IMMUTABLE_CHAT_TRANSITION'); END;
--> statement-breakpoint
CREATE TRIGGER chat_transition_no_delete BEFORE DELETE ON case_chat_transitions BEGIN SELECT RAISE(ABORT,'IMMUTABLE_CHAT_TRANSITION'); END;
--> statement-breakpoint
CREATE TABLE office_billing_settings(
 singleton INTEGER PRIMARY KEY CHECK(singleton=1),currency TEXT CHECK(currency IS NULL OR(length(currency)=3 AND currency NOT GLOB '*[^A-Z]*')),
 updated_by TEXT REFERENCES users(user_id),updated_at TEXT NOT NULL
);
--> statement-breakpoint
INSERT INTO office_billing_settings VALUES(1,NULL,NULL,strftime('%Y-%m-%dT%H:%M:%fZ','now'));
--> statement-breakpoint
CREATE TABLE office_service_catalog(
 service_id TEXT PRIMARY KEY NOT NULL,name_ar TEXT NOT NULL,name_en TEXT NOT NULL,
 price_cents INTEGER NOT NULL CHECK(typeof(price_cents)='integer' AND price_cents BETWEEN 0 AND 9007199254740991),
 currency TEXT NOT NULL CHECK(length(currency)=3 AND currency NOT GLOB '*[^A-Z]*'),active INTEGER NOT NULL CHECK(active IN(0,1)),
 version INTEGER NOT NULL DEFAULT 1,updated_by TEXT NOT NULL REFERENCES users(user_id),updated_at TEXT NOT NULL
);
