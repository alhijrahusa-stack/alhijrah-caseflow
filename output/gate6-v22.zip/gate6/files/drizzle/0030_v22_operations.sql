-- v2.2 Gate 5 — forward migration (additive only; no existing row is rewritten).
-- 1. Evidence integrity: existing uploads stay LEGACY_UNSCANNED (current staff review keeps working); new uploads start
--    QUARANTINED and only a configured scanner can move them to CLEAN. Chat attachments and voice playback require CLEAN.
ALTER TABLE documents ADD COLUMN integrity_state TEXT NOT NULL DEFAULT 'LEGACY_UNSCANNED'
 CHECK(integrity_state IN('LEGACY_UNSCANNED','QUARANTINED','SCANNING','CLEAN','REJECTED','ERROR'));
--> statement-breakpoint
ALTER TABLE documents ADD COLUMN integrity_engine TEXT;
--> statement-breakpoint
ALTER TABLE documents ADD COLUMN integrity_checked_at TEXT;
--> statement-breakpoint
ALTER TABLE documents ADD COLUMN media_duration_ms INTEGER CHECK(media_duration_ms IS NULL OR (typeof(media_duration_ms)='integer' AND media_duration_ms BETWEEN 1 AND 300000));
--> statement-breakpoint
CREATE TRIGGER document_integrity_guard BEFORE UPDATE OF integrity_state ON documents
 WHEN NOT ((OLD.integrity_state IN('QUARANTINED','ERROR') AND NEW.integrity_state='SCANNING') OR (OLD.integrity_state='SCANNING' AND NEW.integrity_state IN('CLEAN','REJECTED','ERROR')) OR (OLD.integrity_state='ERROR' AND NEW.integrity_state='QUARANTINED'))
 BEGIN SELECT RAISE(ABORT,'INVALID_INTEGRITY_TRANSITION'); END;
--> statement-breakpoint
CREATE TRIGGER document_clean_needs_engine BEFORE UPDATE OF integrity_state ON documents
 WHEN NEW.integrity_state='CLEAN' AND (NEW.integrity_engine IS NULL OR NEW.integrity_checked_at IS NULL)
 BEGIN SELECT RAISE(ABORT,'SCAN_ENGINE_REQUIRED'); END;
--> statement-breakpoint
-- 2. Purpose consents (Package 8 / expiry): one current row per case and purpose, every change audited in events.
CREATE TABLE case_purpose_consents(
 case_id TEXT NOT NULL REFERENCES candidates(id),
 purpose TEXT NOT NULL CHECK(purpose IN('LLM_CHAT_ASSISTANT','AUDIO_TRANSCRIPTION','CHAT_NOTIFICATIONS','EXPIRY_NOTIFICATIONS')),
 granted INTEGER NOT NULL CHECK(granted IN(0,1)),notice_version TEXT NOT NULL,
 updated_by TEXT NOT NULL,updated_at TEXT NOT NULL,PRIMARY KEY(case_id,purpose)
);
--> statement-breakpoint
-- 3. Explicit service requests (the only source of a CRM event); idempotent per request key.
CREATE TABLE client_service_requests(
 request_id TEXT PRIMARY KEY NOT NULL,case_id TEXT NOT NULL REFERENCES candidates(id),
 service_id TEXT NOT NULL REFERENCES office_service_catalog(service_id),service_version INTEGER NOT NULL,
 request_key TEXT NOT NULL UNIQUE,request_hash TEXT NOT NULL CHECK(length(request_hash)=64),
 state TEXT NOT NULL DEFAULT 'REQUESTED' CHECK(state IN('REQUESTED','IN_PROGRESS','DONE','CANCELLED')),
 note TEXT CHECK(note IS NULL OR length(note)<=2000),created_at TEXT NOT NULL,updated_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE INDEX service_requests_case ON client_service_requests(case_id,created_at DESC,request_id);
--> statement-breakpoint
-- 4. Employers, vacancies and ATS stages: every employer/vacancy carries an official https source and the date it was
--    checked; no vacancy, ranking or acceptance rate is generated. Private contacts are stored encrypted, staff-only.
CREATE TABLE office_employers(
 employer_id TEXT PRIMARY KEY NOT NULL,name TEXT NOT NULL CHECK(length(name) BETWEEN 2 AND 200),
 source_url TEXT NOT NULL CHECK(source_url LIKE 'https://%'),source_checked_on TEXT NOT NULL CHECK(length(source_checked_on)=10),
 contact_encrypted TEXT,version INTEGER NOT NULL DEFAULT 1,created_by TEXT NOT NULL REFERENCES users(user_id),created_at TEXT NOT NULL,updated_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE TABLE office_vacancies(
 vacancy_id TEXT PRIMARY KEY NOT NULL,employer_id TEXT NOT NULL REFERENCES office_employers(employer_id),
 title TEXT NOT NULL CHECK(length(title) BETWEEN 2 AND 200),noc TEXT CHECK(noc IS NULL OR (length(noc)=5 AND noc NOT GLOB '*[^0-9]*')),
 source_url TEXT NOT NULL CHECK(source_url LIKE 'https://%'),posted_on TEXT NOT NULL CHECK(length(posted_on)=10),
 valid_until TEXT CHECK(valid_until IS NULL OR (length(valid_until)=10 AND valid_until>posted_on)),
 status TEXT NOT NULL DEFAULT 'OPEN' CHECK(status IN('OPEN','CLOSED')),version INTEGER NOT NULL DEFAULT 1,
 created_by TEXT NOT NULL REFERENCES users(user_id),created_at TEXT NOT NULL,updated_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE INDEX vacancies_open ON office_vacancies(status,posted_on DESC,vacancy_id);
--> statement-breakpoint
CREATE TABLE vacancy_applications(
 case_id TEXT NOT NULL REFERENCES candidates(id),vacancy_id TEXT NOT NULL REFERENCES office_vacancies(vacancy_id),
 stage TEXT NOT NULL CHECK(stage IN('SHORTLISTED','SUBMITTED','INTERVIEW','OFFER','REJECTED','WITHDRAWN')),
 version INTEGER NOT NULL DEFAULT 1,updated_by TEXT NOT NULL REFERENCES users(user_id),updated_at TEXT NOT NULL,
 PRIMARY KEY(case_id,vacancy_id)
);
