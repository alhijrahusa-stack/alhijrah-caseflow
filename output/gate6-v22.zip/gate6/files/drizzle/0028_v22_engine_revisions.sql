-- v2.2 Gate 3 — forward migration. Staff-verified engine inputs advance candidates.data_revision so the assessment
-- commit (lib/assessment-store.ts) can compare-and-swap on it: a CRS calculator save, an eligibility run, a change of
-- the client request details and a new fact version. No table is created or rewritten; no existing row changes.
CREATE TRIGGER v22_crs_input_insert AFTER INSERT ON case_crs BEGIN UPDATE candidates SET data_revision=data_revision+1 WHERE id=NEW.candidate_id; END;
--> statement-breakpoint
CREATE TRIGGER v22_crs_input_update AFTER UPDATE OF inputs ON case_crs WHEN NEW.inputs<>OLD.inputs BEGIN UPDATE candidates SET data_revision=data_revision+1 WHERE id=NEW.candidate_id; END;
--> statement-breakpoint
CREATE TRIGGER v22_eligibility_insert AFTER INSERT ON eligibility_runs BEGIN UPDATE candidates SET data_revision=data_revision+1 WHERE id=NEW.candidate_id; END;
--> statement-breakpoint
CREATE TRIGGER v22_client_details_update AFTER UPDATE OF details ON client_cases WHEN NEW.details<>OLD.details BEGIN UPDATE candidates SET data_revision=data_revision+1 WHERE id=NEW.candidate_id; END;
--> statement-breakpoint
CREATE TRIGGER v22_case_fact_insert AFTER INSERT ON case_facts BEGIN UPDATE candidates SET data_revision=data_revision+1 WHERE id=NEW.candidate_id; END;
--> statement-breakpoint
CREATE TRIGGER v22_fact_revision_insert AFTER INSERT ON case_fact_revisions BEGIN UPDATE candidates SET data_revision=data_revision+1 WHERE id=NEW.case_id; END;
