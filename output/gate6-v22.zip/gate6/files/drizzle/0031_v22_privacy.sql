-- v2.2 Gate 6 — privacy lifecycle ledger (additive). One append-only row per access / correction / erasure / legal hold
-- request; only REQUESTED → COMPLETED|REFUSED is allowed. The ledger carries pseudonymous IDs and non-identifying
-- result counts only, so it can be exported and re-applied after a backup restore (re-erasure).
CREATE TABLE privacy_requests(
 request_id TEXT PRIMARY KEY NOT NULL,
 case_id TEXT NOT NULL REFERENCES candidates(id),
 kind TEXT NOT NULL CHECK(kind IN('ACCESS','CORRECTION','ERASURE','HOLD','RELEASE_HOLD')),
 state TEXT NOT NULL DEFAULT 'REQUESTED' CHECK(state IN('REQUESTED','COMPLETED','REFUSED')),
 reason_code TEXT CHECK(reason_code IS NULL OR length(reason_code)<=200),
 request_key TEXT NOT NULL UNIQUE,
 requested_by TEXT NOT NULL REFERENCES users(user_id),
 completed_by TEXT REFERENCES users(user_id),
 result_json TEXT CHECK(result_json IS NULL OR json_valid(result_json)),
 created_at TEXT NOT NULL,
 completed_at TEXT
);
--> statement-breakpoint
CREATE INDEX privacy_requests_case ON privacy_requests(case_id,created_at,request_id);
--> statement-breakpoint
CREATE TRIGGER privacy_requests_no_delete BEFORE DELETE ON privacy_requests BEGIN SELECT RAISE(ABORT,'IMMUTABLE_PRIVACY_LEDGER'); END;
--> statement-breakpoint
CREATE TRIGGER privacy_requests_update_guard BEFORE UPDATE ON privacy_requests
 WHEN NOT (OLD.state='REQUESTED' AND NEW.state IN('COMPLETED','REFUSED') AND NEW.request_id=OLD.request_id AND NEW.case_id=OLD.case_id AND NEW.kind=OLD.kind AND NEW.request_key=OLD.request_key AND NEW.requested_by=OLD.requested_by AND NEW.created_at=OLD.created_at)
 BEGIN SELECT RAISE(ABORT,'IMMUTABLE_PRIVACY_LEDGER'); END;
