-- v2.2 Gate 3 — facts cutover (docs/v22/FACTS_COEXISTENCE.md, Phase B). One release, one direction:
-- 1. Copy legacy REPORTED/VERIFIED case_facts rows into case_fact_revisions under the reserved subject 'UNKNOWN'
--    (rule A: no legacy row is attributed to any person by assumption). fact_id = legacy id, so the copy is
--    re-runnable without duplicates. The legacy recorder, source, status and version are kept in review_note.
--    source_hash: the legacy table recorded no source hash; the all-zero value is the documented sentinel
--    "LEGACY_NO_SOURCE_HASH", never presented as a content hash.
-- 2. No head is created (every copied row is UNKNOWN). Heads appear only through new attributed revisions.
-- 3. Rule B: CONFLICTED rows are not copied; a key whose latest legacy version is CONFLICTED gets one open staff task
--    (deterministic id legacy-conflict:<case>:<key>). CONFIRMED_ABSENT has no lossless canonical state either and no
--    application writer ever produced it; it is handled like CONFLICTED (not copied, review task). UNKNOWN rows are
--    not copied: absence means UNKNOWN.
-- 4. Counts only (no values) go to operation_logs. case_facts is frozen (kept, no DROP) as a read-only archive.
-- 5. 'UNKNOWN' is reserved: no new revision or head may use it.
INSERT INTO case_fact_revisions(fact_id,case_id,fact_key,subject_id,value_json,state,evidence_ids,source_hash,created_by,review_note,created_at)
SELECT f.id,f.candidate_id,f.fact_key,'UNKNOWN',f.value_json,f.status,
 CASE WHEN f.evidence_document_id IS NULL THEN '[]' ELSE json_array(f.evidence_document_id) END,
 '0000000000000000000000000000000000000000000000000000000000000000','system:v2.2',
 json_object('v',f.version,'legacy',json_object('id',f.id,'version',f.version,'status',f.status,'source',f.source,'recordedBy',f.recorded_by)),
 f.recorded_at
FROM case_facts f
WHERE f.status IN('REPORTED','VERIFIED') AND NOT EXISTS(SELECT 1 FROM case_fact_revisions r WHERE r.fact_id=f.id);
--> statement-breakpoint
INSERT INTO tasks(id,owner_id,candidate_id,title,due_date,priority,status,system_key,version,created_at,updated_at)
SELECT 'legacy-conflict:'||f.candidate_id||':'||f.fact_key,c.owner_id,f.candidate_id,
 'مراجعة معلومة من السجل القديم دون حالة قانونية مكافئة: '||f.fact_key,'','high','open',
 'legacy-conflict:'||f.candidate_id||':'||f.fact_key,1,strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now')
FROM case_facts f JOIN candidates c ON c.id=f.candidate_id
WHERE f.status IN('CONFLICTED','CONFIRMED_ABSENT')
 AND f.version=(SELECT max(g.version) FROM case_facts g WHERE g.candidate_id=f.candidate_id AND g.fact_key=f.fact_key)
 AND NOT EXISTS(SELECT 1 FROM tasks t WHERE t.id='legacy-conflict:'||f.candidate_id||':'||f.fact_key);
--> statement-breakpoint
INSERT INTO operation_logs(id,candidate_id,operation,actor,result,code,created_at)
SELECT 'v22-facts-cutover',NULL,'facts_cutover','system:v2.2','completed',
 json_object('legacyRows',(SELECT count(*) FROM case_facts),
  'copied',(SELECT count(*) FROM case_fact_revisions WHERE subject_id='UNKNOWN'),
  'notCopiedUnknown',(SELECT count(*) FROM case_facts WHERE status='UNKNOWN'),
  'notCopiedConflicted',(SELECT count(*) FROM case_facts WHERE status='CONFLICTED'),
  'notCopiedConfirmedAbsent',(SELECT count(*) FROM case_facts WHERE status='CONFIRMED_ABSENT'),
  'reviewTasks',(SELECT count(*) FROM tasks WHERE id LIKE 'legacy-conflict:%'),
  'heads',(SELECT count(*) FROM case_fact_heads)),
 strftime('%Y-%m-%dT%H:%M:%fZ','now')
WHERE NOT EXISTS(SELECT 1 FROM operation_logs WHERE id='v22-facts-cutover');
--> statement-breakpoint
CREATE TRIGGER legacy_facts_frozen_insert BEFORE INSERT ON case_facts BEGIN SELECT RAISE(ABORT,'LEGACY_FACTS_FROZEN'); END;
--> statement-breakpoint
CREATE TRIGGER legacy_facts_frozen_update BEFORE UPDATE ON case_facts BEGIN SELECT RAISE(ABORT,'LEGACY_FACTS_FROZEN'); END;
--> statement-breakpoint
CREATE TRIGGER legacy_facts_frozen_delete BEFORE DELETE ON case_facts BEGIN SELECT RAISE(ABORT,'LEGACY_FACTS_FROZEN'); END;
--> statement-breakpoint
CREATE TRIGGER fact_unknown_subject_reserved BEFORE INSERT ON case_fact_revisions WHEN NEW.subject_id='UNKNOWN' BEGIN SELECT RAISE(ABORT,'UNKNOWN_SUBJECT_RESERVED'); END;
--> statement-breakpoint
CREATE TRIGGER fact_head_unknown_subject BEFORE INSERT ON case_fact_heads WHEN NEW.subject_id='UNKNOWN' BEGIN SELECT RAISE(ABORT,'UNKNOWN_SUBJECT_HAS_NO_HEAD'); END;
