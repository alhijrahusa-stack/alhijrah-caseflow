-- v2.2 Gate 1 (package file 0016_client_portal_upgrade.sql). Numbered 0024 because 0016-0023 are already
-- applied in production. Additive only: new tables, nullable/defaulted columns, guards. No existing row is changed
-- except auth_challenges.purpose derived from the existing channel value.
ALTER TABLE auth_challenges ADD COLUMN purpose TEXT NOT NULL DEFAULT 'case_login'
 CHECK(purpose IN('case_login','account_login','account_password','status_lookup'));
--> statement-breakpoint
UPDATE auth_challenges SET purpose='account_login' WHERE channel='account_email';
--> statement-breakpoint
ALTER TABLE auth_challenges ADD COLUMN delivery_payload_encrypted TEXT;
--> statement-breakpoint
ALTER TABLE auth_challenges ADD COLUMN delivery_lease_until INTEGER NOT NULL DEFAULT 0;
--> statement-breakpoint
ALTER TABLE auth_challenges ADD COLUMN delivery_attempt_count INTEGER NOT NULL DEFAULT 0 CHECK(delivery_attempt_count>=0);
--> statement-breakpoint
CREATE INDEX otp_delivery_due ON auth_challenges(purpose,state,delivery_lease_until,created_at);
--> statement-breakpoint
ALTER TABLE client_sessions ADD COLUMN scope TEXT NOT NULL DEFAULT 'full_case'
 CHECK(scope IN('full_case','case_status'));
--> statement-breakpoint
CREATE TABLE client_account_profiles(
 account_key TEXT PRIMARY KEY CHECK(length(account_key)=64),
 display_name TEXT NOT NULL CHECK(length(display_name) BETWEEN 2 AND 150),
 created_at TEXT NOT NULL,updated_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE TABLE client_application_drafts(
 draft_id TEXT PRIMARY KEY,account_key TEXT NOT NULL REFERENCES client_account_profiles(account_key),
 revision INTEGER NOT NULL CHECK(revision>=1),
 state TEXT NOT NULL DEFAULT 'DRAFT' CHECK(state IN('DRAFT','SUBMITTED')),
 payload_json TEXT NOT NULL CHECK(json_valid(payload_json)),payload_hash TEXT NOT NULL CHECK(length(payload_hash)=64),
 signature_id TEXT UNIQUE,signature_object_key TEXT,signature_sha256 TEXT,
 signed_payload_hash TEXT,signature_legal_version TEXT,signature_signed_at TEXT,
 submitted_candidate_id TEXT REFERENCES candidates(id),
 created_at TEXT NOT NULL,updated_at TEXT NOT NULL,
 CHECK((signature_id IS NULL AND signature_object_key IS NULL AND signature_sha256 IS NULL AND signed_payload_hash IS NULL AND signature_legal_version IS NULL AND signature_signed_at IS NULL) OR (signature_id IS NOT NULL AND signature_object_key IS NOT NULL AND signature_sha256 IS NOT NULL AND length(signature_sha256)=64 AND signed_payload_hash IS NOT NULL AND length(signed_payload_hash)=64 AND signature_legal_version IS NOT NULL AND signature_signed_at IS NOT NULL)),
 CHECK((state='DRAFT' AND submitted_candidate_id IS NULL) OR (state='SUBMITTED' AND submitted_candidate_id IS NOT NULL)),
 UNIQUE(account_key,draft_id)
);
--> statement-breakpoint
CREATE INDEX account_drafts_updated ON client_application_drafts(account_key,state,updated_at,draft_id);
--> statement-breakpoint
CREATE TABLE client_draft_mutations(
 account_key TEXT NOT NULL,draft_id TEXT NOT NULL,mutation_id TEXT NOT NULL,
 expected_revision INTEGER NOT NULL CHECK(expected_revision>=1),
 request_hash TEXT NOT NULL CHECK(length(request_hash)=64),
 created_at TEXT NOT NULL,
 PRIMARY KEY(account_key,draft_id,mutation_id),
 FOREIGN KEY(account_key,draft_id) REFERENCES client_application_drafts(account_key,draft_id)
);
--> statement-breakpoint
CREATE TRIGGER draft_mutation_guard BEFORE INSERT ON client_draft_mutations BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM client_application_drafts d WHERE d.account_key=NEW.account_key AND d.draft_id=NEW.draft_id AND d.revision=NEW.expected_revision AND d.state='DRAFT') THEN RAISE(ABORT,'DRAFT_REVISION_CONFLICT') END;
END;
--> statement-breakpoint
CREATE TRIGGER draft_revision_guard BEFORE UPDATE ON client_application_drafts BEGIN
 SELECT CASE WHEN NEW.account_key<>OLD.account_key OR NEW.draft_id<>OLD.draft_id OR OLD.state='SUBMITTED' OR NEW.revision<>OLD.revision+1 THEN RAISE(ABORT,'INVALID_DRAFT_UPDATE') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM client_draft_mutations m WHERE m.account_key=OLD.account_key AND m.draft_id=OLD.draft_id AND m.expected_revision=OLD.revision) THEN RAISE(ABORT,'DRAFT_MUTATION_REQUIRED') END;
END;
--> statement-breakpoint
CREATE TRIGGER draft_mutation_no_update BEFORE UPDATE ON client_draft_mutations BEGIN SELECT RAISE(ABORT,'IMMUTABLE_DRAFT_MUTATION'); END;
--> statement-breakpoint
CREATE TRIGGER draft_mutation_no_delete BEFORE DELETE ON client_draft_mutations BEGIN SELECT RAISE(ABORT,'IMMUTABLE_DRAFT_MUTATION'); END;
--> statement-breakpoint
CREATE TABLE client_contact_lookup(
 candidate_id TEXT NOT NULL REFERENCES candidates(id),
 contact_kind TEXT NOT NULL CHECK(contact_kind IN('EMAIL','PHONE')),
 contact_hash TEXT NOT NULL CHECK(length(contact_hash)=64),
 key_version TEXT NOT NULL,updated_at TEXT NOT NULL,
 PRIMARY KEY(candidate_id,contact_kind)
);
--> statement-breakpoint
CREATE INDEX client_contact_lookup_hash ON client_contact_lookup(contact_kind,key_version,contact_hash,candidate_id);
--> statement-breakpoint
ALTER TABLE application_authorizations ADD COLUMN signature_id TEXT;
--> statement-breakpoint
ALTER TABLE application_authorizations ADD COLUMN signature_object_key TEXT;
--> statement-breakpoint
ALTER TABLE application_authorizations ADD COLUMN signature_sha256 TEXT;
--> statement-breakpoint
ALTER TABLE application_authorizations ADD COLUMN signed_payload_hash TEXT;
--> statement-breakpoint
ALTER TABLE application_authorizations ADD COLUMN signature_signed_at TEXT;
--> statement-breakpoint
ALTER TABLE application_authorizations ADD COLUMN signer_account_key TEXT REFERENCES client_account_profiles(account_key);
--> statement-breakpoint
CREATE UNIQUE INDEX authorization_signature_id ON application_authorizations(signature_id) WHERE signature_id IS NOT NULL;
--> statement-breakpoint
CREATE TRIGGER authorization_signature_complete BEFORE INSERT ON application_authorizations BEGIN
 SELECT CASE WHEN (NEW.signature_id IS NOT NULL OR NEW.signature_object_key IS NOT NULL OR NEW.signature_sha256 IS NOT NULL OR NEW.signed_payload_hash IS NOT NULL OR NEW.signature_signed_at IS NOT NULL OR NEW.signer_account_key IS NOT NULL) AND NOT (NEW.signature_id IS NOT NULL AND NEW.signature_object_key IS NOT NULL AND NEW.signature_sha256 IS NOT NULL AND length(NEW.signature_sha256)=64 AND NEW.signed_payload_hash IS NOT NULL AND length(NEW.signed_payload_hash)=64 AND NEW.signature_signed_at IS NOT NULL AND NEW.signer_account_key IS NOT NULL) THEN RAISE(ABORT,'INCOMPLETE_SIGNATURE_BINDING') END;
END;
--> statement-breakpoint
CREATE TRIGGER authorization_signature_immutable BEFORE UPDATE OF signature_id,signature_object_key,signature_sha256,signed_payload_hash,signature_signed_at,signer_account_key ON application_authorizations BEGIN
 SELECT RAISE(ABORT,'IMMUTABLE_SIGNATURE_BINDING');
END;
