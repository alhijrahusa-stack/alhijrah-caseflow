-- v2.2 Gate 1 (package file 0017_v2_2_controls_billing.sql; canonical SQL in 09_CLAUDE_CODE_EXECUTION.md section 9).
-- Numbered 0025. assessment_history already exists since 0022 with live rows, so it is extended in place
-- (canonical case_id = candidate_id, history_id = id, payload = output_json, created_at = computed_at) instead of
-- being created again. New canonical columns are nullable: legacy rows keep NULL (unknown), never invented values.
CREATE TABLE users (
 user_id TEXT PRIMARY KEY NOT NULL,
 role TEXT NOT NULL CHECK(role IN('CLIENT','STAFF','MANAGER','SYSTEM')),
 custom_permissions TEXT NOT NULL DEFAULT '{}' CHECK(json_valid(custom_permissions) AND json_type(custom_permissions)='object'),
 permission_version INTEGER NOT NULL DEFAULT 1 CHECK(permission_version>=1),
 active INTEGER NOT NULL DEFAULT 1 CHECK(active IN(0,1)),
 created_at TEXT NOT NULL,
 CHECK(role='STAFF' OR custom_permissions='{}')
);
--> statement-breakpoint
CREATE INDEX users_role_active ON users(role,active,user_id);
--> statement-breakpoint
CREATE TRIGGER users_role_immutable BEFORE UPDATE OF role ON users BEGIN SELECT RAISE(ABORT,'ROLE_CHANGE_NOT_ALLOWED'); END;
--> statement-breakpoint
CREATE TRIGGER users_root_permissions BEFORE UPDATE OF custom_permissions ON users WHEN OLD.role IN('MANAGER','SYSTEM') BEGIN SELECT RAISE(ABORT,'ROOT_PERMISSIONS_IMMUTABLE'); END;
--> statement-breakpoint
CREATE TABLE role_permissions (
 role TEXT PRIMARY KEY NOT NULL CHECK(role='STAFF'),
 permissions_json TEXT NOT NULL DEFAULT '{}' CHECK(json_valid(permissions_json) AND json_type(permissions_json)='object'),
 version INTEGER NOT NULL DEFAULT 1 CHECK(version>=1),
 updated_at TEXT NOT NULL
);
--> statement-breakpoint
-- Office policy (owner decision, overrides the package default '{}'): every STAFF capability is allowed by default;
-- the MANAGER closes what he wants with the Toggles. MANAGER-reserved capabilities are never part of this policy.
INSERT INTO role_permissions(role,permissions_json,updated_at) VALUES('STAFF','{"chat":true,"create_invoice":true,"edit_case":true,"edit_discount":true,"edit_invoice":true,"export_invoice_pdf":true,"record_payment":true,"request_assessment":true,"review_case":true,"send_payment_notice":true,"upload_documents":true,"view_crm":true,"view_documents":true,"view_financials":true}',strftime('%Y-%m-%dT%H:%M:%fZ','now'));
--> statement-breakpoint
CREATE TABLE permission_runtime (
 singleton INTEGER PRIMARY KEY CHECK(singleton=1),
 version INTEGER NOT NULL DEFAULT 1 CHECK(version>=1),
 open_all_enabled INTEGER NOT NULL DEFAULT 0 CHECK(open_all_enabled IN(0,1)),
 open_all_local_date TEXT,
 open_until_ms INTEGER NOT NULL DEFAULT 0 CHECK(typeof(open_until_ms)='integer' AND open_until_ms>=0),
 CHECK(open_all_enabled=0 OR (open_all_local_date IS NOT NULL AND length(open_all_local_date)=10 AND open_until_ms>0))
);
--> statement-breakpoint
INSERT INTO permission_runtime(singleton) VALUES(1);
--> statement-breakpoint
CREATE TABLE permission_changes_audit (
 audit_id TEXT PRIMARY KEY NOT NULL,
 change_kind TEXT NOT NULL CHECK(change_kind IN('ROLE','USER','OPEN_ALL','AUTO_KILL')),
 target_user_id TEXT REFERENCES users(user_id),
 target_role TEXT CHECK(target_role IS NULL OR target_role='STAFF'),
 old_permissions TEXT NOT NULL CHECK(json_valid(old_permissions) AND json_type(old_permissions)='object'),
 new_permissions TEXT NOT NULL CHECK(json_valid(new_permissions) AND json_type(new_permissions)='object'),
 expected_version INTEGER NOT NULL CHECK(expected_version>=1),
 expected_epoch INTEGER NOT NULL CHECK(expected_epoch>=1),
 changed_by TEXT NOT NULL REFERENCES users(user_id),
 changed_at TEXT NOT NULL,
 CHECK((change_kind='USER' AND target_user_id IS NOT NULL AND target_role IS NULL) OR (change_kind<>'USER' AND target_user_id IS NULL AND target_role='STAFF'))
);
--> statement-breakpoint
CREATE INDEX permission_audit_target ON permission_changes_audit(target_user_id,changed_at,audit_id);
--> statement-breakpoint
CREATE INDEX permission_audit_epoch ON permission_changes_audit(expected_epoch,audit_id);
--> statement-breakpoint
CREATE TRIGGER permission_change_guard BEFORE INSERT ON permission_changes_audit BEGIN
 SELECT CASE WHEN NEW.expected_epoch<>(SELECT version FROM permission_runtime WHERE singleton=1) THEN RAISE(ABORT,'PERMISSION_EPOCH_CONFLICT') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM users u WHERE u.user_id=NEW.changed_by AND u.active=1 AND (u.role='MANAGER' OR (u.role='SYSTEM' AND NEW.change_kind='AUTO_KILL'))) THEN RAISE(ABORT,'MANAGER_REQUIRED') END;
 SELECT CASE WHEN NEW.change_kind='USER' AND NOT EXISTS(SELECT 1 FROM users u WHERE u.user_id=NEW.target_user_id AND u.role='STAFF' AND u.permission_version=NEW.expected_version AND u.custom_permissions=NEW.old_permissions) THEN RAISE(ABORT,'INVALID_PERMISSION_TARGET') END;
 SELECT CASE WHEN NEW.change_kind='ROLE' AND NOT EXISTS(SELECT 1 FROM role_permissions r WHERE r.role='STAFF' AND r.version=NEW.expected_version AND r.permissions_json=NEW.old_permissions) THEN RAISE(ABORT,'ROLE_PERMISSION_CONFLICT') END;
 SELECT CASE WHEN NEW.change_kind IN('OPEN_ALL','AUTO_KILL') AND NEW.expected_version<>NEW.expected_epoch THEN RAISE(ABORT,'OPEN_ACCESS_VERSION_CONFLICT') END;
 SELECT CASE WHEN NEW.change_kind IN('ROLE','USER') AND EXISTS(SELECT 1 FROM json_each(NEW.new_permissions) WHERE type NOT IN('true','false') OR key IN('manage_permissions','open_staff_access','seal_rules','approve_invoice')) THEN RAISE(ABORT,'INVALID_PERMISSION_KEY_OR_TYPE') END;
 SELECT CASE WHEN NEW.change_kind IN('OPEN_ALL','AUTO_KILL') AND (COALESCE(json_type(NEW.new_permissions,'$.enabled'),'missing') NOT IN('true','false') OR COALESCE(json_type(NEW.new_permissions,'$.untilMs'),'missing')<>'integer') THEN RAISE(ABORT,'INVALID_OPEN_ACCESS_PAYLOAD') END;
 SELECT CASE WHEN NEW.change_kind IN('OPEN_ALL','AUTO_KILL') AND (json_extract(NEW.old_permissions,'$.enabled') IS NOT (SELECT open_all_enabled FROM permission_runtime WHERE singleton=1) OR json_extract(NEW.old_permissions,'$.localDate') IS NOT (SELECT open_all_local_date FROM permission_runtime WHERE singleton=1) OR json_extract(NEW.old_permissions,'$.untilMs') IS NOT (SELECT open_until_ms FROM permission_runtime WHERE singleton=1)) THEN RAISE(ABORT,'OPEN_ACCESS_SNAPSHOT_CONFLICT') END;
 SELECT CASE WHEN NEW.change_kind='AUTO_KILL' AND (json_extract(NEW.new_permissions,'$.enabled')<>0 OR json_extract(NEW.new_permissions,'$.untilMs')<>0) THEN RAISE(ABORT,'SYSTEM_CANNOT_ENABLE_ACCESS') END;
END;
--> statement-breakpoint
CREATE TRIGGER permission_change_apply AFTER INSERT ON permission_changes_audit BEGIN
 UPDATE users SET custom_permissions=NEW.new_permissions,permission_version=permission_version+1 WHERE NEW.change_kind='USER' AND user_id=NEW.target_user_id;
 UPDATE role_permissions SET permissions_json=NEW.new_permissions,version=version+1,updated_at=NEW.changed_at WHERE NEW.change_kind='ROLE' AND role='STAFF';
 UPDATE permission_runtime SET version=version+1,
  open_all_enabled=CASE WHEN NEW.change_kind IN('OPEN_ALL','AUTO_KILL') THEN json_extract(NEW.new_permissions,'$.enabled') ELSE open_all_enabled END,
  open_all_local_date=CASE WHEN NEW.change_kind IN('OPEN_ALL','AUTO_KILL') THEN json_extract(NEW.new_permissions,'$.localDate') ELSE open_all_local_date END,
  open_until_ms=CASE WHEN NEW.change_kind IN('OPEN_ALL','AUTO_KILL') THEN json_extract(NEW.new_permissions,'$.untilMs') ELSE open_until_ms END
 WHERE singleton=1;
END;
--> statement-breakpoint
CREATE TRIGGER permission_audit_no_update BEFORE UPDATE ON permission_changes_audit BEGIN SELECT RAISE(ABORT,'IMMUTABLE_PERMISSION_AUDIT'); END;
--> statement-breakpoint
CREATE TRIGGER permission_audit_no_delete BEFORE DELETE ON permission_changes_audit BEGIN SELECT RAISE(ABORT,'IMMUTABLE_PERMISSION_AUDIT'); END;
--> statement-breakpoint
CREATE TRIGGER user_permissions_audited BEFORE UPDATE OF custom_permissions,permission_version ON users WHEN OLD.role='STAFF' BEGIN
 SELECT CASE WHEN NEW.permission_version<>OLD.permission_version+1 OR NOT EXISTS(SELECT 1 FROM permission_changes_audit a WHERE a.change_kind='USER' AND a.target_user_id=OLD.user_id AND a.expected_version=OLD.permission_version AND a.old_permissions=OLD.custom_permissions AND a.new_permissions=NEW.custom_permissions AND a.expected_epoch=(SELECT version FROM permission_runtime WHERE singleton=1)) THEN RAISE(ABORT,'PERMISSION_AUDIT_REQUIRED') END;
END;
--> statement-breakpoint
CREATE TRIGGER role_permissions_audited BEFORE UPDATE ON role_permissions BEGIN
 SELECT CASE WHEN NEW.role<>OLD.role OR NEW.version<>OLD.version+1 OR NOT EXISTS(SELECT 1 FROM permission_changes_audit a WHERE a.change_kind='ROLE' AND a.target_role='STAFF' AND a.expected_version=OLD.version AND a.old_permissions=OLD.permissions_json AND a.new_permissions=NEW.permissions_json AND a.expected_epoch=(SELECT version FROM permission_runtime WHERE singleton=1)) THEN RAISE(ABORT,'PERMISSION_AUDIT_REQUIRED') END;
END;
--> statement-breakpoint
CREATE TRIGGER permission_runtime_audited BEFORE UPDATE ON permission_runtime BEGIN
 SELECT CASE WHEN NEW.version<>OLD.version+1 OR NOT EXISTS(SELECT 1 FROM permission_changes_audit a WHERE a.expected_epoch=OLD.version) THEN RAISE(ABORT,'PERMISSION_AUDIT_REQUIRED') END;
END;
--> statement-breakpoint
CREATE TRIGGER role_permissions_no_delete BEFORE DELETE ON role_permissions BEGIN SELECT RAISE(ABORT,'PERMISSION_AUDIT_REQUIRED'); END;
--> statement-breakpoint
CREATE TRIGGER permission_runtime_no_delete BEFORE DELETE ON permission_runtime BEGIN SELECT RAISE(ABORT,'PERMISSION_AUDIT_REQUIRED'); END;
--> statement-breakpoint
CREATE TRIGGER root_user_no_delete BEFORE DELETE ON users WHEN OLD.role IN('MANAGER','SYSTEM') BEGIN SELECT RAISE(ABORT,'ROOT_PERMISSIONS_IMMUTABLE'); END;
--> statement-breakpoint
ALTER TABLE assessment_history ADD COLUMN case_revision INTEGER CHECK(case_revision IS NULL OR (typeof(case_revision)='integer' AND case_revision>=0));
--> statement-breakpoint
ALTER TABLE assessment_history ADD COLUMN canonical_input_hash TEXT CHECK(canonical_input_hash IS NULL OR length(canonical_input_hash)=64);
--> statement-breakpoint
ALTER TABLE assessment_history ADD COLUMN rule_bundle_hash TEXT CHECK(rule_bundle_hash IS NULL OR length(rule_bundle_hash)=64);
--> statement-breakpoint
ALTER TABLE assessment_history ADD COLUMN assessment_mode TEXT CHECK(assessment_mode IS NULL OR assessment_mode IN('PRODUCTION','SHADOW'));
--> statement-breakpoint
ALTER TABLE assessment_history ADD COLUMN assessment_purpose TEXT CHECK(assessment_purpose IS NULL OR assessment_purpose IN('RAPID_SCREENING','VERIFIED_SCREENING'));
--> statement-breakpoint
ALTER TABLE assessment_history ADD COLUMN created_by TEXT REFERENCES users(user_id);
--> statement-breakpoint
CREATE UNIQUE INDEX assessment_canonical_unique ON assessment_history(candidate_id,canonical_input_hash,rule_bundle_hash,engine_version,assessment_mode,assessment_purpose) WHERE canonical_input_hash IS NOT NULL;
--> statement-breakpoint
CREATE TRIGGER assessment_history_insert_guard BEFORE INSERT ON assessment_history BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM candidates WHERE id=NEW.candidate_id) THEN RAISE(ABORT,'ASSESSMENT_CASE_REQUIRED') END;
 SELECT CASE WHEN NOT json_valid(NEW.output_json) OR NOT json_valid(NEW.explanation_trace_json) THEN RAISE(ABORT,'ASSESSMENT_JSON_INVALID') END;
 SELECT CASE WHEN NOT ((NEW.case_revision IS NULL AND NEW.canonical_input_hash IS NULL AND NEW.rule_bundle_hash IS NULL AND NEW.assessment_mode IS NULL AND NEW.assessment_purpose IS NULL AND NEW.created_by IS NULL) OR (NEW.case_revision IS NOT NULL AND NEW.canonical_input_hash IS NOT NULL AND NEW.rule_bundle_hash IS NOT NULL AND NEW.assessment_mode IS NOT NULL AND NEW.assessment_purpose IS NOT NULL AND NEW.created_by IS NOT NULL)) THEN RAISE(ABORT,'ASSESSMENT_CANONICAL_FIELDS_INCOMPLETE') END;
END;
--> statement-breakpoint
CREATE TRIGGER assessment_history_no_update BEFORE UPDATE ON assessment_history BEGIN SELECT RAISE(ABORT,'IMMUTABLE_ASSESSMENT'); END;
--> statement-breakpoint
CREATE TRIGGER assessment_history_no_delete BEFORE DELETE ON assessment_history BEGIN SELECT RAISE(ABORT,'IMMUTABLE_ASSESSMENT'); END;
--> statement-breakpoint
CREATE TABLE source_snapshots (
 source_id TEXT PRIMARY KEY NOT NULL,
 official_url TEXT NOT NULL,
 object_key TEXT NOT NULL UNIQUE,
 content_sha256 TEXT NOT NULL CHECK(length(content_sha256)=64),
 fetched_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE TABLE rule_bundles (
 bundle_id TEXT PRIMARY KEY NOT NULL,
 payload TEXT NOT NULL CHECK(json_valid(payload)),
 payload_sha256 TEXT NOT NULL UNIQUE CHECK(length(payload_sha256)=64),
 source_id TEXT NOT NULL REFERENCES source_snapshots(source_id),
 created_by TEXT NOT NULL REFERENCES users(user_id),
 created_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE TABLE release_sets (
 release_id TEXT PRIMARY KEY NOT NULL,
 manifest_sha256 TEXT NOT NULL UNIQUE CHECK(length(manifest_sha256)=64),
 state TEXT NOT NULL DEFAULT 'BUILDING' CHECK(state IN('BUILDING','SEALED')),
 validation_report_hash TEXT,
 created_by TEXT NOT NULL REFERENCES users(user_id),
 sealed_by TEXT REFERENCES users(user_id),
 sealed_at TEXT,
 CHECK((state='BUILDING' AND sealed_by IS NULL AND sealed_at IS NULL) OR (state='SEALED' AND sealed_by IS NOT NULL AND sealed_at IS NOT NULL AND validation_report_hash IS NOT NULL AND length(validation_report_hash)=64))
);
--> statement-breakpoint
CREATE TABLE release_intervals (
 release_id TEXT NOT NULL REFERENCES release_sets(release_id),
 program_id TEXT NOT NULL,
 family TEXT NOT NULL,
 phase TEXT NOT NULL,
 date_basis TEXT NOT NULL CHECK(date_basis IN('PROFILE','INVITATION','APPLICATION','RECOMMENDATION','APPROVAL_TORONTO')),
 effective_from TEXT NOT NULL,
 effective_to_exclusive TEXT,
 bundle_id TEXT NOT NULL REFERENCES rule_bundles(bundle_id),
 CHECK(length(effective_from)=10),
 CHECK(effective_to_exclusive IS NULL OR effective_to_exclusive>effective_from),
 CHECK(program_id NOT IN('RCIP_PILOT','RCIP_PERMANENT') OR date_basis='APPROVAL_TORONTO'),
 PRIMARY KEY(release_id,program_id,family,phase,date_basis,effective_from)
);
--> statement-breakpoint
CREATE INDEX release_effective_lookup ON release_intervals(release_id,program_id,family,phase,date_basis,effective_from,effective_to_exclusive);
--> statement-breakpoint
CREATE TRIGGER release_insert_guard BEFORE INSERT ON release_sets WHEN NEW.state<>'BUILDING' BEGIN SELECT RAISE(ABORT,'SEALED_MUST_BE_EARNED'); END;
--> statement-breakpoint
CREATE TRIGGER release_interval_insert_guard BEFORE INSERT ON release_intervals BEGIN
 SELECT CASE WHEN (SELECT state FROM release_sets WHERE release_id=NEW.release_id)<>'BUILDING' THEN RAISE(ABORT,'SEALED_RELEASE') END;
 SELECT CASE WHEN EXISTS(SELECT 1 FROM release_intervals r WHERE r.release_id=NEW.release_id AND r.program_id=NEW.program_id AND r.family=NEW.family AND r.phase=NEW.phase AND r.date_basis=NEW.date_basis AND (r.effective_to_exclusive IS NULL OR NEW.effective_from<r.effective_to_exclusive) AND (NEW.effective_to_exclusive IS NULL OR r.effective_from<NEW.effective_to_exclusive)) THEN RAISE(ABORT,'RULE_INTERVAL_OVERLAP') END;
END;
--> statement-breakpoint
CREATE TRIGGER release_seal_guard BEFORE UPDATE ON release_sets BEGIN
 SELECT CASE WHEN OLD.state<>'BUILDING' OR NEW.state<>'SEALED' OR NEW.release_id<>OLD.release_id OR NEW.manifest_sha256<>OLD.manifest_sha256 OR NEW.created_by<>OLD.created_by THEN RAISE(ABORT,'INVALID_RELEASE_TRANSITION') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM users WHERE user_id=NEW.sealed_by AND role='MANAGER' AND active=1) THEN RAISE(ABORT,'MANAGER_REQUIRED') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM release_intervals WHERE release_id=NEW.release_id) THEN RAISE(ABORT,'EMPTY_RELEASE') END;
END;
--> statement-breakpoint
CREATE TABLE rule_activation (
 singleton INTEGER PRIMARY KEY CHECK(singleton=1),
 release_id TEXT REFERENCES release_sets(release_id),
 generation INTEGER NOT NULL DEFAULT 0 CHECK(generation>=0),
 changed_by TEXT REFERENCES users(user_id),
 changed_at TEXT
);
--> statement-breakpoint
INSERT INTO rule_activation(singleton) VALUES(1);
--> statement-breakpoint
CREATE TRIGGER activation_guard BEFORE UPDATE ON rule_activation BEGIN
 SELECT CASE WHEN NEW.generation<>OLD.generation+1 OR NOT EXISTS(SELECT 1 FROM users WHERE user_id=NEW.changed_by AND role='MANAGER' AND active=1) OR (NEW.release_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM release_sets WHERE release_id=NEW.release_id AND state='SEALED')) THEN RAISE(ABORT,'INVALID_RULE_ACTIVATION') END;
END;
--> statement-breakpoint
CREATE TRIGGER release_intervals_no_update BEFORE UPDATE ON release_intervals BEGIN SELECT RAISE(ABORT,'IMMUTABLE_RELEASE_INTERVAL'); END;
--> statement-breakpoint
CREATE TRIGGER release_intervals_no_delete BEFORE DELETE ON release_intervals BEGIN SELECT RAISE(ABORT,'IMMUTABLE_RELEASE_INTERVAL'); END;
--> statement-breakpoint
CREATE TRIGGER rule_bundles_no_update BEFORE UPDATE ON rule_bundles BEGIN SELECT RAISE(ABORT,'IMMUTABLE_RULE_BUNDLE'); END;
--> statement-breakpoint
CREATE TRIGGER rule_bundles_no_delete BEFORE DELETE ON rule_bundles BEGIN SELECT RAISE(ABORT,'IMMUTABLE_RULE_BUNDLE'); END;
--> statement-breakpoint
CREATE TRIGGER source_snapshots_no_update BEFORE UPDATE ON source_snapshots BEGIN SELECT RAISE(ABORT,'IMMUTABLE_SOURCE'); END;
--> statement-breakpoint
CREATE TRIGGER source_snapshots_no_delete BEFORE DELETE ON source_snapshots BEGIN SELECT RAISE(ABORT,'IMMUTABLE_SOURCE'); END;
--> statement-breakpoint
CREATE TRIGGER release_sets_no_delete BEFORE DELETE ON release_sets BEGIN SELECT RAISE(ABORT,'IMMUTABLE_RELEASE'); END;
--> statement-breakpoint
CREATE TABLE invoices (
 invoice_id TEXT PRIMARY KEY NOT NULL,
 case_id TEXT NOT NULL REFERENCES candidates(id),
 currency TEXT NOT NULL CHECK(length(currency)=3 AND currency NOT GLOB '*[^A-Z]*'),
 status TEXT NOT NULL DEFAULT 'DRAFT' CHECK(status IN('DRAFT','PENDING_APPROVAL','PARTIAL','PAID','OVERDUE')),
 subtotal_cents INTEGER NOT NULL DEFAULT 0 CHECK(typeof(subtotal_cents)='integer' AND subtotal_cents BETWEEN 0 AND 9007199254740991),
 discount_cents INTEGER NOT NULL DEFAULT 0 CHECK(typeof(discount_cents)='integer' AND discount_cents BETWEEN 0 AND subtotal_cents),
 total_cents INTEGER NOT NULL DEFAULT 0 CHECK(typeof(total_cents)='integer' AND total_cents=subtotal_cents-discount_cents),
 paid_cents INTEGER NOT NULL DEFAULT 0 CHECK(typeof(paid_cents)='integer' AND paid_cents BETWEEN 0 AND total_cents),
 remaining_cents INTEGER NOT NULL DEFAULT 0 CHECK(typeof(remaining_cents)='integer' AND remaining_cents=total_cents-paid_cents),
 deadline TEXT,
 note TEXT,
 version INTEGER NOT NULL DEFAULT 0 CHECK(version>=0),
 last_operation_id TEXT REFERENCES financial_audit_logs(log_id),
 approval_requested_at TEXT,
 approved_by TEXT REFERENCES users(user_id),
 approved_at TEXT,
 created_by TEXT NOT NULL REFERENCES users(user_id),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 UNIQUE(invoice_id,case_id,currency)
);
--> statement-breakpoint
CREATE INDEX invoices_case_date ON invoices(case_id,created_at DESC,invoice_id);
--> statement-breakpoint
CREATE INDEX invoices_status_deadline ON invoices(status,deadline,invoice_id);
--> statement-breakpoint
CREATE INDEX invoices_created_by ON invoices(created_by,created_at DESC,invoice_id);
--> statement-breakpoint
CREATE TABLE financial_audit_logs (
 log_id TEXT PRIMARY KEY NOT NULL,
 invoice_id TEXT NOT NULL REFERENCES invoices(invoice_id),
 modified_by TEXT NOT NULL REFERENCES users(user_id),
 action_type TEXT NOT NULL CHECK(action_type IN('CREATE','EDIT','DISCOUNT','PAYMENT','REFER','APPROVE','OVERDUE_REFRESH')),
 old_value TEXT NOT NULL CHECK(json_valid(old_value) AND json_type(old_value)='object'),
 new_value TEXT NOT NULL CHECK(json_valid(new_value) AND json_type(new_value)='object'),
 expected_version INTEGER NOT NULL CHECK(expected_version>=0),
 permissions_epoch INTEGER NOT NULL CHECK(permissions_epoch>=1),
 authz_expires_at_ms INTEGER NOT NULL CHECK(typeof(authz_expires_at_ms)='integer'),
 request_hash TEXT NOT NULL CHECK(length(request_hash)=64),
 idempotency_key TEXT NOT NULL UNIQUE,
 timestamp TEXT NOT NULL
);
--> statement-breakpoint
CREATE INDEX financial_audit_invoice ON financial_audit_logs(invoice_id,timestamp,log_id);
--> statement-breakpoint
CREATE INDEX financial_audit_actor ON financial_audit_logs(modified_by,timestamp,log_id);
--> statement-breakpoint
CREATE TRIGGER financial_operation_guard BEFORE INSERT ON financial_audit_logs BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM invoices WHERE invoice_id=NEW.invoice_id AND version=NEW.expected_version) THEN RAISE(ABORT,'INVOICE_REVISION_CONFLICT') END;
 SELECT CASE WHEN COALESCE(json_type(NEW.old_value,'$.subtotal_cents'),'missing')<>'integer' OR COALESCE(json_type(NEW.new_value,'$.subtotal_cents'),'missing')<>'integer' THEN RAISE(ABORT,'AUDIT_SNAPSHOT_REQUIRED') END;
 SELECT CASE WHEN json_extract(NEW.old_value,'$.subtotal_cents') IS NOT (SELECT subtotal_cents FROM invoices WHERE invoice_id=NEW.invoice_id) THEN RAISE(ABORT,'AUDIT_OLD_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN COALESCE(json_type(NEW.old_value,'$.discount_cents'),'missing')<>'integer' OR COALESCE(json_type(NEW.new_value,'$.discount_cents'),'missing')<>'integer' THEN RAISE(ABORT,'AUDIT_SNAPSHOT_REQUIRED') END;
 SELECT CASE WHEN json_extract(NEW.old_value,'$.discount_cents') IS NOT (SELECT discount_cents FROM invoices WHERE invoice_id=NEW.invoice_id) THEN RAISE(ABORT,'AUDIT_OLD_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN COALESCE(json_type(NEW.old_value,'$.total_cents'),'missing')<>'integer' OR COALESCE(json_type(NEW.new_value,'$.total_cents'),'missing')<>'integer' THEN RAISE(ABORT,'AUDIT_SNAPSHOT_REQUIRED') END;
 SELECT CASE WHEN json_extract(NEW.old_value,'$.total_cents') IS NOT (SELECT total_cents FROM invoices WHERE invoice_id=NEW.invoice_id) THEN RAISE(ABORT,'AUDIT_OLD_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN COALESCE(json_type(NEW.old_value,'$.paid_cents'),'missing')<>'integer' OR COALESCE(json_type(NEW.new_value,'$.paid_cents'),'missing')<>'integer' THEN RAISE(ABORT,'AUDIT_SNAPSHOT_REQUIRED') END;
 SELECT CASE WHEN json_extract(NEW.old_value,'$.paid_cents') IS NOT (SELECT paid_cents FROM invoices WHERE invoice_id=NEW.invoice_id) THEN RAISE(ABORT,'AUDIT_OLD_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN COALESCE(json_type(NEW.old_value,'$.remaining_cents'),'missing')<>'integer' OR COALESCE(json_type(NEW.new_value,'$.remaining_cents'),'missing')<>'integer' THEN RAISE(ABORT,'AUDIT_SNAPSHOT_REQUIRED') END;
 SELECT CASE WHEN json_extract(NEW.old_value,'$.remaining_cents') IS NOT (SELECT remaining_cents FROM invoices WHERE invoice_id=NEW.invoice_id) THEN RAISE(ABORT,'AUDIT_OLD_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN COALESCE(json_type(NEW.old_value,'$.version'),'missing')<>'integer' OR COALESCE(json_type(NEW.new_value,'$.version'),'missing')<>'integer' THEN RAISE(ABORT,'AUDIT_SNAPSHOT_REQUIRED') END;
 SELECT CASE WHEN json_extract(NEW.old_value,'$.version') IS NOT (SELECT version FROM invoices WHERE invoice_id=NEW.invoice_id) THEN RAISE(ABORT,'AUDIT_OLD_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN json_extract(NEW.old_value,'$.status') IS NOT (SELECT status FROM invoices WHERE invoice_id=NEW.invoice_id) OR COALESCE(json_type(NEW.new_value,'$.status'),'missing')<>'text' THEN RAISE(ABORT,'AUDIT_STATUS_SNAPSHOT_REQUIRED') END;
 SELECT CASE WHEN NEW.permissions_epoch<>(SELECT version FROM permission_runtime WHERE singleton=1) THEN RAISE(ABORT,'PERMISSION_EPOCH_CONFLICT') END;
 SELECT CASE WHEN NEW.authz_expires_at_ms<=(CAST(strftime('%s','now') AS INTEGER)*1000+CAST(substr(strftime('%f','now'),4,3) AS INTEGER)) THEN RAISE(ABORT,'AUTHORIZATION_EXPIRED') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM users WHERE user_id=NEW.modified_by AND active=1 AND (role IN('MANAGER','STAFF') OR (role='SYSTEM' AND NEW.action_type='OVERDUE_REFRESH'))) THEN RAISE(ABORT,'FINANCIAL_WRITE_DENIED') END;
 SELECT CASE WHEN EXISTS(SELECT 1 FROM users u WHERE u.user_id=NEW.modified_by AND u.role='STAFF' AND NOT (
  ((SELECT open_all_enabled FROM permission_runtime WHERE singleton=1)=1 AND (SELECT open_until_ms FROM permission_runtime WHERE singleton=1)>(CAST(strftime('%s','now') AS INTEGER)*1000+CAST(substr(strftime('%f','now'),4,3) AS INTEGER))) OR
  (COALESCE(json_extract(u.custom_permissions,'$.view_financials'),(SELECT json_extract(permissions_json,'$.view_financials') FROM role_permissions WHERE role='STAFF'),0)=1 AND
   COALESCE(json_extract(u.custom_permissions,CASE NEW.action_type WHEN 'CREATE' THEN '$.create_invoice' WHEN 'EDIT' THEN '$.edit_invoice' WHEN 'DISCOUNT' THEN '$.edit_discount' WHEN 'PAYMENT' THEN '$.record_payment' WHEN 'REFER' THEN '$.edit_invoice' ELSE '$.__reserved' END),
    (SELECT json_extract(permissions_json,CASE NEW.action_type WHEN 'CREATE' THEN '$.create_invoice' WHEN 'EDIT' THEN '$.edit_invoice' WHEN 'DISCOUNT' THEN '$.edit_discount' WHEN 'PAYMENT' THEN '$.record_payment' WHEN 'REFER' THEN '$.edit_invoice' ELSE '$.__reserved' END) FROM role_permissions WHERE role='STAFF'),0)=1)
 )) THEN RAISE(ABORT,'FINANCIAL_PERMISSION_REQUIRED') END;
 SELECT CASE WHEN json_extract(NEW.new_value,'$.discount_cents')<>json_extract(NEW.old_value,'$.discount_cents') AND EXISTS(SELECT 1 FROM users u WHERE u.user_id=NEW.modified_by AND u.role='STAFF' AND NOT (((SELECT open_all_enabled FROM permission_runtime WHERE singleton=1)=1 AND (SELECT open_until_ms FROM permission_runtime WHERE singleton=1)>(CAST(strftime('%s','now') AS INTEGER)*1000+CAST(substr(strftime('%f','now'),4,3) AS INTEGER))) OR COALESCE(json_extract(u.custom_permissions,'$.edit_discount'),(SELECT json_extract(permissions_json,'$.edit_discount') FROM role_permissions WHERE role='STAFF'),0)=1)) THEN RAISE(ABORT,'DISCOUNT_PERMISSION_REQUIRED') END;
 SELECT CASE WHEN (SELECT status FROM invoices WHERE invoice_id=NEW.invoice_id)='PENDING_APPROVAL' AND NEW.action_type<>'APPROVE' THEN RAISE(ABORT,'INVOICE_LOCKED') END;
 SELECT CASE WHEN NEW.action_type='APPROVE' AND (NOT EXISTS(SELECT 1 FROM users WHERE user_id=NEW.modified_by AND active=1 AND role='MANAGER') OR (SELECT status FROM invoices WHERE invoice_id=NEW.invoice_id)<>'PENDING_APPROVAL') THEN RAISE(ABORT,'MANAGER_APPROVAL_REQUIRED') END;
END;
--> statement-breakpoint
CREATE TABLE invoice_items (
 item_id TEXT PRIMARY KEY NOT NULL,
 invoice_id TEXT NOT NULL REFERENCES invoices(invoice_id) ON DELETE CASCADE,
 service_id TEXT,
 service_name TEXT NOT NULL,
 is_custom INTEGER NOT NULL DEFAULT 0 CHECK(is_custom IN(0,1)),
 is_free INTEGER NOT NULL DEFAULT 0 CHECK(is_free IN(0,1)),
 unit_price_cents INTEGER NOT NULL DEFAULT 0 CHECK(typeof(unit_price_cents)='integer' AND unit_price_cents BETWEEN 0 AND 9007199254740991),
 reference_price_cents INTEGER CHECK(reference_price_cents IS NULL OR (typeof(reference_price_cents)='integer' AND reference_price_cents BETWEEN 0 AND 9007199254740991)),
 last_operation_id TEXT NOT NULL REFERENCES financial_audit_logs(log_id),
 CHECK(is_free=0 OR unit_price_cents=0)
);
--> statement-breakpoint
CREATE INDEX invoice_items_invoice ON invoice_items(invoice_id,item_id);
--> statement-breakpoint
CREATE TRIGGER invoice_item_insert_guard BEFORE INSERT ON invoice_items BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM invoices i JOIN financial_audit_logs a ON a.invoice_id=i.invoice_id WHERE i.invoice_id=NEW.invoice_id AND i.status<>'PENDING_APPROVAL' AND a.log_id=NEW.last_operation_id AND a.expected_version=i.version AND a.action_type IN('CREATE','EDIT')) THEN RAISE(ABORT,'INVOICE_ITEM_WRITE_DENIED') END;
END;
--> statement-breakpoint
CREATE TRIGGER invoice_item_update_guard BEFORE UPDATE ON invoice_items BEGIN
 SELECT CASE WHEN NEW.item_id<>OLD.item_id OR NEW.invoice_id<>OLD.invoice_id OR NOT EXISTS(SELECT 1 FROM invoices i JOIN financial_audit_logs a ON a.invoice_id=i.invoice_id WHERE i.invoice_id=NEW.invoice_id AND i.status<>'PENDING_APPROVAL' AND a.log_id=NEW.last_operation_id AND a.expected_version=i.version AND a.action_type='EDIT') THEN RAISE(ABORT,'INVOICE_ITEM_WRITE_DENIED') END;
END;
--> statement-breakpoint
CREATE TRIGGER invoice_item_delete_guard BEFORE DELETE ON invoice_items BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM invoices i JOIN financial_audit_logs a ON a.invoice_id=i.invoice_id WHERE i.invoice_id=OLD.invoice_id AND i.status<>'PENDING_APPROVAL' AND a.expected_version=i.version AND a.action_type='EDIT') THEN RAISE(ABORT,'INVOICE_ITEM_WRITE_DENIED') END;
END;
--> statement-breakpoint
CREATE TABLE payments_ledger (
 payment_id TEXT PRIMARY KEY NOT NULL,
 invoice_id TEXT NOT NULL,
 case_id TEXT NOT NULL,
 currency TEXT NOT NULL,
 amount_cents INTEGER NOT NULL CHECK(typeof(amount_cents)='integer' AND amount_cents BETWEEN 1 AND 9007199254740991),
 method TEXT NOT NULL CHECK(method IN('CASH','CHEQUE','ZELLE','CASH_APP')),
 paid_at TEXT NOT NULL,
 receipt_r2_key TEXT,
 receipt_sha256 TEXT CHECK(receipt_sha256 IS NULL OR length(receipt_sha256)=64),
 notes TEXT,
 idempotency_key TEXT NOT NULL UNIQUE,
 operation_id TEXT NOT NULL UNIQUE REFERENCES financial_audit_logs(log_id),
 created_by TEXT NOT NULL REFERENCES users(user_id),
 created_at TEXT NOT NULL,
 CHECK((receipt_r2_key IS NULL AND receipt_sha256 IS NULL) OR (receipt_r2_key IS NOT NULL AND receipt_sha256 IS NOT NULL)),
 FOREIGN KEY(invoice_id,case_id,currency) REFERENCES invoices(invoice_id,case_id,currency)
);
--> statement-breakpoint
CREATE INDEX payments_invoice_date ON payments_ledger(invoice_id,paid_at,payment_id);
--> statement-breakpoint
CREATE INDEX payments_case_date ON payments_ledger(case_id,paid_at,payment_id);
--> statement-breakpoint
CREATE TRIGGER payment_insert_guard BEFORE INSERT ON payments_ledger BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM invoices i JOIN financial_audit_logs a ON a.invoice_id=i.invoice_id WHERE i.invoice_id=NEW.invoice_id AND i.case_id=NEW.case_id AND i.currency=NEW.currency AND i.status<>'PENDING_APPROVAL' AND NEW.amount_cents<=i.remaining_cents AND a.log_id=NEW.operation_id AND a.idempotency_key=NEW.idempotency_key AND a.modified_by=NEW.created_by AND a.expected_version=i.version AND a.action_type='PAYMENT') THEN RAISE(ABORT,'PAYMENT_NOT_AUTHORIZED') END;
END;
--> statement-breakpoint
CREATE TRIGGER invoice_insert_guard BEFORE INSERT ON invoices BEGIN
 SELECT CASE WHEN NEW.version<>0 OR NEW.status<>'DRAFT' OR NEW.subtotal_cents<>0 OR NEW.discount_cents<>0 OR NEW.total_cents<>0 OR NEW.paid_cents<>0 OR NEW.remaining_cents<>0 OR NEW.last_operation_id IS NOT NULL THEN RAISE(ABORT,'SERVER_TOTALS_REQUIRED') END;
END;
--> statement-breakpoint
CREATE TRIGGER invoice_update_guard BEFORE UPDATE ON invoices BEGIN
 SELECT CASE WHEN NEW.invoice_id<>OLD.invoice_id OR NEW.case_id<>OLD.case_id OR NEW.currency<>OLD.currency OR NEW.created_by<>OLD.created_by OR NEW.created_at<>OLD.created_at OR NEW.version<>OLD.version+1 THEN RAISE(ABORT,'INVALID_INVOICE_UPDATE') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM financial_audit_logs a WHERE a.log_id=NEW.last_operation_id AND a.invoice_id=OLD.invoice_id AND a.expected_version=OLD.version AND a.permissions_epoch=(SELECT version FROM permission_runtime WHERE singleton=1) AND a.authz_expires_at_ms>(CAST(strftime('%s','now') AS INTEGER)*1000+CAST(substr(strftime('%f','now'),4,3) AS INTEGER))) THEN RAISE(ABORT,'AUDITED_OPERATION_REQUIRED') END;
 SELECT CASE WHEN OLD.status='PENDING_APPROVAL' AND NOT EXISTS(SELECT 1 FROM financial_audit_logs a JOIN users u ON u.user_id=a.modified_by WHERE a.log_id=NEW.last_operation_id AND a.action_type='APPROVE' AND u.role='MANAGER' AND u.active=1) THEN RAISE(ABORT,'INVOICE_LOCKED') END;
 SELECT CASE WHEN OLD.status='PENDING_APPROVAL' AND (NEW.subtotal_cents<>OLD.subtotal_cents OR NEW.discount_cents<>OLD.discount_cents OR NEW.total_cents<>OLD.total_cents OR NEW.paid_cents<>OLD.paid_cents OR NEW.remaining_cents<>OLD.remaining_cents OR NEW.deadline IS NOT OLD.deadline OR NEW.note IS NOT OLD.note) THEN RAISE(ABORT,'APPROVE_WITHOUT_EDITING_LOCKED_INVOICE') END;
 SELECT CASE WHEN (SELECT action_type FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) IN('PAYMENT','REFER','OVERDUE_REFRESH') AND (NEW.subtotal_cents<>OLD.subtotal_cents OR NEW.discount_cents<>OLD.discount_cents OR NEW.total_cents<>OLD.total_cents OR NEW.deadline IS NOT OLD.deadline OR NEW.note IS NOT OLD.note) THEN RAISE(ABORT,'ACTION_CANNOT_EDIT_INVOICE_TERMS') END;
 SELECT CASE WHEN (SELECT action_type FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) IN('REFER','OVERDUE_REFRESH') AND (NEW.paid_cents<>OLD.paid_cents OR NEW.remaining_cents<>OLD.remaining_cents) THEN RAISE(ABORT,'ACTION_CANNOT_EDIT_INVOICE_BALANCE') END;
 SELECT CASE WHEN NEW.subtotal_cents<>(SELECT COALESCE(SUM(unit_price_cents),0) FROM invoice_items WHERE invoice_id=OLD.invoice_id) OR NEW.paid_cents<>(SELECT COALESCE(SUM(amount_cents),0) FROM payments_ledger WHERE invoice_id=OLD.invoice_id) THEN RAISE(ABORT,'FINANCIAL_SUM_MISMATCH') END;
 SELECT CASE WHEN NEW.subtotal_cents IS NOT (SELECT json_extract(new_value,'$.subtotal_cents') FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) THEN RAISE(ABORT,'AUDIT_NEW_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN NEW.discount_cents IS NOT (SELECT json_extract(new_value,'$.discount_cents') FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) THEN RAISE(ABORT,'AUDIT_NEW_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN NEW.total_cents IS NOT (SELECT json_extract(new_value,'$.total_cents') FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) THEN RAISE(ABORT,'AUDIT_NEW_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN NEW.paid_cents IS NOT (SELECT json_extract(new_value,'$.paid_cents') FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) THEN RAISE(ABORT,'AUDIT_NEW_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN NEW.remaining_cents IS NOT (SELECT json_extract(new_value,'$.remaining_cents') FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) THEN RAISE(ABORT,'AUDIT_NEW_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN NEW.version IS NOT (SELECT json_extract(new_value,'$.version') FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) THEN RAISE(ABORT,'AUDIT_NEW_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN NEW.status IS NOT (SELECT json_extract(new_value,'$.status') FROM financial_audit_logs WHERE log_id=NEW.last_operation_id) THEN RAISE(ABORT,'AUDIT_NEW_SNAPSHOT_MISMATCH') END;
 SELECT CASE WHEN (SELECT action_type FROM financial_audit_logs WHERE log_id=NEW.last_operation_id)='REFER' AND NEW.status<>'PENDING_APPROVAL' THEN RAISE(ABORT,'REFERRAL_MUST_LOCK') END;
 SELECT CASE WHEN NEW.status='PENDING_APPROVAL' AND (SELECT action_type FROM financial_audit_logs WHERE log_id=NEW.last_operation_id)<>'REFER' THEN RAISE(ABORT,'INVALID_APPROVAL_STATE') END;
 SELECT CASE WHEN NEW.status='PAID' AND NEW.remaining_cents<>0 THEN RAISE(ABORT,'INVALID_PAID_STATE') END;
 SELECT CASE WHEN NEW.status='PARTIAL' AND NOT(NEW.paid_cents>0 AND NEW.remaining_cents>0) THEN RAISE(ABORT,'INVALID_PARTIAL_STATE') END;
END;
--> statement-breakpoint
CREATE TRIGGER payments_no_update BEFORE UPDATE ON payments_ledger BEGIN SELECT RAISE(ABORT,'IMMUTABLE_PAYMENT'); END;
--> statement-breakpoint
CREATE TRIGGER payments_no_delete BEFORE DELETE ON payments_ledger BEGIN SELECT RAISE(ABORT,'IMMUTABLE_PAYMENT'); END;
--> statement-breakpoint
CREATE TRIGGER financial_audit_no_update BEFORE UPDATE ON financial_audit_logs BEGIN SELECT RAISE(ABORT,'IMMUTABLE_FINANCIAL_AUDIT'); END;
--> statement-breakpoint
CREATE TRIGGER financial_audit_no_delete BEFORE DELETE ON financial_audit_logs BEGIN SELECT RAISE(ABORT,'IMMUTABLE_FINANCIAL_AUDIT'); END;
--> statement-breakpoint
CREATE TRIGGER invoices_no_delete BEFORE DELETE ON invoices BEGIN SELECT RAISE(ABORT,'INVOICE_HISTORY_REQUIRED'); END;
