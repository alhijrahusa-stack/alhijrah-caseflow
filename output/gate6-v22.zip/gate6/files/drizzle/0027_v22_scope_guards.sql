-- v2.2 Gate 1 audit fix (Codex). Scope guards the package SQL did not enforce:
-- (1) candidates.latest_verified_assessment_id / latest_rapid_assessment_id may point only to a PRODUCTION assessment
--     of the same case with the matching purpose; (2) case_fact_heads may point only to a revision of the same
--     case, subject_id and fact_key. Additive only: triggers, no data change. 0024-0026 stay identical to the package.
CREATE TRIGGER candidates_assessment_pointer_insert BEFORE INSERT ON candidates
 WHEN NEW.latest_verified_assessment_id IS NOT NULL OR NEW.latest_rapid_assessment_id IS NOT NULL BEGIN
 SELECT RAISE(ABORT,'ASSESSMENT_POINTER_CASE_MISMATCH');
END;
--> statement-breakpoint
CREATE TRIGGER candidates_verified_pointer_guard BEFORE UPDATE OF latest_verified_assessment_id ON candidates
 WHEN NEW.latest_verified_assessment_id IS NOT NULL BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM assessment_history h WHERE h.id=NEW.latest_verified_assessment_id AND h.candidate_id=NEW.id) THEN RAISE(ABORT,'ASSESSMENT_POINTER_CASE_MISMATCH') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM assessment_history h WHERE h.id=NEW.latest_verified_assessment_id AND h.assessment_mode='PRODUCTION' AND h.assessment_purpose='VERIFIED_SCREENING') THEN RAISE(ABORT,'ASSESSMENT_POINTER_PURPOSE_MISMATCH') END;
END;
--> statement-breakpoint
CREATE TRIGGER candidates_rapid_pointer_guard BEFORE UPDATE OF latest_rapid_assessment_id ON candidates
 WHEN NEW.latest_rapid_assessment_id IS NOT NULL BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM assessment_history h WHERE h.id=NEW.latest_rapid_assessment_id AND h.candidate_id=NEW.id) THEN RAISE(ABORT,'ASSESSMENT_POINTER_CASE_MISMATCH') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM assessment_history h WHERE h.id=NEW.latest_rapid_assessment_id AND h.assessment_mode='PRODUCTION' AND h.assessment_purpose='RAPID_SCREENING') THEN RAISE(ABORT,'ASSESSMENT_POINTER_PURPOSE_MISMATCH') END;
END;
--> statement-breakpoint
CREATE TRIGGER case_fact_head_insert_scope BEFORE INSERT ON case_fact_heads BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM case_fact_revisions r WHERE r.case_id=NEW.case_id AND r.fact_id=NEW.fact_id AND r.subject_id=NEW.subject_id AND r.fact_key=NEW.fact_key) THEN RAISE(ABORT,'FACT_HEAD_SCOPE_MISMATCH') END;
END;
--> statement-breakpoint
CREATE TRIGGER case_fact_head_update_scope BEFORE UPDATE ON case_fact_heads BEGIN
 SELECT CASE WHEN NEW.case_id<>OLD.case_id OR NEW.subject_id<>OLD.subject_id OR NEW.fact_key<>OLD.fact_key THEN RAISE(ABORT,'FACT_HEAD_KEY_IMMUTABLE') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM case_fact_revisions r WHERE r.case_id=NEW.case_id AND r.fact_id=NEW.fact_id AND r.subject_id=NEW.subject_id AND r.fact_key=NEW.fact_key) THEN RAISE(ABORT,'FACT_HEAD_SCOPE_MISMATCH') END;
END;
