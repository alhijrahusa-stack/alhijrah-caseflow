import { integer, sqliteTable, text, index, uniqueIndex, primaryKey, type AnySQLiteColumn } from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";
export const candidates = sqliteTable("candidates", {
  id: text("id").primaryKey(), ownerId: text("owner_id").notNull(),
  reference: text("reference").notNull(), profile: text("profile").notNull(),
  assessment: text("assessment").notNull(), status: text("status").notNull().default("new"),
  version: integer("version").notNull().default(1),
  dedupeKey: text("dedupe_key").notNull().default(""),
  emailKey: text("email_key").notNull().default(""),
  contactPairKey: text("contact_pair_key").notNull().default(""),
  identityVersion: integer("identity_version").notNull().default(0),
  priority: text("priority").notNull().default("normal"),
  pathway: text("pathway").notNull().default(""),
  assignedTo: text("assigned_to").notNull().default(""),
  referralTo: text("referral_to").notNull().default(""),
  sharingConsent: integer("sharing_consent", { mode: "boolean" }).notNull().default(false),
  source: text("source").notNull().default("staff"),
  createdAt: text("created_at").notNull(), updatedAt: text("updated_at").notNull(),
  // v2.2 (0026): revision counters and assessment pointers; legacy rows keep defaults/NULL.
  dataRevision: integer("data_revision").notNull().default(0),
  publicationRevision: integer("publication_revision").notNull().default(0),
  latestVerifiedAssessmentId: text("latest_verified_assessment_id").references(() => assessmentHistory.id),
  latestRapidAssessmentId: text("latest_rapid_assessment_id").references(() => assessmentHistory.id),
  approvalForSubmissionAt: text("approval_for_submission_at"),
}, t => [index("candidate_owner_date").on(t.ownerId, t.createdAt),
  uniqueIndex("candidate_owner_identity").on(t.ownerId,t.dedupeKey).where(sql`${t.dedupeKey} <> ''`),
  uniqueIndex("candidate_owner_email_identity").on(t.ownerId,t.emailKey).where(sql`${t.emailKey} <> ''`),
  uniqueIndex("candidate_owner_contact_pair").on(t.ownerId,t.contactPairKey).where(sql`${t.contactPairKey} <> ''`),
  index("candidate_legacy_identity").on(t.ownerId,t.identityVersion),
  uniqueIndex("office_name_phone_identity").on(t.dedupeKey).where(sql`${t.identityVersion} = 1 AND ${t.dedupeKey} <> ''`),
  uniqueIndex("office_name_email_identity").on(t.emailKey).where(sql`${t.identityVersion} = 1 AND ${t.emailKey} <> ''`),
  uniqueIndex("office_contact_pair_identity").on(t.contactPairKey).where(sql`${t.identityVersion} = 1 AND ${t.contactPairKey} <> ''`),
  index("candidate_owner_status").on(t.ownerId,t.status),
  uniqueIndex("candidate_client_reference").on(t.reference).where(sql`${t.source} = 'client'`),
]);
export const documents = sqliteTable("documents", {
  id: text("id").primaryKey(), ownerId: text("owner_id").notNull(),
  candidateId: text("candidate_id").notNull().references(() => candidates.id),
  name: text("name").notNull(), objectKey: text("object_key").notNull(),
  size: integer("size").notNull(), mime: text("mime").notNull(),
  preparation: text("preparation").notNull().default("{}"), category: text("category").notNull(), sha256: text("sha256").notNull(),
  verified: integer("verified", { mode: "boolean" }).notNull().default(false),
  createdAt: text("created_at").notNull(),
  // v2.2 Gate 5 (0030): integrity pipeline state; legacy rows stay LEGACY_UNSCANNED.
  integrityState: text("integrity_state").notNull().default("LEGACY_UNSCANNED"), integrityEngine: text("integrity_engine"),
  integrityCheckedAt: text("integrity_checked_at"), mediaDurationMs: integer("media_duration_ms"),
}, t => [index("document_owner_candidate").on(t.ownerId, t.candidateId), index("document_candidate_date").on(t.candidateId, t.createdAt)]);
export const events = sqliteTable("events", {
  id: text("id").primaryKey(), ownerId: text("owner_id").notNull(),
  candidateId: text("candidate_id").notNull().references(() => candidates.id),
  action: text("action").notNull(), note: text("note").notNull().default(""),
  createdAt: text("created_at").notNull(),
}, t => [index("event_owner_candidate").on(t.ownerId, t.candidateId)]);

export const tasks = sqliteTable("tasks", {
  id: text("id").primaryKey(), ownerId: text("owner_id").notNull(),
  candidateId: text("candidate_id").notNull().references(() => candidates.id),
  title: text("title").notNull(), dueDate: text("due_date").notNull().default(""),
  priority: text("priority").notNull().default("normal"),
  status: text("status").notNull().default("open"),
  systemKey: text("system_key"), version: integer("version").notNull().default(1),
  createdAt: text("created_at").notNull(), updatedAt: text("updated_at").notNull(),
}, t => [index("task_owner_status_due").on(t.ownerId,t.status,t.dueDate),
  index("task_owner_candidate").on(t.ownerId,t.candidateId),
  uniqueIndex("task_system_key").on(t.ownerId,t.candidateId,t.systemKey),
]);

export const officeSettings = sqliteTable("office_settings", {
  id: text("id").primaryKey(), primaryOwnerId: text("primary_owner_id").notNull().default(""),
  whatsappSid:text("whatsapp_sid").notNull().default(""), whatsappToken:text("whatsapp_token").notNull().default(""),
  whatsappFrom:text("whatsapp_from").notNull().default(""), whatsappTemplate:text("whatsapp_template").notNull().default(""),
  aiKey:text("ai_key").notNull().default(""), aiModel:text("ai_model").notNull().default("llama-3.1-8b-instant"),
  professionalProvider:text('professional_provider').notNull().default(''),professionalKey:text('professional_key').notNull().default(''),professionalModel:text('professional_model').notNull().default(''),calendarUrl:text('calendar_url').notNull().default(''),captchaSiteKey:text('captcha_site_key').notNull().default(''),captchaSecret:text('captcha_secret').notNull().default(''),whatsappStatusTemplate:text('whatsapp_status_template').notNull().default(''),
  marketSnapshot:text("market_snapshot").notNull().default(""),
  mailKey: text("mail_key").notNull().default(""), mailFrom: text("mail_from").notNull().default(""),
  updatedAt: text("updated_at").notNull(),
});
export const officeMembers = sqliteTable("office_members", {
  email: text("email").primaryKey(), name: text("name").notNull(),
  active: integer("active", {mode:"boolean"}).notNull().default(true), createdAt:text("created_at").notNull(),
});
export const clientCases = sqliteTable("client_cases", {
  candidateId: text("candidate_id").primaryKey().references(()=>candidates.id),
  requestId: text("request_id").notNull().unique(), payloadHash: text("payload_hash").notNull(),
  accessHash: text("access_hash").notNull(), accessEncrypted: text("access_encrypted").notNull(),
  otpOnly:integer("otp_only",{mode:"boolean"}).notNull().default(false),
  inbox: text("inbox").notNull().default("pending"), details:text("details").notNull().default("{}"),
  lmiaStream:text("lmia_stream").notNull().default(""),lmiaCompleteDate:text("lmia_complete_date").notNull().default(""),lmiaEvidenceId:text("lmia_evidence_id").notNull().default(""),
  followUpDate:text("follow_up_date").notNull().default(""),
  instructions:text("instructions").notNull().default(""), requestedDocuments:text("requested_documents").notNull().default("[]"),
  consentVersion:text("consent_version").notNull(), submittedAt:text("submitted_at").notNull(),
  version:integer("version").notNull().default(1),
},t=>[index("client_inbox_date").on(t.inbox,t.submittedAt),uniqueIndex("client_access_hash").on(t.accessHash)]);
export const clientMessages = sqliteTable("client_messages", {
  id:text("id").primaryKey(), candidateId:text("candidate_id").notNull().references(()=>candidates.id),
  kind:text("kind").notNull(), recipient:text("recipient").notNull(), subject:text("subject").notNull(), body:text("body").notNull(),
  state:text("state").notNull().default("pending"), providerId:text("provider_id").notNull().default(""),
  error:text("error").notNull().default(""), actor:text("actor").notNull(),
  requestKey:text("request_key").notNull().unique(), createdAt:text("created_at").notNull(), sentAt:text("sent_at").notNull().default(""),
},t=>[index("message_candidate_date").on(t.candidateId,t.createdAt)]);
export const rateLimits = sqliteTable("rate_limits", {
  key:text("key").primaryKey(), count:integer("count").notNull(), expires:integer("expires").notNull(),
}, t => [index("rate_limit_expiry").on(t.expires)]);

export const caseReviews=sqliteTable("case_reviews",{
 candidateId:text("candidate_id").primaryKey().references(()=>candidates.id),
 state:text("state").notNull().default("draft"),preparedBy:text("prepared_by").notNull().default(""),
 reviewedBy:text("reviewed_by").notNull().default(""),checklist:text("checklist").notNull().default("{}"),
 note:text("note").notNull().default(""),contentVersion:integer("content_version").notNull().default(0),
 version:integer("version").notNull().default(1),submittedAt:text("submitted_at").notNull().default(""),
 reviewedAt:text("reviewed_at").notNull().default(""),updatedAt:text("updated_at").notNull(),
},t=>[index("review_state_date").on(t.state,t.updatedAt)]);

export const authChallenges=sqliteTable("auth_challenges",{
 id:text("id").primaryKey(),candidateId:text("candidate_id").references(()=>candidates.id),channel:text("channel").notNull(),
 contactHash:text("contact_hash").notNull().default(""),codeHash:text("code_hash").notNull(),requestKey:text("request_key").notNull().unique(),state:text("state").notNull(),
 attempts:integer("attempts").notNull().default(0),expiresAt:integer("expires_at").notNull(),createdAt:integer("created_at").notNull(),
 usedAt:integer("used_at"),consumedBy:text("consumed_by").notNull().default(""),providerId:text("provider_id").notNull().default(""),
 purpose:text("purpose").notNull().default("case_login"),deliveryPayloadEncrypted:text("delivery_payload_encrypted"),
 deliveryLeaseUntil:integer("delivery_lease_until").notNull().default(0),deliveryAttemptCount:integer("delivery_attempt_count").notNull().default(0),
},t=>[index("challenge_candidate_date").on(t.candidateId,t.createdAt),index("challenge_expiry").on(t.expiresAt)]);
export const clientSessions=sqliteTable("client_sessions",{
 tokenHash:text("token_hash").primaryKey(),candidateId:text("candidate_id").notNull().references(()=>candidates.id),
 method:text("method").notNull(),createdAt:integer("created_at").notNull(),expiresAt:integer("expires_at").notNull(),
 revokedAt:integer("revoked_at"),scope:text("scope").notNull().default("full_case"),
},t=>[index("session_candidate_expiry").on(t.candidateId,t.expiresAt),index("client_session_expiry").on(t.expiresAt)]);
export const contactRequests=sqliteTable("contact_requests",{
 id:text("id").primaryKey(),candidateId:text("candidate_id").notNull().references(()=>candidates.id),
 requestedName:text("requested_name").notNull().default(""),requestedEmail:text("requested_email").notNull().default(""),requestedPhone:text("requested_phone").notNull().default(""),
 note:text("note").notNull().default(""),state:text("state").notNull().default("pending"),createdAt:text("created_at").notNull(),
 resolvedAt:text("resolved_at").notNull().default(""),resolvedBy:text("resolved_by").notNull().default(""),
},t=>[index("contact_request_candidate").on(t.candidateId,t.createdAt),uniqueIndex("one_pending_contact_request").on(t.candidateId).where(sql`${t.state} = 'pending'`)]);

export const loginCredentials=sqliteTable('login_credentials',{
 id:text('id').primaryKey(),scope:text('scope').notNull(),subject:text('subject').notNull(),passwordHash:text('password_hash').notNull(),version:integer('version').notNull().default(1),changedAt:integer('changed_at').notNull(),
},t=>[uniqueIndex('credential_scope_subject').on(t.scope,t.subject)]);
export const staffChallenges=sqliteTable('staff_challenges',{
 id:text('id').primaryKey(),email:text('email').notNull(),purpose:text('purpose').notNull(),codeHash:text('code_hash').notNull(),requestKey:text('request_key').notNull().unique(),state:text('state').notNull(),attempts:integer('attempts').notNull().default(0),expiresAt:integer('expires_at').notNull(),createdAt:integer('created_at').notNull(),usedAt:integer('used_at'),consumedBy:text('consumed_by').notNull().default(''),providerId:text('provider_id').notNull().default(''),
},t=>[index('staff_challenge_expiry').on(t.expiresAt),index('staff_challenge_email').on(t.email,t.createdAt)]);
export const staffSessions=sqliteTable('staff_sessions',{
 tokenHash:text('token_hash').primaryKey(),email:text('email').notNull(),method:text('method').notNull(),createdAt:integer('created_at').notNull(),expiresAt:integer('expires_at').notNull(),revokedAt:integer('revoked_at'),
},t=>[index('staff_session_email').on(t.email,t.expiresAt),index('staff_session_expiry').on(t.expiresAt)]);
export const authSecurityLog=sqliteTable('auth_security_log',{
 id:text('id').primaryKey(),scope:text('scope').notNull(),action:text('action').notNull(),subjectHash:text('subject_hash').notNull(),ipHash:text('ip_hash').notNull(),result:text('result').notNull(),createdAt:integer('created_at').notNull(),
},t=>[index('security_scope_date').on(t.scope,t.createdAt)]);

export const caseIntelligence=sqliteTable('case_intelligence',{
 candidateId:text('candidate_id').primaryKey().references(()=>candidates.id),version:integer('version').notNull(),ruleVersion:text('rule_version').notNull(),state:text('state').notNull(),report:text('report').notNull().default('{}'),model:text('model').notNull().default(''),generatedAt:text('generated_at').notNull().default(''),leaseUntil:integer('lease_until').notNull().default(0),
});

export const applicationAuthorizations=sqliteTable('application_authorizations',{
 candidateId:text('candidate_id').primaryKey().references(()=>candidates.id),version:text('version').notNull(),acceptedAt:text('accepted_at').notNull(),authorizationText:text('authorization_text').notNull(),termsText:text('terms_text').notNull(),snapshot:text('snapshot').notNull(),snapshotHash:text('snapshot_hash').notNull(),pdfObjectKey:text('pdf_object_key').notNull().default(''),pdfSha256:text('pdf_sha256').notNull().default(''),pdfGeneratedAt:text('pdf_generated_at').notNull().default(''),signatureId:text('signature_id'),signatureObjectKey:text('signature_object_key'),signatureSha256:text('signature_sha256'),signedPayloadHash:text('signed_payload_hash'),signatureSignedAt:text('signature_signed_at'),signerAccountKey:text('signer_account_key').references(()=>clientAccountProfiles.accountKey),
});

export const caseCrs=sqliteTable('case_crs',{candidateId:text('candidate_id').primaryKey().references(()=>candidates.id),inputs:text('inputs').notNull(),result:text('result').notNull(),sourceHash:text('source_hash').notNull(),reviewedBy:text('reviewed_by').notNull(),reviewedAt:text('reviewed_at').notNull()});

export const eligibilityRuns=sqliteTable('eligibility_runs',{id:text('id').primaryKey(),candidateId:text('candidate_id').notNull().references(()=>candidates.id),inputs:text('inputs').notNull(),result:text('result').notNull(),sourceHash:text('source_hash').notNull(),actor:text('actor').notNull(),createdAt:text('created_at').notNull()},t=>[index('eligibility_candidate_date').on(t.candidateId,t.createdAt)]);
export const crsHistory=sqliteTable('crs_history',{id:text('id').primaryKey(),candidateId:text('candidate_id').notNull().references(()=>candidates.id),inputs:text('inputs').notNull(),result:text('result').notNull(),sourceHash:text('source_hash').notNull(),actor:text('actor').notNull(),createdAt:text('created_at').notNull()},t=>[index('crs_history_candidate').on(t.candidateId,t.createdAt)]);
export const generatedDocuments=sqliteTable('cv_generation_log',{id:text('id').primaryKey(),candidateId:text('candidate_id').notNull().references(()=>candidates.id),requestKey:text('request_key').notNull().unique(),kind:text('kind').notNull(),state:text('state').notNull(),sourceHash:text('source_hash').notNull(),sourceSnapshot:text('source_snapshot').notNull(),content:text('content').notNull().default(''),provider:text('provider').notNull(),model:text('model').notNull(),objectKey:text('object_key').notNull().default(''),coverKey:text('cover_key').notNull().default(''),sha256:text('sha256').notNull().default(''),coverSha256:text('cover_sha256').notNull().default(''),verificationToken:text('verification_token').notNull().unique(),createdBy:text('created_by').notNull(),reviewedBy:text('reviewed_by').notNull().default(''),createdAt:text('created_at').notNull(),updatedAt:text('updated_at').notNull(),approvedAt:text('approved_at').notNull().default(''),errorCode:text('error_code').notNull().default('')},t=>[index('generated_candidate_date').on(t.candidateId,t.createdAt)]);
export const documentAiPermissions=sqliteTable('document_ai_permissions',{candidateId:text('candidate_id').primaryKey().references(()=>candidates.id),provider:text('provider').notNull(),consent:integer('consent',{mode:'boolean'}).notNull(),version:text('version').notNull(),updatedAt:text('updated_at').notNull()});
export const documentRevisions=sqliteTable('document_revisions',{id:text('id').primaryKey(),documentId:text('document_id').notNull().references(()=>generatedDocuments.id),snapshot:text('snapshot').notNull(),actor:text('actor').notNull(),createdAt:text('created_at').notNull()},t=>[index('document_revision_date').on(t.documentId,t.createdAt)]);
export const operationLogs=sqliteTable('operation_logs',{id:text('id').primaryKey(),candidateId:text('candidate_id').references(()=>candidates.id),operation:text('operation').notNull(),actor:text('actor').notNull(),result:text('result').notNull(),code:text('code').notNull().default(''),createdAt:text('created_at').notNull()},t=>[index('operation_date').on(t.createdAt),index('operation_kind_date').on(t.operation,t.createdAt)]);
export const clientFeedback=sqliteTable('client_feedback',{candidateId:text('candidate_id').primaryKey().references(()=>candidates.id),rating:integer('rating').notNull(),comment:text('comment').notNull(),updatedAt:text('updated_at').notNull()});
export const notificationPreferences=sqliteTable('notification_preferences',{candidateId:text('candidate_id').primaryKey().references(()=>candidates.id),whatsapp:integer('whatsapp',{mode:'boolean'}).notNull().default(false),updatedAt:text('updated_at').notNull()});
export const statusNotifications=sqliteTable('status_notifications',{id:text('id').primaryKey(),candidateId:text('candidate_id').notNull().references(()=>candidates.id),caseVersion:integer('case_version').notNull(),channel:text('channel').notNull(),state:text('state').notNull(),providerId:text('provider_id').notNull().default(''),createdAt:text('created_at').notNull()},t=>[uniqueIndex('one_status_notification').on(t.candidateId,t.caseVersion,t.channel)]);
export const announcements=sqliteTable('announcements',{id:text('id').primaryKey(),title:text('title').notNull(),body:text('body').notNull().default(''),tone:text('tone').notNull().default('admin'),active:integer('active',{mode:'boolean'}).notNull().default(true),expiresAt:text('expires_at').notNull().default(''),createdBy:text('created_by').notNull(),createdAt:text('created_at').notNull(),updatedAt:text('updated_at').notNull()},t=>[index('announcement_active_expiry').on(t.active,t.expiresAt)]);
export const faqNotes=sqliteTable('faq_notes',{entryId:text('entry_id').primaryKey(),note:text('note').notNull(),updatedBy:text('updated_by').notNull(),updatedAt:text('updated_at').notNull()});
export const aiCaseReviews=sqliteTable('ai_case_reviews',{id:text('id').primaryKey(),candidateId:text('candidate_id').notNull().references(()=>candidates.id),sourceVersion:integer('source_version').notNull(),provider:text('provider').notNull(),model:text('model').notNull(),content:text('content').notNull(),createdBy:text('created_by').notNull(),createdAt:text('created_at').notNull()},t=>[index('ai_case_review_candidate_date').on(t.candidateId,t.createdAt)]);
export const supportThreads=sqliteTable('support_threads',{candidateId:text('candidate_id').primaryKey().references(()=>candidates.id),status:text('status').notNull().default('ai'),handoffReason:text('handoff_reason').notNull().default(''),staffUnread:integer('staff_unread').notNull().default(0),clientUnread:integer('client_unread').notNull().default(0),lastMessageAt:text('last_message_at').notNull(),updatedAt:text('updated_at').notNull(),assignedTo:text('assigned_to').notNull().default(''),assignedAt:text('assigned_at').notNull().default('')},t=>[index('support_thread_status_date').on(t.status,t.lastMessageAt)]);
export const supportMessages=sqliteTable('support_messages',{id:text('id').primaryKey(),candidateId:text('candidate_id').notNull().references(()=>candidates.id),sender:text('sender').notNull(),author:text('author').notNull().default(''),body:text('body').notNull(),createdAt:text('created_at').notNull(),attachmentKey:text('attachment_key').notNull().default(''),attachmentType:text('attachment_type').notNull().default(''),attachmentName:text('attachment_name').notNull().default('')},t=>[index('support_message_candidate_date').on(t.candidateId,t.createdAt)]);
export const supportTransitions=sqliteTable('support_transitions',{id:text('id').primaryKey(),candidateId:text('candidate_id').notNull().references(()=>candidates.id),fromState:text('from_state').notNull(),toState:text('to_state').notNull(),actor:text('actor').notNull(),at:text('at').notNull()},t=>[index('support_transition_candidate').on(t.candidateId,t.at)]);
export const scoringConfig=sqliteTable('scoring_config',{id:text('id').primaryKey(),weights:text('weights').notNull(),hotThreshold:integer('hot_threshold').notNull(),warmThreshold:integer('warm_threshold').notNull(),updatedBy:text('updated_by').notNull(),updatedAt:text('updated_at').notNull()});
export const leadScores=sqliteTable('lead_scores',{candidateId:text('candidate_id').primaryKey().references(()=>candidates.id),score:integer('score').notNull(),tier:text('tier').notNull(),factors:text('factors').notNull(),computedAt:text('computed_at').notNull()},t=>[index('lead_score_tier').on(t.tier,t.score)]);

// v15.23 decision-engine foundation (migration 0022). DDL as given in the engine contract, step 1.
export const assessmentHistory=sqliteTable('assessment_history',{id:text('id').primaryKey(),candidateId:text('candidate_id').notNull(),computedAt:text('computed_at').notNull(),inputsHash:text('inputs_hash').notNull(),engineVersion:text('engine_version').notNull(),rulesVersion:text('rules_version').notNull(),outputJson:text('output_json').notNull(),explanationTraceJson:text('explanation_trace_json').notNull(),caseRevision:integer('case_revision'),canonicalInputHash:text('canonical_input_hash'),ruleBundleHash:text('rule_bundle_hash'),assessmentMode:text('assessment_mode'),assessmentPurpose:text('assessment_purpose'),createdBy:text('created_by').references(()=>users.userId)});
export const decisionAudit=sqliteTable('decision_audit',{id:text('id').primaryKey(),caseId:text('case_id').notNull(),decidedAt:text('decided_at').notNull(),rulesVersion:text('rules_version').notNull(),engineVersion:text('engine_version').notNull(),inputsHash:text('inputs_hash').notNull(),topPathwaysJson:text('top_pathways_json').notNull(),gapAnalysisJson:text('gap_analysis_json').notNull(),humanReviewerId:text('human_reviewer_id').notNull(),decisionTaken:text('decision_taken').notNull()});
export const caseOutcomes=sqliteTable('case_outcomes',{id:text('id').primaryKey(),caseId:text('case_id').notNull().unique(),pathwayChosen:text('pathway_chosen').notNull(),crsAtDecision:integer('crs_at_decision'),outcome:text('outcome').notNull(),outcomeDate:text('outcome_date'),processingDays:integer('processing_days'),rulesVersionAtDecision:text('rules_version_at_decision').notNull(),notes:text('notes')});
export const rulesVersions=sqliteTable('rules_versions',{id:text('id').primaryKey(),ruleKey:text('rule_key').notNull(),version:text('version').notNull(),effectiveFrom:text('effective_from').notNull(),effectiveUntil:text('effective_until'),payloadJson:text('payload_json').notNull(),sourceUrl:text('source_url').notNull(),createdAt:text('created_at').notNull()});
export const drawThresholds=sqliteTable('draw_thresholds',{id:text('id').primaryKey(),category:text('category').notNull(),drawDate:text('draw_date').notNull(),crsMin:integer('crs_min').notNull(),invitations:integer('invitations').notNull(),sourceUrl:text('source_url').notNull()});
export const pnpStreams=sqliteTable('pnp_streams',{id:text('id').primaryKey(),province:text('province').notNull(),streamName:text('stream_name').notNull(),requiredNocCodes:text('required_noc_codes').notNull(),minScore:integer('min_score'),effectiveFrom:text('effective_from').notNull(),effectiveUntil:text('effective_until'),sourceUrl:text('source_url').notNull()});
export const caseFacts=sqliteTable('case_facts',{id:text('id').primaryKey(),candidateId:text('candidate_id').notNull().references(()=>candidates.id),factKey:text('fact_key').notNull(),version:integer('version').notNull(),status:text('status').notNull(),valueJson:text('value_json').notNull(),source:text('source').notNull(),evidenceDocumentId:text('evidence_document_id').references(()=>documents.id),recordedBy:text('recorded_by').notNull(),recordedAt:text('recorded_at').notNull()},t=>[uniqueIndex('case_facts_candidate_key_version').on(t.candidateId,t.factKey,t.version)]);
// v2.2 Gate 1 — generated from migrations 0024–0026 and checked by tests/v22/database.test.mjs (ORM == SQL).
// Constraints, CHECKs, triggers and composite foreign keys are authoritative in SQL.
export const clientAccountProfiles=sqliteTable('client_account_profiles',{
 accountKey:text('account_key').primaryKey(),
 displayName:text('display_name').notNull(),
 createdAt:text('created_at').notNull(),
 updatedAt:text('updated_at').notNull()
});
export const clientApplicationDrafts=sqliteTable('client_application_drafts',{
 draftId:text('draft_id').primaryKey(),
 accountKey:text('account_key').notNull().references(()=>clientAccountProfiles.accountKey),
 revision:integer('revision').notNull(),
 state:text('state').notNull().default("DRAFT"),
 payloadJson:text('payload_json').notNull(),
 payloadHash:text('payload_hash').notNull(),
 signatureId:text('signature_id'),
 signatureObjectKey:text('signature_object_key'),
 signatureSha256:text('signature_sha256'),
 signedPayloadHash:text('signed_payload_hash'),
 signatureLegalVersion:text('signature_legal_version'),
 signatureSignedAt:text('signature_signed_at'),
 submittedCandidateId:text('submitted_candidate_id').references(()=>candidates.id),
 createdAt:text('created_at').notNull(),
 updatedAt:text('updated_at').notNull()
});
export const clientDraftMutations=sqliteTable('client_draft_mutations',{
 accountKey:text('account_key').notNull(),
 draftId:text('draft_id').notNull(),
 mutationId:text('mutation_id').notNull(),
 expectedRevision:integer('expected_revision').notNull(),
 requestHash:text('request_hash').notNull(),
 createdAt:text('created_at').notNull()
},t=>[primaryKey({columns:[t.accountKey,t.draftId,t.mutationId]})]);
export const clientContactLookup=sqliteTable('client_contact_lookup',{
 candidateId:text('candidate_id').notNull().references(()=>candidates.id),
 contactKind:text('contact_kind').notNull(),
 contactHash:text('contact_hash').notNull(),
 keyVersion:text('key_version').notNull(),
 updatedAt:text('updated_at').notNull()
},t=>[primaryKey({columns:[t.candidateId,t.contactKind]})]);
export const users=sqliteTable('users',{
 userId:text('user_id').primaryKey(),
 role:text('role').notNull(),
 customPermissions:text('custom_permissions').notNull().default("{}"),
 permissionVersion:integer('permission_version').notNull().default(1),
 active:integer('active').notNull().default(1),
 createdAt:text('created_at').notNull()
});
export const rolePermissions=sqliteTable('role_permissions',{
 role:text('role').primaryKey(),
 permissionsJson:text('permissions_json').notNull().default("{}"),
 version:integer('version').notNull().default(1),
 updatedAt:text('updated_at').notNull()
});
export const permissionRuntime=sqliteTable('permission_runtime',{
 singleton:integer('singleton').primaryKey(),
 version:integer('version').notNull().default(1),
 openAllEnabled:integer('open_all_enabled').notNull().default(0),
 openAllLocalDate:text('open_all_local_date'),
 openUntilMs:integer('open_until_ms').notNull().default(0)
});
export const permissionChangesAudit=sqliteTable('permission_changes_audit',{
 auditId:text('audit_id').primaryKey(),
 changeKind:text('change_kind').notNull(),
 targetUserId:text('target_user_id').references(()=>users.userId),
 targetRole:text('target_role'),
 oldPermissions:text('old_permissions').notNull(),
 newPermissions:text('new_permissions').notNull(),
 expectedVersion:integer('expected_version').notNull(),
 expectedEpoch:integer('expected_epoch').notNull(),
 changedBy:text('changed_by').notNull().references(()=>users.userId),
 changedAt:text('changed_at').notNull()
});
export const sourceSnapshots=sqliteTable('source_snapshots',{
 sourceId:text('source_id').primaryKey(),
 officialUrl:text('official_url').notNull(),
 objectKey:text('object_key').notNull(),
 contentSha256:text('content_sha256').notNull(),
 fetchedAt:text('fetched_at').notNull()
});
export const ruleBundles=sqliteTable('rule_bundles',{
 bundleId:text('bundle_id').primaryKey(),
 payload:text('payload').notNull(),
 payloadSha256:text('payload_sha256').notNull(),
 sourceId:text('source_id').notNull().references(()=>sourceSnapshots.sourceId),
 createdBy:text('created_by').notNull().references(()=>users.userId),
 createdAt:text('created_at').notNull()
});
export const releaseSets=sqliteTable('release_sets',{
 releaseId:text('release_id').primaryKey(),
 manifestSha256:text('manifest_sha256').notNull(),
 state:text('state').notNull().default("BUILDING"),
 validationReportHash:text('validation_report_hash'),
 createdBy:text('created_by').notNull().references(()=>users.userId),
 sealedBy:text('sealed_by').references(()=>users.userId),
 sealedAt:text('sealed_at')
});
export const releaseIntervals=sqliteTable('release_intervals',{
 releaseId:text('release_id').notNull().references(()=>releaseSets.releaseId),
 programId:text('program_id').notNull(),
 family:text('family').notNull(),
 phase:text('phase').notNull(),
 dateBasis:text('date_basis').notNull(),
 effectiveFrom:text('effective_from').notNull(),
 effectiveToExclusive:text('effective_to_exclusive'),
 bundleId:text('bundle_id').notNull().references(()=>ruleBundles.bundleId)
},t=>[primaryKey({columns:[t.releaseId,t.programId,t.family,t.phase,t.dateBasis,t.effectiveFrom]})]);
export const ruleActivation=sqliteTable('rule_activation',{
 singleton:integer('singleton').primaryKey(),
 releaseId:text('release_id').references(()=>releaseSets.releaseId),
 generation:integer('generation').notNull().default(0),
 changedBy:text('changed_by').references(()=>users.userId),
 changedAt:text('changed_at')
});
export const invoices=sqliteTable('invoices',{
 invoiceId:text('invoice_id').primaryKey(),
 caseId:text('case_id').notNull().references(()=>candidates.id),
 currency:text('currency').notNull(),
 status:text('status').notNull().default("DRAFT"),
 subtotalCents:integer('subtotal_cents').notNull().default(0),
 discountCents:integer('discount_cents').notNull().default(0),
 totalCents:integer('total_cents').notNull().default(0),
 paidCents:integer('paid_cents').notNull().default(0),
 remainingCents:integer('remaining_cents').notNull().default(0),
 deadline:text('deadline'),
 note:text('note'),
 version:integer('version').notNull().default(0),
 lastOperationId:text('last_operation_id').references(():AnySQLiteColumn=>financialAuditLogs.logId),
 approvalRequestedAt:text('approval_requested_at'),
 approvedBy:text('approved_by').references(()=>users.userId),
 approvedAt:text('approved_at'),
 createdBy:text('created_by').notNull().references(()=>users.userId),
 createdAt:text('created_at').notNull(),
 updatedAt:text('updated_at').notNull()
});
export const financialAuditLogs=sqliteTable('financial_audit_logs',{
 logId:text('log_id').primaryKey(),
 invoiceId:text('invoice_id').notNull().references(()=>invoices.invoiceId),
 modifiedBy:text('modified_by').notNull().references(()=>users.userId),
 actionType:text('action_type').notNull(),
 oldValue:text('old_value').notNull(),
 newValue:text('new_value').notNull(),
 expectedVersion:integer('expected_version').notNull(),
 permissionsEpoch:integer('permissions_epoch').notNull(),
 authzExpiresAtMs:integer('authz_expires_at_ms').notNull(),
 requestHash:text('request_hash').notNull(),
 idempotencyKey:text('idempotency_key').notNull(),
 timestamp:text('timestamp').notNull()
});
export const invoiceItems=sqliteTable('invoice_items',{
 itemId:text('item_id').primaryKey(),
 invoiceId:text('invoice_id').notNull().references(()=>invoices.invoiceId),
 serviceId:text('service_id'),
 serviceName:text('service_name').notNull(),
 isCustom:integer('is_custom').notNull().default(0),
 isFree:integer('is_free').notNull().default(0),
 unitPriceCents:integer('unit_price_cents').notNull().default(0),
 referencePriceCents:integer('reference_price_cents'),
 lastOperationId:text('last_operation_id').notNull().references(()=>financialAuditLogs.logId)
});
export const paymentsLedger=sqliteTable('payments_ledger',{
 paymentId:text('payment_id').primaryKey(),
 invoiceId:text('invoice_id').notNull(),
 caseId:text('case_id').notNull(),
 currency:text('currency').notNull(),
 amountCents:integer('amount_cents').notNull(),
 method:text('method').notNull(),
 paidAt:text('paid_at').notNull(),
 receiptR2Key:text('receipt_r2_key'),
 receiptSha256:text('receipt_sha256'),
 notes:text('notes'),
 idempotencyKey:text('idempotency_key').notNull(),
 operationId:text('operation_id').notNull().references(()=>financialAuditLogs.logId),
 createdBy:text('created_by').notNull().references(()=>users.userId),
 createdAt:text('created_at').notNull()
});
export const caseAccess=sqliteTable('case_access',{
 caseId:text('case_id').notNull().references(()=>candidates.id),
 userId:text('user_id').notNull().references(()=>users.userId),
 grantedBy:text('granted_by').notNull().references(()=>users.userId),
 createdAt:text('created_at').notNull()
},t=>[primaryKey({columns:[t.caseId,t.userId]})]);
export const caseFactRevisions=sqliteTable('case_fact_revisions',{
 factId:text('fact_id').primaryKey(),
 caseId:text('case_id').notNull().references(()=>candidates.id),
 factKey:text('fact_key').notNull(),
 subjectId:text('subject_id').notNull(),
 valueJson:text('value_json').notNull(),
 state:text('state').notNull(),
 evidenceIds:text('evidence_ids').notNull().default("[]"),
 sourceHash:text('source_hash').notNull(),
 createdBy:text('created_by').notNull().references(()=>users.userId),
 reviewNote:text('review_note'),
 createdAt:text('created_at').notNull()
});
export const caseFactHeads=sqliteTable('case_fact_heads',{
 caseId:text('case_id').notNull().references(()=>candidates.id),
 subjectId:text('subject_id').notNull(),
 factKey:text('fact_key').notNull(),
 factId:text('fact_id').notNull()
},t=>[primaryKey({columns:[t.caseId,t.subjectId,t.factKey]})]);
export const durableJobs=sqliteTable('durable_jobs',{
 jobId:text('job_id').primaryKey(),
 caseId:text('case_id').references(()=>candidates.id),
 kind:text('kind').notNull(),
 requestKey:text('request_key').notNull(),
 requestHash:text('request_hash').notNull(),
 payload:text('payload').notNull(),
 state:text('state').notNull().default("PENDING"),
 attempts:integer('attempts').notNull().default(0),
 leaseUntilMs:integer('lease_until_ms').notNull().default(0),
 fence:integer('fence').notNull().default(0),
 nextAtMs:integer('next_at_ms').notNull(),
 createdBy:text('created_by').notNull().references(()=>users.userId),
 createdAt:text('created_at').notNull(),
 updatedAt:text('updated_at').notNull(),
 resultRef:text('result_ref'),
 errorCode:text('error_code')
});
export const deliveryOutbox=sqliteTable('delivery_outbox',{
 eventId:text('event_id').primaryKey(),
 caseId:text('case_id').notNull().references(()=>candidates.id),
 kind:text('kind').notNull(),
 businessKey:text('business_key').notNull(),
 payloadEncrypted:text('payload_encrypted').notNull(),
 state:text('state').notNull().default("PENDING"),
 attempts:integer('attempts').notNull().default(0),
 fence:integer('fence').notNull().default(0),
 leaseUntilMs:integer('lease_until_ms').notNull().default(0),
 nextAtMs:integer('next_at_ms').notNull(),
 providerReference:text('provider_reference'),
 errorCode:text('error_code'),
 createdAt:text('created_at').notNull()
});
export const caseConversations=sqliteTable('case_conversations',{
 conversationId:text('conversation_id').primaryKey(),
 caseId:text('case_id').notNull().references(()=>candidates.id),
 state:text('state').notNull().default("BOT_ACTIVE"),
 assignedTo:text('assigned_to').references(()=>users.userId),
 revision:integer('revision').notNull().default(0),
 automationGeneration:integer('automation_generation').notNull().default(0),
 lastSequence:integer('last_sequence').notNull().default(0),
 lastClientSequence:integer('last_client_sequence').notNull().default(0),
 createdAt:text('created_at').notNull(),
 updatedAt:text('updated_at').notNull()
});
export const caseChatMessages=sqliteTable('case_chat_messages',{
 messageId:text('message_id').primaryKey(),
 conversationId:text('conversation_id').notNull(),
 caseId:text('case_id').notNull(),
 sequence:integer('sequence').notNull(),
 senderId:text('sender_id').notNull().references(()=>users.userId),
 actorType:text('actor_type').notNull(),
 clientMessageId:text('client_message_id').notNull(),
 payloadHash:text('payload_hash').notNull(),
 kind:text('kind').notNull(),
 bodyEncrypted:text('body_encrypted').notNull(),
 evidenceId:text('evidence_id').references(()=>documents.id),
 automationGeneration:integer('automation_generation'),
 contextDataRevision:integer('context_data_revision'),
 contextRuleGeneration:integer('context_rule_generation'),
 inReplyToSequence:integer('in_reply_to_sequence'),
 createdAt:text('created_at').notNull()
});
export const caseChatReceipts=sqliteTable('case_chat_receipts',{
 conversationId:text('conversation_id').notNull().references(()=>caseConversations.conversationId),
 userId:text('user_id').notNull().references(()=>users.userId),
 deliveredSequence:integer('delivered_sequence').notNull().default(0),
 readSequence:integer('read_sequence').notNull().default(0),
 updatedAt:text('updated_at').notNull()
},t=>[primaryKey({columns:[t.conversationId,t.userId]})]);
export const caseInAppNotifications=sqliteTable('case_in_app_notifications',{
 notificationId:text('notification_id').primaryKey(),
 userId:text('user_id').notNull().references(()=>users.userId),
 caseId:text('case_id').notNull().references(()=>candidates.id),
 kind:text('kind').notNull(),
 resourceId:text('resource_id').notNull(),
 businessKey:text('business_key').notNull(),
 createdAt:text('created_at').notNull(),
 readAt:text('read_at')
});
export const caseChatTransitions=sqliteTable('case_chat_transitions',{
 transitionId:text('transition_id').primaryKey(),
 conversationId:text('conversation_id').notNull().references(()=>caseConversations.conversationId),
 requestKey:text('request_key').notNull(),
 requestHash:text('request_hash').notNull(),
 expectedRevision:integer('expected_revision').notNull(),
 oldState:text('old_state').notNull(),
 newState:text('new_state').notNull(),
 assignedTo:text('assigned_to').references(()=>users.userId),
 actorId:text('actor_id').notNull().references(()=>users.userId),
 createdAt:text('created_at').notNull()
});
export const officeBillingSettings=sqliteTable('office_billing_settings',{
 singleton:integer('singleton').primaryKey(),
 currency:text('currency'),
 updatedBy:text('updated_by').references(()=>users.userId),
 updatedAt:text('updated_at').notNull()
});
export const officeServiceCatalog=sqliteTable('office_service_catalog',{
 serviceId:text('service_id').primaryKey(),
 nameAr:text('name_ar').notNull(),
 nameEn:text('name_en').notNull(),
 priceCents:integer('price_cents').notNull(),
 currency:text('currency').notNull(),
 active:integer('active').notNull(),
 version:integer('version').notNull().default(1),
 updatedBy:text('updated_by').notNull().references(()=>users.userId),
 updatedAt:text('updated_at').notNull()
});

// v2.2 Gate 5 — 0030 (constraints and guards are authoritative in SQL).
export const casePurposeConsents=sqliteTable('case_purpose_consents',{caseId:text('case_id').notNull().references(()=>candidates.id),purpose:text('purpose').notNull(),granted:integer('granted',{mode:'boolean'}).notNull(),noticeVersion:text('notice_version').notNull(),updatedBy:text('updated_by').notNull(),updatedAt:text('updated_at').notNull()},t=>[primaryKey({columns:[t.caseId,t.purpose]})]);
export const clientServiceRequests=sqliteTable('client_service_requests',{requestId:text('request_id').primaryKey(),caseId:text('case_id').notNull().references(()=>candidates.id),serviceId:text('service_id').notNull().references(()=>officeServiceCatalog.serviceId),serviceVersion:integer('service_version').notNull(),requestKey:text('request_key').notNull().unique(),requestHash:text('request_hash').notNull(),state:text('state').notNull().default('REQUESTED'),note:text('note'),createdAt:text('created_at').notNull(),updatedAt:text('updated_at').notNull()},t=>[index('service_requests_case').on(t.caseId,t.createdAt,t.requestId)]);
export const officeEmployers=sqliteTable('office_employers',{employerId:text('employer_id').primaryKey(),name:text('name').notNull(),sourceUrl:text('source_url').notNull(),sourceCheckedOn:text('source_checked_on').notNull(),contactEncrypted:text('contact_encrypted'),version:integer('version').notNull().default(1),createdBy:text('created_by').notNull().references(()=>users.userId),createdAt:text('created_at').notNull(),updatedAt:text('updated_at').notNull()});
export const officeVacancies=sqliteTable('office_vacancies',{vacancyId:text('vacancy_id').primaryKey(),employerId:text('employer_id').notNull().references(()=>officeEmployers.employerId),title:text('title').notNull(),noc:text('noc'),sourceUrl:text('source_url').notNull(),postedOn:text('posted_on').notNull(),validUntil:text('valid_until'),status:text('status').notNull().default('OPEN'),version:integer('version').notNull().default(1),createdBy:text('created_by').notNull().references(()=>users.userId),createdAt:text('created_at').notNull(),updatedAt:text('updated_at').notNull()},t=>[index('vacancies_open').on(t.status,t.postedOn,t.vacancyId)]);
export const vacancyApplications=sqliteTable('vacancy_applications',{caseId:text('case_id').notNull().references(()=>candidates.id),vacancyId:text('vacancy_id').notNull().references(()=>officeVacancies.vacancyId),stage:text('stage').notNull(),version:integer('version').notNull().default(1),updatedBy:text('updated_by').notNull().references(()=>users.userId),updatedAt:text('updated_at').notNull()},t=>[primaryKey({columns:[t.caseId,t.vacancyId]})]);
// v2.2 Gate 6 — 0031 privacy lifecycle ledger (append-only; guards in SQL).
export const privacyRequests=sqliteTable('privacy_requests',{requestId:text('request_id').primaryKey(),caseId:text('case_id').notNull().references(()=>candidates.id),kind:text('kind').notNull(),state:text('state').notNull().default('REQUESTED'),reasonCode:text('reason_code'),requestKey:text('request_key').notNull().unique(),requestedBy:text('requested_by').notNull().references(()=>users.userId),completedBy:text('completed_by').references(()=>users.userId),resultJson:text('result_json'),createdAt:text('created_at').notNull(),completedAt:text('completed_at')},t=>[index('privacy_requests_case').on(t.caseId,t.createdAt,t.requestId)]);
