declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    BUCKET?: R2Bucket;
    OFFICE_ADMIN_EMAIL?: string;
    APP_SECRET?: string;
    VAULT_ENCRYPTION_KEY?: string;
    VAULT_ENCRYPTION_KEY_PREVIOUS?: string;
    SIGNING_SECRET?: string;
    PASSWORD_PEPPER?: string;
    TRUST_SITES_IDENTITY_HEADERS?: string;
    ADMIN_SETUP_TOKEN?: string;
    /** Optional v2.2 permission-policy cache. Absent = D1 only (D1 is always the authority). */
    PERMISSIONS_KV?: KVNamespace;
    PERMISSIONS_KV_NAMESPACE?: string;
    /** Optional v2.2 Gate 5 Durable Object namespace (CaseChatRoom) for WebSocket fan-out; absent = HTTP replay only. */
    CHAT_ROOMS?: DurableObjectNamespace;
    /** Optional v2.2 Gate 5 evidence scanner service binding; absent = uploads stay QUARANTINED. */
    EVIDENCE_SCANNER?: Fetcher;
  }
}
