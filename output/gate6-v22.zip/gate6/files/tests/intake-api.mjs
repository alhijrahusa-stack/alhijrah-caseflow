import {intakeSessionFixture} from './intake-session-fixture.mjs';
import {signIntake} from './signed-intake-fixture.mjs';
import assert from 'node:assert/strict';
import { seedOfficeManager } from './v22/office-fixture.mjs';
import {createRequire} from 'node:module';
import {readFile,readdir} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
const require=createRequire(import.meta.url),wr=createRequire(require.resolve('wrangler/package.json')),{Miniflare,createFetchMock}=wr('miniflare');
const mock=createFetchMock();mock.disableNetConnect();
const files=await readdir('dist/server',{recursive:true});
const mf=new Miniflare({modules:['index.js',...files.filter(f=>f!=='index.js'&&f.endsWith('.js'))].map(f=>({type:'ESModule',path:path.resolve('dist/server',f)})),modulesRoot:path.resolve('dist/server'),compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:{DB:'qa-intake-isolated'},r2Buckets:['BUCKET'],bindings:{TRUST_SITES_IDENTITY_HEADERS:'1',OFFICE_ADMIN_EMAIL:'admin@example.test',APP_SECRET:'b'.repeat(64)},fetchMock:mock,cf:false});
const base='http://desk.test',admin={'oai-authenticated-user-id':'owner','oai-authenticated-user-email':'admin@example.test'},outsider={'oai-authenticated-user-id':'outsider','oai-authenticated-user-email':'outsider@example.test'},employee={'oai-authenticated-user-id':'employee','oai-authenticated-user-email':'employee@example.test'};
async function request(url,method='GET',body,headers={},origin=base) {if(url==='/api/intake'&&method==='POST'&&body?.profile?.email)headers=await intakeSessionFixture(mf,body.profile.email,'b'.repeat(64),headers);body=await signIntake(mf,base,body,headers);const req=new Request(origin+url,{method,headers:{...(body&&!(body instanceof FormData)?{'Content-Type':'application/json'}:{}),...headers},body:body?(body instanceof FormData?body:JSON.stringify(body)):undefined});return mf.dispatchFetch(req.url,{method:req.method,headers:Object.fromEntries(req.headers),body:method==='GET'||method==='HEAD'?undefined:Buffer.from(await req.arrayBuffer())});}
async function json(r,status){assert.equal(r.status,status,await r.clone().text());return r.json();}
try{const db=await mf.getD1Database('DB');for(const file of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())for(const statement of (await readFile('drizzle/'+file,'utf8')).split('--> statement-breakpoint').map(s=>s.trim()).filter(Boolean))await db.prepare(statement).run();await seedOfficeManager(db,'owner');
for(const endpoint of ['/api/candidates','/api/new-clients','/api/office','/api/tasks','/api/team-review']){assert.equal((await request(endpoint)).status,401);assert.equal((await request(endpoint,'GET',null,outsider)).status,403);}
await json(await request('/api/office','GET',null,admin),200);
const payload={requestId:randomUUID(),profile:{fullName:'Intake QA <img src=x>',email:'client@example.test',phone:'+15551112222',nationality:'Yemen',country:'Yemen',occupation:'Farm worker',education:'secondary',consent:true},details:{city:'Sana’a',service:'work',passportExpiry:'2031-01-01',notes:'Client note',jobs:[{employer:'Farm A',title:'Farm worker',country:'Yemen',start:'2024-01',end:'2024-12',fullTime:true,duties:'Daily care',weekly_hours:40},{employer:'Farm B',title:'Farm worker',country:'Yemen',start:'2024-06',end:'2025-06',fullTime:true,duties:'Milking',weekly_hours:40}]},consentVersion:'intake-2026-11-v4',legalAuthorization:true};
assert.equal((await request('/api/intake','POST',{...payload,profile:{...payload.profile,consent:false}})).status,400);
assert.equal((await request('/api/intake','POST',payload,{origin:'https://attacker.test'})).status,403);
assert.equal((await request('/api/intake','POST',{...payload,requestId:randomUUID(),details:{...payload.details,passportExpiry:'2025-01-01'}})).status,422,'passport under 6 months blocks submission');
let r=await request('/api/intake','POST',payload),receipt=await json(r,201);assert.match(receipt.reference,/^ALH-CA-\d{4}-[A-F0-9]{12}$/);assert.match(receipt.accessCode,/^[a-f0-9]{64}$/);assert.equal(receipt.emailState,'pending');let cookie=r.headers.get('set-cookie').split(';')[0];await (await mf.getD1Database('DB')).prepare("update client_cases set details=json_set(details,'$.passportExpiry','2025-01-01') where candidate_id=(select id from candidates where reference=?)").bind(receipt.reference).run();assert.ok(r.headers.get('set-cookie').includes('HttpOnly'));assert.ok(r.headers.get('cache-control').includes('no-store'));
const retry=await json(await request('/api/intake','POST',payload),200);assert.equal(retry.reference,receipt.reference);assert.equal(retry.accessCode,receipt.accessCode);
assert.equal((await request('/api/intake','POST',{...payload,details:{...payload.details,notes:'changed'}})).status,409);
assert.equal((await request('/api/intake','POST',{...payload,requestId:randomUUID()})).status,409);
assert.equal((await request('/api/client')).status,401);assert.equal((await request('/api/client/access','POST',{reference:receipt.reference,code:'c'.repeat(64)})).status,403);
let client=await json(await request('/api/client','GET',null,{cookie}),200);assert.equal(client.reference,receipt.reference);assert.ok(client.screening.documents.some(d=>d.category==='passport'&&d.state==='missing'));assert.equal(client.screening.conflicts.length,2);assert.ok(!JSON.stringify(client).includes('ownerId'));assert.ok(!JSON.stringify(client).includes('accessHash'));
let inbox=await json(await request('/api/new-clients','GET',null,admin),200);assert.equal(inbox.total,1);const id=inbox.items[0].id;
const legacy=await json(await request('/api/candidates','POST',{fullName:'Internal QA',phone:'5550005555',consent:true,jobs:[{title:'QA role',employer:'QA employer',country:'Yemen',start:'2024-01',end:'2024-12',weekly_hours:40}]},admin),201);const list=await json(await request('/api/candidates','GET',null,admin),200);assert.equal(list.total,2,'new and legacy office files coexist');
let form=new FormData();form.append('category','passport');form.append('file',new Blob(['<!doctype html>'],{type:'image/jpeg'}),'fake.jpg');assert.equal((await request('/api/client/documents','POST',form,{cookie})).status,400,'file magic enforced');
form=new FormData();form.append('category','passport');form.append('file',new Blob([new Uint8Array([255,216,255,1,2,3,4])],{type:'image/jpeg'}),'passport.jpg');await json(await request('/api/client/documents','POST',form,{cookie}),201);await json(await request('/api/client/documents','POST',form,{cookie}),201);
client=await json(await request('/api/client','GET',null,{cookie}),200);assert.equal(client.documents.length,1,'duplicate upload is idempotent');assert.equal(client.documents[0].verified,false);assert.equal(client.screening.documents.find(d=>d.category==='passport').state,'uploaded');const docId=client.documents[0].id;
assert.equal((await request('/api/documents/'+docId)).status,401);assert.equal((await request('/api/documents/'+docId,'GET',null,outsider)).status,403);
let detail=await json(await request('/api/candidates/'+id,'GET',null,admin),200);assert.equal(detail.documents.length,1);await json(await request('/api/documents/'+docId,'PATCH',{verified:true},admin),200);client=await json(await request('/api/client','GET',null,{cookie}),200);assert.equal(client.screening.documents.find(d=>d.category==='passport').state,'reviewed');
const public2=await json(await request('/api/intake','POST',{...payload,requestId:randomUUID(),profile:{...payload.profile,fullName:'Other QA',email:'other-client@example.test',phone:'5559990001'}}),201);const otherCookie='alh_client_access='+public2.accessCode;assert.equal((await request('/api/client/documents/'+docId,'GET',null,{cookie:otherCookie})).status,404);
detail=await json(await request('/api/candidates/'+id,'GET',null,admin),200);
await json(await request('/api/candidates/'+id,'PATCH',{version:detail.version,note:'INTERNAL ONLY SECRET NOTE'},admin),200);
let review=await json(await request('/api/candidates/'+id+'/client','GET',null,admin),200);await json(await request('/api/candidates/'+id+'/client','PATCH',{version:review.client.version,inbox:'needs_info',instructions:'Please upload your resume',requestedDocuments:['resume'],followUpDate:'2026-12-01'},admin),200);assert.equal((await request('/api/candidates/'+id+'/client','PATCH',{version:review.client.version,inbox:'accepted',instructions:'old',requestedDocuments:[]},admin)).status,409);
client=await json(await request('/api/client','GET',null,{cookie}),200);assert.equal(client.status,'documents');assert.equal(client.instructions,'Please upload your resume');assert.equal(client.followUpDate,'2026-12-01');assert.ok(!JSON.stringify(client).includes('INTERNAL ONLY'));
const message=await json(await request('/api/candidates/'+id+'/messages','POST',{requestKey:randomUUID(),subject:'Document request',body:'Please attach the requested documents.'},admin),200);assert.equal(message.state,'pending');assert.equal(message.needsConfiguration,true);client=await json(await request('/api/client','GET',null,{cookie}),200);assert.ok(!client.messages.some(m=>m.subject==='Document request'),'unsent staff drafts are private');
await json(await request('/api/office','POST',{action:'member',email:'employee@example.test',name:'QA Employee',active:true},admin),200);await json(await request('/api/candidates/'+id,'GET',null,employee),200);assert.equal((await request('/api/office','POST',{action:'mail',sender:'office@example.test',key:'re_abcdefghijklmno'},employee)).status,403);
await json(await request('/api/office','POST',{action:'mail',sender:'office@example.test',key:'re_abcdefghijklmno'},admin),200);const office=await json(await request('/api/office','GET',null,admin),200);assert.equal(office.mail.configured,true);assert.ok(!JSON.stringify(office).includes('re_abcdefghijklmno'),'secret never returned');const settings=await db.prepare('select mail_key from office_settings').first();assert.ok(!settings.mail_key.includes('re_'),'mail key encrypted at rest');
mock.get('https://api.resend.com').intercept({path:'/emails',method:'POST',headers:headers=>!!headers['idempotency-key']}).reply(200,{id:'provider-qa-1'});
const sent=await json(await request('/api/candidates/'+id+'/messages','POST',{messageId:message.id},employee),200);assert.equal(sent.state,'sent');
await json(await request('/api/candidates/'+id+'/messages','POST',{messageId:message.id},employee),200);client=await json(await request('/api/client','GET',null,{cookie}),200);assert.ok(client.messages.some(m=>m.subject==='Document request'));
mock.get('https://api.resend.com').intercept({path:'/emails',method:'POST'}).reply(403,{message:'Unverified sender'});
const failed=await json(await request('/api/candidates/'+id+'/messages','POST',{requestKey:randomUUID(),subject:'Rejected send',body:'This send should fail.'},admin),200);assert.equal(failed.state,'failed');
mock.get('https://api.resend.com').intercept({path:'/emails',method:'POST'}).reply(500,{message:'uncertain'});
const uncertain=await json(await request('/api/candidates/'+id+'/messages','POST',{requestKey:randomUUID(),subject:'Uncertain send',body:'This send is unconfirmed.'},admin),200);assert.equal(uncertain.state,'unknown');assert.equal((await request('/api/candidates/'+id+'/messages','POST',{messageId:uncertain.id},admin)).status,409,'uncertain send is not duplicated');

mock.get('https://api.resend.com').intercept({path:'/emails',method:'POST'}).reply(200,{id:'provider-qa-auto'});
const automaticPayload={...payload,details:{...payload.details,preferredLanguage:'en'},requestId:randomUUID(),profile:{...payload.profile,fullName:'Automatic Receipt QA',phone:'+15554445555',email:'auto@example.test'}};
const automatic=await json(await request('/api/intake','POST',automaticPayload),201);assert.equal(automatic.emailState,'sent','configured initial receipt reaches the provider');
const automaticRetry=await json(await request('/api/intake','POST',automaticPayload),200);assert.equal(automaticRetry.emailState,'sent','retry reports the persisted actual mail state');assert.equal(automaticRetry.reference,automatic.reference);const englishReceipt=await db.prepare('select subject, body from client_messages where recipient = ?').bind('auto@example.test').first();assert.ok(englishReceipt.subject.startsWith('Application received'));assert.ok(englishReceipt.body.includes('ALHIJRAH has received'));
const storedBodies=await db.prepare('select body from client_messages').all();assert.ok(storedBodies.results.every(m=>!m.body.includes(receipt.accessCode)),'raw access codes are not stored in email bodies');
const adminPage=await request('/','GET',null,admin);assert.equal(adminPage.status,200);const adminHtml=await adminPage.text();assert.ok(adminHtml.includes('New Clients'),'new inbox is present in the real admin application');

// Minimal intake requires only the three contact fields; all other answers can be added later.
const minimalPayload={requestId:randomUUID(),profile:{fullName:'Three Field QA',phone:'+١٥٥٥٦٦٦٧٧٧٧',email:'minimal@example.test',consent:true},consentVersion:'intake-2026-11-v4',legalAuthorization:true};
mock.get('https://api.resend.com').intercept({path:'/emails',method:'POST'}).reply(200,{id:'provider-qa-minimal'});
const minimalResponse=await request('/api/intake','POST',minimalPayload,{'cf-connecting-ip':'192.0.2.42'}),minimal=await json(minimalResponse,201);assert.equal(minimal.profile.country,'');assert.equal(minimal.profile.nationality,'');assert.equal(minimal.profile.phone,'+15556667777');assert.equal(minimal.profile.occupation,'');
for(const key of ['fullName','phone','email']){const profile={...minimalPayload.profile};delete profile[key];assert.equal((await request('/api/intake','POST',{...minimalPayload,requestId:randomUUID(),profile},{'cf-connecting-ip':'192.0.2.42'})).status,400,key+' is required');}
const minimalCookie=minimalResponse.headers.get('set-cookie').split(';')[0];
let minimalData=await json(await request('/api/client','GET',null,{cookie:minimalCookie}),200);assert.ok(minimalData.screening.missingFields.includes('بلد الإقامة'));assert.equal(minimalData.details.service,'unknown');
await json(await request('/api/client','PATCH',{version:minimalData.version,profile:{country:'Canada'},details:{...minimalData.details,jobs:[{title:'Partial role'}],companions:[{relationship:'child'}]}},{cookie:minimalCookie}),200);
assert.equal((await request('/api/client','PATCH',{version:minimalData.version,profile:{country:'Yemen'},details:minimalData.details},{cookie:minimalCookie})).status,409,'stale client update rejected');
minimalData=await json(await request('/api/client','GET',null,{cookie:minimalCookie}),200);assert.equal(minimalData.profile.country,'Canada');assert.equal(minimalData.details.jobs[0].start,'');assert.equal(minimalData.details.companions[0].name,'');
assert.equal((await request('/api/client','PATCH',{version:minimalData.version,profile:{email:'attacker@example.test'},details:minimalData.details},{cookie:minimalCookie})).status,400,'contact fields cannot be changed through supplements');
// Both production hostnames generate canonical receipt, email, and dashboard links.
const canonical='https://canada.careergate.us';
for(const [index,origin] of ['https://alhijrah-canada-desk.alhijrah.chatgpt.site',canonical].entries()){
 let emailBody='';
 mock.get('https://api.resend.com').intercept({path:'/emails',method:'POST'}).reply(200,async ({body})=>{emailBody=JSON.parse(await new Response(body).text()).text;return {id:'provider-domain-'+index};});
 const domainPayload={...minimalPayload,requestId:randomUUID(),profile:{...minimalPayload.profile,fullName:'Canonical Domain QA '+index,email:'domain-'+index+'@example.test',phone:'+1555888000'+index}};
 const headers={origin,'cf-connecting-ip':'192.0.2.'+(70+index)};
 const response=await request('/api/intake','POST',domainPayload,headers,origin),issued=await json(response,201);
 assert.equal(issued.emailState,'sent');assert.ok(emailBody.includes(canonical+'/client/login?case='+issued.reference),'outgoing tracking links use the custom domain');assert.ok(!emailBody.includes('.chatgpt.site'));
 assert.ok(issued.verificationUrl.startsWith(canonical+'/verify/'));
 const retried=await json(await request('/api/intake','POST',domainPayload,headers,origin),200);assert.equal(retried.verificationUrl,issued.verificationUrl);
 const domainCookie=response.headers.get('set-cookie').split(';')[0];
 const dashboard=await json(await request('/api/client','GET',null,{cookie:domainCookie},origin),200);assert.equal(dashboard.verificationUrl,issued.verificationUrl);
}
// Public verification proves only a receipt exists; no customer details are exposed.
assert.ok(receipt.verificationUrl.startsWith(base+'/verify/'));let verification=await request(receipt.verificationUrl.slice(base.length));assert.equal(verification.status,200);let verificationHtml=await verification.text();assert.ok(verificationHtml.includes(receipt.reference));assert.ok(!verificationHtml.includes(payload.profile.email));assert.ok(!verificationHtml.includes(payload.profile.fullName));
const tampered=receipt.verificationUrl.slice(0,-1)+(receipt.verificationUrl.endsWith('a')?'b':'a');verificationHtml=await (await request(tampered.slice(base.length))).text();assert.ok(!verificationHtml.includes(receipt.reference),'modified verification signatures reveal no receipt');
// Maker/reviewer: a separate authorized staff member must perform the review.
let team=await json(await request('/api/candidates/'+id+'/review','GET',null,admin),200);assert.equal(team.review,null);
await json(await request('/api/candidates/'+id+'/review','POST',{version:0,action:'submit'},admin),200);
const allChecks={identity:true,contacts:true,dates:true,evidence:true,wording:true,consent:true};
assert.equal((await request('/api/candidates/'+id+'/review','POST',{version:1,action:'approve',checklist:allChecks},admin)).status,403,'preparer cannot approve their own case');
assert.equal((await request('/api/candidates/'+id+'/review','POST',{version:1,action:'approve'},employee)).status,400,'checklist required');
assert.equal((await request('/api/candidates/'+id+'/review','POST',{version:1,action:'approve',checklist:allChecks},employee)).status,400,'reviewed resume required');
const resume=new FormData();resume.append('category','resume');resume.append('file',new Blob(['%PDF-1.4 test resume']),'resume.pdf');await json(await request('/api/candidates/'+id+'/documents','POST',resume,admin),201);
detail=await json(await request('/api/candidates/'+id,'GET',null,admin),200);await json(await request('/api/documents/'+detail.documents.find(d=>d.category==='resume').id,'PATCH',{verified:true},admin),200);
assert.equal((await request('/api/candidates/'+id+'/review','POST',{version:1,action:'approve',checklist:allChecks},employee)).status,409,'document updates invalidate the submitted revision');
await json(await request('/api/candidates/'+id+'/review','POST',{version:1,action:'submit'},admin),200);
assert.equal((await request('/api/candidates/'+id+'/review','POST',{version:2,action:'approve',checklist:allChecks},employee)).status,400,'critical expired-passport flag prevents administrative approval');
client=await json(await request('/api/client','GET',null,{cookie}),200);
await json(await request('/api/client','PATCH',{version:client.version,profile:{},details:{...client.details,passportExpiry:'2030-01-01'}},{cookie}),200);
assert.equal((await request('/api/candidates/'+id+'/review','POST',{version:2,action:'approve',checklist:allChecks},employee)).status,409,'client updates invalidate the submitted revision');
await json(await request('/api/candidates/'+id+'/review','POST',{version:2,action:'submit'},admin),200);
await json(await request('/api/candidates/'+id+'/review','POST',{version:3,action:'request_changes',note:'Clarify the work dates.'},employee),200);
await json(await request('/api/candidates/'+id+'/review','POST',{version:4,action:'submit',checklist:allChecks},admin),200);
team=await json(await request('/api/candidates/'+id+'/review','GET',null,employee),200);assert.deepEqual(team.review.checklist,{},'resubmission clears prior review confirmations');
await json(await request('/api/candidates/'+id+'/review','POST',{version:5,action:'approve',checklist:allChecks,note:'Administrative documents checked.'},employee),200);
let teamQueue=await json(await request('/api/team-review?state=approved','GET',null,admin),200);assert.ok(teamQueue.items.some(c=>c.id===id&&c.reviewedBy==='employee@example.test'));
detail=await json(await request('/api/candidates/'+id,'GET',null,admin),200);assert.ok(detail.events.some(e=>e.action.includes('مراجع مستقل')&&e.note.includes('employee@example.test')),'independent review is audited');
await json(await request('/api/candidates/'+id,'PATCH',{version:detail.version,note:'Updated information for review.'},admin),200);
teamQueue=await json(await request('/api/team-review?state=stale','GET',null,admin),200);assert.ok(teamQueue.items.some(c=>c.id===id),'approved cases become stale after subsequent changes');
await json(await request('/api/office','POST',{action:'member',email:'employee@example.test',name:'QA Employee',active:false},admin),200);assert.equal((await request('/api/candidates','GET',null,employee)).status,403);
await json(await request('/api/client/access','DELETE',null,{cookie}),200);
for(const route of ['/apply','/client','/privacy']){const html=await request(route);assert.equal(html.status,200);assert.ok((await html.text()).includes('ALHIJRAH'));}
console.log('Intake API passed: three-field submission, optional partial jobs/companions, secure supplements, privacy-safe signed receipt verification, independent team review, stale approval detection, follow-up dates, bilingual receipts, consent, durable server case, retry deduplication, private access, cross-client isolation, uploads, screening, review, protected staff roles, encrypted mail credentials, actual provider result handling, and no duplicate uncertain sends.');
}finally{await mf.dispose();}
