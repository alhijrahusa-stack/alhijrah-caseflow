import {intakeSessionFixture} from './intake-session-fixture.mjs';
import {signIntake} from './signed-intake-fixture.mjs';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,readdir} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';

const require=createRequire(import.meta.url),wr=createRequire(require.resolve('wrangler/package.json')),{Miniflare}=wr('miniflare');
const files=await readdir('dist/server',{recursive:true}),messages=[];
const mf=new Miniflare({modules:['index.js',...files.filter(f=>f!=='index.js'&&f.endsWith('.js'))].map(f=>({type:'ESModule',path:path.resolve('dist/server',f)})),modulesRoot:path.resolve('dist/server'),compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:{DB:'qa-identity-isolated'},r2Buckets:['BUCKET'],bindings:{TRUST_SITES_IDENTITY_HEADERS:'1',OFFICE_ADMIN_EMAIL:'admin@example.test',APP_SECRET:'e'.repeat(64)},outboundService:async request=>{
  assert.equal(new URL(request.url).origin,'https://api.resend.com','all external traffic is mocked');
  messages.push(await request.json());return Response.json({id:randomUUID()});
},cf:false});
const base='http://identity.test',admin={'oai-authenticated-user-id':'office-owner','oai-authenticated-user-email':'admin@example.test'};
async function request(url,method='GET',body,headers={}) {if(url==='/api/intake'&&method==='POST'&&body?.profile?.email)headers=await intakeSessionFixture(mf,body.profile.email,'e'.repeat(64),headers);body=await signIntake(mf,base,body,headers);return mf.dispatchFetch(base+url,{method,headers:{...(body?{'Content-Type':'application/json'}:{}),...headers},body:body?JSON.stringify(body):undefined});}
async function json(response,status=200){assert.equal(response.status,status,await response.clone().text());return response.json();}
const payload=profile=>({requestId:randomUUID(),profile:{...profile,consent:true},consentVersion:'intake-2026-11-v4',legalAuthorization:true});
const cookie=response=>response.headers.get('set-cookie').split(';')[0];

try{
  const db=await mf.getD1Database('DB');
  async function migration(file){for(const statement of (await readFile('drizzle/'+file,'utf8')).split('--> statement-breakpoint').map(s=>s.trim()).filter(Boolean))await db.prepare(statement).run();}
  const migrations=(await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort();
  for(const file of migrations.filter(f=>!f.startsWith('0010_')))await migration(file);
  const old={fullName:'أَحْمَد  علي',phone:'00967 777-111-222',email:'Old.Client@Example.Test',consent:true};
  for(const [id,name] of [['legacy-one',old.fullName],['legacy-two','Different old spelling']])await db.prepare("INSERT INTO candidates(id,owner_id,reference,profile,assessment,status,created_at,updated_at,dedupe_key,email_key) VALUES (?,?,?,?,?,'new',?,?,?,?)").bind(id,'office:alhijrah-canada','CA-OLD-'+id,JSON.stringify({...old,fullName:name}),'{}','2026-01-01','2026-01-01',name+'|967777111222',name+'|old.client@example.test').run();
  const before=await db.prepare('SELECT id,reference,profile FROM candidates ORDER BY id').all();
  for(const file of migrations.filter(f=>f.startsWith('0010_')))await migration(file);
  assert.deepEqual((await db.prepare('SELECT id,reference,profile FROM candidates ORDER BY id').all()).results,before.results,'migration retains existing files, including historical duplicates');
  await json(await request('/api/office','GET',null,admin));
  const reset=()=>db.prepare('DELETE FROM rate_limits').run();
  const primary={fullName:'أحمد حسن علي',phone:'+967 777-222-333',email:'ahmad@example.test'};
  const initialPayload=payload(primary),initialResponse=await request('/api/intake','POST',initialPayload),initial=await json(initialResponse,201);
  assert.equal((await db.prepare('SELECT identity_version FROM candidates WHERE reference=?').bind(initial.reference).first()).identity_version,1);
  const variants=[
    {...primary,fullName:'اَحمد حسن   علي',phone:'٠٠٩٦٧٧٧٧٢٢٢٣٣٣',email:' AHMad@EXAMPLE.TEST '},
    {...primary,fullName:'أحمد حسن علي',phone:'+۹۶۷ (۷۷۷) ۲۲۲-۳۳۳',email:'different@example.test'},
    {...primary,phone:'+15550000999'},
    {...primary,fullName:'Different name spelling'},
  ];
  for(const variant of variants){const body=await json(await request('/api/intake','POST',payload(variant)),409);assert.equal(body.code,'APPLICATION_EXISTS');assert.ok(!JSON.stringify(body).includes(initial.reference),'previous reference is protected until contact verification');assert.ok(!('profile' in body));}
  await json(await request('/api/intake','POST',payload({fullName:'احمد علي',phone:'+967777111222',email:'new-old@example.test'})),409);
  await json(await request('/api/intake','POST',payload({fullName:'A changed legacy name',phone:'+967777111222',email:'old.client@example.test'})),409);
  const count=await db.prepare('SELECT count(*) n FROM candidates').first();assert.equal(count.n,3,'duplicate attempts add no files');
  const retry=await json(await request('/api/intake','POST',initialPayload),200);assert.equal(retry.reference,initial.reference);
  await json(await request('/api/intake','POST',{...initialPayload,profile:{...initialPayload.profile,email:'changed@example.test'}}),409);
  await reset();
  for(const profile of [
    {...primary,fullName:'Another family member',email:'family@example.test'},
    {...primary,fullName:'Different applicant',phone:'+15551112223'},
    {...primary,phone:'+15551112224',email:'other-ahmad@example.test'},
  ])await json(await request('/api/intake','POST',payload(profile)),201);
  const simultaneous={fullName:'Concurrent Applicant',phone:'+15552223333',email:'concurrent@example.test'};
  const raced=await Promise.all([request('/api/intake','POST',payload(simultaneous)),request('/api/intake','POST',payload({...simultaneous,fullName:'Concurrent spelling variation'}))]);
  assert.deepEqual(raced.map(r=>r.status).sort(),[201,409],'contact-pair unique constraint closes concurrent name variations');
  assert.equal((await db.prepare("SELECT count(*) n FROM candidates WHERE json_extract(profile,'$.email')=?").bind(simultaneous.email).first()).n,1);
  assert.equal((await db.prepare('SELECT count(*) n FROM events e LEFT JOIN candidates c ON c.id=e.candidate_id WHERE c.id IS NULL').first()).n,0,'failed batch leaves no audit orphans');
  const cross={fullName:'Office and portal race',phone:'+15553334444',email:'cross@example.test',consent:true};
  const officeJobs=[{title:'QA role',employer:'QA employer',country:'Yemen',start:'2024-01',end:'2024-12',weekly_hours:40}];
  const crossRace=await Promise.all([request('/api/candidates','POST',{...cross,jobs:officeJobs},admin),request('/api/intake','POST',payload({...cross,fullName:'Office portal alternate spelling'}))]);
  assert.deepEqual(crossRace.map(r=>r.status).sort(),[201,409],'office and public intake share a database uniqueness boundary');
  const internal={fullName:'Already registered by office',phone:'+15554445555',email:'internal@example.test',consent:true};
  const internalReceipt=await json(await request('/api/candidates','POST',{...internal,jobs:officeJobs},admin),201);
  await json(await request('/api/intake','POST',payload({...internal,fullName:'Updated office spelling'})),409);
  const csv='fullName,phone,email\nCSV other spelling,'+primary.phone+','+primary.email;
  const csvResult=await json(await request('/api/candidates/import','POST',{mode:'preview',csv},admin));assert.equal(csvResult.duplicates,1,'CSV uses the same contact-pair policy');assert.equal(csvResult.rows[0].reference,initial.reference);
  assert.equal((await request('/api/intake/recover','POST',{profile:primary,channel:'email',requestKey:randomUUID()})).status,503,'unconfigured channels never claim to send');
  await json(await request('/api/office','POST',{action:'mail',sender:'office@example.test',key:'re_abcdefghijklmnopqrst'},admin));
  const recovery={profile:primary,channel:'email',locale:'ar',requestKey:randomUUID()};
  await json(await request('/api/intake/recover','POST',recovery,{origin:'https://attacker.test'}),403);
  await json(await request('/api/intake/recover','POST',{...recovery,destination:'attacker@example.test'}),400);
  await json(await request('/api/intake/recover','POST',{...recovery,channel:'whatsapp'}),400,'WhatsApp requires explicit consent');
  await reset();
  let challenge=await json(await request('/api/intake/recover','POST',{...recovery,profile:{...primary,email:'attacker@example.test'}}));
  assert.deepEqual(Object.keys(challenge).sort(),['expiresAt','requestId','resendAfter']);
  assert.deepEqual(messages.at(-1).to,[primary.email],'delivery uses the stored email even when a caller supplies a different one');
  const otp=messages.at(-1).text.match(/\b\d{6}\b/)[0];assert.ok(!JSON.stringify(challenge).includes(otp));
  const calls=messages.length;
  assert.equal((await json(await request('/api/intake/recover','POST',{...recovery,profile:{...primary,email:'attacker@example.test'}}))).requestId,challenge.requestId);assert.equal(messages.length,calls,'recovery retry sends one message');
  await json(await request('/api/intake/recover','POST',{...recovery,requestKey:randomUUID()}),429,'stored case cooldown applies across submitted contact variations');
  await json(await request('/api/client/otp/verify','POST',{requestId:challenge.requestId,code:otp==='000000'?'000001':'000000'}),400);
  const verified=await request('/api/client/otp/verify','POST',{requestId:challenge.requestId,code:otp});await json(verified);
  const view=await json(await request('/api/client','GET',null,{cookie:cookie(verified)}));assert.equal(view.reference,initial.reference,'previous case number is returned after proof of contact');
  await json(await request('/api/client/otp/verify','POST',{requestId:challenge.requestId,code:otp}),400,'recovery code is single use');
  assert.equal((await request('/api/client')).status,401,'recovery does not expose a file without a session');
  await reset();
  const unknown=await json(await request('/api/intake/recover','POST',{...recovery,requestKey:randomUUID(),profile:{fullName:'Unregistered',phone:'+15557778888',email:'unregistered@example.test'}}));assert.deepEqual(Object.keys(unknown).sort(),Object.keys(challenge).sort());assert.equal(messages.length,calls,'unmatched recovery cannot send to an attacker-selected contact');await json(await request('/api/client/otp/verify','POST',{requestId:unknown.requestId,code:'123456'}),400);
  const internalChallenge=await json(await request('/api/intake/recover','POST',{...recovery,requestKey:randomUUID(),profile:((({consent,...rest})=>rest)(internal))}));assert.equal(messages.length,calls,'internal-only files require office handover rather than implicit portal access');assert.ok(!JSON.stringify(internalChallenge).includes(internalReceipt.reference));
  const officeRows=await json(await request('/api/candidates','GET',null,admin));assert.ok(officeRows.items.every(c=>!('contactPairKey' in c)&&!('identityVersion' in c)));
  for(const id of ['legacy-one','legacy-two'])await json(await request('/api/candidates/'+id,'PATCH',{version:1,status:'reviewing'},admin));
  assert.equal((await db.prepare("SELECT count(*) n FROM candidates WHERE id IN ('legacy-one','legacy-two') AND identity_version=0").first()).n,2,'unrelated status updates do not rewrite or merge legacy identities');
  const internalRow=await json(await request('/api/candidates/'+internalReceipt.id,'GET',null,admin));
  await json(await request('/api/candidates/'+internalReceipt.id,'PATCH',{version:internalRow.version,profile:{...internalRow.profile,phone:primary.phone,email:primary.email}},admin),409,'staff contact changes cannot duplicate a public case');
  const authenticated=await request('/api/client','GET',null,{cookie:cookie(initialResponse)});assert.equal(authenticated.status,200,'original client session and data remain available');
  console.log('Identity tests passed: preserved legacy data; Arabic/Persian digits and name normalization; all three identity pairs; family shared-contact exceptions; public/staff and same-office concurrent uniqueness; CSV policy; structured duplicate responses; retry safety; saved-contact recovery; no public case-number disclosure; consent/cooldown/replay controls. All email calls were mocked.');
}finally{await mf.dispose();}
