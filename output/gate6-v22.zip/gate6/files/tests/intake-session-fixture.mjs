import {createCipheriv,randomBytes,randomUUID,createHash} from 'node:crypto';
export async function intakeSessionFixture(mf,email,secret,headers={}){
 if(!email)return headers;if((headers.cookie||'').includes('alh_application_account='))return headers;
 const id=randomUUID(),token=randomBytes(32).toString('hex'),expiresAt=Date.now()+3600000,hash=s=>createHash('sha256').update(s).digest('hex'),normalized=email.trim().toLowerCase(),db=await mf.getD1Database('DB');
 await db.prepare('INSERT INTO auth_challenges (id, channel, purpose, contact_hash, code_hash, request_key, state, attempts, used_at, consumed_by, expires_at, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)').bind(id,'account_email','account_login',hash(normalized),'fixture-code',randomUUID(),'accepted',0,Date.now(),hash(token),expiresAt,Date.now()).run();
 const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',Buffer.from(secret,'hex'),iv),encrypted=Buffer.concat([cipher.update(JSON.stringify({id,email:normalized,token,expiresAt}),'utf8'),cipher.final(),cipher.getAuthTag()]),value=Buffer.concat([iv,encrypted]).toString('hex');return {...headers,cookie:[headers.cookie,'alh_application_account='+value].filter(Boolean).join('; ')};
}
