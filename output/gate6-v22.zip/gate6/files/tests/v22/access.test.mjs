// v2.2 Gate 2 — identity, four roles and server-side permissions on the built Worker (Workers/D1/KV local via
// Miniflare, no D1/KV mocks). Office policy: all active staff see every case; assignment by name/email by any staff. Forged
// role/session/scope, Toggles with audit+epoch, stale-KV revocation, deactivation, concurrent toggles, root protection,
// the STAFF open switch (no MANAGER authority), expiry with a stopped cron, AUTO_KILL dedupe, DST/new-year days, and a
// financial transaction crossing expiry rolling back. API/KV/UI criteria of later gates stay NOT_RUN.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { seedOfficeManager } from './office-fixture.mjs';
import { torontoDate, nextTorontoMidnightMs, openAllActive } from '../../lib/v22-core.ts';

const require = createRequire(import.meta.url);
const { Miniflare } = createRequire(require.resolve('wrangler/package.json'))('miniflare');
const sha = s => createHash('sha256').update(s).digest('hex');
const base = 'http://canada-desk.test';
const id = (uid, email) => ({ 'oai-authenticated-user-id': uid, 'oai-authenticated-user-email': email });
const admin = id('admin-1', 'admin@example.test'), staffA = id('staff-a', 'staff-a@example.test'), staffB = id('staff-b', 'staff-b@example.test'), stranger = id('x-1', 'stranger@example.test');

let mf, db, kv, send;
const json = async (r, status = 200) => { const t = await r.text(); assert.equal(r.status, status, t); return t ? JSON.parse(t) : null; };
const key = () => crypto.randomUUID();
const profile = (n, phone) => ({ fullName: 'QA Gate2 ' + n, phone, consent: true, jobs: [{ title: 'QA role', employer: 'QA employer', country: 'Yemen', start: '2024-01', end: '2024-12', weekly_hours: 40 }], occupation: 'Synthetic test', noc: '72401', teer: 2, experience3: 12, experience10: 24, englishMin: 5, englishDate: '2026-10-01' });
const perms = () => send('/api/office/permissions', 'GET', undefined, admin).then(r => json(r));

test.before(async () => {
  const files = await readdir('dist/server', { recursive: true });
  mf = new Miniflare({
    modules: ['index.js', ...files.filter(f => f !== 'index.js' && f.endsWith('.js'))].map(f => ({ type: 'ESModule', path: path.resolve('dist/server', f) })),
    modulesRoot: path.resolve('dist/server'), compatibilityDate: '2026-05-15', compatibilityFlags: ['nodejs_compat'],
    d1Databases: { DB: 'gate2-db' }, r2Buckets: ['BUCKET'], kvNamespaces: { PERMISSIONS_KV: 'gate2-kv' },
    bindings: { TRUST_SITES_IDENTITY_HEADERS: '1', OFFICE_ADMIN_EMAIL: 'admin@example.test', APP_SECRET: 'a'.repeat(64), PERMISSIONS_KV_NAMESPACE: 'test' },
    outboundService: async () => new Response('blocked', { status: 599 }),
  });
  send = (p, method = 'GET', body, headers = {}) => mf.dispatchFetch(base + p, { method, headers: { ...(body ? { 'content-type': 'application/json' } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined });
  db = await mf.getD1Database('DB'); kv = await mf.getKVNamespace('PERMISSIONS_KV');
  for (const f of (await readdir('drizzle')).filter(f => f.endsWith('.sql')).sort())
    for (const s of (await readFile('drizzle/' + f, 'utf8')).split('--> statement-breakpoint').map(s => s.trim()).filter(Boolean)) await db.prepare(s).run();
  await seedOfficeManager(db, 'admin-1');
  await json(await send('/api/office', 'GET', undefined, admin));
  for (const s of [['staff-a@example.test', 'QA Staff A'], ['staff-b@example.test', 'QA Staff B']])
    await json(await send('/api/office', 'POST', { action: 'member', email: s[0], name: s[1], active: true }, admin));
});
test.after(async () => { await mf?.dispose(); });

const cases = {};
test('office visibility: every active STAFF member sees all cases, sub-resources, tasks and client-portal cases at once', async () => {
  cases.m1 = (await json(await send('/api/candidates', 'POST', profile('M1', '+15553330001'), admin), 201));
  cases.a1 = (await json(await send('/api/candidates', 'POST', profile('A1', '+15553330002'), staffA), 201));
  const now = new Date().toISOString(), portal = crypto.randomUUID();
  await db.prepare("INSERT INTO candidates(id,owner_id,reference,profile,assessment,source,created_at,updated_at) VALUES(?,'office:alhijrah-canada',?,?,'{}','client',?,?)").bind(portal, 'ALH-CA-PORTAL1', JSON.stringify({ fullName: 'QA Portal Client' }), now, now).run();
  cases.portal = { id: portal };
  for (const who of [staffA, staffB, admin]) {
    const list = await json(await send('/api/candidates', 'GET', undefined, who));
    for (const c of [cases.m1.id, cases.a1.id, portal]) assert.ok(list.items.some(i => i.id === c), 'sees ' + c);
  }
  const search = await json(await send('/api/candidates?q=' + encodeURIComponent(cases.m1.reference), 'GET', undefined, staffB));
  assert.equal(search.total, 1, 'search finds a case created by someone else');
  assert.equal((await send('/api/candidates/' + cases.m1.id, 'GET', undefined, staffB)).status, 200, 'no assignment needed');
  assert.equal((await send('/api/candidates/' + cases.a1.id + '/preliminary', 'GET', undefined, staffB)).status, 200);
  const tasksB = await json(await send('/api/tasks', 'GET', undefined, staffB)); assert.ok(tasksB.total >= 2, 'tasks of all cases');
  const state = await json(await send('/api/office/engine/state', 'GET', undefined, staffB)); assert.ok(state.files >= 3, 'office aggregates');
  assert.equal((await send('/api/candidates/00000000-0000-4000-8000-000000000000', 'GET', undefined, staffB)).status, 404);
});
test('assignment by name or email by any staff member; ambiguous names ask for the email', async () => {
  const get = async (c, who = staffA) => json(await send('/api/candidates/' + c, 'GET', undefined, who));
  const assign = async (c, value, who, status = 200) => { const v = (await get(c, who)).version; return json(await send('/api/candidates/' + c, 'PATCH', { version: v, assignedTo: value }, who), status); };
  await assign(cases.m1.id, 'QA Staff B', staffA);
  assert.equal((await get(cases.m1.id)).assignedTo, 'QA Staff B');
  assert.deepEqual((await db.prepare('SELECT user_id FROM case_access WHERE case_id=?').bind(cases.m1.id).all()).results, [{ user_id: 'staff:staff-b@example.test' }], 'name resolved to the staff member');
  await assign(cases.m1.id, 'STAFF-A@example.test', staffB);
  assert.deepEqual((await db.prepare('SELECT user_id FROM case_access WHERE case_id=?').bind(cases.m1.id).all()).results, [{ user_id: 'staff:staff-a@example.test' }], 'email resolved, case-insensitive');
  await assign(cases.a1.id, 'qa staff a', staffA);
  assert.deepEqual((await db.prepare('SELECT user_id FROM case_access WHERE case_id=? ORDER BY user_id').bind(cases.a1.id).all()).results, [{ user_id: 'staff:staff-a@example.test' }], 'self-assignment by name');
  await json(await send('/api/office', 'POST', { action: 'member', email: 'twin@example.test', name: 'QA Staff B', active: true }, admin));
  const conflict = await assign(cases.m1.id, 'QA Staff B', staffA, 409);
  assert.match(conflict.error, /البريد/);
  await assign(cases.m1.id, 'External Partner', staffA);
  assert.equal((await get(cases.m1.id)).assignedTo, 'External Partner', 'a name outside the staff list is still saved');
  assert.equal((await db.prepare('SELECT count(*) n FROM case_access WHERE case_id=?').bind(cases.m1.id).first()).n, 0);
  await json(await send('/api/office', 'POST', { action: 'member', email: 'twin@example.test', name: 'QA Staff B', active: false }, admin));
  assert.equal((await send('/api/candidates/' + cases.m1.id, 'GET', undefined, staffB)).status, 200, 'assignment never limits visibility');
});
test('forgery: role, session, scope and permission payloads fail', async () => {
  assert.equal((await send('/api/candidates', 'GET', undefined, stranger)).status, 403, 'unknown identity is not staff');
  assert.equal((await send('/api/candidates', 'GET', undefined, { cookie: 'alh_staff_session=' + 'f'.repeat(64) })).status, 401, 'forged session');
  assert.equal((await send('/api/office/permissions', 'GET', undefined, staffA)).status, 403, 'STAFF cannot read the permission console');
  const st = await perms();
  assert.equal((await send('/api/office/permissions', 'POST', { action: 'toggle', target: 'ROLE', key: 'view_financials', value: true, expectedVersion: st.role.version, expectedEpoch: st.epoch, requestKey: key() }, staffA)).status, 403);
  assert.equal((await send('/api/office/permissions', 'POST', { action: 'toggle', target: 'ROLE', key: 'view_crm', value: true, expectedVersion: st.role.version, expectedEpoch: st.epoch, requestKey: key(), role: 'MANAGER' }, admin)).status, 400, 'extra role field rejected');
  assert.equal((await send('/api/office/permissions', 'POST', { action: 'toggle', target: 'ROLE', key: 'approve_invoice', value: true, expectedVersion: st.role.version, expectedEpoch: st.epoch, requestKey: key() }, admin)).status, 400, 'reserved MANAGER capability');
  assert.equal((await send('/api/office/permissions', 'POST', { action: 'toggle', target: 'USER', targetUserId: 'admin-1', key: 'view_crm', value: false, expectedVersion: 1, expectedEpoch: st.epoch, requestKey: key() }, admin)).status, 400, 'MANAGER is not a Toggle target');
  assert.equal((await send('/api/office/permissions', 'POST', { action: 'toggle', target: 'USER', targetUserId: 'staff:system:v2.2', key: 'view_crm', value: false, expectedVersion: 1, expectedEpoch: st.epoch, requestKey: key() }, admin)).status, 409, 'SYSTEM/non-STAFF target finds no STAFF row');
  assert.equal((await send('/api/office/permissions', 'POST', { action: 'open_all', enabled: true, expectedEpoch: st.epoch, requestKey: key(), untilMs: Date.now() + 864e5 }, admin)).status, 400, 'no client-provided expiry');
  assert.equal((await send('/api/office/permissions', 'GET', undefined, admin)).status, 200);
});

test('Toggles: audit + value + epoch atomically; stale KV cannot restore a revoked permission; deactivation is immediate', async () => {
  let st = await perms();
  const epoch0 = st.epoch;
  assert.equal(await kv.get(`test:perm:v1:role:STAFF:e${epoch0}`) !== null, true, 'policy cached under the current epoch');
  const audits0 = (await db.prepare('SELECT count(*) n FROM permission_changes_audit').first()).n;
  st = await json(await send('/api/office/permissions', 'POST', { action: 'toggle', target: 'ROLE', key: 'chat', value: false, expectedVersion: st.role.version, expectedEpoch: st.epoch, requestKey: key() }, admin));
  assert.equal(st.epoch, epoch0 + 1); assert.equal(st.role.permissions.chat, false);
  assert.equal((await db.prepare('SELECT count(*) n FROM permission_changes_audit').first()).n, audits0 + 1);
  // Forge the old-epoch KV entry to grant everything: authority keys on the D1 epoch, so it is never consulted.
  await kv.put(`test:perm:v1:role:STAFF:e${epoch0}`, JSON.stringify({ view_crm: true, chat: true, edit_case: true }));
  assert.equal((await send('/api/support', 'GET', undefined, staffA)).status, 403, 'revoked chat stays revoked with a stale KV entry');
  // Per-user custom override wins over the role value.
  const a = st.staff.find(s => s.userId === 'staff:staff-a@example.test');
  st = await json(await send('/api/office/permissions', 'POST', { action: 'toggle', target: 'USER', targetUserId: a.userId, key: 'chat', value: true, expectedVersion: a.version, expectedEpoch: st.epoch, requestKey: key() }, admin));
  assert.equal((await send('/api/support', 'GET', undefined, staffA)).status, 200, 'custom true over role false');
  assert.equal((await send('/api/support', 'GET', undefined, staffB)).status, 403);
  await json(await send('/api/office', 'POST', { action: 'member', email: 'staff-b@example.test', name: 'QA Staff B', active: false }, admin));
  assert.equal((await send('/api/candidates', 'GET', undefined, staffB)).status, 403, 'deactivated member denied at once');
  await json(await send('/api/office', 'POST', { action: 'member', email: 'staff-b@example.test', name: 'QA Staff B', active: true }, admin));
});

test('concurrent toggles with the same expected version: one wins, the other conflicts, no partial audit', async () => {
  const st = await perms(), audits0 = (await db.prepare('SELECT count(*) n FROM permission_changes_audit').first()).n;
  const body = v => ({ action: 'toggle', target: 'ROLE', key: 'upload_documents', value: v, expectedVersion: st.role.version, expectedEpoch: st.epoch, requestKey: key() });
  const [r1, r2] = await Promise.all([send('/api/office/permissions', 'POST', body(false), admin), send('/api/office/permissions', 'POST', body(true), admin)]);
  assert.deepEqual([r1.status, r2.status].sort(), [200, 409]);
  assert.equal((await db.prepare('SELECT count(*) n FROM permission_changes_audit').first()).n, audits0 + 1);
  await assert.rejects(db.prepare("UPDATE role_permissions SET permissions_json='{}',version=version+1").run(), /PERMISSION_AUDIT_REQUIRED/, 'no write without audit');
});

test('STAFF open switch: ends at Toronto midnight, grants no MANAGER authority, expiry holds with a stopped cron, AUTO_KILL is deduplicated', async () => {
  let st = await perms();
  const before = Date.now();
  st = await json(await send('/api/office/permissions', 'POST', { action: 'open_all', enabled: true, expectedEpoch: st.epoch, requestKey: key() }, admin));
  assert.equal(st.openAll.active, true); assert.equal(st.openAll.localDate, torontoDate(Date.now()));
  assert.ok([nextTorontoMidnightMs(before), nextTorontoMidnightMs(Date.now())].includes(st.openAll.untilMs), 'server-computed Toronto midnight');
  assert.equal((await send('/api/support', 'GET', undefined, staffB)).status, 200, 'open switch opens STAFF capabilities');
  assert.equal((await send('/api/office/permissions', 'GET', undefined, staffB)).status, 403, 'but never MANAGER authority');
  // Simulate an expired switch whose cron never ran: a MANAGER-audited state dated yesterday with an end in the past.
  const run = await db.prepare('SELECT version v,open_all_local_date d,open_until_ms u FROM permission_runtime').first();
  await db.prepare("INSERT INTO permission_changes_audit(audit_id,change_kind,target_role,old_permissions,new_permissions,expected_version,expected_epoch,changed_by,changed_at) VALUES('t:expired','OPEN_ALL','STAFF',?,?,?,?,'admin-1',?)")
    .bind(JSON.stringify({ enabled: true, localDate: run.d, untilMs: run.u }), JSON.stringify({ enabled: true, localDate: '2026-01-01', untilMs: Date.UTC(2026, 0, 2, 5) }), run.v, run.v, new Date().toISOString()).run();
  assert.equal((await send('/api/support', 'GET', undefined, staffB)).status, 403, 'expired switch is inactive without the cron');
  const worker = await mf.getWorker();
  for (let i = 0; i < 2; i++) await worker.scheduled({ cron: '17 8 * * *', scheduledTime: new Date() });
  const after = await db.prepare('SELECT open_all_enabled e,open_until_ms u FROM permission_runtime').first();
  assert.deepEqual(after, { e: 0, u: 0 });
  assert.equal((await db.prepare("SELECT count(*) n FROM permission_changes_audit WHERE change_kind='AUTO_KILL' AND changed_by='system:v2.2'").first()).n, 1, 'one AUTO_KILL for repeated ticks');
  await assert.rejects(db.prepare("INSERT INTO permission_changes_audit(audit_id,change_kind,target_role,old_permissions,new_permissions,expected_version,expected_epoch,changed_by,changed_at) SELECT 't:sys-open','AUTO_KILL','STAFF','{\"enabled\":false,\"localDate\":null,\"untilMs\":0}','{\"enabled\":true,\"localDate\":\"2026-11-15\",\"untilMs\":1}',version,version,'system:v2.2','x' FROM permission_runtime").run(), /SYSTEM_CANNOT_ENABLE_ACCESS/);
});

test('a financial transaction authorized by an expired open switch or expired authz rolls back completely', async () => {
  // record_payment is allowed by default; the MANAGER closes it for staff A so that only the open switch could authorize.
  let st0 = await perms();
  const a = st0.staff.find(x => x.userId === 'staff:staff-a@example.test');
  await json(await send('/api/office/permissions', 'POST', { action: 'toggle', target: 'USER', targetUserId: a.userId, key: 'record_payment', value: false, expectedVersion: a.version, expectedEpoch: st0.epoch, requestKey: key() }, admin));
  const st = await perms();
  st && await json(await send('/api/office/permissions', 'POST', { action: 'open_all', enabled: true, expectedEpoch: st.epoch, requestKey: key() }, admin));
  const now = new Date().toISOString(), epochOf = async () => (await db.prepare('SELECT version v FROM permission_runtime').first()).v;
  const zeros = { subtotal_cents: 0, discount_cents: 0, total_cents: 0, paid_cents: 0, remaining_cents: 0, version: 0, status: 'DRAFT' };
  const totals = { subtotal_cents: 1000, discount_cents: 0, total_cents: 1000, paid_cents: 0, remaining_cents: 1000, version: 1, status: 'DRAFT' };
  const audit = (logId, by, oldV, newV, exp, idem, kind, e) => db.prepare('INSERT INTO financial_audit_logs(log_id,invoice_id,modified_by,action_type,old_value,new_value,expected_version,permissions_epoch,authz_expires_at_ms,request_hash,idempotency_key,timestamp) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').bind(logId, 'inv-g2', by, kind, JSON.stringify(oldV), JSON.stringify(newV), oldV.version, e, exp, sha(logId), idem, now);
  let e = await epochOf();
  await db.batch([
    db.prepare("INSERT INTO invoices(invoice_id,case_id,currency,created_by,created_at,updated_at) VALUES('inv-g2',?,'CAD','admin-1',?,?)").bind(cases.a1.id, now, now),
    audit('g2-op1', 'admin-1', zeros, totals, Date.now() + 3600e3, 'g2-k1', 'CREATE', e),
    db.prepare("INSERT INTO invoice_items(item_id,invoice_id,service_name,unit_price_cents,last_operation_id) VALUES('g2-i1','inv-g2','svc',1000,'g2-op1')"),
    db.prepare("UPDATE invoices SET subtotal_cents=1000,total_cents=1000,remaining_cents=1000,version=1,last_operation_id='g2-op1',updated_at=? WHERE invoice_id='inv-g2'").bind(now),
  ]);
  const paid = { ...totals, paid_cents: 100, remaining_cents: 900, version: 2, status: 'PARTIAL' };
  const pay = (logId, idem, exp, ep) => db.batch([
    audit(logId, 'staff:staff-a@example.test', totals, paid, exp, idem, 'PAYMENT', ep),
    db.prepare("INSERT INTO payments_ledger(payment_id,invoice_id,case_id,currency,amount_cents,method,paid_at,idempotency_key,operation_id,created_by,created_at) VALUES(?,'inv-g2',?,'CAD',100,'CASH',?,?,?,'staff:staff-a@example.test',?)").bind('p-' + logId, cases.a1.id, now, idem, logId, now),
    db.prepare("UPDATE invoices SET paid_cents=100,remaining_cents=900,version=2,status='PARTIAL',last_operation_id=?,updated_at=? WHERE invoice_id='inv-g2'").bind(logId, now),
  ]);
  e = await epochOf();
  await assert.rejects(pay('g2-exp', 'g2-pk1', Date.now() - 1, e), /AUTHORIZATION_EXPIRED/);
  // Expire the open switch (STAFF has no record_payment otherwise): the same payment must now be denied.
  const run = await db.prepare('SELECT version v,open_all_local_date d,open_until_ms u FROM permission_runtime').first();
  await db.prepare("INSERT INTO permission_changes_audit(audit_id,change_kind,target_role,old_permissions,new_permissions,expected_version,expected_epoch,changed_by,changed_at) VALUES('t:fin-expired','OPEN_ALL','STAFF',?,?,?,?,'admin-1',?)")
    .bind(JSON.stringify({ enabled: true, localDate: run.d, untilMs: run.u }), JSON.stringify({ enabled: true, localDate: '2026-01-01', untilMs: 1000 }), run.v, run.v, now).run();
  e = await epochOf();
  await assert.rejects(pay('g2-open', 'g2-pk2', Date.now() + 3600e3, e), /FINANCIAL_PERMISSION_REQUIRED/);
  assert.equal((await db.prepare("SELECT count(*) n FROM payments_ledger WHERE invoice_id='inv-g2'").first()).n, 0);
  assert.equal((await db.prepare("SELECT count(*) n FROM financial_audit_logs WHERE action_type='PAYMENT'").first()).n, 0);
  assert.deepEqual(await db.prepare("SELECT paid_cents p,version v FROM invoices WHERE invoice_id='inv-g2'").first(), { p: 0, v: 1 });
});

test('Toronto day boundaries: DST 23/25-hour days, new year, no carry-over to the next day', () => {
  const day = d => nextTorontoMidnightMs(Date.UTC(...d, 12));
  assert.equal(day([2026, 2, 8]) - day([2026, 2, 7]), 23 * 3600e3);
  assert.equal(day([2026, 10, 1]) - day([2026, 9, 31]), 25 * 3600e3);
  const nye = Date.UTC(2027, 0, 1, 4, 30);
  assert.equal(torontoDate(nye), '2026-12-31', 'UTC new year is still 31 Dec in Toronto');
  assert.equal(nextTorontoMidnightMs(nye), Date.UTC(2027, 0, 1, 5), 'Toronto midnight is 05:00 UTC in winter');
  assert.equal(torontoDate(Date.UTC(2027, 0, 1, 5)), '2027-01-01');
  assert.equal(openAllActive({ enabled: true, localDate: '2026-12-31', untilMs: Date.UTC(2027, 0, 9) }, Date.UTC(2027, 0, 1, 5)), false, 'a switch from yesterday is never active today');
});
