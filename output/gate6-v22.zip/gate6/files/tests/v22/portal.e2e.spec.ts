// v2.2 Gate 4 — browser E2E on the built Worker (Miniflare) behind a local HTTPS test server (self-signed certificate
// generated per run) that serves dist/client with correct MIME types and forwards every other request to the Worker,
// Chromium via Playwright. Email delivery is a declared test double (outboundService captures the code). Covers the two entries,
// OTP paste + auto-verify, welcome, Smart Path focus/back, account autosave + reload, offline queue, two-tab conflict,
// the single signature pad across resize and later edits, submission, header indicator, footer lookup dialog
// (keyboard/focus), RTL/LTR, 360/768/1440 without horizontal overflow or duplicate entries, and reduced motion.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, readdir, mkdir } from 'node:fs/promises';
import path from 'node:path';
import https from 'node:https';
import os from 'node:os';
import { execFileSync } from 'node:child_process';
import { createReadStream, existsSync, statSync, readFileSync, mkdtempSync } from 'node:fs';
import { seedOfficeManager } from './office-fixture.mjs';

const require = createRequire(import.meta.url);
const { Miniflare } = createRequire(require.resolve('wrangler/package.json'))('miniflare');
const { chromium } = require('playwright');
const SHOTS = process.env.E2E_SHOTS || '';
type Mf = { ready: Promise<URL>; dispatchFetch: (u: string, init?: Record<string, unknown>) => Promise<Response>; getD1Database: (n: string) => Promise<{ prepare: (q: string) => { run: () => Promise<unknown> } }>; dispose: () => Promise<void> };
// Playwright is the preinstalled global package (no project types); the spec drives it through Playwright's own API.
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- untyped global Playwright handle (test-only)
type Browser = { newContext: (o: Record<string, unknown>) => Promise<any>; close: () => Promise<void> };
let mf: Mf, url = '', browser: Browser, server: https.Server;
const MIME: Record<string, string> = { '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.html': 'text/html', '.wasm': 'application/wasm' };
const mails: { to: string[]; text: string }[] = [];
const codeFor = async (email: string, after: number) => {
  for (let i = 0; i < 200; i++) { const m = mails.slice(after).reverse().find(x => x.to.includes(email)); if (m) return /\b(\d{6})\b/.exec(m.text)![1]; await new Promise(r => setTimeout(r, 25)); }
  throw new Error('no code for ' + email);
};
test.before(async () => {
  const files = await readdir('dist/server', { recursive: true });
  mf = new Miniflare({
    modules: ['index.js', ...files.filter((f: string) => f !== 'index.js' && f.endsWith('.js'))].map((f: string) => ({ type: 'ESModule', path: path.resolve('dist/server', f) })),
    modulesRoot: path.resolve('dist/server'), compatibilityDate: '2026-05-15', compatibilityFlags: ['nodejs_compat'],
    d1Databases: { DB: 'gate4-e2e' }, r2Buckets: ['BUCKET'],
    bindings: { TRUST_SITES_IDENTITY_HEADERS: '1', OFFICE_ADMIN_EMAIL: 'admin@example.test', APP_SECRET: 'd'.repeat(64) },
    outboundService: async (req: Request) => {
      const u = new URL(req.url);
      if (u.hostname === 'api.resend.com') { const b = await req.json() as { to: string[]; text?: string }; mails.push({ to: b.to, text: b.text || '' }); return Response.json({ id: 'm' + mails.length }); }
      return new Response('blocked', { status: 599 });
    },
  });
  const dir = mkdtempSync(path.join(os.tmpdir(), 'alh-e2e-')), clientDir = path.resolve('dist/client');
  execFileSync('openssl', ['req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', dir + '/k.pem', '-out', dir + '/c.pem', '-days', '1', '-subj', '/CN=127.0.0.1', '-addext', 'subjectAltName=IP:127.0.0.1'], { stdio: 'ignore' });
  server = https.createServer({ key: readFileSync(dir + '/k.pem'), cert: readFileSync(dir + '/c.pem') }, async (req, res) => {
    try {
      const u = new URL(req.url || '/', 'https://127.0.0.1'), file = path.join(clientDir, decodeURIComponent(u.pathname));
      if (u.pathname !== '/' && file.startsWith(clientDir + path.sep) && existsSync(file) && statSync(file).isFile()) { res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream' }); createReadStream(file).pipe(res); return; }
      const chunks: Buffer[] = []; for await (const c of req) chunks.push(c as Buffer);
      const headers = Object.entries(req.headers).filter(([k]) => !['host', 'connection', 'content-length'].includes(k)).map(([k, v]) => [k, Array.isArray(v) ? v.join(', ') : String(v)]);
      const r = await mf.dispatchFetch(url + req.url, { method: req.method, headers, body: ['GET', 'HEAD'].includes(req.method || 'GET') ? undefined : Buffer.concat(chunks), redirect: 'manual' });
      const out: Record<string, string | string[]> = {}; r.headers.forEach((v: string, k: string) => { if (!['set-cookie', 'content-encoding', 'content-length', 'transfer-encoding'].includes(k)) out[k] = v; });
      const cookies = r.headers.getSetCookie(); if (cookies.length) out['set-cookie'] = cookies;
      res.writeHead(r.status, out); res.end(Buffer.from(await r.arrayBuffer()));
    } catch (e) { res.writeHead(502); res.end(String(e)); }
  });
  await new Promise<void>(r => server.listen(0, '127.0.0.1', () => r()));
  url = 'https://127.0.0.1:' + (server.address() as { port: number }).port;
  const db = await mf.getD1Database('DB');
  for (const f of (await readdir('drizzle')).filter((f: string) => f.endsWith('.sql')).sort())
    for (const s of (await readFile('drizzle/' + f, 'utf8')).split('--> statement-breakpoint').map((s: string) => s.trim()).filter(Boolean)) await db.prepare(s).run();
  await seedOfficeManager(db, 'admin-1');
  const admin = { 'oai-authenticated-user-id': 'admin-1', 'oai-authenticated-user-email': 'admin@example.test' };
  await mf.dispatchFetch(url + '/api/office', { headers: admin });
  const r = await mf.dispatchFetch(url + '/api/office', { method: 'POST', headers: { ...admin, 'content-type': 'application/json' }, body: JSON.stringify({ action: 'mail', sender: 'notifications@example.test', key: 're_test_' + 'x'.repeat(24) }) });
  assert.equal(r.status, 200, await r.text());
  browser = await chromium.launch();
  if (SHOTS) await mkdir(SHOTS, { recursive: true });
});
test.after(async () => { await browser?.close(); server?.close(); await mf?.dispose(); });
const ctx = (opts: Record<string, unknown> = {}) => browser.newContext({ ignoreHTTPSErrors: true, ...opts });

test('entry: two intents only, one lookup button, no horizontal overflow at 360/768/1440, RTL then LTR', async () => {
  for (const width of [360, 768, 1440]) {
    const c = await ctx({ viewport: { width, height: 900 } }), page = await c.newPage();
    await page.goto(url + '/apply');
    await page.locator('.account-intent').first().waitFor();
    assert.equal(await page.locator('.account-intent').count(), 2, 'two entry cards');
    assert.equal(await page.locator('.lookup-button').count(), 1, 'one footer lookup button');
    assert.equal(await page.locator('.entry-btn').count(), 0, 'no second set of entry buttons');
    assert.equal(await page.locator('form').count(), 1, 'one auth form for the preselected intent');
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), 'no horizontal overflow at ' + width);
    assert.equal(await page.locator('.portal-page').getAttribute('dir'), 'rtl');
    if (SHOTS) await page.screenshot({ path: path.join(SHOTS, `entry-${width}.png`), fullPage: false });
    if (width === 1440) { await page.locator('.language-toggle').click(); assert.equal(await page.locator('.portal-page').getAttribute('dir'), 'ltr'); await page.getByText('Continue an existing application').waitFor(); }
    await c.close();
  }
});

test('lookup dialog: keyboard opens it, focus stays inside, Escape closes and returns focus', async () => {
  const c = await ctx(), page = await c.newPage();
  await page.goto(url + '/apply');
  await page.locator('.lookup-button').focus(); await page.keyboard.press('Enter');
  await page.locator('dialog.status-lookup-dialog[open]').waitFor();
  assert.ok(await page.evaluate(() => !!document.activeElement?.closest('dialog.status-lookup-dialog')), 'focus inside the dialog');
  await page.locator('dialog input').fill('+1 313 555 0101');
  assert.match(await page.locator('.lookup-kind').innerText(), /هاتف دولي/);
  await page.keyboard.press('Escape');
  await page.waitForFunction(() => !document.querySelector('dialog.status-lookup-dialog'));
  assert.ok(await page.evaluate(() => document.activeElement?.classList.contains('lookup-button')), 'focus returned to the opener');
  await c.close();
});

test('journey: START_NEW + OTP paste auto-verify, welcome, path focus/back, autosave+reload, offline, two tabs, signature, submit', async () => {
  const c = await ctx({ viewport: { width: 1280, height: 900 } }), page = await c.newPage(), email = 'journey@example.test';
  page.on('response', (r: { status: () => number; url: () => string; request: () => { method: () => string } }) => { if (r.status() >= 400 && r.url().includes('/api/')) console.error('HTTP', r.status(), r.request().method(), r.url().replace(url, '')); });
  await page.goto(url + '/apply');
  await page.locator('.account-intent.on').waitFor();
  assert.equal(await page.locator('.session-indicator').count(), 0, 'no indicator before sign-in');
  await page.getByLabel('الاسم الكامل').fill('سارة الاختبار');
  await page.getByLabel('البريد الإلكتروني').fill(email);
  const sent = mails.length; await page.getByRole('button', { name: 'إرسال رمز التحقق' }).click();
  const code = await codeFor(email, sent);
  await page.locator('.auth-pin input').first().fill(code);   // the whole code in one box (paste/autofill path)
  await page.waitForURL(url + '/apply');
  await page.locator('.account-welcome').waitFor();
  assert.match(await page.locator('.account-welcome').innerText(), /سارة الاختبار/);
  await page.locator('.session-indicator').waitFor();
  assert.match(await page.locator('.session-indicator').innerText(), /متصل ومؤمن/);
  // Smart Path Selector: focus hides the others (inert after the fade), back restores without losing the choice.
  await page.getByRole('radio', { name: /الإقامة الدائمة/ }).click();
  await page.waitForFunction(() => document.querySelectorAll('.pw-card.off[inert]').length === 4);
  assert.equal(await page.locator('.pw-unsure').count(), 0);
  await page.getByRole('button', { name: 'رجوع للخلف' }).click();
  assert.equal(await page.locator('.pw-card.off').count(), 0);
  assert.equal(await page.getByRole('radio', { name: /الإقامة الدائمة/ }).getAttribute('aria-checked'), 'true', 'selection kept after back');
  await page.getByRole('radio', { name: /الإقامة الدائمة/ }).click();
  await page.getByRole('radio', { name: /Express Entry/ }).first().click();
  await page.getByRole('button', { name: 'متابعة التقييم والتقديم' }).click();
  // Autosave to the account; reload keeps it (server is the source of truth).
  await page.getByLabel(/الهاتف/).first().fill('+15557770001');
  await page.locator('.draft-status.saved').waitFor({ timeout: 8000 }).catch(async (e: Error) => { console.log('STATUS', await page.locator('.draft-status').allInnerTexts(), await page.locator('.error-banner').allInnerTexts()); throw e; });
  await page.reload();
  await page.locator('.draft-status.saved').waitFor({ timeout: 8000 }).catch(async (e: Error) => { console.error('STATUS-AFTER-RELOAD', JSON.stringify(await page.locator('.draft-status').allInnerTexts()), JSON.stringify(await page.evaluate(() => Object.keys(localStorage)))); throw e; });
  assert.equal(await page.getByLabel(/الهاتف/).first().inputValue(), '+15557770001', 'reload keeps the saved value');
  // Offline: edits queue locally, no false "saved"; back online they reach the server.
  await c.setOffline(true);
  await page.getByLabel(/الهاتف/).first().fill('+15557770002');
  await page.locator('.draft-status.offline').waitFor({ timeout: 8000 });
  assert.equal(await page.locator('.draft-status.saved').count(), 0);
  await c.setOffline(false); await page.evaluate(() => window.dispatchEvent(new Event('online')));
  await page.locator('.draft-status.saved').waitFor({ timeout: 8000 });
  // Two tabs: the stale tab sees a conflict instead of silently overwriting.
  const tab2 = await c.newPage(); await tab2.goto(url + '/apply'); await tab2.locator('.draft-status.saved').waitFor();
  await page.getByLabel(/الهاتف/).first().fill('+15557770003'); await page.locator('.draft-status.saved').waitFor();
  await page.waitForTimeout(700);
  await tab2.getByLabel(/الهاتف/).first().fill('+15557770009');
  await tab2.locator('.draft-conflict').waitFor({ timeout: 8000 });
  await tab2.getByRole('button', { name: 'استخدام النسخة الأحدث' }).click();
  await tab2.waitForFunction(() => !document.querySelector('.draft-conflict'));
  assert.equal(await tab2.getByLabel(/الهاتف/).first().inputValue(), '+15557770003');
  await tab2.close();
  // One signature pad (finger/pen/mouse via Pointer Events); survives resize and later edits; then submit.
  await page.locator('#legalAuthCheckbox').check();
  assert.equal(await page.locator('.signature-pad').count(), 1, 'a single pad');
  const box = await page.locator('.signature-canvas').boundingBox();
  await page.mouse.move(box.x + 30, box.y + 40); await page.mouse.down();
  for (let i = 1; i <= 25; i++) await page.mouse.move(box.x + 30 + i * 10, box.y + 40 + (i % 5) * 12);
  await page.mouse.up();
  await page.setViewportSize({ width: 820, height: 900 });
  await page.getByRole('button', { name: 'حفظ التوقيع' }).click();
  await page.locator('.signature-status.signed').waitFor();
  await page.setViewportSize({ width: 390, height: 860 });
  assert.equal(await page.locator('.signature-status.signed').count(), 1, 'still signed after resize');
  await page.getByLabel(/الهاتف/).first().fill('+15557770004'); await page.locator('.draft-status.saved').waitFor();
  assert.equal(await page.locator('.signature-status.signed').count(), 1, 'editing data does not remove the signature');
  assert.equal(await page.getByText(/STALE/).count(), 0);
  if (SHOTS) await page.screenshot({ path: path.join(SHOTS, 'signed-390.png'), fullPage: false });
  await page.getByRole('button', { name: 'إرسال طلب التقييم' }).click();
  await page.getByText(/ALH-CA-\d{4}-/).first().waitFor({ timeout: 15000 });
  await c.close();
});

test('reduced motion: no entry transitions or welcome animation', async () => {
  const c = await ctx({ reducedMotion: 'reduce' }), page = await c.newPage();
  await page.goto(url + '/apply'); await page.locator('.account-intent').first().waitFor();
  const d = await page.locator('.account-intent').first().evaluate((el: Element) => getComputedStyle(el).transitionDuration);
  assert.ok(parseFloat(d) <= 0.001, 'transition effectively disabled: ' + d);
  await c.close();
});
