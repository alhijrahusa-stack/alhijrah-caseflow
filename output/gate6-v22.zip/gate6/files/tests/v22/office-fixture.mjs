// Test fixture mirroring production after migrations 0024-0027 on an office that already has a manager:
// the manager users row. The STAFF policy is the migration default (every STAFF capability allowed).
export async function seedOfficeManager(db, managerId) {
  await db.prepare("INSERT INTO users(user_id,role,created_at) VALUES(?,'MANAGER',?)").bind(managerId, new Date().toISOString()).run();
}
