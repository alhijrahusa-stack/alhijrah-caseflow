// v2.2 Gate 5 — Package 8 case chat on the built Worker with the CaseChatRoom Durable Object (Miniflare). HTTP and WS:
// ordering under concurrency, dedup/ACK loss, replay after reconnect, revocation closing the socket; one claim winner;
// assistant consent and fencing (late output after a handoff is discarded); attachments/voice through the quarantine
// pipeline (no playback before CLEAN, no scanner → stays processing); transcription consent; external notices only with
// consent and one per unread window; Rapid Assessment from the same engine never touching the verified pointer; the
// legacy support endpoints writing to the canonical chat.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { seedOfficeManager } from './office-fixture.mjs';
import { clientCaseFixture, grantConsent } from './client-case-fixture.mjs';
import { SOURCES, crsBundle, programBundle, nocBundle } from './engine-fixtures.mjs';

const require = createRequire(import.meta.url);
const { Miniflare } = createRequire(require.resolve('wrangler/package.json'))('miniflare');
const base = 'http://canada-desk.test';
const id = (uid, email) => ({ 'oai-authenticated-user-id': uid, 'oai-authenticated-user-email': email });
const admin = id('admin-1', 'admin@example.test'), staffA = id('staff-a', 'staff-a@example.test'), staffB = id('staff-b', 'staff-b@example.test');
let mf, db, send, worker;
const json = async (r, status = 200) => { const t = await r.text(); assert.equal(r.status, status, t); return t ? JSON.parse(t) : null; };
const key = () => crypto.randomUUID();
const one = (sql, ...b) => db.prepare(sql).bind(...b).first();
const count = async (sql, ...b) => (await one(sql, ...b)).n;
const tick = () => worker.scheduled({ cron: '*/5 * * * *', scheduledTime: new Date() });
const b64 = s => Buffer.from(s, 'utf8').toString('base64');
let llm = async () => ({ text: 'Your file is under review.', handoffRecommended: false }), llmCalls = 0;
const text = (t, cid = key()) => ({ clientMessageId: cid, repliedToMessageId: null, kind: 'TEXT', text: t });

test.before(async () => {
  const files = await readdir('dist/server', { recursive: true });
  mf = new Miniflare({
    modules: ['index.js', ...files.filter(f => f !== 'index.js' && f.endsWith('.js'))].map(f => ({ type: 'ESModule', path: path.resolve('dist/server', f) })),
    modulesRoot: path.resolve('dist/server'), compatibilityDate: '2026-05-15', compatibilityFlags: ['nodejs_compat'],
    d1Databases: { DB: 'chat-db' }, r2Buckets: ['BUCKET'], kvNamespaces: { PERMISSIONS_KV: 'chat-kv' }, durableObjects: { CHAT_ROOMS: 'CaseChatRoom' },
    bindings: { TRUST_SITES_IDENTITY_HEADERS: '1', OFFICE_ADMIN_EMAIL: 'admin@example.test', APP_SECRET: 'd'.repeat(64), PERMISSIONS_KV_NAMESPACE: 'test' },
    outboundService: async req => {
      if (new URL(req.url).hostname !== 'api.openai.com') return new Response('blocked', { status: 599 });
      llmCalls++; const draft = await llm();
      return Response.json({ status: 'completed', output: [{ type: 'message', content: [{ type: 'output_text', text: JSON.stringify(draft) }] }] });
    },
  });
  send = (p, method = 'GET', body, headers = {}) => mf.dispatchFetch(base + p, { method, headers: { ...(body ? { 'content-type': 'application/json' } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined });
  db = await mf.getD1Database('DB'); worker = await mf.getWorker();
  for (const f of (await readdir('drizzle')).filter(f => f.endsWith('.sql')).sort())
    for (const s of (await readFile('drizzle/' + f, 'utf8')).split('--> statement-breakpoint').map(s => s.trim()).filter(Boolean)) await db.prepare(s).run();
  await seedOfficeManager(db, 'admin-1');
  await json(await send('/api/office', 'GET', undefined, admin));
  for (const s of [['staff-a@example.test', 'QA Staff A'], ['staff-b@example.test', 'QA Staff B']]) await json(await send('/api/office', 'POST', { action: 'member', email: s[0], name: s[1], active: true }, admin));
  await json(await send('/api/office', 'POST', { action: 'professional', provider: 'openai', model: 'qa-model-1', key: 'sk-qa-' + 'k'.repeat(30) }, admin));
  await json(await send('/api/office', 'POST', { action: 'mail', sender: 'office@example.test', key: 're_' + 'm'.repeat(20) }, admin));
});
test.after(async () => { await mf?.dispose(); });

const st = {};
const client = c => ({ cookie: c.cookie });
const chat = (c, body, status) => send('/api/client/chat', 'POST', body, client(c)).then(r => status ? json(r, status) : r);
const page = (c, after = 0) => send('/api/client/chat?after=' + after, 'GET', undefined, client(c)).then(r => json(r));
test('HTTP: without assistant consent the message goes to staff; retries replay; same id + other text = 409; concurrent sends get contiguous sequences', async () => {
  st.c = await clientCaseFixture(db, { name: 'QA Chat', email: 'chat@example.test', phone: '+15557770001' });
  const m = text('Hello office', 'cm-' + key());
  const a = await chat(st.c, { action: 'send', message: m }, 201);
  const b = await chat(st.c, { action: 'send', message: m }, 200);
  assert.equal(a.sequence, 1); assert.equal(b.sequence, 1); assert.equal(b.replayed, true, 'lost ACK: the retry returns the committed message');
  assert.equal((await chat(st.c, { action: 'send', message: { ...m, text: 'different' } })).status, 409);
  let p = await page(st.c);
  assert.equal(p.conversation.state, 'HANDOFF_PENDING'); assert.equal(p.conversation.assistantAvailability, 'CONSENT_REQUIRED');
  assert.equal(await count("SELECT count(*) n FROM durable_jobs WHERE kind='ASSISTANT'"), 0, 'no LLM job without consent');
  const rs = await Promise.all(Array.from({ length: 8 }, (_, i) => chat(st.c, { action: 'send', message: text('burst ' + i) })));
  const statuses = await Promise.all(rs.map(async r => r.status + ':' + (r.status === 201 ? '' : await r.text())));
  assert.ok(rs.every(r => r.status === 201), statuses.join(' | '));
  p = await page(st.c);
  assert.deepEqual(p.items.map(i => i.sequence), Array.from({ length: 9 }, (_, i) => i + 1), 'no gap, no duplicate');
  assert.equal(new Set(p.items.map(i => i.text)).size, 9, 'no message lost');
  const tail = await page(st.c, 7); assert.deepEqual(tail.items.map(i => i.sequence), [8, 9], 'keyset replay after a sequence');
  assert.ok(p.items.every(i => i.senderDisplayRef !== 'staff:staff-a@example.test'));
});
test('claim race: two staff members, one winner; the other cannot write; release/close/reopen are CAS transitions', async () => {
  const s = await json(await send(`/api/candidates/${st.c.id}/chat`, 'GET', undefined, staffA));
  const rev = s.conversation.conversationRevision;
  const [x, y] = await Promise.all([staffA, staffB].map(h => send(`/api/candidates/${st.c.id}/chat`, 'POST', { action: 'transition', transition: { action: 'claim', expectedRevision: rev, requestKey: key() } }, h)));
  assert.deepEqual([x.status, y.status].sort(), [200, 409]);
  const winner = x.status === 200 ? staffA : staffB, loser = winner === staffA ? staffB : staffA, winnerId = 'staff:' + winner['oai-authenticated-user-email'];
  assert.equal((await one('SELECT assigned_to a,state s FROM case_conversations WHERE case_id=?', st.c.id)).a, winnerId);
  assert.equal((await send(`/api/candidates/${st.c.id}/chat`, 'POST', { action: 'send', message: text('loser reply') }, loser)).status, 409);
  await grantConsent(db, st.c.id, 'CHAT_NOTIFICATIONS', true);
  await json(await send(`/api/candidates/${st.c.id}/chat`, 'POST', { action: 'send', message: text('Office reply 1') }, winner), 201);
  await json(await send(`/api/candidates/${st.c.id}/chat`, 'POST', { action: 'send', message: text('Office reply 2') }, winner), 201);
  assert.equal(await count("SELECT count(*) n FROM delivery_outbox WHERE case_id=? AND kind='CHAT_NOTICE'", st.c.id), 1, 'one external notice per unread window');
  const last = (await page(st.c)).lastSequence;
  const r = await chat(st.c, { action: 'receipt', deliveredSequence: last + 50, readSequence: last + 99 }, 200);
  assert.deepEqual([r.deliveredSequence, r.readSequence], [last, last], 'receipts clamp to last_sequence and read ≤ delivered');
  const r2 = await chat(st.c, { action: 'receipt', deliveredSequence: 1, readSequence: 1 }, 200);
  assert.equal(r2.readSequence, last, 'receipts never move back');
  await json(await send(`/api/candidates/${st.c.id}/chat`, 'POST', { action: 'send', message: text('Office reply 3') }, winner), 201);
  assert.equal(await count("SELECT count(*) n FROM delivery_outbox WHERE case_id=? AND kind='CHAT_NOTICE'", st.c.id), 2, 'a new window after the client read');
  const notice = await one("SELECT payload_encrypted p FROM delivery_outbox WHERE case_id=? AND kind='CHAT_NOTICE'", st.c.id);
  assert.ok(!notice.p.includes('Office reply'), 'no message content in the notice payload');
  const cur = (await json(await send(`/api/candidates/${st.c.id}/chat`, 'GET', undefined, winner))).conversation.conversationRevision;
  assert.equal((await send(`/api/candidates/${st.c.id}/chat`, 'POST', { action: 'transition', transition: { action: 'release', expectedRevision: cur, requestKey: key() } }, loser)).status, 409, 'only the owner releases');
  const closed = await json(await send(`/api/candidates/${st.c.id}/chat`, 'POST', { action: 'transition', transition: { action: 'close', expectedRevision: cur, requestKey: key() } }, winner));
  assert.equal(closed.conversation.state, 'CLOSED');
  assert.equal((await chat(st.c, { action: 'transition', transition: { action: 'close', expectedRevision: closed.conversation.conversationRevision, requestKey: key() } })).status, 403, 'client cannot close');
  await chat(st.c, { action: 'send', message: text('Reopen please') }, 201);
  assert.equal((await page(st.c)).conversation.state, 'HANDOFF_PENDING', 'a client message reopens to the staff queue');
});
test('assistant: consent + configured provider → fenced reply; a handoff while the model is running discards the late output', async () => {
  const c = await clientCaseFixture(db, { name: 'QA Assistant', email: 'assistant@example.test', phone: '+15557770002' });
  await grantConsent(db, c.id, 'LLM_CHAT_ASSISTANT', true);
  await chat(c, { action: 'send', message: text('What documents are missing?') }, 201);
  assert.equal((await page(c)).conversation.state, 'BOT_ACTIVE');
  assert.equal(await count("SELECT count(*) n FROM durable_jobs WHERE kind='ASSISTANT' AND case_id=?", c.id), 1);
  await tick();
  let p = await page(c);
  assert.equal(p.items.at(-1).actorType, 'ASSISTANT'); assert.equal(p.items.at(-1).text, 'Your file is under review.');
  // Late output: the model answers only after the client asked for a person.
  let release; const gate = new Promise(r => { release = r; }); llm = async () => { await gate; return { text: 'LATE ANSWER', handoffRecommended: false }; };
  await chat(c, { action: 'send', message: text('Second question') }, 201);
  const calls0 = llmCalls, running = tick();
  for (let i = 0; i < 100 && llmCalls === calls0; i++) await new Promise(r => setTimeout(r, 20));
  const rev = (await page(c)).conversation.conversationRevision;
  await chat(c, { action: 'transition', transition: { action: 'handoff', expectedRevision: rev, requestKey: key() } }, 200);
  release(); await running;
  p = await page(c);
  assert.ok(!p.items.some(i => i.text === 'LATE ANSWER'), 'late assistant output never published');
  assert.equal((await one("SELECT state s,error_code e FROM durable_jobs WHERE kind='ASSISTANT' AND case_id=? ORDER BY created_at DESC LIMIT 1", c.id)).e, 'ASSISTANT_FENCED_DISCARDED');
  llm = async () => ({ text: 'Your file is under review.', handoffRecommended: false });
  // Trigger level: an ASSISTANT row with a stale generation is rejected.
  const conv = await one('SELECT * FROM case_conversations WHERE case_id=?', c.id);
  await assert.rejects(db.prepare("INSERT INTO case_chat_messages(message_id,conversation_id,case_id,sequence,sender_id,actor_type,client_message_id,payload_hash,kind,body_encrypted,automation_generation,context_data_revision,context_rule_generation,in_reply_to_sequence,created_at) VALUES(?,?,?,?,'system:v2.2','ASSISTANT',?,?,'TEXT','x',?,0,0,?,?)")
    .bind(key(), conv.conversation_id, c.id, conv.last_sequence + 1, key(), 'f'.repeat(64), conv.automation_generation - 1, conv.last_client_sequence, new Date().toISOString()).run(), /ASSISTANT_FENCED/);
});
async function clientUpload(c, kind, bytes, name, type) {
  const form = new FormData(); form.set('file', new File([bytes], name, { type })); if (kind === 'file') form.set('category', 'other');
  const req = new Request(base + '/api/client/chat?upload=' + kind, { method: 'POST', body: form, headers: client(c) });
  return json(await mf.dispatchFetch(req.url, { method: 'POST', headers: Object.fromEntries(req.headers), body: await req.arrayBuffer() }), 201);
}
test('attachments and voice: quarantine pipeline, no playback before CLEAN, no scanner → stays processing; transcription consent', async () => {
  const c = st.c, other = await clientCaseFixture(db, { name: 'QA Other', email: 'other@example.test', phone: '+15557770003' });
  const f = await clientUpload(c, 'file', new TextEncoder().encode('%PDF-1.4\nchat attachment ' + key() + '\n%%EOF'), 'doc.pdf', 'application/pdf');
  await chat(c, { action: 'send', message: { clientMessageId: key(), repliedToMessageId: null, kind: 'ATTACHMENT', evidenceIds: [f.evidenceId] } }, 201);
  assert.equal((await chat(other, { action: 'send', message: { clientMessageId: key(), repliedToMessageId: null, kind: 'ATTACHMENT', evidenceIds: [f.evidenceId] } })).status, 422, 'evidence of another case');
  const voiceBytes = new Uint8Array([0x1a, 0x45, 0xdf, 0xa3, 1, 2, 3, 4, 5, 6, 7, 8, ...new TextEncoder().encode(key())]);
  const v = await clientUpload(c, 'voice', voiceBytes, 'voice.webm', 'audio/webm');
  await chat(c, { action: 'send', message: { clientMessageId: key(), repliedToMessageId: null, kind: 'VOICE_NOTE', evidenceId: v.evidenceId } }, 201);
  let p = await page(c); const att = p.items.find(i => i.kind === 'ATTACHMENT').attachments[0], voice = p.items.find(i => i.kind === 'VOICE_NOTE').attachments[0];
  assert.deepEqual([att.state, voice.state, voice.mediaKind, voice.transcriptState], ['PROCESSING', 'PROCESSING', 'VOICE_NOTE', 'CONSENT_REQUIRED']);
  for (const e of [f.evidenceId, v.evidenceId]) assert.equal((await send('/api/client/chat?media=' + e, 'GET', undefined, client(c))).status, 423, 'no playback/download before CLEAN');
  await tick();
  assert.equal((await one("SELECT state s,error_code e FROM durable_jobs WHERE request_key=?", 'ingest:' + v.evidenceId)).e, 'SCANNER_NOT_CONFIGURED');
  assert.equal((await one('SELECT integrity_state s FROM documents WHERE id=?', v.evidenceId)).s, 'QUARANTINED', 'honest: still quarantined');
  await grantConsent(db, c.id, 'AUDIO_TRANSCRIPTION', true);
  const v2 = await clientUpload(c, 'voice', new Uint8Array([...voiceBytes, 9]), 'voice2.webm', 'audio/webm');
  await chat(c, { action: 'send', message: { clientMessageId: key(), repliedToMessageId: null, kind: 'VOICE_NOTE', evidenceId: v2.evidenceId } }, 201);
  await tick();
  p = await page(c); const t = p.items.filter(i => i.kind === 'VOICE_NOTE').at(-1).attachments[0];
  assert.equal(t.transcriptState, 'FAILED'); assert.equal((await one('SELECT error_code e FROM durable_jobs WHERE request_key=?', 'transcribe:' + v2.evidenceId)).e, 'TRANSCRIPTION_NOT_CONFIGURED');
});
function wsOpen(p, headers) {
  return mf.dispatchFetch(base + p, { headers: { ...headers, Upgrade: 'websocket', Origin: base } }).then(async r => { if (r.status !== 101) assert.fail(r.status + ' ' + await r.text()); const ws = r.webSocket; const frames = []; let closed = null; ws.addEventListener('message', e => frames.push(JSON.parse(e.data))); ws.addEventListener('close', e => { closed = e.code; }); ws.accept(); return { ws, frames, get closed() { return closed; } }; });
}
const until = async (f, ms = 3000) => { for (let i = 0; i < ms / 20; i++) { if (await f()) return true; await new Promise(r => setTimeout(r, 20)); } return false; };
test('WebSocket: commit-then-fan-out, SEND over WS acks with the committed sequence, reconnect replays the gap, revocation closes the socket', async () => {
  const c = await clientCaseFixture(db, { name: 'QA Socket', email: 'socket@example.test', phone: '+15557770004' });
  await chat(c, { action: 'send', message: text('first') }, 201);
  for (const origin of [undefined, 'https://evil.example']) {
    const r = await mf.dispatchFetch(base + '/api/client/chat?socket=1', { headers: { ...client(c), Upgrade: 'websocket', ...(origin ? { Origin: origin } : {}) } });
    assert.equal(r.status, 403, 'socket Origin enforced: ' + origin);
  }
  const sock = await wsOpen('/api/client/chat?socket=1', client(c));
  await json(await send(`/api/candidates/${c.id}/chat`, 'POST', { action: 'send', message: text('pushed by staff') }, staffA), 201);
  assert.ok(await until(() => sock.frames.some(f => f.type === 'MESSAGE_COMMITTED' && f.message.text === 'pushed by staff')), 'push received');
  const cmd = key();
  sock.ws.send(JSON.stringify({ protocolVersion: '2.0.0', type: 'SEND_MESSAGE', commandId: cmd, message: text('sent over socket', 'ws-' + key()) }));
  assert.ok(await until(() => sock.frames.some(f => f.type === 'MESSAGE_COMMITTED' && f.commandId === cmd)));
  const ack = sock.frames.find(f => f.commandId === cmd);
  assert.equal((await one('SELECT count(*) n FROM case_chat_messages WHERE case_id=? AND sequence=?', c.id, ack.message.sequence)).n, 1, 'the ACK refers to a committed D1 row');
  sock.ws.send(JSON.stringify({ protocolVersion: '1.0.0', type: 'HEARTBEAT', commandId: key() }));
  assert.ok(await until(() => sock.frames.some(f => f.type === 'ERROR')), 'wrong protocol version → ERROR frame');
  // Disconnect, miss messages, reconnect: HTTP replay from the last seen sequence fills the gap.
  const seen = Math.max(...sock.frames.filter(f => f.type === 'MESSAGE_COMMITTED').map(f => f.message.sequence)); sock.ws.close(1000);
  await json(await send(`/api/candidates/${c.id}/chat`, 'POST', { action: 'send', message: text('while offline 1') }, staffA), 201);
  await json(await send(`/api/candidates/${c.id}/chat`, 'POST', { action: 'send', message: text('while offline 2') }, staffA), 201);
  const gap = await page(c, seen); assert.deepEqual(gap.items.map(i => i.text), ['while offline 1', 'while offline 2']);
  const again = await wsOpen('/api/client/chat?socket=1', client(c));
  await db.prepare('UPDATE client_sessions SET revoked_at=? WHERE token_hash=?').bind(Date.now(), c.tokenHash).run();
  again.ws.send(JSON.stringify({ protocolVersion: '2.0.0', type: 'HEARTBEAT', commandId: key() }));
  assert.ok(await until(() => again.closed === 4401), 'revoked session disconnected');
  assert.equal((await send('/api/client/chat', 'GET', undefined, client(c))).status, 401, 'and HTTP refuses it too');
  // Staff deactivation also closes a staff socket.
  const ss = await wsOpen(`/api/candidates/${c.id}/chat?socket=1`, staffB);
  await json(await send('/api/office', 'POST', { action: 'member', email: 'staff-b@example.test', name: 'QA Staff B', active: false }, admin));
  ss.ws.send(JSON.stringify({ protocolVersion: '2.0.0', type: 'HEARTBEAT', commandId: key() }));
  assert.ok(await until(() => ss.closed === 4401), 'deactivated staff disconnected');
  await json(await send('/api/office', 'POST', { action: 'member', email: 'staff-b@example.test', name: 'QA Staff B', active: true }, admin));
});
test('AC-32: an idle socket whose session is revoked is closed by the room alarm within 30 s (no inbound frame needed)', async () => {
  const c = await clientCaseFixture(db, { name: 'QA Idle Socket', email: 'idle@example.test', phone: '+15557770009' });
  const s = await wsOpen('/api/client/chat?socket=1', client(c)), t0 = Date.now();
  await db.prepare('UPDATE client_sessions SET revoked_at=? WHERE token_hash=?').bind(Date.now(), c.tokenHash).run();
  assert.ok(await until(() => s.closed === 4401, 32000), 'closed by the alarm sweep');
  assert.ok(Date.now() - t0 <= 31000, 'within 30 s (+1 s scheduling), took ' + (Date.now() - t0) + ' ms');
});
test('Rapid Assessment: same engine and release, RAPID_SCREENING only, verified pointer untouched; no active release → RULE_UNAVAILABLE', async () => {
  const c = await clientCaseFixture(db, { name: 'QA Rapid', email: 'rapid@example.test', phone: '+15557770005' });
  assert.equal((await chat(c, { action: 'rapid_assessment', requestKey: key(), confirmed: true })).status, 409, 'no sealed release');
  for (const [sid, s] of Object.entries(SOURCES)) await json(await send('/api/office/rules/import', 'POST', { action: 'source', sourceId: sid, officialUrl: s.officialUrl, authority: 'TEST_ONLY', contentBase64: b64(s.text) }, admin), 201);
  const up = async b => (await json(await send('/api/office/rules/import', 'POST', { action: 'bundle', payload: b.payload, payloadHash: b.hash }, admin), 201)).bundleId;
  const W = { crs: await up(await crsBundle()), fsw: await up(await programBundle()), noc: await up(await nocBundle()) };
  const iv = (programId, family, effectiveFrom, bundleId) => ({ programId, family, phase: 'PROFILE', dateBasis: 'PROFILE', effectiveFrom, effectiveToExclusive: null, bundleId });
  const intervals = [iv('EE_CRS', 'CRS', '2026-11-03', W.crs), iv('EE_FSWP', 'ELIGIBILITY', '2026-01-01', W.fsw), iv('NOC_2021', 'NOC_CATALOG', '2026-01-01', W.noc)];
  const pv = await json(await send('/api/office/rules/releases', 'POST', { action: 'preview', intervals }, admin), 200);
  await json(await send('/api/office/rules/releases', 'POST', { action: 'seal', intervals, manifestHash: pv.manifestHash, activate: { expectedGeneration: 0, reasonCode: 'gate5-chat-test' } }, admin), 201);
  const before = await one('SELECT latest_verified_assessment_id v FROM candidates WHERE id=?', c.id);
  const rk = key(), r = await chat(c, { action: 'rapid_assessment', requestKey: rk, confirmed: true }, 201);
  assert.equal(r.purpose, 'RAPID_SCREENING');
  const h = await one('SELECT assessment_purpose p,assessment_mode m,engine_version e FROM assessment_history WHERE id=?', r.assessmentId);
  assert.deepEqual([h.p, h.m, h.e], ['RAPID_SCREENING', 'PRODUCTION', 'v22-engine-1.0.0']);
  const after = await one('SELECT latest_verified_assessment_id v,latest_rapid_assessment_id r FROM candidates WHERE id=?', c.id);
  assert.equal(after.v, before.v, 'verified pointer untouched'); assert.equal(after.r, r.assessmentId);
  const again = await chat(c, { action: 'rapid_assessment', requestKey: rk, confirmed: true }, 201);
  assert.equal(again.assessmentId, r.assessmentId); assert.equal(await count('SELECT count(*) n FROM assessment_history WHERE candidate_id=?', c.id), 1, 'no duplicate history');
  const p = await page(c); assert.equal(p.items.filter(i => i.kind === 'ASSESSMENT_LINK').length, 1, 'one assessment message');
  assert.ok(!JSON.stringify(p).includes('FINAL'), 'never presented as FINAL');
});
test('legacy support endpoints write to the canonical chat and keep old history readable', async () => {
  const c = await clientCaseFixture(db, { name: 'QA Legacy', email: 'legacy-chat@example.test', phone: '+15557770006' });
  await db.prepare("INSERT INTO support_threads(candidate_id,status,last_message_at,updated_at) VALUES(?,'ai',?,?)").bind(c.id, '2026-01-01T00:00:00Z', '2026-01-01T00:00:00Z').run();
  await db.prepare("INSERT INTO support_messages(id,candidate_id,sender,body,created_at) VALUES(?,?,'client','old legacy message','2026-01-01T00:00:00Z')").bind(key(), c.id).run();
  const r = await json(await send('/api/client/support', 'POST', { body: 'new via legacy', human: true }, client(c)));
  assert.deepEqual(r.messages.map(m => m.body), ['old legacy message', 'new via legacy']); assert.equal(r.withStaff, true);
  assert.equal(await count('SELECT count(*) n FROM support_messages WHERE candidate_id=?', c.id), 1, 'no new legacy row');
  assert.equal(await count('SELECT count(*) n FROM case_chat_messages WHERE case_id=?', c.id), 1);
  const inbox = await json(await send('/api/support', 'GET', undefined, staffA));
  assert.ok(inbox.items.some(i => i.candidateId === c.id && i.state === 'HANDOFF_PENDING'));
  await json(await send(`/api/support/${c.id}/claim`, 'POST', undefined, staffA));
  const v = await json(await send(`/api/support/${c.id}`, 'POST', { body: 'staff via legacy' }, staffA));
  assert.equal(v.state, 'HUMAN_ACTIVE'); assert.equal(v.messages.at(-1).body, 'staff via legacy');
});
