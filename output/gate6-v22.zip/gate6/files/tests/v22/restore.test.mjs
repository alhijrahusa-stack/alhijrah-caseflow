// v2.2 Gate 6 — privacy lifecycle and isolated restore drill on the built Worker (Miniflare D1/R2; never production).
// Privacy: MANAGER-only, append-only ledger, legal hold refuses erasure, access export, erasure removes deletable
// personal bytes (R2 evidence, identity fields, sessions, notice payloads) and reports immutable records as retained.
// Restore: logical D1+R2 backup with key fingerprints → failure after more writes and an erasure → restore into a fresh
// isolated instance (wrong key refused) → quick_check / foreign_key_check / per-table counts+hashes / R2 bytes →
// measured RPO/RTO → erasure journal re-applied (re-erasure) → outbox rows not confirmed become AMBIGUOUS and are re-sent
// only with the same Idempotency-Key → capability disable (no CHAT_ROOMS / scanner) → rollback: the previous build
// (44fd112, before 0031) runs on the restored, forward-migrated database.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, readdir, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { seedOfficeManager } from './office-fixture.mjs';
import { clientCaseFixture } from './client-case-fixture.mjs';
import { backup, restore, postRestore, verify } from '../../scripts/restore-drill.mjs';

const require = createRequire(import.meta.url);
const { Miniflare } = createRequire(require.resolve('wrangler/package.json'))('miniflare');
const base = 'http://canada-desk.test', SECRET = 'f'.repeat(64);
const ROLLBACK_DIST = process.env.ROLLBACK_DIST || '';
const admin = { 'oai-authenticated-user-id': 'admin-1', 'oai-authenticated-user-email': 'admin@example.test' };
const staffA = { 'oai-authenticated-user-id': 'staff-a', 'oai-authenticated-user-email': 'staff-a@example.test' };
const key = () => crypto.randomUUID();
let calls = [];
async function instance(name, { dist = 'dist/server', chatRooms = false, secret = SECRET } = {}) {
  const files = await readdir(dist, { recursive: true });
  const mf = new Miniflare({
    modules: ['index.js', ...files.filter(f => f !== 'index.js' && f.endsWith('.js'))].map(f => ({ type: 'ESModule', path: path.resolve(dist, f) })),
    modulesRoot: path.resolve(dist), compatibilityDate: '2026-05-15', compatibilityFlags: ['nodejs_compat'],
    d1Databases: { DB: name + '-db' }, r2Buckets: { BUCKET: name + '-r2' }, ...(chatRooms ? { durableObjects: { CHAT_ROOMS: 'CaseChatRoom' } } : {}),
    bindings: { TRUST_SITES_IDENTITY_HEADERS: '1', OFFICE_ADMIN_EMAIL: 'admin@example.test', APP_SECRET: secret },
    outboundService: async req => { if (new URL(req.url).hostname !== 'api.resend.com') return new Response('blocked', { status: 599 }); calls.push(req.headers.get('idempotency-key')); return Response.json({ id: 're_' + calls.length }); },
  });
  const send = async (p, method = 'GET', body, headers = admin) => mf.dispatchFetch(base + p, { method, headers: { ...headers, ...(body ? { 'content-type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const json = async (r, status = 200) => { const t = await r.text(); assert.equal(r.status, status, t); return t ? JSON.parse(t) : null; };
  return { mf, db: await mf.getD1Database('DB'), bucket: await mf.getR2Bucket('BUCKET'), send, json, worker: await mf.getWorker() };
}
async function migrate(db) { for (const f of (await readdir('drizzle')).filter(f => f.endsWith('.sql')).sort()) for (const s of (await readFile('drizzle/' + f, 'utf8')).split('--> statement-breakpoint').map(s => s.trim()).filter(Boolean)) await db.prepare(s).run(); }
async function upload(src, caseId, text) {
  const form = new FormData(); form.set('file', new File([new TextEncoder().encode('%PDF-1.4\n' + text + '\n%%EOF')], 'doc.pdf', { type: 'application/pdf' })); form.set('category', 'other');
  const req = new Request(base + `/api/candidates/${caseId}/documents`, { method: 'POST', body: form, headers: admin });
  return src.json(await src.mf.dispatchFetch(req.url, { method: 'POST', headers: Object.fromEntries(req.headers), body: await req.arrayBuffer() }), 201);
}
const profile = (n, phone, email) => ({ fullName: n, phone, email, consent: true, jobs: [{ title: 'QA role', employer: 'QA employer', country: 'Yemen', start: '2024-01', end: '2024-12', weekly_hours: 40 }], occupation: 'Synthetic test', noc: '72401', teer: 2, experience3: 12, experience10: 24, englishMin: 5, englishDate: '2026-10-01' });
let src; const st = {};
test.before(async () => {
  src = await instance('restore-src', { chatRooms: true }); await migrate(src.db); await seedOfficeManager(src.db, 'admin-1');
  await src.json(await src.send('/api/office'));
  await src.json(await src.send('/api/office', 'POST', { action: 'member', email: 'staff-a@example.test', name: 'QA Staff A', active: true }));
  await src.json(await src.send('/api/office', 'POST', { action: 'mail', sender: 'office@example.test', key: 're_' + 'r'.repeat(20) }));
  await src.json(await src.send('/api/office', 'POST', { action: 'billing_currency', currency: 'CAD' }));
});
test.after(async () => { await src?.mf.dispose(); await st.dst?.mf.dispose(); await st.old?.mf.dispose(); });
async function clientCase(name, phone, email) {
  const c = await src.json(await src.send('/api/candidates', 'POST', profile(name, phone, email)), 201);
  return clientCaseFixture(src.db, { name, email, phone, candidateId: c.id });
}
test('privacy: MANAGER-only ledger; hold refuses erasure; access export; erasure removes deletable personal data and reports retained records', async () => {
  const y = await clientCase('QA Privacy Subject', '+15559990001', 'privacy-subject@example.test'), cookie = { cookie: y.cookie };
  const doc = await upload(src, y.id, 'private evidence ' + key());
  const obj = (await src.db.prepare('SELECT object_key k FROM documents WHERE id=?').bind(doc.id).first()).k;
  await src.json(await src.send('/api/client/chat', 'POST', { action: 'send', message: { clientMessageId: key(), repliedToMessageId: null, kind: 'TEXT', text: 'my private question' } }, cookie), 201);
  await src.json(await src.send('/api/client/chat', 'POST', { action: 'send', message: { clientMessageId: key(), repliedToMessageId: null, kind: 'ATTACHMENT', evidenceIds: [doc.id] } }, cookie), 201);
  const inv = await src.json(await src.send(`/api/candidates/${y.id}/invoices`, 'POST', { currency: 'CAD', items: [{ kind: 'CUSTOM', serviceName: 'Service', unitPriceCents: 5000, isFree: false, referencePriceCents: null }], discountCents: 0, deadline: null, note: null, requestKey: key() }), 201);
  await src.json(await src.send(`/api/invoices/${inv.invoiceId}/notice`, 'POST', { expectedVersion: inv.version, channel: 'EMAIL', requestKey: key() }), 202);
  const p = (kind, requestKey = key(), headers = admin) => src.send(`/api/candidates/${y.id}/privacy`, 'POST', { kind, reasonCode: 'qa-' + kind.toLowerCase(), requestKey }, headers);
  assert.equal((await p('ERASURE', key(), staffA)).status, 403, 'STAFF cannot run privacy requests');
  assert.equal((await src.send(`/api/candidates/${y.id}/privacy`, 'GET', undefined, staffA)).status, 403);
  const exp = await src.json(await p('ACCESS'));
  assert.equal(exp.state, 'COMPLETED'); assert.equal(exp.export.profile.email, 'privacy-subject@example.test');
  assert.ok(exp.export.chat.some(m => m.text === 'my private question')); assert.equal(exp.export.invoices[0].totalCents, 5000);
  assert.equal((await src.json(await p('HOLD'))).state, 'COMPLETED');
  const refused = await src.json(await p('ERASURE')); assert.equal(refused.state, 'REFUSED'); assert.equal(refused.result.reason, 'LEGAL_HOLD_ACTIVE');
  assert.ok(await src.bucket.get(obj), 'nothing erased under hold');
  assert.equal((await src.json(await p('RELEASE_HOLD'))).state, 'COMPLETED');
  const ek = key(), erased = await src.json(await p('ERASURE', ek));
  assert.equal(erased.state, 'COMPLETED'); assert.equal(erased.result.objectsDeleted, 1); assert.equal(erased.result.policyApproved, false);
  assert.ok(erased.result.retainedPendingPolicy.includes('financial_ledger_and_receipts'), 'immutable records reported, not hidden');
  const again = await src.json(await p('ERASURE', ek)); assert.equal(again.replayed, true); assert.equal(again.requestId, erased.requestId);
  const c = await src.db.prepare('SELECT profile,email_key,status FROM candidates WHERE id=?').bind(y.id).first(), prof = JSON.parse(c.profile);
  assert.deepEqual([prof.fullName, prof.email, prof.erased, c.email_key, c.status], ['[erased]', '', true, '', 'archived']);
  assert.equal(await src.bucket.get(obj), null, 'R2 evidence deleted');
  assert.equal((await src.send('/api/client/chat', 'GET', undefined, cookie)).status, 401, 'client sessions revoked');
  const ob = await src.db.prepare("SELECT state,error_code e,payload_encrypted p FROM delivery_outbox WHERE case_id=?").bind(y.id).first();
  assert.deepEqual([ob.state, ob.e], ['CANCELLED', 'ERASED']);
  const chat = await src.json(await src.send(`/api/candidates/${y.id}/chat`, 'GET', undefined, admin));
  assert.equal(chat.items.find(i => i.kind === 'ATTACHMENT').attachments[0].state, 'ERASED');
  assert.equal((await src.send(`/api/candidates/${y.id}/chat?media=${doc.id}`, 'GET', undefined, admin)).status, 410);
  await assert.rejects(src.db.prepare("UPDATE privacy_requests SET result_json='{}' WHERE request_id=?").bind(erased.requestId).run(), /IMMUTABLE_PRIVACY_LEDGER/);
  await assert.rejects(src.db.prepare('DELETE FROM privacy_requests').run(), /IMMUTABLE_PRIVACY_LEDGER/);
  const ledger = await src.json(await src.send(`/api/candidates/${y.id}/privacy`));
  assert.deepEqual(ledger.ledger.map(r => r.kind + ':' + r.state), ['ACCESS:COMPLETED', 'HOLD:COMPLETED', 'ERASURE:REFUSED', 'RELEASE_HOLD:COMPLETED', 'ERASURE:COMPLETED']);
});
test('restore drill: backup → more writes + erasure → isolated restore, verification, RPO/RTO, re-erasure, no unconfirmed resend, capability disable, rollback', async () => {
  // State at backup time.
  const x = await clientCase('QA Restore Subject', '+15559990002', 'restore-subject@example.test'), cookie = { cookie: x.cookie };
  const doc = await upload(src, x.id, 'restore evidence ' + key());
  await src.json(await src.send('/api/client/chat', 'POST', { action: 'send', message: { clientMessageId: key(), repliedToMessageId: null, kind: 'TEXT', text: 'before backup' } }, cookie), 201);
  const inv = await src.json(await src.send(`/api/candidates/${x.id}/invoices`, 'POST', { currency: 'CAD', items: [{ kind: 'CUSTOM', serviceName: 'Service', unitPriceCents: 9000, isFree: false, referencePriceCents: null }], discountCents: 0, deadline: null, note: null, requestKey: key() }), 201);
  const form = new FormData(); form.set('payload', JSON.stringify({ expectedVersion: 1, amountCents: 4000, method: 'ZELLE', paidAt: new Date().toISOString(), notes: null, idempotencyKey: 'pay-' + key() })); form.set('receipt', new File([new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3])], 'r.png', { type: 'image/png' }));
  const preq = new Request(base + `/api/invoices/${inv.invoiceId}/payments`, { method: 'POST', body: form, headers: admin });
  const paid = await src.json(await src.mf.dispatchFetch(preq.url, { method: 'POST', headers: Object.fromEntries(preq.headers), body: await preq.arrayBuffer() }), 201);
  const notice = await src.json(await src.send(`/api/invoices/${inv.invoiceId}/notice`, 'POST', { expectedVersion: paid.version, channel: 'EMAIL', requestKey: key() }), 202);
  const w = await clientCase('QA Restore Other', '+15559990003', 'restore-other@example.test');
  const winv = await src.json(await src.send(`/api/candidates/${w.id}/invoices`, 'POST', { currency: 'CAD', items: [{ kind: 'CUSTOM', serviceName: 'Service', unitPriceCents: 1000, isFree: false, referencePriceCents: null }], discountCents: 0, deadline: null, note: null, requestKey: key() }), 201);
  const wnotice = await src.json(await src.send(`/api/invoices/${winv.invoiceId}/notice`, 'POST', { expectedVersion: winv.version, channel: 'EMAIL', requestKey: key() }), 202);
  const b = await backup({ db: src.db, bucket: src.bucket, secrets: { APP_SECRET: SECRET } });
  assert.ok(b.snapshot.r2.length >= 2, 'evidence + receipt objects in the backup'); assert.equal(b.snapshot.keyFingerprints.APP_SECRET.length, 64);
  assert.ok(!JSON.stringify(b.snapshot.keyFingerprints).includes(SECRET), 'secrets never stored in the snapshot');
  // Writes after the backup (lost by design within the RPO) and an erasure recorded in the journal.
  await src.json(await src.send('/api/client/chat', 'POST', { action: 'send', message: { clientMessageId: key(), repliedToMessageId: null, kind: 'TEXT', text: 'after backup' } }, cookie), 201);
  await src.json(await src.send(`/api/candidates/${x.id}/privacy`, 'POST', { kind: 'ERASURE', reasonCode: 'qa-erasure', requestKey: key() }));
  const { journal } = await src.json(await src.send('/api/office', 'POST', { action: 'privacy_journal' }));
  assert.ok(journal.some(j => j.caseId === x.id));
  const failureAtMs = Date.now();
  // Isolated restore. A wrong key is refused before anything is written.
  const wrong = await instance('restore-wrongkey', { secret: 'e'.repeat(64) });
  await assert.rejects(restore({ db: wrong.db, bucket: wrong.bucket, secrets: { APP_SECRET: 'e'.repeat(64) } }, b.snapshot), /KEY_FINGERPRINT_MISMATCH/);
  await wrong.mf.dispose();
  const restoreStart = Date.now();
  st.dst = await instance('restore-dst'); const dst = st.dst;
  const r = await restore({ db: dst.db, bucket: dst.bucket, secrets: { APP_SECRET: SECRET } }, b.snapshot);
  const post = await postRestore({ db: dst.db });
  await dst.json(await dst.send('/api/candidates/' + x.id));                                 // first authorized read on the restored service
  const rtoMs = Date.now() - restoreStart, rpoMs = failureAtMs - b.snapshot.takenAtMs;
  assert.deepEqual(r.verification.quickCheck, ['ok']); assert.equal(r.verification.foreignKeyViolations, 0);
  assert.ok(r.verification.allTablesOk, JSON.stringify(Object.entries(r.verification.tables).filter(([, t]) => !t.countOk || !t.hashOk)));
  assert.equal(r.verification.r2Bad.length, 0); assert.equal(r.verification.schemaObjects, r.verification.schemaObjectsExpected);
  // Encrypted data is readable with the restored key; the post-backup message is absent (inside the measured RPO).
  const replay = await dst.json(await dst.send(`/api/candidates/${x.id}/chat`, 'GET', undefined, admin));
  assert.ok(replay.items.some(i => i.text === 'before backup')); assert.ok(!replay.items.some(i => i.text === 'after backup'));
  assert.equal(replay.transport, 'HTTP_POLL', 'capability disabled (no CHAT_ROOMS): chat still served over HTTP');
  // Re-erasure from the external journal.
  const objKey = (await dst.db.prepare('SELECT object_key k FROM documents WHERE id=?').bind(doc.id).first()).k;
  assert.ok(objKey && await dst.bucket.get(objKey), 'the restored snapshot predates the erasure');
  const re = await dst.json(await dst.send('/api/office', 'POST', { action: 'privacy_reapply', journal }));
  assert.ok(re.reapplied >= 1);
  assert.equal(JSON.parse((await dst.db.prepare('SELECT profile FROM candidates WHERE id=?').bind(x.id).first()).profile).fullName, '[erased]');
  assert.equal(await dst.bucket.get(objKey), null, 'evidence erased again in the restored bucket');
  assert.equal((await dst.db.prepare("SELECT count(*) n FROM privacy_requests WHERE case_id=? AND kind='ERASURE' AND state='COMPLETED'").bind(x.id).first()).n, 1, 'ledger row restored once');
  // No unconfirmed resend: the notice was never confirmed → AMBIGUOUS → cancelled by the re-erasure for this subject.
  assert.ok(post.outboxMarkedAmbiguous >= 1);
  const ob = await dst.db.prepare('SELECT state,error_code e FROM delivery_outbox WHERE event_id=?').bind(notice.eventId).first();
  assert.deepEqual([ob.state, ob.e], ['CANCELLED', 'ERASED']);
  // A notice of another (not erased) case restored as AMBIGUOUS is re-sent once, with its original event-id key.
  assert.equal((await dst.db.prepare('SELECT state FROM delivery_outbox WHERE event_id=?').bind(wnotice.eventId).first()).state, 'AMBIGUOUS');
  calls = []; await dst.worker.scheduled({ cron: '*/5 * * * *', scheduledTime: new Date() }); await dst.worker.scheduled({ cron: '*/5 * * * *', scheduledTime: new Date() });
  assert.deepEqual(calls, ['outbox/' + wnotice.eventId], 'one call, with the original event-id Idempotency-Key');
  assert.equal((await dst.db.prepare('SELECT state FROM delivery_outbox WHERE event_id=?').bind(wnotice.eventId).first()).state, 'DELIVERED');
  const verifyAfter = await verify({ db: dst.db, bucket: dst.bucket }, b.snapshot);
  assert.deepEqual(verifyAfter.quickCheck, ['ok']); assert.equal(verifyAfter.foreignKeyViolations, 0);
  // Rollback compatibility: the previous build (before 0031) serves the restored, forward-migrated database.
  if (ROLLBACK_DIST && existsSync(ROLLBACK_DIST)) {
    st.old = await instance('restore-dst', { dist: ROLLBACK_DIST });
    const restoreInto = await restore({ db: st.old.db, bucket: st.old.bucket, secrets: { APP_SECRET: SECRET } }, b.snapshot);
    assert.ok(restoreInto.verification.allTablesOk);
    await st.old.json(await st.old.send('/api/office'));
    const list = await st.old.json(await st.old.send('/api/candidates'));
    assert.ok(list.items.some(i => i.id === x.id), 'previous build reads the restored data');
    await st.old.json(await st.old.send(`/api/candidates/${x.id}/invoices`));
    st.rollback = 'PASS (previous build at ' + (process.env.ROLLBACK_REF || ROLLBACK_DIST) + ')';
  } else st.rollback = 'NOT_RUN (ROLLBACK_DIST not provided)';
  const report = { takenAtMs: b.snapshot.takenAtMs, backupDurationMs: b.durationMs, backupSha256: b.sha256, failureAtMs, rpoMs, restoreDurationMs: r.durationMs, rtoMs, tables: Object.keys(b.snapshot.tables).length, rows: Object.values(b.snapshot.tables).reduce((n, t) => n + t.count, 0), r2Objects: b.snapshot.r2.length, postRestore: post, reErasure: re, rollback: st.rollback, environment: 'Miniflare (local, isolated); not Cloudflare staging' };
  if (process.env.RESTORE_REPORT) await writeFile(process.env.RESTORE_REPORT, JSON.stringify(report, null, 2));
  console.log('RESTORE_REPORT ' + JSON.stringify(report));
});
