// v2.2 Gate 5 — browser E2E (Chromium via Playwright) on the built Worker in Miniflare with the CaseChatRoom Durable
// Object, behind the same local HTTPS test server as Gate 4 (self-signed per run; static assets from dist/client, all
// other requests to the Worker). Staff identity uses the trusted test headers; the client uses a full_case session
// cookie created by the fixture. Covers: MANAGER billing settings, invoice creation and a partial cash payment from the
// case drawer, office billing totals, the client's invoice card, the client chat ↔ staff inbox round trip (claim and
// reply), the client privacy toggles, and no horizontal overflow at 360/1440.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, readdir, mkdir } from 'node:fs/promises';
import path from 'node:path';
import https from 'node:https';
import os from 'node:os';
import { execFileSync } from 'node:child_process';
import { createReadStream, existsSync, statSync, readFileSync, mkdtempSync } from 'node:fs';
import { seedOfficeManager } from './office-fixture.mjs';
import { clientCaseFixture } from './client-case-fixture.mjs';

const require = createRequire(import.meta.url);
const { Miniflare } = createRequire(require.resolve('wrangler/package.json'))('miniflare');
const { chromium } = require('playwright');
const SHOTS = process.env.E2E_SHOTS || '';
type Db = { prepare: (q: string) => { bind: (...a: unknown[]) => { first: () => Promise<Record<string, unknown>>; run: () => Promise<unknown> }; run: () => Promise<unknown> } };
type Mf = { dispatchFetch: (u: string, init?: Record<string, unknown>) => Promise<Response>; getD1Database: (n: string) => Promise<Db>; dispose: () => Promise<void> };
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- untyped global Playwright handle (test-only)
type Browser = { newContext: (o: Record<string, unknown>) => Promise<any>; close: () => Promise<void> };
let mf: Mf, url = '', browser: Browser, server: https.Server, db: Db;
const MIME: Record<string, string> = { '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.json': 'application/json', '.webmanifest': 'application/manifest+json' };
const admin = { 'oai-authenticated-user-id': 'admin-1', 'oai-authenticated-user-email': 'admin@example.test' };
const staffA = { 'oai-authenticated-user-id': 'staff-a', 'oai-authenticated-user-email': 'staff-a@example.test' };
const api = async (p: string, method = 'GET', body?: unknown, headers: Record<string, string> = admin) => { const r = await mf.dispatchFetch(url + p, { method, headers: { ...headers, ...(body ? { 'content-type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined }); const t = await r.text(); assert.ok(r.status < 300, p + ' ' + r.status + ' ' + t); return t ? JSON.parse(t) : null; };
const st: Record<string, { id: string; reference: string; cookie?: string; token?: string }> = {};

test.before(async () => {
  const files = await readdir('dist/server', { recursive: true });
  mf = new Miniflare({
    modules: ['index.js', ...files.filter((f: string) => f !== 'index.js' && f.endsWith('.js'))].map((f: string) => ({ type: 'ESModule', path: path.resolve('dist/server', f) })),
    modulesRoot: path.resolve('dist/server'), compatibilityDate: '2026-05-15', compatibilityFlags: ['nodejs_compat'],
    d1Databases: { DB: 'gate5-e2e' }, r2Buckets: ['BUCKET'], durableObjects: { CHAT_ROOMS: 'CaseChatRoom' },
    bindings: { TRUST_SITES_IDENTITY_HEADERS: '1', OFFICE_ADMIN_EMAIL: 'admin@example.test', APP_SECRET: 'e'.repeat(64) },
    outboundService: async () => new Response('blocked', { status: 599 }),
  }) as unknown as Mf;
  const dir = mkdtempSync(path.join(os.tmpdir(), 'alh-e2e5-')), clientDir = path.resolve('dist/client');
  execFileSync('openssl', ['req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', dir + '/k.pem', '-out', dir + '/c.pem', '-days', '1', '-subj', '/CN=127.0.0.1', '-addext', 'subjectAltName=IP:127.0.0.1'], { stdio: 'ignore' });
  server = https.createServer({ key: readFileSync(dir + '/k.pem'), cert: readFileSync(dir + '/c.pem') }, async (req, res) => {
    try {
      const u = new URL(req.url || '/', 'https://127.0.0.1'), file = path.join(clientDir, decodeURIComponent(u.pathname));
      if (u.pathname !== '/' && file.startsWith(clientDir + path.sep) && existsSync(file) && statSync(file).isFile()) { res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream' }); createReadStream(file).pipe(res); return; }
      const chunks: Buffer[] = []; for await (const c of req) chunks.push(c as Buffer);
      const headers = Object.entries(req.headers).filter(([k]) => !['host', 'connection', 'content-length'].includes(k)).map(([k, v]) => [k, Array.isArray(v) ? v.join(', ') : String(v)]);
      const r = await mf.dispatchFetch(url + req.url, { method: req.method, headers, body: ['GET', 'HEAD'].includes(req.method || 'GET') ? undefined : Buffer.concat(chunks), redirect: 'manual' });
      const out: Record<string, string | string[]> = {}; r.headers.forEach((v: string, k: string) => { if (!['set-cookie', 'content-encoding', 'content-length', 'transfer-encoding'].includes(k)) out[k] = v; });
      const cookies = r.headers.getSetCookie(); if (cookies.length) out['set-cookie'] = cookies;
      res.writeHead(r.status, out); res.end(Buffer.from(await r.arrayBuffer()));
    } catch (e) { res.writeHead(502); res.end(String(e)); }
  });
  await new Promise<void>(r => server.listen(0, '127.0.0.1', () => r()));
  url = 'https://127.0.0.1:' + (server.address() as { port: number }).port;
  db = await mf.getD1Database('DB');
  for (const f of (await readdir('drizzle')).filter((f: string) => f.endsWith('.sql')).sort())
    for (const s of (await readFile('drizzle/' + f, 'utf8')).split('--> statement-breakpoint').map((s: string) => s.trim()).filter(Boolean)) await db.prepare(s).run();
  await seedOfficeManager(db, 'admin-1');
  await api('/api/office');
  await api('/api/office', 'POST', { action: 'member', email: 'staff-a@example.test', name: 'QA Staff A', active: true });
  const created = await api('/api/candidates', 'POST', { fullName: 'QA E2E Client', phone: '+15558880001', email: 'e2e-client@example.test', consent: true, jobs: [{ title: 'QA role', employer: 'QA employer', country: 'Yemen', start: '2024-01', end: '2024-12', weekly_hours: 40 }], occupation: 'Synthetic test', noc: '72401', teer: 2, experience3: 12, experience10: 24, englishMin: 5, englishDate: '2026-10-01' });
  st.client = await clientCaseFixture(db, { name: 'QA E2E Client', email: 'e2e-client@example.test', phone: '+15558880001', candidateId: created.id }) as unknown as { id: string; reference: string; token: string; cookie: string };
  browser = await chromium.launch();
  if (SHOTS) await mkdir(SHOTS, { recursive: true });
});
test.after(async () => { await browser?.close(); server?.close(); await mf?.dispose(); });
const ctx = (opts: Record<string, unknown> = {}) => browser.newContext({ ignoreHTTPSErrors: true, ...opts });
const noOverflow = (page: { evaluate: (f: () => boolean) => Promise<boolean> }) => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1);

test('MANAGER billing: explicit currency and catalog, invoice from the case drawer, partial cash payment, office totals', async () => {
  const c = await ctx({ viewport: { width: 1440, height: 900 }, extraHTTPHeaders: admin }), page = await c.newPage();
  page.on('dialog', (d: { accept: () => void }) => d.accept()); page.on('pageerror', (e: Error) => console.log('PAGEERROR', e.message));
  await page.goto(url + '/');
  await page.locator('.nav-item', { hasText: 'الفوترة' }).click();
  await page.getByText('لا تُنشأ فواتير قبل تحديدها').waitFor();
  await page.getByLabel('عملة المكتب (ISO)').fill('CAD'); await page.getByRole('button', { name: 'حفظ العملة' }).click();
  await page.getByText('الحالية: CAD').waitFor();
  await page.getByLabel('رمز الخدمة').fill('profile-prep'); await page.getByLabel('الاسم بالعربية').fill('تجهيز الملف'); await page.getByLabel('الاسم بالإنجليزية').fill('Profile preparation'); await page.getByLabel('السعر').fill('250.00');
  await page.getByRole('button', { name: 'حفظ الخدمة' }).click();
  await page.locator('.billing-table td', { hasText: 'profile-prep' }).waitFor();
  assert.ok(await noOverflow(page), 'billing view fits 1440');
  if (SHOTS) await page.screenshot({ path: path.join(SHOTS, 'office-billing-1440.png') });
  // Case drawer → billing tab → invoice → payment.
  await page.goto(url + '/?candidate=' + st.client.id);
  await page.locator('.detail-tabs button', { hasText: 'الفوترة' }).click();
  await page.getByRole('button', { name: 'فاتورة جديدة' }).click();
  await page.locator('.invoice-form select').first().selectOption('profile-prep');
  await page.locator('.invoice-terms input').first().fill('50.00');
  await page.getByRole('button', { name: 'إنشاء الفاتورة' }).click();
  await page.locator('.invoice-summary', { hasText: '200.00 CAD' }).waitFor();
  await page.locator('.invoice-summary').first().click();
  await page.locator('.payment-form input').first().fill('75.25');
  await page.getByRole('button', { name: 'تسجيل الدفعة' }).click();
  await page.locator('.invoice-summary', { hasText: 'مدفوعة جزئيًا' }).waitFor();
  const inv = await db.prepare('SELECT total_cents t,paid_cents p,remaining_cents r,status s FROM invoices WHERE case_id=?').bind(st.client.id).first();
  assert.deepEqual([inv.t, inv.p, inv.r, inv.s], [20000, 7525, 12475, 'PARTIAL'], 'server figures match the UI');
  if (SHOTS) await page.screenshot({ path: path.join(SHOTS, 'case-billing-1440.png') });
  await page.goto(url + '/');
  await page.locator('.nav-item', { hasText: 'الفوترة' }).click();
  await page.locator('.billing-kpis', { hasText: '75.25 CAD' }).waitFor();
  await c.close();
});
test('client portal: invoice card and case chat ↔ staff inbox (claim + reply) with privacy toggles; 360 px fits', async () => {
  for (const width of [360, 1440]) {
    const c = await ctx({ viewport: { width, height: 900 } });
    await c.addCookies([{ name: 'alh_client_session', value: st.client.token, url }]);
    const page = await c.newPage();
    await page.goto(url + '/client');
    await page.locator('.client-billing').waitFor();
    assert.ok(await page.locator('.client-billing summary', { hasText: '200.00 CAD' }).count() >= 1, 'client sees the invoice');
    assert.ok(await noOverflow(page), 'no horizontal overflow at ' + width);
    if (width === 1440) {
      await page.locator('.case-chat input[aria-label="رسالتك"]').fill('سؤال من البوابة');
      await page.locator('.case-chat .gc-input button[aria-label="إرسال"]').click();
      await page.locator('.case-chat .gc-bubble.client', { hasText: 'سؤال من البوابة' }).waitFor();
      await page.locator('.case-chat .gc-row:not(.pending) .gc-bubble.client', { hasText: 'سؤال من البوابة' }).waitFor();
      await page.getByRole('button', { name: 'خيارات الخصوصية' }).click();
      await page.locator('.chat-consents input').nth(1).click(); // controlled by the server state; confirmed below
      await page.waitForFunction(() => (document.querySelectorAll('.chat-consents input')[1] as HTMLInputElement).checked);
      const consent = await db.prepare("SELECT granted g FROM case_purpose_consents WHERE case_id=? AND purpose='CHAT_NOTIFICATIONS'").bind(st.client.id).first();
      assert.equal(consent.g, 1, 'consent stored');
      // Staff: inbox shows the waiting conversation; claim; reply. The client sees it (WebSocket push or replay).
      const s = await ctx({ viewport: { width: 1440, height: 900 }, extraHTTPHeaders: staffA }), sp = await s.newPage();
      await sp.goto(url + '/');
      await sp.locator('.nav-item', { hasText: 'محادثات العملاء' }).click();
      await sp.locator('.support-row', { hasText: 'QA E2E Client' }).click();
      await sp.getByRole('button', { name: 'استلام' }).click();
      await sp.locator('.chat-state', { hasText: 'مع موظف' }).first().waitFor();
      await sp.locator('.support-input textarea').fill('رد المكتب عبر الواجهة');
      await sp.locator('.support-input button[aria-label="إرسال"]').click();
      await sp.locator('.support-msg.staff', { hasText: 'رد المكتب عبر الواجهة' }).waitFor();
      await page.locator('.case-chat .gc-bubble.staff', { hasText: 'رد المكتب عبر الواجهة' }).waitFor({ timeout: 15000 });
      const conv = await db.prepare('SELECT state s,assigned_to a FROM case_conversations WHERE case_id=?').bind(st.client.id).first();
      assert.deepEqual([conv.s, conv.a], ['HUMAN_ACTIVE', 'staff:staff-a@example.test']);
      if (SHOTS) { await page.screenshot({ path: path.join(SHOTS, 'client-chat-1440.png') }); await sp.screenshot({ path: path.join(SHOTS, 'staff-inbox-1440.png') }); }
      await s.close();
    } else if (SHOTS) await page.screenshot({ path: path.join(SHOTS, 'client-portal-360.png'), fullPage: true });
    await c.close();
  }
});
test('client chat in LTR, keyboard-only send, reduced motion, and a send while offline: nothing committed, the user retry commits exactly one message (lost-ACK same-id replay is covered in chat.test)', async () => {
  const c = await ctx({ viewport: { width: 768, height: 900 }, reducedMotion: 'reduce' });
  await c.addCookies([{ name: 'alh_client_session', value: st.client.token, url }]);
  const page = await c.newPage();
  await page.goto(url + '/client');
  await page.locator('.language-toggle').click();
  await page.locator('.case-chat').waitFor();
  assert.equal(await page.locator('.portal-page').getAttribute('dir'), 'ltr');
  await page.getByText('Privacy options').waitFor();
  const input = page.locator('.case-chat input[aria-label="Your message"]');
  await input.focus(); await page.keyboard.type('Keyboard message'); await page.keyboard.press('Enter');
  await page.locator('.case-chat .gc-row:not(.pending) .gc-bubble.client', { hasText: 'Keyboard message' }).waitFor();
  // Offline on the first attempt: the request fails before reaching the server; the user retries and exactly one
  // message is committed.
  await c.setOffline(true);
  await input.fill('Offline message'); await page.keyboard.press('Enter');
  await page.locator('.case-chat .error-banner').waitFor();
  await c.setOffline(false);
  await input.fill('Offline message'); await page.keyboard.press('Enter');
  await page.locator('.case-chat .gc-row:not(.pending) .gc-bubble.client', { hasText: 'Offline message' }).waitFor();
  const n = await db.prepare("SELECT count(*) n FROM case_chat_messages WHERE case_id=?").bind(st.client.id).first();
  const texts = await page.locator('.case-chat .gc-bubble.client').allInnerTexts();
  assert.equal(texts.filter((t: string) => t.includes('Offline message')).length, 1, 'no duplicate bubble');
  assert.ok(Number(n.n) >= 3);
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), 'no overflow at 768 LTR');
  await c.close();
});
