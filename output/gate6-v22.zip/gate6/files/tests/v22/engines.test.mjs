// v2.2 Gate 3 — rules, engines and the unified assessment. Unit tests on the pure modules, then the built Worker on
// Workers/D1/R2 local via Miniflare (no D1/R2 mocks; the external AI provider is a declared test double through
// outboundService). Payloads come from tests/v22/engine-fixtures.mjs and are TEST_ONLY: they exist only in the
// isolated test database. UI, E2E and live-provider criteria are NOT_RUN here.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { seedOfficeManager } from './office-fixture.mjs';
import { SOURCES, sourceFacts, crsBundle, programBundle, rcipBundle, nocBundle, NOC_ROWS } from './engine-fixtures.mjs';
import { jcs, jcsHash, sha256Hex, torontoDate } from '../../lib/v22-core.ts';
import { validateBundle, validateRelease, computeReleaseManifest, allowedSourceUrl } from '../../lib/rule-import.ts';
import { resolveRule, routeRcip } from '../../lib/rule-resolver.ts';
import { evaluateObligations } from '../../lib/pathways.ts';
import { normalizeCase, FACT_PATH_LIST } from '../../lib/normalization.ts';
import { crsFromPolicy, calculateCrs } from '../../lib/crs.ts';
import { buildV22Assessment } from '../../lib/assessment.ts';
import { eligibilitySchema } from '../../lib/eligibility.ts';
import { validateNocSuggestion, nocSuggestionRequestSchema } from '../../lib/noc.ts';

const today = torontoDate(Date.now());
const blankProfile = { education: 'unknown', eca: 'unknown', noc: '', jobOffer: 'unknown', designated: 'unknown', jobConditions: 'unknown', recommendation: 'unknown' };
const blankDetails = { birthDate: '', passportConfirmed: false, marital: 'unknown', companions: [], guide: { offer: '' }, offerNoc: '31102', recommendationDate: '' };
const loader = map => async id => map.get(id) ?? null;
async function stored(b, id) { return { bundleId: id, payload: jcs(b.payload), payloadSha256: b.hash }; }
const interval = (programId, family, phase, dateBasis, effectiveFrom, effectiveToExclusive, bundleId) => ({ programId, family, phase, dateBasis, effectiveFrom, effectiveToExclusive, bundleId });

// ---------------------------------------------------------------- unit: canonical form, import, release, resolver
test('JCS: member order by code units, nested arrays, non-finite numbers rejected; hash is over UTF-8 bytes', async () => {
  assert.equal(jcs({ b: 1, a: [true, null, { d: 'x', c: 2 }] }), '{"a":[true,null,{"c":2,"d":"x"}],"b":1}');
  assert.equal(jcs({ é: 1, z: 2, A: 3 }), '{"A":3,"z":2,"é":1}');
  assert.throws(() => jcs({ a: NaN }), /NON_FINITE/);
  assert.equal(await jcsHash({ a: 1 }), await sha256Hex('{"a":1}'));
});

test('import: complete payload accepted; missing source, altered bytes, hash, manifest, cycle, path, table and engine defects rejected', async () => {
  const src = await sourceFacts(), good = await programBundle();
  assert.equal((await validateBundle(good.payload, good.hash, src)).ok, true);
  assert.deepEqual((await validateBundle(good.payload, '0'.repeat(64), src)).codes, ['PAYLOAD_HASH_MISMATCH']);
  const noSrc = new Map(src); noSrc.delete('SRC-TEST-PROGRAM');
  assert.ok((await validateBundle(good.payload, good.hash, noSrc)).codes.includes('SOURCE_MISSING:SRC-TEST-PROGRAM'));
  const altered = new Map(src); altered.set('SRC-TEST-PROGRAM', { contentSha256: src.get('SRC-TEST-PROGRAM').contentSha256, storedSha256: 'f'.repeat(64) });
  assert.ok((await validateBundle(good.payload, good.hash, altered)).codes.includes('SOURCE_BYTES_MISMATCH:SRC-TEST-PROGRAM'));
  const rehash = async p => validateBundle(p, await jcsHash(p), src);
  // A required branch removed from the manifest (the obligation stays in the graph): rejected.
  const p1 = structuredClone(good.payload); p1.requiredObligationIds = p1.requiredObligationIds.filter(x => x !== 'p.offer');
  assert.ok((await rehash(p1)).codes.some(c => c.startsWith('OBLIGATION_NOT_IN_MANIFEST:p.offer')));
  // A branch removed from the graph but still in the manifest: rejected.
  const p2 = structuredClone(good.payload); p2.obligations = p2.obligations.filter(o => o.obligationId !== 'p.offer');
  assert.ok((await rehash(p2)).codes.includes('OBLIGATION_NODE_MISSING:p.support>p.offer'));
  const p3 = structuredClone(good.payload); p3.obligations.find(o => o.obligationId === 'p.support').expression.nodeIds.push('p.root');
  assert.ok((await rehash(p3)).codes.some(c => c.startsWith('OBLIGATION_CYCLE')));
  const p4 = structuredClone(good.payload); p4.obligations.find(o => o.obligationId === 'p.age').expression.normalizedFactPath = 'person.salary';
  assert.ok((await rehash(p4)).codes.includes('UNSUPPORTED_FACT_PATH:person.salary'));
  const p5 = structuredClone(good.payload); p5.engineCompatibility = ['other-engine'];
  assert.ok((await rehash(p5)).codes.includes('ENGINE_INCOMPATIBLE'));
  const p6 = structuredClone(good.payload); p6.obligations.push({ ...p6.obligations[1], obligationId: 'p.orphan' }); p6.requiredObligationIds.push('p.orphan'); p6.obligationManifestHash = await jcsHash([...p6.requiredObligationIds].sort());
  assert.ok((await rehash(p6)).codes.includes('OBLIGATION_UNREACHABLE:p.orphan'));
  const crs = await crsBundle(), c1 = structuredClone(crs.payload); c1.decisionTables[0].rows[0].points += 1;
  assert.ok((await rehash(c1)).codes.includes('TABLE_ROW_SET_HASH_MISMATCH:CRS_AGE'));
  const c2 = structuredClone(crs.payload); c2.decisionTables = c2.decisionTables.filter(t => t.tableId !== 'CRS_HIGH_WAGE_OFFER');
  assert.ok((await rehash(c2)).codes.includes('CRS_TABLE_MISSING:CRS_HIGH_WAGE_OFFER'));
  const c3 = structuredClone(crs.payload); c3.caps = c3.caps.filter(t => t.capId !== 'CRS_LMIF_CAP_WITH_SPOUSE');
  assert.ok((await rehash(c3)).codes.includes('CRS_CAP_MISSING:CRS_LMIF_CAP_WITH_SPOUSE'));
  assert.equal((await rehash({ ...good.payload, sealed: true })).ok, false, 'no extra member such as a browser-supplied state');
  assert.equal(allowedSourceUrl('https://www.canada.ca/en/x.html'), true);
  for (const u of ['http://www.canada.ca/x', 'https://canada.ca.evil.test/x', 'https://user:pw@canada.ca/x', 'https://canada.ca:8443/x', 'https://10.0.0.1/x']) assert.equal(allowedSourceUrl(u), false, u);
});

test('release: overlap, RCIP range overlap and identity mismatch block sealing; manifest is order-independent', async () => {
  const src = await sourceFacts(), p = await programBundle(), r1 = await rcipBundle('RCIP_PILOT'), r2 = await rcipBundle('RCIP_PERMANENT');
  const bundles = new Map([['b-p', await stored(p, 'b-p')], ['b-r1', await stored(r1, 'b-r1')], ['b-r2', await stored(r2, 'b-r2')]]);
  const a = interval('EE_FSWP', 'ELIGIBILITY', 'PROFILE', 'PROFILE', '2026-01-01', '2027-01-01', 'b-p'), b = interval('EE_FSWP', 'ELIGIBILITY', 'PROFILE', 'PROFILE', '2026-06-01', null, 'b-p');
  assert.ok((await validateRelease([a, b], bundles, src)).codes.includes('RULE_INTERVAL_OVERLAP:EE_FSWP|ELIGIBILITY|PROFILE|PROFILE'));
  const adj = interval('EE_FSWP', 'ELIGIBILITY', 'PROFILE', 'PROFILE', '2027-01-01', null, 'b-p');
  assert.deepEqual((await validateRelease([a, adj], bundles, src)).codes, [], 'adjacent [from,to) intervals do not overlap');
  const pilot = interval('RCIP_PILOT', 'ELIGIBILITY', 'APPLICATION', 'APPROVAL_TORONTO', '2026-01-01', '2027-02-01', 'b-r1'), perm = interval('RCIP_PERMANENT', 'ELIGIBILITY', 'APPLICATION', 'APPROVAL_TORONTO', '2027-01-01', null, 'b-r2');
  assert.ok((await validateRelease([pilot, perm], bundles, src)).codes.includes('RCIP_RANGE_OVERLAP'));
  assert.ok((await validateRelease([interval('EE_CEC', 'ELIGIBILITY', 'PROFILE', 'PROFILE', '2026-01-01', null, 'b-p')], bundles, src)).codes.includes('BUNDLE_IDENTITY_MISMATCH:b-p'));
  const hashes = new Map([['b-p', p.hash], ['b-r1', r1.hash]]);
  assert.equal(await computeReleaseManifest([a, pilot], hashes), await computeReleaseManifest([pilot, a], hashes));
  assert.notEqual(await computeReleaseManifest([a], hashes), await computeReleaseManifest([adj], hashes));
});

test('resolver: one interval per date, [from,to) boundaries, missing date => CONTEXT_INCOMPLETE, tampered bytes => RULE_UNAVAILABLE, historic replay', async () => {
  const p = await programBundle(), sp = await stored(p, 'b-p'), map = new Map([['b-p', sp]]);
  const ctx = d => ({ profileDate: d, invitationDate: null, applicationDate: null, recommendationIssuedOn: null });
  const rel = { releaseId: 'r1', manifestSha256: 'a'.repeat(64), generation: 1, intervals: [interval('EE_FSWP', 'ELIGIBILITY', 'PROFILE', 'PROFILE', '2026-11-03', '2027-01-01', 'b-p')] };
  const q = { programId: 'EE_FSWP', family: 'ELIGIBILITY', phase: 'PROFILE' };
  assert.equal((await resolveRule(null, q, ctx('2026-11-03'), loader(map))).reason, 'NO_ACTIVE_RELEASE');
  assert.equal((await resolveRule(rel, q, ctx('2026-11-02'), loader(map))).reason, 'NO_INTERVAL_FOR_DATE');
  assert.equal((await resolveRule(rel, q, ctx('2026-11-03'), loader(map))).status, 'RESOLVED');
  assert.equal((await resolveRule(rel, q, ctx('2026-12-31'), loader(map))).status, 'RESOLVED');
  assert.equal((await resolveRule(rel, q, ctx('2027-01-01'), loader(map))).reason, 'NO_INTERVAL_FOR_DATE', 'expired interval => no successor => blocked, not PROGRAM_CLOSED');
  assert.equal((await resolveRule(rel, { ...q, programId: 'AIP' }, ctx('2026-11-03'), loader(map))).reason, 'NOT_CONFIGURED');
  const inv = { ...rel, intervals: [interval('EE_FSWP', 'ELIGIBILITY', 'PROFILE', 'INVITATION', '2026-11-03', null, 'b-p')] };
  assert.equal((await resolveRule(inv, q, ctx('2026-11-03'), loader(map))).status, 'CONTEXT_INCOMPLETE');
  const dup = { ...rel, intervals: [rel.intervals[0], interval('EE_FSWP', 'ELIGIBILITY', 'PROFILE', 'PROFILE', '2026-12-01', null, 'b-p')] };
  assert.equal((await resolveRule(dup, q, ctx('2026-12-15'), loader(map))).reason, 'OVERLAPPING_INTERVALS');
  const tampered = new Map([['b-p', { ...sp, payload: sp.payload.replace('"GE"', '"GT"'), payloadSha256: '1'.repeat(64) }]]);
  assert.equal((await resolveRule(rel, q, ctx('2026-11-03'), loader(tampered))).reason, 'PAYLOAD_HASH_MISMATCH');
  // A successor release does not change what an older release resolves to (immutable bytes, same hash).
  const successor = { releaseId: 'r2', manifestSha256: 'b'.repeat(64), generation: 2, intervals: [interval('EE_FSWP', 'ELIGIBILITY', 'PROFILE', 'PROFILE', '2027-01-01', null, 'b-p')] };
  const old = await resolveRule(rel, q, ctx('2026-12-01'), loader(map));
  assert.equal((await resolveRule(successor, q, ctx('2027-03-01'), loader(map))).status, 'RESOLVED');
  assert.equal((await resolveRule(rel, q, ctx('2026-12-01'), loader(map))).bundleHash, old.bundleHash);
});

test('RCIP: approval timestamp converted to Toronto first; 2026 pilot, 2027 permanent rejecting a 2026 recommendation; no transition state', () => {
  const rel = { releaseId: 'r', manifestSha256: 'a'.repeat(64), generation: 1, intervals: [interval('RCIP_PILOT', 'ELIGIBILITY', 'APPLICATION', 'APPROVAL_TORONTO', '2026-01-01', '2027-01-01', 'b1'), interval('RCIP_PERMANENT', 'ELIGIBILITY', 'APPLICATION', 'APPROVAL_TORONTO', '2027-01-01', null, 'b2')] };
  const at = (iso, rec = null) => routeRcip(rel, 'ELIGIBILITY', 'APPLICATION', { profileDate: '2026-11-15', invitationDate: null, applicationDate: null, recommendationIssuedOn: rec, approvalForSubmissionAt: iso });
  assert.deepEqual(at('2027-01-01T04:59:59.000Z'), { status: 'RESOLVED', programId: 'RCIP_PILOT', date: '2026-12-31' }, 'UTC new year is still 2026 in Toronto');
  assert.deepEqual(at('2027-01-01T05:00:00.000Z'), { status: 'RESOLVED', programId: 'RCIP_PERMANENT', date: '2027-01-01' });
  assert.equal(at('2027-01-01T05:00:00.000Z', '2026-12-31').status, 'FAIL');
  assert.equal(at('2027-01-01T05:00:00.000Z', '2026-12-31').code, 'RECOMMENDATION_OUTSIDE_APPROVED_POLICY');
  assert.equal(at('2026-12-31T12:00:00.000Z', '2026-12-31').status, 'RESOLVED', '2026 recommendation is fine for the pilot');
  assert.equal(at(null).status, 'CONTEXT_INCOMPLETE');
  assert.equal(routeRcip({ ...rel, intervals: rel.intervals.slice(0, 1) }, 'ELIGIBILITY', 'APPLICATION', { profileDate: '2026-11-15', invitationDate: null, applicationDate: null, recommendationIssuedOn: null, approvalForSubmissionAt: '2027-03-01T12:00:00Z' }).status, 'RULE_UNAVAILABLE', 'no approved permanent range => RULE_UNAVAILABLE, no grace');
  for (const r of [at('2026-12-31T12:00:00Z'), at('2027-01-01T05:00:00Z', '2026-12-31')]) assert.ok(!JSON.stringify(r).match(/TRANSITION|GRACE/));
});

// ---------------------------------------------------------------- unit: interpreter, normalization, CRS, assembly
const fact = (value, state = 'VERIFIED') => ({ value, state, origin: 'test' });
const facts = over => { const f = Object.fromEntries(FACT_PATH_LIST.map(p => [p, { value: null, state: 'UNKNOWN', origin: 'none' }])); return { ...f, ...over }; };
const sourcesMap = new Map(Object.entries(SOURCES).map(([k, v]) => [k, { officialUrl: v.officialUrl, sourceHash: 'c'.repeat(64) }]));
async function run(b, f, purpose = 'VERIFIED_SCREENING') {
  return evaluateObligations({ obligations: b.obligations, rootObligationId: b.rootObligationId, requiredObligationIds: b.requiredObligationIds, ruleHash: 'd'.repeat(64), facts: f, supportedPaths: new Set(FACT_PATH_LIST), dates: { PROFILE: '2026-11-15' }, defaultBasis: 'PROFILE', sources: sourcesMap, purpose });
}
test('obligations: ALL/ANY, UNKNOWN never FAIL, unverified facts in VERIFIED_SCREENING, citations on every predicate, removed branch cannot PASS', async () => {
  const { payload: b } = await programBundle();
  const pass = await run(b, facts({ 'person.ageYears': fact(30), 'language.first.min': fact(8), 'funds.satisfied': fact(false), 'offer.present': fact(true) }));
  assert.equal(pass.eligibility, 'PASS'); assert.ok(pass.predicates.every(p => p.citations.length >= 1 && p.citations[0].officialUrl.startsWith('https://')));
  assert.equal((await run(b, facts({ 'person.ageYears': fact(17), 'language.first.min': fact(8), 'funds.satisfied': fact(true) }))).eligibility, 'FAIL');
  const unk = await run(b, facts({ 'person.ageYears': fact(30), 'language.first.min': fact(8) }));
  assert.equal(unk.eligibility, 'UNKNOWN'); assert.ok(unk.reasonCodes.includes('p.funds:FACT_UNKNOWN'));
  const rep = await run(b, facts({ 'person.ageYears': fact(30), 'language.first.min': fact(8), 'funds.satisfied': fact(true, 'REPORTED') }));
  assert.equal(rep.eligibility, 'UNKNOWN'); assert.ok(rep.reasonCodes.includes('p.funds:FACT_NOT_VERIFIED'));
  assert.equal((await run(b, facts({ 'person.ageYears': fact(30), 'language.first.min': fact(8), 'funds.satisfied': fact(true, 'REPORTED') }), 'RAPID_SCREENING')).eligibility, 'PASS');
  // Tampered payload that bypasses import: dropping a required branch blocks evaluation (never PASS).
  const cut = structuredClone(b); cut.obligations.find(o => o.obligationId === 'p.root').expression.nodeIds = ['p.age', 'p.support'];
  const cutRes = await run(cut, facts({ 'person.ageYears': fact(30), 'language.first.min': fact(8), 'funds.satisfied': fact(true), 'offer.present': fact(true) }));
  assert.equal(cutRes.blocked, 'OBLIGATION_COVERAGE_INCOMPLETE'); assert.notEqual(cutRes.eligibility, 'PASS');
  const op = structuredClone(b); op.obligations.find(o => o.obligationId === 'p.age').expression.operator = 'REGEX';
  assert.equal((await run(op, facts({}))).blocked, 'UNSUPPORTED_OPERATOR');
  const mis = structuredClone(b); mis.obligations.find(o => o.obligationId === 'p.age').expression.expected = 'eighteen';
  assert.equal((await run(mis, facts({ 'person.ageYears': fact(30), 'language.first.min': fact(8), 'funds.satisfied': fact(true) }))).blocked, 'OPERAND_TYPE_MISMATCH');
});

function rng(seed) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }
const CRS_EDU = ['below_secondary', 'secondary', 'one_year', 'two_year', 'bachelor', 'two_or_more', 'master', 'doctorate'];
const TIER = { none: null, '1.3': 'TIER_130', '1.5': 'TIER_150', '2': 'TIER_200' };
function sample(r, asOf) {
  const pick = a => a[Math.floor(r() * a.length)], int = (a, b) => a + Math.floor(r() * (b - a + 1)), skills = () => [int(0, 12), int(0, 12), int(0, 12), int(0, 12)];
  const daysAgo = n => { const d = new Date(asOf + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() - n); const s = d.toISOString().slice(0, 10); return s.endsWith('-02-29') ? daysAgo(n + 1) : s; };
  const first = pick(['english', 'french']), withSpouse = r() < 0.4;
  const lang = { english: skills(), french: skills() };
  if (lang[first].every(v => v === 0)) lang[first] = [5, 6, 7, 8];
  if (r() < 0.35) lang[first === 'english' ? 'french' : 'english'] = [0, 0, 0, 0];
  const canadianYears = int(0, 5), spouseLanguage = withSpouse && r() < 0.7 ? skills() : [0, 0, 0, 0];
  return { age: int(16, 50), withSpouse, education: pick(CRS_EDU), english: lang.english, french: lang.french, firstLanguage: first,
    englishDate: lang.english.some(v => v > 0) ? daysAgo(int(1, 700)) : '', frenchDate: lang.french.some(v => v > 0) ? daysAgo(int(1, 700)) : '',
    canadianYears, foreignYears: int(0, 3), highWageWork: canadianYears === 0 ? 'none' : pick(['none', '1.3', '1.5', '2']), highWageOffer: pick(['none', '1.3', '1.5', '2']),
    spouseEducation: withSpouse ? pick(CRS_EDU) : 'below_secondary', spouseLanguage, spouseLanguageDate: spouseLanguage.some(v => v > 0) ? daysAgo(int(1, 700)) : '', spouseCanadianYears: withSpouse ? int(0, 5) : 0,
    tradeCertificate: r() < 0.3, canadianEducation: pick(['none', 'one_two', 'three_plus']), sibling: r() < 0.2, nomination: r() < 0.1, verified: true };
}
const normFor = (input, asOf, extra = {}) => normalizeCase({ profileDate: asOf, profile: blankProfile, details: blankDetails, crsInput: input, eligibility: { inputs: eligibilitySchema.parse({ asOf, verified: true, noc: '21231' }), asOf }, verifiedCategories: ['offer'], wageRows: [...(TIER[input.highWageWork] ? [{ nocCode: '21231', tier: TIER[input.highWageWork] }] : []), ...(TIER[input.highWageOffer] ? [{ nocCode: '31102', tier: TIER[input.highWageOffer] }] : [])], ...extra });
test('CRS from the sealed payload: differential against lib/crs.ts over 600 seeded profiles (components, MAX, caps, total)', async () => {
  const b = (await crsBundle()).payload, policy = { tables: b.decisionTables, caps: b.caps, policyHash: 'e'.repeat(64) }, r = rng(20261115), asOf = '2026-11-15';
  let ties = 0;
  for (let n = 0; n < 600; n++) {
    const input = sample(r, asOf), expected = calculateCrs(input, new Date(asOf + 'T12:00:00Z')), got = crsFromPolicy(policy, normFor(input, asOf), 'VERIFIED_SCREENING');
    assert.equal(got.status, 'COMPLETE', JSON.stringify({ input, got }));
    assert.equal(got.total, expected.total, JSON.stringify(input));
    assert.deepEqual(got.components, { age: expected.breakdown.age, education: expected.breakdown.education, firstLanguage: expected.breakdown.firstLanguage, secondLanguage: expected.breakdown.secondLanguage, lmif: expected.breakdown.integration, spouse: expected.spouse, skillTransferability: expected.transfer, additional: expected.additional });
    const t = got.trace.lmif; assert.equal(t.experienceRoute, t.workLengthPoints + t.highWageExperiencePoints); assert.equal(got.components.lmif, Math.min(t.cap, Math.max(t.experienceRoute, t.offerRoute)));
    if (t.tie) ties++;
    assert.equal(Object.values(got.components).reduce((s, v) => s + v, 0), got.total);
  }
  assert.ok(ties > 0, 'MAX tie cases were exercised');
});
test('CRS failure modes: unknown => INCOMPLETE with no number, unverified => INCOMPLETE, corrupt/missing data => RULE_UNAVAILABLE, LMIF cap from payload', async () => {
  const b = (await crsBundle()).payload, policy = { tables: b.decisionTables, caps: b.caps, policyHash: 'e'.repeat(64) }, asOf = '2026-11-15';
  const input = sample(rng(7), asOf), f = normFor(input, asOf);
  const unknown = crsFromPolicy(policy, { ...f, 'person.ageYears': { value: null, state: 'UNKNOWN', origin: 'none' } }, 'VERIFIED_SCREENING');
  assert.equal(unknown.status, 'INCOMPLETE'); assert.equal(unknown.total, null); assert.deepEqual(unknown.missingFields, ['person.ageYears']);
  const reported = crsFromPolicy(policy, { ...f, 'education.level': { ...f['education.level'], state: 'REPORTED' } }, 'VERIFIED_SCREENING');
  assert.equal(reported.status, 'INCOMPLETE'); assert.deepEqual(reported.reasonCodes, ['FACT_NOT_VERIFIED']);
  assert.equal(crsFromPolicy(policy, { ...f, 'education.level': { ...f['education.level'], state: 'REPORTED' } }, 'RAPID_SCREENING').status, 'COMPLETE');
  const dupRow = { ...policy, tables: policy.tables.map(t => t.tableId === 'CRS_AGE' ? { ...t, rows: [...t.rows, t.rows[0]] } : t) };
  assert.deepEqual(crsFromPolicy(dupRow, f, 'VERIFIED_SCREENING').reasonCodes, ['CRS_TABLE_DUPLICATE_ROW:CRS_AGE']);
  const missingRow = { ...policy, tables: policy.tables.map(t => t.tableId === 'CRS_CANADIAN_WORK' ? { ...t, rows: t.rows.filter(x => x.dimensionValues[1] !== input.canadianYears) } : t) };
  assert.equal(crsFromPolicy(missingRow, f, 'VERIFIED_SCREENING').status, 'RULE_UNAVAILABLE');
  assert.equal(crsFromPolicy({ ...policy, caps: policy.caps.filter(c => c.capId !== 'CRS_SPOUSE_CAP') }, f, 'VERIFIED_SCREENING').reasonCodes[0], 'CRS_CAP_MISSING:CRS_SPOUSE_CAP');
  assert.equal(crsFromPolicy({ ...policy, tables: policy.tables.map(t => t.tableId === 'CRS_AGE' ? { ...t, rows: [{ ...t.rows[0], points: -5 }, ...t.rows.slice(1)] } : t) }, f, 'VERIFIED_SCREENING').status, 'RULE_UNAVAILABLE');
  assert.equal(crsFromPolicy(null, f, 'VERIFIED_SCREENING').status, 'RULE_UNAVAILABLE');
  const strong = { ...sample(rng(3), asOf), withSpouse: false, canadianYears: 5, highWageWork: '2', highWageOffer: '2' };
  const capped = crsFromPolicy({ ...policy, caps: policy.caps.map(c => c.capId === 'CRS_LMIF_CAP_WITHOUT_SPOUSE' ? { ...c, points: 120 } : c) }, normFor(strong, asOf), 'VERIFIED_SCREENING');
  assert.equal(capped.components.lmif, 120); assert.equal(capped.trace.lmif.experienceRoute, 150); assert.equal(capped.trace.lmif.tie, false);
  const contradiction = crsFromPolicy(policy, { ...f, 'work.canadianYears': fact(0), 'work.highWageTier': fact('TIER_200') }, 'VERIFIED_SCREENING');
  assert.equal(contradiction.status, 'INVALID_INPUT');
});
test('normalization: a submitted high-wage tier is not proof; the tier comes only from the sealed wage dataset', () => {
  const input = { ...sample(rng(11), '2026-11-15'), canadianYears: 2, highWageWork: '2' };
  const noWage = normalizeCase({ profileDate: '2026-11-15', profile: blankProfile, details: blankDetails, crsInput: input, eligibility: { inputs: eligibilitySchema.parse({ asOf: '2026-11-15', verified: true, noc: '21231' }), asOf: '2026-11-15' }, verifiedCategories: [], wageRows: null });
  assert.equal(noWage['work.highWageTier'].state, 'UNKNOWN');
  const listed = normFor(input, '2026-11-15', { wageRows: [] });
  assert.equal(listed['work.highWageTier'].value, 'NONE', 'occupation not on the list => no high-wage points regardless of the stated tier');
  const reportedOnly = normalizeCase({ profileDate: '2026-11-15', profile: { ...blankProfile, noc: '21231', education: 'diploma' }, details: null, crsInput: null, eligibility: null, verifiedCategories: [], wageRows: [{ nocCode: '21231', tier: 'TIER_200' }] });
  assert.equal(reportedOnly['work.primaryNoc'].state, 'REPORTED'); assert.equal(reportedOnly['work.highWageTier'].state, 'UNKNOWN');
  assert.equal(reportedOnly['education.level'].state, 'UNKNOWN', "'diploma' is not guessed as one or two years");
});
test('assembly: deterministic canonical hash, purpose/mode change the hash, no release => BLOCKED_RULES, ranking unavailable', async () => {
  const p = await programBundle(), c = await crsBundle(), map = new Map([['b-p', await stored(p, 'b-p')], ['b-c', await stored(c, 'b-c')]]);
  const active = { releaseId: 'r1', manifestSha256: 'a'.repeat(64), generation: 1, intervals: [interval('EE_FSWP', 'ELIGIBILITY', 'PROFILE', 'PROFILE', '2026-01-01', null, 'b-p'), interval('EE_CRS', 'CRS', 'PROFILE', 'PROFILE', '2026-01-01', null, 'b-c')] };
  const input = sample(rng(5), '2026-11-15');
  const base = { caseId: 'case-1', dataRevision: 3, mode: 'PRODUCTION', purpose: 'VERIFIED_SCREENING', eventContext: { profileDate: '2026-11-15', invitationDate: null, applicationDate: null, recommendationIssuedOn: null, approvalForSubmissionAt: null }, selectedPrograms: [{ programId: 'EE_FSWP', streamId: null, phase: 'PROFILE' }], normalization: { profile: blankProfile, details: blankDetails, crsInput: input, eligibility: { inputs: eligibilitySchema.parse({ asOf: '2026-11-15', verified: true, noc: '21231', fundsSatisfied: 'yes' }), asOf: '2026-11-15' }, verifiedCategories: ['offer'] }, active, loadBundle: loader(map), sources: sourcesMap };
  const a1 = await buildV22Assessment(base), a2 = await buildV22Assessment({ ...base, selectedPrograms: [...base.selectedPrograms, ...base.selectedPrograms] });
  assert.equal(a1.canonicalHash, a2.canonicalHash, 'duplicate selections collapse');
  assert.equal(a1.output.crs.status, 'COMPLETE'); assert.equal(a1.output.ranking.status, 'RANK_UNAVAILABLE');
  assert.notEqual((await buildV22Assessment({ ...base, purpose: 'RAPID_SCREENING' })).canonicalHash, a1.canonicalHash);
  assert.notEqual((await buildV22Assessment({ ...base, mode: 'SHADOW' })).canonicalHash, a1.canonicalHash);
  assert.equal((await buildV22Assessment({ ...base, dataRevision: 9 })).canonicalHash, a1.canonicalHash, 'revision numbers are not content');
  const none = await buildV22Assessment({ ...base, active: null });
  assert.equal(none.output.stage, 'BLOCKED_RULES'); assert.equal(none.output.pathways[0].evaluationStatus, 'RULE_UNAVAILABLE'); assert.equal(none.output.crs.status, 'RULE_UNAVAILABLE');
  assert.equal((await buildV22Assessment({ ...base, purpose: 'RAPID_SCREENING' })).output.stage === 'FINAL_VERIFIED_ASSESSMENT', false, 'rapid is never final');
});
test('NOC adapter contract: no consent field, forged code/duty/quote rejected as a whole', () => {
  assert.equal(nocSuggestionRequestSchema.safeParse({ action: 'noc_suggestion', expectedDataRevision: 0, workEpisodeId: 'job:0', targetNocCodes: ['21231'] }).success, true);
  assert.equal(nocSuggestionRequestSchema.safeParse({ action: 'noc_suggestion', expectedDataRevision: 0, workEpisodeId: 'job:0', targetNocCodes: ['21231'], consentId: 'c1' }).success, false);
  const ctx = { episodeText: 'Design and develop software applications for clients.', targets: ['21231'], catalog: NOC_ROWS };
  const ok = { suggestions: [{ nocCode: '21231', leadStatementSupported: true, dutyMatches: [{ officialDutyId: '21231-d1', evidenceQuote: 'Design and develop software applications', reason: 'r' }], exclusionNotes: [] }], warnings: [] };
  assert.equal(validateNocSuggestion(ok, ctx).ok, true);
  const bad = (m) => { const x = structuredClone(ok); m(x); return validateNocSuggestion(x, ctx); };
  assert.equal(bad(x => { x.suggestions[0].nocCode = '72401'; }).code, 'NOC_CITATION_FORGED:code');
  assert.equal(bad(x => { x.suggestions[0].dutyMatches[0].officialDutyId = '21231-d9'; }).code, 'NOC_CITATION_FORGED:duty');
  assert.equal(bad(x => { x.suggestions[0].dutyMatches[0].evidenceQuote = 'Led a team of fifty engineers'; }).code, 'NOC_CITATION_FORGED:quote');
});

// ---------------------------------------------------------------- Worker: Workers/D1/R2 local via Miniflare
const require = createRequire(import.meta.url);
const { Miniflare } = createRequire(require.resolve('wrangler/package.json'))('miniflare');
const base = 'http://canada-desk.test';
const who = (uid, email) => ({ 'oai-authenticated-user-id': uid, 'oai-authenticated-user-email': email });
const admin = who('admin-1', 'admin@example.test'), staffA = who('staff-a', 'staff-a@example.test'), staffB = who('staff-b', 'staff-b@example.test');
let mf, db, bucket, send, nocMode = 'valid', providerCalls = 0;
const json = async (r, status) => { const t = await r.text(); if (status !== undefined) assert.equal(r.status, status, t); return t ? JSON.parse(t) : null; };
const key = () => crypto.randomUUID().replace(/-/g, '');
const b64 = s => Buffer.from(s, 'utf8').toString('base64');
const one = async (q, ...p) => (await db.prepare(q).bind(...p).first());
const count = async (q, ...p) => (await db.prepare(q).bind(...p).first()).n;
test.before(async () => {
  const files = await readdir('dist/server', { recursive: true });
  mf = new Miniflare({
    modules: ['index.js', ...files.filter(f => f !== 'index.js' && f.endsWith('.js'))].map(f => ({ type: 'ESModule', path: path.resolve('dist/server', f) })),
    modulesRoot: path.resolve('dist/server'), compatibilityDate: '2026-05-15', compatibilityFlags: ['nodejs_compat'],
    d1Databases: { DB: 'gate3-db' }, r2Buckets: ['BUCKET'],
    bindings: { TRUST_SITES_IDENTITY_HEADERS: '1', OFFICE_ADMIN_EMAIL: 'admin@example.test', APP_SECRET: 'b'.repeat(64) },
    // Declared test double for the configured provider (OpenAI Responses API); every other host is blocked.
    outboundService: async req => {
      const u = new URL(req.url);
      if (u.hostname !== 'api.openai.com' || u.pathname !== '/v1/responses') return new Response('blocked', { status: 599 });
      const body = await req.json(); providerCalls++;
      const input = JSON.parse(body.input), quote = nocMode === 'valid' ? input.episode.text.slice(0, 40) : 'Led a team of fifty engineers on Mars';
      const out = { suggestions: [{ nocCode: input.catalog[0].nocCode, leadStatementSupported: true, dutyMatches: [{ officialDutyId: input.catalog[0].mainDuties[0].dutyId, evidenceQuote: quote, reason: 'matches duty' }], exclusionNotes: [] }], warnings: [] };
      return Response.json({ status: 'completed', output: [{ type: 'message', content: [{ type: 'output_text', text: JSON.stringify(out) }] }] });
    },
  });
  send = (p, method = 'GET', body, headers = {}) => mf.dispatchFetch(base + p, { method, headers: { ...(body !== undefined ? { 'content-type': 'application/json' } : {}), ...headers }, body: body !== undefined ? JSON.stringify(body) : undefined });
  db = await mf.getD1Database('DB'); bucket = await mf.getR2Bucket('BUCKET');
  for (const f of (await readdir('drizzle')).filter(f => f.endsWith('.sql')).sort())
    for (const s of (await readFile('drizzle/' + f, 'utf8')).split('--> statement-breakpoint').map(s => s.trim()).filter(Boolean)) await db.prepare(s).run();
  await seedOfficeManager(db, 'admin-1');
  await json(await send('/api/office', 'GET', undefined, admin), 200);
  for (const s of [['staff-a@example.test', 'QA Staff A'], ['staff-b@example.test', 'QA Staff B']]) await json(await send('/api/office', 'POST', { action: 'member', email: s[0], name: s[1], active: true }, admin), 200);
});
test.after(async () => { await mf?.dispose(); });

const W = {};
const goodIntervals = () => [
  interval('EE_CRS', 'CRS', 'PROFILE', 'PROFILE', '2026-11-03', null, W.crs),
  interval('EE_FSWP', 'ELIGIBILITY', 'PROFILE', 'PROFILE', '2026-01-01', null, W.fsw),
  interval('RCIP_PILOT', 'ELIGIBILITY', 'APPLICATION', 'APPROVAL_TORONTO', '2026-01-01', '2027-01-01', W.pilot),
  interval('RCIP_PERMANENT', 'ELIGIBILITY', 'APPLICATION', 'APPROVAL_TORONTO', '2027-01-01', null, W.perm),
  interval('NOC_2021', 'NOC_CATALOG', 'PROFILE', 'PROFILE', '2026-01-01', null, W.noc),
];
test('Worker seal: MANAGER-only import, server hashes, INSERT SEALED refused, overlap/missing source/stale generation block, one manager creates and seals, atomic', async () => {
  const src = { action: 'source', sourceId: 'SRC-TEST-CRS', officialUrl: SOURCES['SRC-TEST-CRS'].officialUrl, authority: 'TEST_ONLY', contentBase64: b64(SOURCES['SRC-TEST-CRS'].text) };
  assert.equal((await send('/api/office/rules/import', 'POST', src, staffA)).status, 403, 'STAFF cannot import rules');
  for (const [id, s] of Object.entries(SOURCES)) {
    const r = await json(await send('/api/office/rules/import', 'POST', { action: 'source', sourceId: id, officialUrl: s.officialUrl, authority: 'TEST_ONLY', contentBase64: b64(s.text) }, admin), 201);
    assert.equal(r.contentSha256, await sha256Hex(s.text));
  }
  assert.equal((await json(await send('/api/office/rules/import', 'POST', src, admin), 200)).replayed, true);
  await json(await send('/api/office/rules/import', 'POST', { ...src, contentBase64: b64('different bytes') }, admin), 409);
  await json(await send('/api/office/rules/import', 'POST', { ...src, sourceId: 'SRC-X', officialUrl: 'https://example.com/law' }, admin), 422);
  const upload = async (b, status = 201) => json(await send('/api/office/rules/import', 'POST', { action: 'bundle', payload: b.payload, payloadHash: b.hash }, admin), status);
  W.crs = (await upload(await crsBundle())).bundleId; W.fsw = (await upload(await programBundle())).bundleId;
  W.pilot = (await upload(await rcipBundle('RCIP_PILOT'))).bundleId; W.perm = (await upload(await rcipBundle('RCIP_PERMANENT'))).bundleId; W.noc = (await upload(await nocBundle())).bundleId;
  const fsw = await programBundle();
  assert.match((await upload({ payload: fsw.payload, hash: '0'.repeat(64) }, 422)).error, /PAYLOAD_HASH_MISMATCH/);
  const ghost = await programBundle('EE_CEC', b => ({ ...b, sourceIds: ['SRC-GHOST'], obligations: b.obligations.map(o => ({ ...o, sourceIds: ['SRC-GHOST'] })) }));
  assert.match((await upload(ghost, 422)).error, /SOURCE_MISSING:SRC-GHOST/);
  // Stored source bytes are rehashed: an altered R2 object blocks the payload.
  await json(await send('/api/office/rules/import', 'POST', { action: 'source', sourceId: 'SRC-TEST-TAMPER', officialUrl: 'https://www.canada.ca/en/test-only/tamper.html', authority: 'TEST_ONLY', contentBase64: b64('TEST_ONLY tamper source') }, admin), 201);
  await bucket.put('rules/sources/' + await sha256Hex('TEST_ONLY tamper source'), 'altered after import');
  const tamper = await programBundle('EE_CEC', b => ({ ...b, sourceIds: ['SRC-TEST-TAMPER'], obligations: b.obligations.map(o => ({ ...o, sourceIds: ['SRC-TEST-TAMPER'] })) }));
  assert.match((await upload(tamper, 422)).error, /SOURCE_BYTES_MISMATCH:SRC-TEST-TAMPER/);

  await assert.rejects(db.prepare("INSERT INTO release_sets(release_id,manifest_sha256,state,validation_report_hash,created_by,sealed_by,sealed_at) VALUES('direct',?,'SEALED',?,'admin-1','admin-1','2026-11-15T00:00:00Z')").bind('9'.repeat(64), '8'.repeat(64)).run(), /SEALED_MUST_BE_EARNED/);
  const overlap = [...goodIntervals(), interval('EE_FSWP', 'ELIGIBILITY', 'PROFILE', 'PROFILE', '2026-06-01', null, W.fsw)];
  const pv = await json(await send('/api/office/rules/releases', 'POST', { action: 'preview', intervals: overlap }, admin), 200);
  assert.ok(pv.validationCodes.some(c => c.startsWith('RULE_INTERVAL_OVERLAP')));
  await json(await send('/api/office/rules/releases', 'POST', { action: 'seal', intervals: overlap, manifestHash: pv.manifestHash, activate: null }, admin), 422);
  const preview = await json(await send('/api/office/rules/releases', 'POST', { action: 'preview', intervals: goodIntervals() }, admin), 200);
  assert.deepEqual(preview.validationCodes, []);
  assert.equal((await send('/api/office/rules/releases', 'POST', { action: 'seal', intervals: goodIntervals(), manifestHash: preview.manifestHash, activate: null }, staffA)).status, 403);
  await json(await send('/api/office/rules/releases', 'POST', { action: 'seal', intervals: goodIntervals(), manifestHash: '7'.repeat(64), activate: null }, admin), 409);
  const sealed = await json(await send('/api/office/rules/releases', 'POST', { action: 'seal', intervals: goodIntervals(), manifestHash: preview.manifestHash, activate: { expectedGeneration: 0, reasonCode: 'gate3-test' } }, admin), 201);
  W.release = sealed.releaseId; W.manifest = preview.manifestHash;
  const rel = await one('SELECT state,created_by,sealed_by,validation_report_hash FROM release_sets WHERE release_id=?', W.release);
  assert.deepEqual([rel.state, rel.created_by, rel.sealed_by], ['SEALED', 'admin-1', 'admin-1'], 'the same MANAGER creates and seals; no second approval');
  assert.match(rel.validation_report_hash, /^[a-f0-9]{64}$/);
  assert.deepEqual(await one('SELECT release_id,generation FROM rule_activation'), { release_id: W.release, generation: 1 });
  // A different release with a stale activation generation: the whole batch (release + intervals + seal) rolls back.
  const subset = goodIntervals().slice(0, 2), ps = await json(await send('/api/office/rules/releases', 'POST', { action: 'preview', intervals: subset }, admin), 200);
  const before = await count('SELECT count(*) n FROM release_sets');
  await json(await send('/api/office/rules/releases', 'POST', { action: 'seal', intervals: subset, manifestHash: ps.manifestHash, activate: { expectedGeneration: 0, reasonCode: 'stale' } }, admin), 409);
  assert.equal(await count('SELECT count(*) n FROM release_sets'), before, 'no partial release after a failed batch');
  assert.equal(await count('SELECT count(*) n FROM release_intervals WHERE release_id<>?', W.release), 0);
  await assert.rejects(db.prepare("UPDATE rule_bundles SET payload='{}' WHERE bundle_id=?").bind(W.fsw).run(), /IMMUTABLE_RULE_BUNDLE/);
  await assert.rejects(db.prepare('DELETE FROM release_intervals WHERE release_id=?').bind(W.release).run(), /IMMUTABLE_RELEASE_INTERVAL/);
  await assert.rejects(db.prepare("UPDATE release_sets SET state='SEALED',sealed_at='x' WHERE release_id=?").bind(W.release).run(), /INVALID_RELEASE_TRANSITION/);
  await assert.rejects(db.prepare("INSERT INTO release_intervals(release_id,program_id,family,phase,date_basis,effective_from,bundle_id) VALUES(?,'AIP','ELIGIBILITY','PROFILE','PROFILE','2026-01-01',?)").bind(W.release, W.fsw).run(), /SEALED_RELEASE/);
  const state = await json(await send('/api/office/rules/releases', 'GET', undefined, staffB), 200);
  const ready = Object.fromEntries(state.readiness.map(r => [r.programId, r.status]));
  assert.equal(ready.EE_FSWP, 'CONFIGURED'); assert.equal(ready.AIP, 'NOT_CONFIGURED'); assert.equal(ready.FCIP, 'NOT_CONFIGURED');
});

const crsInput = () => {
  const d = new Date(); d.setUTCDate(d.getUTCDate() - 60); const date = d.toISOString().slice(0, 10);
  return { age: 29, withSpouse: false, education: 'master', english: [9, 9, 8, 8], french: [0, 0, 0, 0], firstLanguage: 'english', englishDate: date, frenchDate: '', canadianYears: 1, foreignYears: 3, highWageWork: '2', highWageOffer: 'none', spouseEducation: 'below_secondary', spouseLanguage: [0, 0, 0, 0], spouseLanguageDate: '', spouseCanadianYears: 0, tradeCertificate: false, canadianEducation: 'none', sibling: false, nomination: false, verified: true };
};
const rev = async id => one('SELECT data_revision d,publication_revision p,latest_verified_assessment_id v,latest_rapid_assessment_id r FROM candidates WHERE id=?', id);
const recomputeBody = (r, over = {}) => ({ action: 'recompute', requestKey: key(), expectedDataRevision: r.d, expectedPublicationRevision: r.p, assessmentMode: 'PRODUCTION', assessmentPurpose: 'VERIFIED_SCREENING', selectedPrograms: [{ programId: 'EE_FSWP', streamId: null, phase: 'PROFILE' }, { programId: 'RCIP', streamId: null, phase: 'APPLICATION' }], eventContext: { profileDate: today, invitationDate: null, applicationDate: null, recommendationIssuedOn: null }, ...over });
const recompute = (id, body, who = staffA) => send('/api/candidates/' + id + '/analysis', 'POST', body, who);
test('Worker assessment: same engine and history, canonical dedup under 100 concurrent requests, idempotency key, CAS, SHADOW, RAPID, atomic rollback', async () => {
  const c = await json(await send('/api/candidates', 'POST', { fullName: 'QA Gate3 Engine', phone: '+15553339001', consent: true, recommendation: 'yes', jobs: [{ title: 'Developer', employer: 'QA Employer', country: 'Canada', start: '2024-01', end: '2025-06', weekly_hours: 40, duties: 'Design and develop software applications for clients and test systems daily.' }], noc: '21231' }, staffA), 201);
  W.case = c.id;
  await json(await send('/api/candidates/' + c.id + '/crs', 'POST', crsInput(), staffA), 200);
  await json(await send('/api/candidates/' + c.id + '/eligibility', 'POST', { asOf: new Date().toISOString().slice(0, 10), verified: true, noc: '21231', fundsSatisfied: 'yes' }, staffA), 200);
  let r = await rev(c.id);
  const created = await json(await recompute(c.id, recomputeBody(r)), 201);
  assert.equal(created.status, 'CREATED');
  const a = created.assessment, expected = calculateCrs(crsInput(), new Date());
  assert.equal(a.crs.status, 'COMPLETE'); assert.equal(a.crs.total, expected.total, 'sealed payload CRS equals the verified calculator on the same facts');
  assert.equal(a.pathways.find(p => p.program.programId === 'EE_FSWP').eligibility, 'PASS');
  assert.equal(a.pathways.find(p => p.program.programId === 'RCIP').evaluationStatus, 'CONTEXT_INCOMPLETE', 'no server-recorded approval for submission yet');
  assert.equal(a.ranking.status, 'RANK_UNAVAILABLE'); assert.equal(a.ruleReleaseHash, W.manifest);
  const row = await one('SELECT engine_version,canonical_input_hash,rule_bundle_hash,assessment_mode,assessment_purpose,created_by,case_revision FROM assessment_history WHERE id=?', created.assessmentId);
  assert.deepEqual(row, { engine_version: 'v22-engine-1.0.0', canonical_input_hash: a.fingerprint, rule_bundle_hash: W.manifest, assessment_mode: 'PRODUCTION', assessment_purpose: 'VERIFIED_SCREENING', created_by: 'staff:staff-a@example.test', case_revision: r.d });
  const after = await rev(c.id); assert.equal(after.v, created.assessmentId); assert.equal(after.p, r.p + 1);
  // Change data (new revision), then 100 identical concurrent requests: one canonical row, all converge to it.
  await json(await send('/api/candidates/' + c.id + '/eligibility', 'POST', { asOf: new Date().toISOString().slice(0, 10), verified: true, noc: '21231', fundsSatisfied: 'yes', outsideQuebec: 'yes' }, staffA), 200);
  r = await rev(c.id);
  const historyBefore = await count('SELECT count(*) n FROM assessment_history WHERE candidate_id=?', c.id), payload = recomputeBody(r);
  const results = await Promise.all(Array.from({ length: 100 }, () => recompute(c.id, { ...payload, requestKey: key() }).then(async x => ({ status: x.status, body: await x.json() }))));
  assert.ok(results.every(x => x.status === 200 || x.status === 201), JSON.stringify(results.filter(x => x.status >= 300).slice(0, 2)));
  assert.equal(new Set(results.map(x => x.body.assessmentId)).size, 1, 'one canonical result');
  assert.equal(results.filter(x => x.body.status === 'CREATED').length, 1);
  assert.equal(await count('SELECT count(*) n FROM assessment_history WHERE candidate_id=?', c.id), historyBefore + 1);
  assert.equal((await rev(c.id)).p, r.p + 1, 'publication revision advanced once');
  // Idempotency key: replay returns the recorded result; same key with another payload => 409.
  const k = key(), first = await json(await recompute(c.id, { ...payload, requestKey: k }), 200);
  assert.equal((await json(await recompute(c.id, { ...payload, requestKey: k }), 200)).status, 'REPLAYED');
  assert.equal((await json(await recompute(c.id, { ...payload, requestKey: k }), 200)).assessmentId, first.assessmentId);
  await json(await recompute(c.id, { ...payload, requestKey: k, assessmentPurpose: 'RAPID_SCREENING' }), 409);
  // CAS: a stale revision with different content publishes nothing.
  const n0 = await count('SELECT count(*) n FROM assessment_history');
  await json(await recompute(c.id, recomputeBody(r, { selectedPrograms: [{ programId: 'EE_FSWP', streamId: null, phase: 'PROFILE' }] })), 409);
  assert.equal(await count('SELECT count(*) n FROM assessment_history'), n0);
  // SHADOW: history only; no pointer or publication revision change.
  r = await rev(c.id);
  const sh = await json(await recompute(c.id, recomputeBody(r, { assessmentMode: 'SHADOW' })), 201);
  assert.deepEqual(await rev(c.id), r); assert.equal((await one('SELECT assessment_mode m FROM assessment_history WHERE id=?', sh.assessmentId)).m, 'SHADOW');
  // RAPID: preliminary only, its own pointer; reported facts usable but never final.
  const rp = await json(await recompute(c.id, recomputeBody(r, { assessmentPurpose: 'RAPID_SCREENING' })), 201);
  assert.notEqual(rp.assessment.stage, 'FINAL_VERIFIED_ASSESSMENT');
  const r2 = await rev(c.id); assert.equal(r2.r, rp.assessmentId); assert.equal(r2.v, r.v);
  // Append-only history and pointer guards.
  await assert.rejects(db.prepare("UPDATE assessment_history SET output_json='{}' WHERE id=?").bind(rp.assessmentId).run());
  await assert.rejects(db.prepare('UPDATE candidates SET latest_verified_assessment_id=? WHERE id=?').bind(rp.assessmentId, c.id).run(), /ASSESSMENT_POINTER_PURPOSE_MISMATCH/);
  // Batch atomicity on D1: an insert followed by a failing guarded update leaves no row.
  const ghostId = crypto.randomUUID();
  await assert.rejects(db.batch([
    db.prepare("INSERT INTO assessment_history(id,candidate_id,computed_at,inputs_hash,engine_version,rules_version,output_json,explanation_trace_json) VALUES(?,?,'2026-11-15','x','x','x','{}','{}')").bind(ghostId, c.id),
    db.prepare('UPDATE candidates SET publication_revision=CASE WHEN (SELECT generation FROM rule_activation WHERE singleton=1)=999 THEN publication_revision+1 ELSE -1 END WHERE id=?').bind(c.id),
  ]), /CHECK constraint failed/);
  assert.equal(await count('SELECT count(*) n FROM assessment_history WHERE id=?', ghostId), 0);
  // GET exposes the published results through the existing case screens.
  const crsView = await json(await send('/api/candidates/' + c.id + '/crs', 'GET', undefined, staffB), 200);
  assert.equal(crsView.v22.crs.total, expected.total);
  const eligView = await json(await send('/api/candidates/' + c.id + '/eligibility', 'GET', undefined, staffB), 200);
  assert.ok(eligView.v22.pathways.some(p => p.program.programId === 'EE_FSWP'));
});

test('Worker RCIP: server-recorded approval in Toronto selects pilot/permanent; 2026 recommendation fails in permanent; browser timestamp ignored', async () => {
  const id = W.case, rcipOf = async (body) => (await json(await recompute(id, body), 201)).assessment.pathways.find(p => p.program.programId.startsWith('RCIP'));
  await db.prepare('UPDATE candidates SET approval_for_submission_at=? WHERE id=?').bind('2027-01-01T04:30:00.000Z', id).run();
  let p = await rcipOf(recomputeBody(await rev(id), { assessmentPurpose: 'RAPID_SCREENING' }));
  assert.equal(p.program.programId, 'RCIP_PILOT'); assert.equal(p.eligibility, 'PASS', 'reported recommendation is usable in RAPID_SCREENING');
  assert.equal(p.intakeState === 'TRANSITION_ONLY', false);
  await db.prepare('UPDATE candidates SET approval_for_submission_at=? WHERE id=?').bind('2027-01-01T05:30:00.000Z', id).run();
  p = await rcipOf(recomputeBody(await rev(id), { assessmentPurpose: 'RAPID_SCREENING', eventContext: { profileDate: today, invitationDate: null, applicationDate: null, recommendationIssuedOn: null, approvalForSubmissionAt: '2026-06-01T12:00:00.000Z' } }));
  assert.equal(p.program.programId, 'RCIP_PERMANENT', 'the browser-supplied approval timestamp is not authority');
  p = await rcipOf(recomputeBody(await rev(id), { assessmentPurpose: 'RAPID_SCREENING', eventContext: { profileDate: today, invitationDate: null, applicationDate: null, recommendationIssuedOn: '2026-12-20' } }));
  assert.deepEqual([p.program.programId, p.eligibility, p.reasonCodes], ['RCIP_PERMANENT', 'FAIL', ['RECOMMENDATION_OUTSIDE_APPROVED_POLICY']]);
  const v = await json(await recompute(id, recomputeBody(await rev(id))), 201);
  assert.equal(v.assessment.pathways.find(x => x.program.programId === 'RCIP_PERMANENT').eligibility, 'UNKNOWN', 'reported recommendation is not verified evidence');
  W.lastVerified = v.assessmentId;
});

test('Worker auto-recompute: a profile change republishes through the same engine as SYSTEM', async () => {
  const id = W.case, c = await json(await send('/api/candidates/' + id, 'GET', undefined, staffA), 200), before = await rev(id);
  assert.equal(before.v, W.lastVerified);
  await json(await send('/api/candidates/' + id, 'PATCH', { version: c.version, profile: { ...c.profile, recommendation: 'no' } }, staffA), 200);
  const after = await rev(id);
  assert.notEqual(after.v, before.v, 'changed fact => new published result');
  assert.deepEqual(await one('SELECT created_by c,engine_version e FROM assessment_history WHERE id=?', after.v), { c: 'system:v2.2', e: 'v22-engine-1.0.0' });
  assert.equal(after.p, before.p + 1);
  // Reverting the fact republishes the earlier identical result: no duplicate row, pointer back, revision advanced.
  const v22Rows = () => count("SELECT count(*) n FROM assessment_history WHERE candidate_id=? AND engine_version='v22-engine-1.0.0'", id);
  const rowsBefore = await v22Rows(), c2 = await json(await send('/api/candidates/' + id, 'GET', undefined, staffA), 200);
  await json(await send('/api/candidates/' + id, 'PATCH', { version: c2.version, profile: { ...c2.profile, recommendation: 'yes' } }, staffA), 200);
  const back = await rev(id);
  assert.equal(back.v, W.lastVerified); assert.equal(back.p, after.p + 1);
  assert.equal(await v22Rows(), rowsBefore, 'no new v2.2 row on revert');
});

test('Worker NOC adapter: works without any consent record; provider, RBAC, scope, catalog and citations still enforced; other consents unchanged', async () => {
  const id = W.case, body = async (over = {}) => ({ action: 'noc_suggestion', expectedDataRevision: (await rev(id)).d, workEpisodeId: 'job:0', targetNocCodes: ['21231'], ...over });
  await json(await send('/api/candidates/' + id + '/analysis', 'POST', await body(), staffA), 503);
  await json(await send('/api/office', 'POST', { action: 'professional', provider: 'openai', model: 'gpt-new', key: 'sk-test-' + 'x'.repeat(30) }, admin), 200);
  assert.equal(await count('SELECT count(*) n FROM document_ai_permissions WHERE candidate_id=?', id), 0, 'no consent recorded for this case');
  const ok = await json(await send('/api/candidates/' + id + '/analysis', 'POST', await body(), staffA), 200);
  assert.equal(ok.status, 'PROVISIONAL'); assert.equal(ok.requiresProfessionalReview, true); assert.match(ok.catalogHash, /^[a-f0-9]{64}$/);
  assert.equal(ok.suggestions[0].dutyMatches[0].officialDutyId, '21231-d1');
  const factsBefore = await count('SELECT count(*) n FROM case_fact_revisions WHERE case_id=?', id);
  nocMode = 'forged';
  assert.match((await json(await send('/api/candidates/' + id + '/analysis', 'POST', await body(), staffA), 502)).error, /NOC_CITATION_FORGED:quote/);
  nocMode = 'valid';
  assert.equal(await count('SELECT count(*) n FROM case_fact_revisions WHERE case_id=?', id), factsBefore, 'a suggestion never becomes a fact');
  await json(await send('/api/candidates/' + id + '/analysis', 'POST', await body({ targetNocCodes: ['99999'] }), staffA), 422);
  await json(await send('/api/candidates/' + id + '/analysis', 'POST', await body({ workEpisodeId: 'job:7' }), staffA), 404);
  await json(await send('/api/candidates/' + id + '/analysis', 'POST', await body({ expectedDataRevision: 0 }), staffA), 409);
  await json(await send('/api/candidates/' + id + '/analysis', 'POST', await body({ consentId: 'c-1' }), staffA), 400);
  await json(await send('/api/candidates/00000000-0000-4000-8000-000000000000/analysis', 'POST', await body(), staffA), 404);
  const st = await json(await send('/api/office/permissions', 'GET', undefined, admin), 200), b = st.staff.find(s => s.email === 'staff-b@example.test');
  await json(await send('/api/office/permissions', 'POST', { action: 'toggle', target: 'USER', targetUserId: b.userId, key: 'review_case', value: false, expectedVersion: b.version, expectedEpoch: st.epoch, requestKey: key() }, admin), 200);
  await json(await send('/api/candidates/' + id + '/analysis', 'POST', await body(), staffB), 403);
  const calls = providerCalls;
  assert.match((await json(await send('/api/candidates/' + id + '/analysis', 'POST', undefined, staffA), 409)).error, /تفويض/, 'the case-brief provider consent is not removed');
  assert.equal(providerCalls, calls, 'no provider call without that consent');
});

test('Worker deactivation: no active release => BLOCKED_RULES and RULE_UNAVAILABLE; historic assessments keep their rules', async () => {
  const id = W.case, gen = (await one('SELECT generation g FROM rule_activation')).g;
  await json(await send('/api/office/rules/releases', 'POST', { action: 'activate', expectedGeneration: gen + 5, releaseId: null, reasonCode: 'stale' }, admin), 409);
  await json(await send('/api/office/rules/releases', 'POST', { action: 'activate', expectedGeneration: gen, releaseId: null, reasonCode: 'gate3-test-off' }, admin), 200);
  const out = await json(await recompute(id, recomputeBody(await rev(id))), 201);
  assert.equal(out.assessment.stage, 'BLOCKED_RULES'); assert.equal(out.assessment.crs.status, 'RULE_UNAVAILABLE');
  assert.ok(out.assessment.pathways.every(p => p.evaluationStatus === 'RULE_UNAVAILABLE' && p.reasonCodes[0] === 'NO_ACTIVE_RELEASE'));
  const old = await one("SELECT output_json o FROM assessment_history WHERE rule_bundle_hash=? AND assessment_mode='PRODUCTION' LIMIT 1", W.manifest);
  assert.equal(JSON.parse(old.o).ruleReleaseHash, W.manifest, 'historic result retrievable with the rules used then');
});
