// v2.2 Gate 5 — durable automation on the built Worker: one delivery outbox (lease/fence, retry with backoff,
// AMBIGUOUS re-sent only with the same provider Idempotency-Key, DLQ, concurrent dispatch → one provider call, consent
// re-checked at dispatch), durable jobs (lease expiry → RETRY / DEAD_LETTER), Zero-Touch ingestion through the scanner
// binding (CLEAN / REJECTED / scanner error → retry; hash ≠ fact), expiry milestones with catch-up and dedup, explicit
// service requests as the only CRM source, and sourced employers/vacancies/ATS with ranking unavailable.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { seedOfficeManager } from './office-fixture.mjs';
import { clientCaseFixture, grantConsent } from './client-case-fixture.mjs';
import { torontoDate } from '../../lib/v22-core.ts';

const require = createRequire(import.meta.url);
const { Miniflare } = createRequire(require.resolve('wrangler/package.json'))('miniflare');
const base = 'http://canada-desk.test';
const id = (uid, email) => ({ 'oai-authenticated-user-id': uid, 'oai-authenticated-user-email': email });
const admin = id('admin-1', 'admin@example.test'), staffA = id('staff-a', 'staff-a@example.test');
let mf, db, send, worker;
const json = async (r, status = 200) => { const t = await r.text(); assert.equal(r.status, status, t); return t ? JSON.parse(t) : null; };
const key = () => crypto.randomUUID();
const today = torontoDate(Date.now());
const plusDays = n => new Date(Date.parse(today + 'T12:00:00Z') + n * 86400000).toISOString().slice(0, 10);
const count = async (sql, ...b) => (await db.prepare(sql).bind(...b).first()).n;
const one = (sql, ...b) => db.prepare(sql).bind(...b).first();
const tick = () => worker.scheduled({ cron: '*/5 * * * *', scheduledTime: new Date() });
const daily = () => worker.scheduled({ cron: '17 8 * * *', scheduledTime: new Date() });
// Programmable provider (Resend) and scanner.
let provider = async () => Response.json({ id: 're_ok' }), calls = [], scanner = 'ok';
test.before(async () => {
  const files = await readdir('dist/server', { recursive: true });
  mf = new Miniflare({
    modules: ['index.js', ...files.filter(f => f !== 'index.js' && f.endsWith('.js'))].map(f => ({ type: 'ESModule', path: path.resolve('dist/server', f) })),
    modulesRoot: path.resolve('dist/server'), compatibilityDate: '2026-05-15', compatibilityFlags: ['nodejs_compat'],
    d1Databases: { DB: 'automation-db' }, r2Buckets: ['BUCKET'], kvNamespaces: { PERMISSIONS_KV: 'automation-kv' },
    bindings: { TRUST_SITES_IDENTITY_HEADERS: '1', OFFICE_ADMIN_EMAIL: 'admin@example.test', APP_SECRET: 'c'.repeat(64), PERMISSIONS_KV_NAMESPACE: 'test' },
    serviceBindings: { EVIDENCE_SCANNER: async req => {
      const text = new TextDecoder().decode(new Uint8Array(await req.arrayBuffer()));
      if (scanner === 'down') return new Response('down', { status: 503 });
      return Response.json({ verdict: text.includes('EICAR-QA') ? 'INFECTED' : 'CLEAN', engine: 'qa-scanner-1' });
    } },
    outboundService: async req => {
      if (new URL(req.url).hostname !== 'api.resend.com') return new Response('blocked', { status: 599 });
      const body = await req.json(); calls.push({ key: req.headers.get('idempotency-key'), body });
      return provider(req, body);
    },
  });
  send = (p, method = 'GET', body, headers = {}) => mf.dispatchFetch(base + p, { method, headers: { ...(body ? { 'content-type': 'application/json' } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined });
  db = await mf.getD1Database('DB'); worker = await mf.getWorker();
  for (const f of (await readdir('drizzle')).filter(f => f.endsWith('.sql')).sort())
    for (const s of (await readFile('drizzle/' + f, 'utf8')).split('--> statement-breakpoint').map(s => s.trim()).filter(Boolean)) await db.prepare(s).run();
  await seedOfficeManager(db, 'admin-1');
  await json(await send('/api/office', 'GET', undefined, admin));
  await json(await send('/api/office', 'POST', { action: 'member', email: 'staff-a@example.test', name: 'QA Staff A', active: true }, admin));
  await json(await send('/api/office', 'POST', { action: 'mail', sender: 'office@example.test', key: 're_' + 'z'.repeat(20) }, admin));
  await json(await send('/api/office', 'POST', { action: 'billing_currency', currency: 'CAD' }, admin));
});
test.after(async () => { await mf?.dispose(); });

const st = {};
async function paymentNotice(c) {
  const inv = await json(await send(`/api/candidates/${c.id}/invoices`, 'POST', { currency: 'CAD', items: [{ kind: 'CUSTOM', serviceName: 'Service', unitPriceCents: 1000, isFree: false, referencePriceCents: null }], discountCents: 0, deadline: null, note: null, requestKey: key() }, staffA), 201);
  return (await json(await send(`/api/invoices/${inv.invoiceId}/notice`, 'POST', { expectedVersion: inv.version, channel: 'EMAIL', requestKey: key() }, staffA), 202)).eventId;
}
const row = eventId => one('SELECT * FROM delivery_outbox WHERE event_id=?', eventId);
test('outbox: delivery with the event id as Idempotency-Key; limited text (remaining/currency/deadline only)', async () => {
  st.c = await clientCaseFixture(db, { name: 'QA Outbox', email: 'outbox-client@example.test', phone: '+15556660001' });
  const ev = await paymentNotice(st.c); calls = [];
  await tick();
  const r = await row(ev);
  assert.equal(r.state, 'DELIVERED'); assert.equal(r.provider_reference, 're_ok'); assert.equal(r.attempts, 1);
  assert.equal(calls.length, 1); assert.equal(calls[0].key, 'outbox/' + ev); assert.deepEqual(calls[0].body.to, ['outbox-client@example.test']);
  assert.match(calls[0].body.text, /10\.00 CAD/, 'remaining balance and currency (AC-56)');
  assert.doesNotMatch(calls[0].body.text, /Service|QA Outbox|outbox-client@/, 'no items, names or contact in the text');
  await tick(); assert.equal(calls.length, 1, 'delivered rows are never re-sent');
});
test('outbox: 5xx → RETRY with backoff; lost response → AMBIGUOUS, re-sent only with the same key; 400 → DEAD_LETTER', async () => {
  const ev = await paymentNotice(st.c); calls = [];
  provider = async () => new Response('err', { status: 502 });
  await tick(); let r = await row(ev);
  assert.equal(r.state, 'RETRY'); assert.equal(r.error_code, 'PROVIDER_502'); assert.ok(r.next_at_ms > Date.now() + 30000, 'backoff in the future');
  await tick(); assert.equal(calls.length, 1, 'not retried before next_at');
  await db.prepare('UPDATE delivery_outbox SET next_at_ms=0 WHERE event_id=?').bind(ev).run();
  // The provider accepted the request but the response was lost mid-body: the outcome is unknown.
  provider = async () => new Response(new ReadableStream({ start(c) { c.error(new Error('connection reset')); } }), { status: 200, headers: { 'content-type': 'application/json' } });
  await tick(); r = await row(ev); assert.equal(r.state, 'AMBIGUOUS'); assert.match(r.error_code, /PROVIDER_IDEMPOTENCY_IN_PROGRESS|PROVIDER_OUTCOME_UNKNOWN/);
  await db.prepare('UPDATE delivery_outbox SET next_at_ms=0 WHERE event_id=?').bind(ev).run();
  provider = async () => Response.json({ id: 're_after_ambiguous' });
  await tick(); r = await row(ev);
  assert.equal(r.state, 'DELIVERED'); assert.equal(new Set(calls.map(c => c.key)).size, 1, 'every attempt used the same Idempotency-Key');
  const dead = await paymentNotice(st.c); provider = async () => new Response('bad', { status: 400 });
  await tick(); assert.equal((await row(dead)).state, 'DEAD_LETTER');
  provider = async () => Response.json({ id: 're_ok' });
});
test('outbox: an expired lease becomes AMBIGUOUS (same key); concurrent dispatchers send once', async () => {
  const ev = await paymentNotice(st.c); calls = [];
  await db.prepare("UPDATE delivery_outbox SET state='LEASED',fence=fence+1,lease_until_ms=?,attempts=1 WHERE event_id=?").bind(Date.now() - 1000, ev).run();
  await tick(); const r = await row(ev);
  assert.equal(r.state, 'DELIVERED'); assert.equal(calls.length, 1); assert.equal(calls[0].key, 'outbox/' + ev);
  const ev2 = await paymentNotice(st.c); calls = [];
  let release; const gate = new Promise(res => { release = res; });
  provider = async () => { await gate; return Response.json({ id: 're_once' }); };
  const both = Promise.all([tick(), tick()]); setTimeout(release, 300); await both;
  assert.equal(calls.filter(c => c.key === 'outbox/' + ev2).length, 1, 'the lease CAS lets one dispatcher send');
  assert.equal((await row(ev2)).state, 'DELIVERED');
  provider = async () => Response.json({ id: 're_ok' });
});
test('outbox: consent is re-checked at dispatch; a revoked CHAT/EXPIRY consent cancels the notice', async () => {
  const c = await clientCaseFixture(db, { name: 'QA Consent', email: 'consent@example.test', phone: '+15556660002', details: { passportExpiry: plusDays(20) } });
  await grantConsent(db, c.id, 'EXPIRY_NOTIFICATIONS', true);
  await daily();
  const ev = await one("SELECT event_id,state,business_key FROM delivery_outbox WHERE case_id=? AND kind='EXPIRY_NOTICE'", c.id);
  assert.ok(ev, 'expiry notice queued'); assert.match(ev.business_key, /:passport:.*:30$/, 'catch-up: only the most urgent reached milestone (30), not 90');
  await db.prepare("UPDATE delivery_outbox SET state='PENDING',next_at_ms=0,attempts=0,provider_reference=NULL WHERE event_id=?").bind(ev.event_id).run();
  await grantConsent(db, c.id, 'EXPIRY_NOTIFICATIONS', false); calls = [];
  await tick();
  const queued = ev;
  const r = await row(queued.event_id); assert.equal(r.state, 'CANCELLED'); assert.equal(r.error_code, 'CONSENT_REQUIRED'); assert.equal(calls.length, 0);
});
test('expiry: dedup per milestone, expired language test → 0-day task; no consent → no client notice', async () => {
  const c = await clientCaseFixture(db, { name: 'QA Expiry', email: 'expiry@example.test', phone: '+15556660003', details: { passportExpiry: plusDays(60) }, profile: { englishDate: plusDays(-735) } });
  await daily(); await daily();
  assert.equal(await count("SELECT count(*) n FROM delivery_outbox WHERE case_id=?", c.id), 0, 'no consent, nothing external');
  assert.equal(await count("SELECT count(*) n FROM tasks WHERE candidate_id=? AND system_key LIKE 'doc-expiry:english_test:%:0'", c.id), 1, 'one staff task, deduplicated');
  await grantConsent(db, c.id, 'EXPIRY_NOTIFICATIONS', true);
  await daily(); await daily();
  const keys = (await db.prepare("SELECT business_key k FROM delivery_outbox WHERE case_id=? ORDER BY k").bind(c.id).all()).results.map(r => r.k);
  assert.equal(keys.length, 2, 'passport 90 + english 0, each once'); assert.ok(keys.some(k => /passport:.*:90$/.test(k))); assert.ok(keys.some(k => /english_test:.*:0$/.test(k)));
});
test('jobs: an expired RUNNING lease returns to RETRY and completes; an exhausted one is dead-lettered', async () => {
  const now = new Date().toISOString(), j1 = key(), j2 = key();
  await db.prepare("INSERT INTO durable_jobs(job_id,case_id,kind,request_key,request_hash,payload,state,attempts,lease_until_ms,fence,next_at_ms,created_by,created_at,updated_at) VALUES(?,?,'ASSESSMENT',?,?,'{}','RUNNING',1,?,3,0,'system:v2.2',?,?)").bind(j1, st.c.id, 'qa-' + j1, 'd'.repeat(64), Date.now() - 1000, now, now).run();
  await db.prepare("INSERT INTO durable_jobs(job_id,case_id,kind,request_key,request_hash,payload,state,attempts,lease_until_ms,fence,next_at_ms,created_by,created_at,updated_at) VALUES(?,?,'ASSESSMENT',?,?,'{}','RUNNING',5,?,9,0,'system:v2.2',?,?)").bind(j2, st.c.id, 'qa-' + j2, 'e'.repeat(64), Date.now() - 1000, now, now).run();
  await tick();
  const a = await one('SELECT state,fence,attempts FROM durable_jobs WHERE job_id=?', j1), b = await one('SELECT state,error_code FROM durable_jobs WHERE job_id=?', j2);
  assert.equal(a.state, 'SUCCEEDED'); assert.equal(a.fence, 4, 'new lease = new fence'); assert.equal(a.attempts, 2);
  assert.deepEqual([b.state, b.error_code], ['DEAD_LETTER', 'LEASE_EXPIRED']);
});
async function upload(caseId, bytes, name) {
  const form = new FormData(); form.set('file', new File([bytes], name, { type: 'application/pdf' })); form.set('category', 'other');
  const req = new Request(base + `/api/candidates/${caseId}/documents`, { method: 'POST', body: form, headers: staffA });
  const r = await mf.dispatchFetch(req.url, { method: 'POST', headers: Object.fromEntries(req.headers), body: await req.arrayBuffer() });
  const t = await r.text(); assert.ok(r.status === 200 || r.status === 201, t); return JSON.parse(t);
}
test('ingestion: upload → QUARANTINED + INGESTION job in one batch → scanner CLEAN / INFECTED → REJECTED / outage → retry', async () => {
  const pdf = s => new TextEncoder().encode('%PDF-1.4\n' + s + '\n%%EOF');
  const ok = await upload(st.c.id, pdf('clean ' + key()), 'clean.pdf'), bad = await upload(st.c.id, pdf('EICAR-QA ' + key()), 'bad.pdf');
  for (const d of [ok, bad]) {
    assert.equal((await one('SELECT integrity_state s FROM documents WHERE id=?', d.id)).s, 'QUARANTINED');
    assert.equal(await count("SELECT count(*) n FROM durable_jobs WHERE request_key=? AND kind='INGESTION'", 'ingest:' + d.id), 1);
  }
  await tick();
  const clean = await one('SELECT integrity_state s,integrity_engine e,integrity_checked_at t,verified v FROM documents WHERE id=?', ok.id);
  assert.deepEqual([clean.s, clean.e, !!clean.t, clean.v], ['CLEAN', 'qa-scanner-1', true, 0], 'CLEAN is not "verified": staff review is still required');
  assert.equal((await one('SELECT integrity_state s FROM documents WHERE id=?', bad.id)).s, 'REJECTED');
  await assert.rejects(db.prepare("UPDATE documents SET integrity_state='CLEAN' WHERE id=?").bind(bad.id).run(), /INVALID_INTEGRITY_TRANSITION/);
  scanner = 'down';
  const later = await upload(st.c.id, pdf('later ' + key()), 'later.pdf');
  await tick();
  const j = await one("SELECT state,error_code FROM durable_jobs WHERE request_key=?", 'ingest:' + later.id);
  assert.equal(j.state, 'RETRY'); assert.equal((await one('SELECT integrity_state s FROM documents WHERE id=?', later.id)).s, 'ERROR');
  scanner = 'ok'; await db.prepare("UPDATE durable_jobs SET next_at_ms=0 WHERE request_key=?").bind('ingest:' + later.id).run();
  await tick();
  assert.equal((await one('SELECT integrity_state s FROM documents WHERE id=?', later.id)).s, 'CLEAN', 'recovered after the outage');
  const legacy = await one("SELECT count(*) n FROM documents WHERE integrity_state='LEGACY_UNSCANNED'"); assert.equal(typeof legacy.n, 'number');
});
test('services: only an explicit client request creates the CRM event and task (idempotent, version-checked)', async () => {
  await json(await send('/api/office', 'POST', { action: 'service', serviceId: 'cv-review', nameAr: 'مراجعة السيرة', nameEn: 'CV review', priceCents: 5000, currency: 'CAD', active: true, expectedVersion: null }, admin));
  await json(await send('/api/office', 'POST', { action: 'service', serviceId: 'old-service', nameAr: 'خدمة متوقفة', nameEn: 'Retired', priceCents: 100, currency: 'CAD', active: false, expectedVersion: null }, admin));
  const cookie = { cookie: st.c.cookie }, events0 = await count('SELECT count(*) n FROM events WHERE candidate_id=?', st.c.id);
  const cat = await json(await send('/api/client/services', 'GET', undefined, cookie));
  assert.equal(cat.currency, 'CAD'); assert.deepEqual(cat.services.map(s => s.serviceId), ['cv-review'], 'inactive services hidden');
  assert.equal(await count('SELECT count(*) n FROM events WHERE candidate_id=?', st.c.id), events0, 'viewing creates nothing');
  const body = { serviceId: 'cv-review', serviceVersion: 1, note: 'Please review', requestKey: key() };
  const r = await json(await send('/api/client/services', 'POST', body, cookie), 201);
  assert.equal((await json(await send('/api/client/services', 'POST', body, cookie))).requestId, r.requestId, 'replay');
  assert.equal((await send('/api/client/services', 'POST', { ...body, note: 'other' }, cookie)).status, 409);
  assert.equal((await send('/api/client/services', 'POST', { ...body, requestKey: key(), serviceVersion: 2 }, cookie)).status, 409, 'stale service version');
  assert.equal((await send('/api/client/services', 'POST', { serviceId: 'old-service', serviceVersion: 1, note: null, requestKey: key() }, cookie)).status, 422);
  assert.equal(await count('SELECT count(*) n FROM events WHERE candidate_id=?', st.c.id), events0 + 1);
  assert.equal(await count("SELECT count(*) n FROM tasks WHERE system_key=?", 'service-request:' + r.requestId), 1);
});
test('employers/ATS: https source and real dates required, CAS stages, ranking unavailable, edit_case enforced', async () => {
  const emp = { action: 'employer', employerId: null, expectedVersion: null, name: 'QA Employer Inc.', sourceUrl: 'https://www.jobbank.gc.ca/jobsearch/jobposting/00000000', sourceCheckedOn: today, contact: 'hr@example.test' };
  assert.equal((await send('/api/office/employers', 'POST', { ...emp, sourceUrl: 'http://insecure.example.test' }, staffA)).status, 400);
  assert.equal((await send('/api/office/employers', 'POST', { ...emp, sourceCheckedOn: plusDays(3) }, staffA)).status, 422, 'future check date');
  const { employerId } = await json(await send('/api/office/employers', 'POST', emp, staffA), 201);
  const vac = { action: 'vacancy', vacancyId: null, expectedVersion: null, employerId, title: 'Cook', noc: '63200', sourceUrl: 'https://www.jobbank.gc.ca/jobsearch/jobposting/00000001', postedOn: today, validUntil: plusDays(30), status: 'OPEN' };
  const { vacancyId } = await json(await send('/api/office/employers', 'POST', vac, staffA), 201);
  assert.equal((await json(await send('/api/office/employers', 'POST', { action: 'stage', caseId: st.c.id, vacancyId, stage: 'SHORTLISTED', expectedVersion: null }, staffA))).version, 1);
  assert.equal((await send('/api/office/employers', 'POST', { action: 'stage', caseId: st.c.id, vacancyId, stage: 'SUBMITTED', expectedVersion: 5 }, staffA)).status, 409);
  assert.equal((await json(await send('/api/office/employers', 'POST', { action: 'stage', caseId: st.c.id, vacancyId, stage: 'SUBMITTED', expectedVersion: 1 }, staffA))).version, 2);
  const board = await json(await send('/api/office/employers?case=' + st.c.id, 'GET', undefined, staffA));
  assert.equal(board.rank, 'RANK_UNAVAILABLE'); assert.ok(board.vacancies.every(v => v.rank === 'RANK_UNAVAILABLE'));
  assert.equal(board.employers[0].contact, 'hr@example.test'); assert.notEqual((await one('SELECT contact_encrypted c FROM office_employers')).c, 'hr@example.test', 'contact encrypted at rest');
  const st0 = await json(await send('/api/office/permissions', 'GET', undefined, admin)), a = st0.staff.find(x => x.userId === 'staff:staff-a@example.test');
  await json(await send('/api/office/permissions', 'POST', { action: 'toggle', target: 'USER', targetUserId: a.userId, key: 'edit_case', value: false, expectedVersion: a.version, expectedEpoch: st0.epoch, requestKey: key() }, admin));
  assert.equal((await send('/api/office/employers', 'POST', { ...emp, name: 'Blocked' }, staffA)).status, 403);
  assert.equal((await send('/api/office/employers', 'GET', undefined, staffA)).status, 200, 'reading stays with view_crm');
});
