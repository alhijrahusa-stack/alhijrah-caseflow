// v2.2 Gate 6 — workload measurement on the built Worker in LOCAL Miniflare (one process; NOT Cloudflare staging — the
// AC-27/AC-39 staging run remains NOT_RUN). Profile from AC-39: 100 authorized sockets across 20 case rooms (1 client +
// 4 staff sockets per room), messages committed over HTTPS at 5 msg/s aggregate for LOAD_SECONDS (default 60; the
// specified 15 min is LOAD_SECONDS=900), concurrent HTTP/D1 reads, Rapid Assessment requests, and a reconnect wave
// (20 sockets closed and reopened mid-run, gap replayed over HTTP). Targets: p95 commit ≤ 1 s, p95 fan-out ≤ 2 s,
// rapid enqueue (request accepted) ≤ 800 ms and rapid result (assessment visible in canonical replay) ≤ 5 s measured
// separately, client:staff message distribution exactly 1:3 (counted by sender and verified in D1),
// zero lost and zero leaked committed messages. Writes a JSON report (LOAD_REPORT) and exits 1 if a target is missed.
import { createRequire } from 'node:module';
import { readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { seedOfficeManager } from './office-fixture.mjs';
import { clientCaseFixture } from './client-case-fixture.mjs';
import { SOURCES, crsBundle, programBundle, nocBundle } from './engine-fixtures.mjs';

const require = createRequire(import.meta.url);
const { Miniflare } = createRequire(require.resolve('wrangler/package.json'))('miniflare');
const base = 'http://canada-desk.test', SECONDS = Number(process.env.LOAD_SECONDS || 60), RATE = 5, ROOMS = 20, PER_ROOM = 5;
const admin = { 'oai-authenticated-user-id': 'admin-1', 'oai-authenticated-user-email': 'admin@example.test' };
const staff = [admin, { 'oai-authenticated-user-id': 'staff-a', 'oai-authenticated-user-email': 'staff-a@example.test' }];
const files = await readdir('dist/server', { recursive: true });
const mf = new Miniflare({
  modules: ['index.js', ...files.filter(f => f !== 'index.js' && f.endsWith('.js'))].map(f => ({ type: 'ESModule', path: path.resolve('dist/server', f) })),
  modulesRoot: path.resolve('dist/server'), compatibilityDate: '2026-05-15', compatibilityFlags: ['nodejs_compat'],
  d1Databases: { DB: 'load-db' }, r2Buckets: ['BUCKET'], durableObjects: { CHAT_ROOMS: 'CaseChatRoom' },
  bindings: { TRUST_SITES_IDENTITY_HEADERS: '1', OFFICE_ADMIN_EMAIL: 'admin@example.test', APP_SECRET: '7'.repeat(64) },
  outboundService: async () => new Response('blocked', { status: 599 }),
});
const send = (p, method = 'GET', body, headers = admin) => mf.dispatchFetch(base + p, { method, headers: { ...headers, ...(body ? { 'content-type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined });
const ok = async (r, ...codes) => { if (!codes.includes(r.status)) throw new Error(r.status + ' ' + await r.text()); return r.json(); };
const db = await mf.getD1Database('DB');
for (const f of (await readdir('drizzle')).filter(f => f.endsWith('.sql')).sort()) for (const s of (await readFile('drizzle/' + f, 'utf8')).split('--> statement-breakpoint').map(s => s.trim()).filter(Boolean)) await db.prepare(s).run();
await seedOfficeManager(db, 'admin-1');
await ok(await send('/api/office'), 200);
await ok(await send('/api/office', 'POST', { action: 'member', email: 'staff-a@example.test', name: 'QA Staff A', active: true }), 200);
// Sealed test release so Rapid Assessment runs the real engine.
for (const [sid, s] of Object.entries(SOURCES)) await ok(await send('/api/office/rules/import', 'POST', { action: 'source', sourceId: sid, officialUrl: s.officialUrl, authority: 'TEST_ONLY', contentBase64: Buffer.from(s.text).toString('base64') }), 201);
const up = async b => (await ok(await send('/api/office/rules/import', 'POST', { action: 'bundle', payload: b.payload, payloadHash: b.hash }), 201)).bundleId;
const W = { crs: await up(await crsBundle()), fsw: await up(await programBundle()), noc: await up(await nocBundle()) };
const iv = (programId, family, from, bundleId) => ({ programId, family, phase: 'PROFILE', dateBasis: 'PROFILE', effectiveFrom: from, effectiveToExclusive: null, bundleId });
const intervals = [iv('EE_CRS', 'CRS', '2026-11-03', W.crs), iv('EE_FSWP', 'ELIGIBILITY', '2026-01-01', W.fsw), iv('NOC_2021', 'NOC_CATALOG', '2026-01-01', W.noc)];
const pv = await ok(await send('/api/office/rules/releases', 'POST', { action: 'preview', intervals }), 200);
await ok(await send('/api/office/rules/releases', 'POST', { action: 'seal', intervals, manifestHash: pv.manifestHash, activate: { expectedGeneration: 0, reasonCode: 'load' } }), 201);

const rooms = [];
for (let i = 0; i < ROOMS; i++) {
  const c = await ok(await send('/api/candidates', 'POST', { fullName: 'Load Client ' + i, phone: '+1555200' + String(i).padStart(4, '0'), email: `load${i}@example.test`, consent: true, jobs: [{ title: 'QA role', employer: 'QA employer', country: 'Yemen', start: '2024-01', end: '2024-12', weekly_hours: 40 }], occupation: 'Synthetic test', noc: '72401', teer: 2, experience3: 12, experience10: 24, englishMin: 5, englishDate: '2026-10-01' }), 201);
  rooms.push({ ...(await clientCaseFixture(db, { name: 'Load Client ' + i, email: `load${i}@example.test`, phone: '+1555200' + i, candidateId: c.id })), sockets: [], sent: new Map() });
}
const leaks = [];
async function open(room, idx) {
  const isClient = idx === 0, url = isClient ? '/api/client/chat?socket=1' : `/api/candidates/${room.id}/chat?socket=1`;
  const r = await mf.dispatchFetch(base + url, { headers: { ...(isClient ? { cookie: room.cookie } : staff[idx % 2]), Upgrade: 'websocket', Origin: base } });
  if (r.status !== 101) throw new Error('socket ' + r.status);
  const s = { ws: r.webSocket, seen: new Map(), open: true, idx };
  s.ws.addEventListener('message', e => { const f = JSON.parse(e.data); if (f.type !== 'MESSAGE_COMMITTED') return; if (f.message.caseId !== room.id) leaks.push(f.message.caseId); if (!s.seen.has(f.message.sequence)) s.seen.set(f.message.sequence, Date.now()); });
  s.ws.addEventListener('close', () => { s.open = false; });
  s.ws.accept(); return s;
}
for (const room of rooms) for (let k = 0; k < PER_ROOM; k++) room.sockets.push(await open(room, k));
const commit = [], http = [], rapidEnqueue = [], rapidResult = [], errors = [], senders = { client: 0, staff: 0 };
const pct = (a, p) => { if (!a.length) return null; const s = [...a].sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.ceil(p / 100 * s.length) - 1)]; };
let n = 0, stop = false;
const startedAt = Date.now();
async function sendOne() {
  const room = rooms[n % ROOMS], i = n++, t0 = Date.now();
  // 1 in 4 messages from the client (stays under the client limit of 60 per case per 15 min even at LOAD_SECONDS=900),
  // 3 in 4 from the staff member holding the conversation (claimed with the first staff message).
  const fromClient = (room.n = (room.n ?? 0) + 1) % 4 === 1, message = { clientMessageId: 'load-message-' + i, repliedToMessageId: null, kind: 'TEXT', text: 'load message ' + i };
  try { const r = await ok(fromClient ? await send('/api/client/chat', 'POST', { action: 'send', message }, { cookie: room.cookie }) : await send(`/api/candidates/${room.id}/chat`, 'POST', { action: 'send', message }, admin), 201); commit.push(Date.now() - t0); room.sent.set(r.sequence, t0); senders[fromClient ? 'client' : 'staff']++; }
  catch (e) { errors.push('send:' + e.message.slice(0, 80)); }
}
const reader = (async () => { while (!stop) { const t0 = Date.now(); try { await ok(await send('/api/candidates'), 200); await ok(await send('/api/client', 'GET', undefined, { cookie: rooms[Math.floor(Math.random() * ROOMS)].cookie }), 200); http.push(Date.now() - t0); } catch (e) { errors.push('read:' + e.message.slice(0, 80)); } await new Promise(r => setTimeout(r, 100)); } })();
const sender = (async () => { const total = Math.floor(SECONDS * RATE / (ROOMS * 4)) * ROOMS * 4; /* whole 1:3 cycles in every room */ for (let k = 0; k < total; k++) { const due = startedAt + k * (1000 / RATE); const wait = due - Date.now(); if (wait > 0) await new Promise(r => setTimeout(r, wait)); void sendOne(); } })();
// Reconnect wave at the middle of the run: one staff socket per room is closed, then reopened after 2 s.
const wave = (async () => { await new Promise(r => setTimeout(r, SECONDS * 500)); for (const room of rooms) { const s = room.sockets[1]; s.ws.close(1000); } await new Promise(r => setTimeout(r, 2000)); for (const room of rooms) { const old = room.sockets[1]; const fresh = await open(room, 1); fresh.previous = old; room.sockets[1] = fresh; } })();
// Rapid Assessment: enqueue = time until the server accepts the request (HTTP response); result = time until the
// assessment message with that assessmentId is visible in the room's canonical replay (observed separately by polling).
const rapidRun = (async () => { for (let k = 0; k < 10; k++) { await new Promise(r => setTimeout(r, SECONDS * 100)); const room = rooms[k % ROOMS], t0 = Date.now();
  try { const r = await ok(await send('/api/client/chat', 'POST', { action: 'rapid_assessment', requestKey: 'rapid-request-' + k, confirmed: true }, { cookie: room.cookie }), 201); rapidEnqueue.push(Date.now() - t0);
    let seen = false; for (let i = 0; i < 250 && !seen; i++) { const p = await ok(await send(`/api/client/chat?after=${Math.max(0, r.messageSequence - 1)}&limit=5`, 'GET', undefined, { cookie: room.cookie }), 200); seen = p.items.some(m => m.kind === 'ASSESSMENT_LINK' && m.assessmentId === r.assessmentId); if (!seen) await new Promise(res => setTimeout(res, 20)); }
    if (seen) rapidResult.push(Date.now() - t0); else errors.push('rapid:result-not-visible'); }
  catch (e) { errors.push('rapid:' + e.message.slice(0, 120)); } } })();
await sender; await wave; await rapidRun; await new Promise(r => setTimeout(r, 3000)); stop = true; await reader;
// Delivery accounting: every committed message must reach every socket of its room (frames, plus HTTP replay for the
// gap of a reconnected socket). Fan-out latency = first frame time − send start.
const fanout = []; let lost = 0;
for (const room of rooms) {
  const page = await ok(await send(`/api/candidates/${room.id}/chat?after=0&limit=100`), 200);
  let all = page.items.map(i => i.sequence), after = page.nextAfterSequence;
  while (after !== null) { const p = await ok(await send(`/api/candidates/${room.id}/chat?after=${after}&limit=100`), 200); all = all.concat(p.items.map(i => i.sequence)); after = p.nextAfterSequence; }
  for (const [seq, t0] of room.sent) {
    if (!all.includes(seq)) { lost++; continue; }
    for (const s of room.sockets) {
      const at = s.seen.get(seq) ?? s.previous?.seen.get(seq);
      if (at) fanout.push(at - t0);
      else if (!s.previous) lost++;                       // a socket that never reconnected and missed a frame = lost
    }
  }
}
const dbRows = (await db.prepare("SELECT actor_type a,count(*) n FROM case_chat_messages WHERE client_message_id LIKE 'load-message-%' GROUP BY actor_type").all()).results;
const dbCounts = { client: dbRows.find(r => r.a === 'CLIENT')?.n ?? 0, staff: dbRows.find(r => r.a === 'STAFF')?.n ?? 0 };
const report = {
  environment: 'Miniflare local single process (not Cloudflare staging)', profile: { seconds: SECONDS, rateMsgPerSec: RATE, rooms: ROOMS, socketsPerRoom: PER_ROOM, sockets: ROOMS * PER_ROOM },
  messages: { committed: commit.length, attempted: n, errors: errors.length, errorSamples: errors.slice(0, 5) },
  commitMs: { p50: pct(commit, 50), p95: pct(commit, 95), max: Math.max(0, ...commit) }, fanoutMs: { samples: fanout.length, p50: pct(fanout, 50), p95: pct(fanout, 95) },
  httpReadMs: { samples: http.length, p50: pct(http, 50), p95: pct(http, 95) }, rapidEnqueueMs: { samples: rapidEnqueue.length, p50: pct(rapidEnqueue, 50), p95: pct(rapidEnqueue, 95), max: Math.max(0, ...rapidEnqueue) }, rapidResultMs: { samples: rapidResult.length, p50: pct(rapidResult, 50), p95: pct(rapidResult, 95), max: Math.max(0, ...rapidResult) },
  reconnect: { socketsReconnected: ROOMS, gapReplayedOverHttp: true }, lostCommitted: lost, leakedFrames: leaks.length,
  senderDistribution: { ...senders, dbClientMessages: dbCounts.client, dbStaffMessages: dbCounts.staff, ratioStaffPerClient: senders.client ? +(senders.staff / senders.client).toFixed(3) : null },
  evidenceNote: 'LOCAL evidence only: Miniflare runs Workers/D1/DO in one local process; it is not Cloudflare staging and does not prove AC-27/AC-39.',
};
report.targets = { commitP95le1000: report.commitMs.p95 !== null && report.commitMs.p95 <= 1000, fanoutP95le2000: report.fanoutMs.p95 !== null && report.fanoutMs.p95 <= 2000, rapidEnqueueP95le800: rapidEnqueue.length === 10 && report.rapidEnqueueMs.p95 <= 800, rapidResultMaxle5000: rapidResult.length === 10 && report.rapidResultMs.max <= 5000, distribution1to3: senders.client > 0 && senders.staff === 3 * senders.client && dbCounts.client === senders.client && dbCounts.staff === senders.staff, zeroLost: lost === 0, zeroLeaked: leaks.length === 0, noErrors: errors.length === 0 };
console.log(JSON.stringify(report, null, 2));
if (process.env.LOAD_REPORT) await writeFile(process.env.LOAD_REPORT, JSON.stringify(report, null, 2));
for (const room of rooms) for (const s of room.sockets) try { s.ws.close(1000); } catch { /* closed */ }
await mf.dispose();
process.exit(Object.values(report.targets).every(Boolean) ? 0 : 1);
