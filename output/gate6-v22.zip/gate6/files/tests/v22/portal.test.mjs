// v2.2 Gate 4 — client account, drafts, fixed signature, atomic submission and the limited status lookup on the built
// Worker (Workers/D1/R2 local via Miniflare; no D1/R2 mocks). The email provider (Resend) is a declared test double
// through outboundService; codes are read from the captured message. Browser/device criteria are in portal.e2e.spec.ts.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { seedOfficeManager } from './office-fixture.mjs';
import { signaturePng, signingHash } from '../signed-intake-fixture.mjs';
import { LEGAL_VERSION } from '../../lib/legal.ts';
import { inspectSignaturePng } from '../../lib/signature.ts';
import { SOURCES, crsBundle, programBundle, nocBundle } from './engine-fixtures.mjs';

const require = createRequire(import.meta.url);
const { Miniflare } = createRequire(require.resolve('wrangler/package.json'))('miniflare');
const base = 'https://canada-desk.test';
const admin = { 'oai-authenticated-user-id': 'admin-1', 'oai-authenticated-user-email': 'admin@example.test' };
const sha = s => createHash('sha256').update(s).digest('hex');
let mf, db, bucket, mails = [], mailMode = 'ok';
// Multipart bodies are serialized by undici first so the boundary header survives dispatchFetch.
async function send(p, method = 'GET', body, headers = {}) {
  if (body instanceof FormData) { const r = new Request(base + p, { method, body }); return mf.dispatchFetch(base + p, { method, headers: { 'content-type': r.headers.get('content-type'), ...headers }, body: await r.arrayBuffer() }); }
  return mf.dispatchFetch(base + p, { method, headers: { ...(body !== undefined ? { 'content-type': 'application/json' } : {}), ...headers }, body: body !== undefined ? JSON.stringify(body) : undefined });
}
const json = async (r, status) => { const t = await r.text(); if (status !== undefined) assert.equal(r.status, status, t); return t ? JSON.parse(t) : null; };
const cookieOf = (r, name) => (r.headers.getSetCookie?.() ?? [r.headers.get('set-cookie') || '']).map(c => c.split(';')[0]).find(c => c.startsWith(name + '=') && c.length > name.length + 1) || '';
const lastCode = to => { const m = [...mails].reverse().find(x => x.to.includes(to)); assert.ok(m, 'mail to ' + to); return /\b(\d{6})\b/.exec(m.text)[1]; };
const one = async (q, ...p) => db.prepare(q).bind(...p).first();
const count = async (q, ...p) => (await one(q, ...p)).n;

test.before(async () => {
  const files = await readdir('dist/server', { recursive: true });
  mf = new Miniflare({
    modules: ['index.js', ...files.filter(f => f !== 'index.js' && f.endsWith('.js'))].map(f => ({ type: 'ESModule', path: path.resolve('dist/server', f) })),
    modulesRoot: path.resolve('dist/server'), compatibilityDate: '2026-05-15', compatibilityFlags: ['nodejs_compat'],
    d1Databases: { DB: 'gate4-db' }, r2Buckets: ['BUCKET'],
    bindings: { TRUST_SITES_IDENTITY_HEADERS: '1', OFFICE_ADMIN_EMAIL: 'admin@example.test', APP_SECRET: 'c'.repeat(64) },
    outboundService: async req => {
      const u = new URL(req.url);
      if (u.hostname === 'api.resend.com') { const b = await req.json(); mails.push({ to: b.to, text: b.text || '', subject: b.subject }); return mailMode === 'ok' ? Response.json({ id: 'msg-' + mails.length }) : new Response('down', { status: 500 }); }
      return new Response('blocked', { status: 599 });
    },
  });
  db = await mf.getD1Database('DB'); bucket = await mf.getR2Bucket('BUCKET');
  for (const f of (await readdir('drizzle')).filter(f => f.endsWith('.sql')).sort())
    for (const s of (await readFile('drizzle/' + f, 'utf8')).split('--> statement-breakpoint').map(s => s.trim()).filter(Boolean)) await db.prepare(s).run();
  await seedOfficeManager(db, 'admin-1');
  await json(await send('/api/office', 'GET', undefined, admin), 200);
  await json(await send('/api/office', 'POST', { action: 'mail', sender: 'notifications@example.test', key: 're_test_' + 'x'.repeat(24) }, admin), 200);
});
test.after(async () => { await mf?.dispose(); });

async function signIn(email, intent, name) {
  await db.prepare('DELETE FROM rate_limits').run(); // test clock: the 60 s resend cooldown is exercised separately
  const r = await json(await send('/api/client/account', 'POST', { action: 'request', email, intent, ...(name ? { name } : {}), requestKey: randomUUID(), locale: 'ar' }), 200);
  assert.equal(r.messageKey, 'CHECK_REGISTERED_CONTACT_IF_MATCHED');
  const v = await send('/api/client/account', 'POST', { action: 'verify', ticket: r.ticket, code: lastCode(email) });
  return { body: await json(v, 200), cookie: cookieOf(v, 'alh_application_account'), session: cookieOf(v, 'alh_client_session'), ticket: r.ticket };
}
const A = {};
test('entries: START_NEW needs a name, creates one profile after proof, never redirects to an old file; concurrent verify does not duplicate', async () => {
  await json(await send('/api/client/account', 'POST', { action: 'request', email: 'new@example.test', intent: 'START_NEW', requestKey: randomUUID(), locale: 'ar' }), 400);
  const r = await json(await send('/api/client/account', 'POST', { action: 'request', email: 'New@Example.test', intent: 'START_NEW', name: 'QA  New  Client', requestKey: randomUUID(), locale: 'ar' }), 200);
  assert.equal(await count('SELECT count(*) n FROM client_account_profiles'), 0, 'no profile before proof');
  const code = lastCode('new@example.test'), both = await Promise.all([1, 2].map(() => send('/api/client/account', 'POST', { action: 'verify', ticket: r.ticket, code })));
  assert.deepEqual(both.map(x => x.status).sort(), [200, 400], 'one-use code');
  const ok = both.find(x => x.status === 200), body = await ok.json();
  assert.deepEqual(body, { authenticated: true, displayName: 'QA New Client', intent: 'START_NEW', destination: '/apply', caseReferences: [] });
  A.cookie = cookieOf(ok, 'alh_application_account');
  assert.equal((await send('/api/client/account', 'POST', { action: 'request', email: 'new@example.test', intent: 'RETURN', requestKey: randomUUID(), locale: 'ar' })).status, 429, '60 s resend cooldown');
  const again = await signIn('new@example.test', 'START_NEW', 'Another Name');
  assert.equal(again.body.displayName, 'QA New Client', 'existing profile reused, not overwritten');
  assert.equal(await count('SELECT count(*) n FROM client_account_profiles'), 1);
  const ret = await signIn('nobody@example.test', 'RETURN');
  assert.deepEqual([ret.body.displayName, ret.body.destination], [null, '/apply']);
  assert.equal((await send('/api/intake/drafts', 'POST', { requestKey: randomUUID() }, { cookie: ret.cookie })).status, 428, 'name required before a profile exists');
  assert.equal((await json(await send('/api/client/account', 'POST', { action: 'profile', name: 'Returning Person' }, { cookie: ret.cookie }), 200)).displayName, 'Returning Person');
});

test('drafts: idempotent create, two tabs conflict, lost ACK replays, reused mutation id 409, owner isolation, email forced', async () => {
  const c = { cookie: A.cookie }, key = randomUUID();
  const d1 = await json(await send('/api/intake/drafts', 'POST', { requestKey: key }, c), 201);
  assert.equal((await json(await send('/api/intake/drafts', 'POST', { requestKey: key }, c), 200)).draftId, d1.draftId);
  assert.equal(d1.payload.profile.fullName, 'QA New Client');
  const payload = { ...d1.payload, profile: { ...d1.payload.profile, email: 'attacker@example.test', phone: '+15551230001' }, pathSelection: { selectedPathId: 'immigration', focused: true, needsGuidance: false, subOptions: [{ key: 'category', value: 'pr' }] }, step: 2 };
  const m1 = randomUUID(), tab1 = await json(await send('/api/intake/drafts/' + d1.draftId, 'PUT', { expectedRevision: 1, mutationId: m1, payload }, c), 200);
  assert.equal(tab1.revision, 2);
  assert.equal((await json(await send('/api/intake/drafts/' + d1.draftId, 'PUT', { expectedRevision: 1, mutationId: m1, payload }, c), 200)).revision, 2, 'lost ACK: same mutation replays the committed revision');
  const conflict = await json(await send('/api/intake/drafts/' + d1.draftId, 'PUT', { expectedRevision: 1, mutationId: randomUUID(), payload: { ...payload, step: 3 } }, c), 409);
  assert.deepEqual([conflict.code, conflict.currentRevision], ['DRAFT_REVISION_CONFLICT', 2], 'second tab sees the conflict, no silent overwrite');
  assert.equal((await json(await send('/api/intake/drafts/' + d1.draftId, 'PUT', { expectedRevision: 2, mutationId: m1, payload: { ...payload, step: 3 } }, c), 409)).code, 'MUTATION_REUSED');
  const read = await json(await send('/api/intake/drafts/' + d1.draftId, 'GET', undefined, c), 200);
  assert.deepEqual([read.revision, read.payload.step, read.payload.profile.email], [2, 2, 'new@example.test']);
  const other = await signIn('other@example.test', 'START_NEW', 'Other Person');
  assert.equal((await send('/api/intake/drafts/' + d1.draftId, 'GET', undefined, { cookie: other.cookie })).status, 404);
  assert.equal((await send('/api/intake/drafts/' + d1.draftId, 'GET')).status, 401);
  assert.equal((await send('/api/intake/drafts/' + d1.draftId, 'PUT', { expectedRevision: 2, mutationId: randomUUID(), payload: { ...payload, pathSelection: { selectedPathId: 'unsure', focused: true, needsGuidance: false, subOptions: [] } } }, c)).status, 400, 'unsure requires needsGuidance');
  A.draft = d1.draftId; A.other = other.cookie;
});

const signForm = (manifest, png = signaturePng()) => { const f = new FormData(); f.append('manifest', JSON.stringify(manifest)); f.append('image', new Blob([png], { type: 'image/png' }), 's.png'); return f; };
test('signature: real ink required, bound to the original snapshot, survives later edits, explicit clear only', async () => {
  assert.equal((await inspectSignaturePng(signaturePng(320, 120, false))).code, 'SIGNATURE_EMPTY');
  assert.equal((await inspectSignaturePng(signaturePng(2100, 100))).code, 'SIGNATURE_DIMENSIONS');
  const c = { cookie: A.cookie }, accountKey = sha('client-account:v1:new@example.test');
  let d = await json(await send('/api/intake/drafts/' + A.draft, 'GET', undefined, c), 200);
  const hash = await signingHash(accountKey, A.draft, d.payload), man = r => ({ expectedRevision: r, mutationId: randomUUID(), signedPayloadHash: hash, legalVersion: LEGAL_VERSION });
  assert.equal((await send('/api/intake/drafts/' + A.draft + '/signature', 'PUT', signForm(man(d.revision), signaturePng(320, 120, false)), c)).status, 422, 'transparent image is not a signature');
  assert.equal((await json(await send('/api/intake/drafts/' + A.draft + '/signature', 'PUT', signForm({ ...man(d.revision), signedPayloadHash: 'a'.repeat(64) }), c), 409)).code, 'SIGNED_PAYLOAD_MISMATCH');
  assert.equal((await send('/api/intake/drafts/' + A.draft + '/signature', 'PUT', signForm(man(d.revision)), { cookie: A.other })).status, 404);
  const sig = await json(await send('/api/intake/drafts/' + A.draft + '/signature', 'PUT', signForm(man(d.revision)), c), 200);
  assert.equal(sig.state, 'SIGNED'); assert.equal(sig.signedPayloadHash, hash); assert.equal(sig.draftRevision, d.revision + 1); assert.match(sig.signedAt, /Z$/);
  assert.equal((await send('/api/intake/drafts/' + A.draft + '/signature', 'GET', undefined, c)).headers.get('content-type'), 'image/png');
  assert.equal((await send('/api/intake/drafts/' + A.draft + '/signature', 'GET', undefined, { cookie: A.other })).status, 404);
  // Edit after signing: no STALE, no new time, same original hash.
  d = await json(await send('/api/intake/drafts/' + A.draft, 'GET', undefined, c), 200);
  await json(await send('/api/intake/drafts/' + A.draft, 'PUT', { expectedRevision: d.revision, mutationId: randomUUID(), payload: { ...d.payload, profile: { ...d.payload.profile, occupation: 'Edited after signing' }, step: 4 } }, c), 200);
  d = await json(await send('/api/intake/drafts/' + A.draft, 'GET', undefined, c), 200);
  assert.deepEqual(d.signature, sig, 'signature unchanged after editing the data');
  assert.ok(!JSON.stringify(d).includes('STALE'));
  assert.equal((await json(await send('/api/intake/drafts/' + A.draft + '/signature', 'PUT', signForm(man(d.revision)), c), 409)).code, 'SIGNATURE_EXISTS');
  const key = (await one('SELECT signature_object_key k FROM client_application_drafts WHERE draft_id=?', A.draft)).k;
  const cleared = await json(await send('/api/intake/drafts/' + A.draft + '/signature', 'DELETE', { expectedRevision: d.revision, mutationId: randomUUID() }, c), 200);
  assert.equal(cleared.revision, d.revision + 1); assert.equal(await bucket.get(key), null, 'cleared image removed');
  d = await json(await send('/api/intake/drafts/' + A.draft, 'GET', undefined, c), 200); assert.equal(d.signature, null);
  A.sig = await json(await send('/api/intake/drafts/' + A.draft + '/signature', 'PUT', signForm({ ...man(d.revision), signedPayloadHash: await signingHash(accountKey, A.draft, d.payload) }), c), 200);
  A.rev = A.sig.draftRevision;
});

const submitBody = over => ({ requestId: randomUUID(), profile: { fullName: 'QA New Client', phone: '+15551230001', email: 'new@example.test', consent: true }, details: {}, consentVersion: LEGAL_VERSION, legalAuthorization: true, website: '', draftId: A.draft, expectedDraftRevision: A.rev, signatureId: A.sig.signatureId, signedPayloadHash: A.sig.signedPayloadHash, ...over });
test('submission: signature required and verified server-side, atomic binding, concurrent/replayed/forged submits create nothing partial', async () => {
  const c = { cookie: A.cookie }, before = await count('SELECT count(*) n FROM candidates');
  const unsigned = submitBody(); for (const k of ['draftId', 'expectedDraftRevision', 'signatureId', 'signedPayloadHash']) delete unsigned[k];
  assert.equal((await send('/api/intake', 'POST', unsigned, c)).status, 422, 'no signature, no submission');
  assert.equal((await send('/api/intake', 'POST', submitBody({ signatureId: randomUUID() }), c)).status, 422, 'forged signature id');
  assert.equal((await send('/api/intake', 'POST', submitBody({ expectedDraftRevision: A.rev - 1 }), c)).status, 409, 'stale draft revision');
  assert.equal((await send('/api/intake', 'POST', submitBody({ profile: { fullName: 'Other Person', phone: '+15551230099', email: 'other@example.test', consent: true } }), { cookie: A.other })).status, 404, "another account's draft");
  assert.equal(await count('SELECT count(*) n FROM candidates'), before);
  const bodies = [submitBody(), submitBody()], raced = await Promise.all(bodies.map(b => send('/api/intake', 'POST', b, c)));
  const statuses = raced.map(r => r.status).sort();
  assert.equal(statuses[0], 201); assert.ok(statuses[1] === 409, 'the second submit of the same draft is rejected: ' + statuses);
  assert.equal(await count('SELECT count(*) n FROM candidates'), before + 1, 'exactly one case');
  assert.equal(await count('SELECT count(*) n FROM application_authorizations'), 1, 'no partial authorization');
  const winner = bodies[raced.findIndex(r => r.status === 201)], receipt = await json(await send('/api/intake', 'POST', winner, c), 200);
  assert.equal(await count('SELECT count(*) n FROM candidates'), before + 1, 'replay creates nothing');
  const auth = await one('SELECT candidate_id,signature_id,signature_sha256,signed_payload_hash,signature_signed_at,signer_account_key FROM application_authorizations');
  assert.deepEqual([auth.signature_id, auth.signature_sha256, auth.signed_payload_hash, auth.signature_signed_at], [A.sig.signatureId, A.sig.imageHash, A.sig.signedPayloadHash, A.sig.signedAt]);
  assert.equal(auth.signer_account_key, sha('client-account:v1:new@example.test'));
  const draft = await one('SELECT state,submitted_candidate_id c FROM client_application_drafts WHERE draft_id=?', A.draft);
  assert.deepEqual([draft.state, draft.c], ['SUBMITTED', auth.candidate_id]);
  await assert.rejects(db.prepare("UPDATE application_authorizations SET signature_signed_at='2020-01-01T00:00:00Z'").run(), /IMMUTABLE_SIGNATURE_BINDING/);
  await assert.rejects(db.prepare("UPDATE client_application_drafts SET payload_json='{}' WHERE draft_id=?").bind(A.draft).run(), /INVALID_DRAFT_UPDATE/);
  // The case is later edited by the client: signature and its original snapshot stay; the PDF embeds the signature.
  const session = { cookie: cookieOf(raced.find(r => r.status === 201), 'alh_client_session') };
  const pdf = await send('/api/client/authorization/pdf', 'GET', undefined, session);
  assert.equal(pdf.status, 200); assert.equal(pdf.headers.get('content-type'), 'application/pdf'); assert.ok((await pdf.arrayBuffer()).byteLength > 1000);
  assert.ok(receipt.reference.startsWith('ALH-CA-'));
  A.reference = receipt.reference; A.caseId = auth.candidate_id; A.session = session.cookie;
});

test('legacy: a record without a signature stays unsigned (no back-fill) and still renders its PDF', async () => {
  const now = new Date().toISOString(), id = randomUUID(), snapshot = JSON.stringify({ reference: 'ALH-CA-LEGACY1', acceptedAt: now, version: 'intake-2026-11-v3', authorizationText: 'A', termsText: [], profile: { fullName: 'Legacy QA', phone: '+15550000000', email: 'legacy@example.test', consent: true, jobs: [] }, details: { jobs: [], companions: [] } });
  await db.prepare("INSERT INTO candidates(id,owner_id,reference,profile,assessment,source,created_at,updated_at) VALUES(?,'office:alhijrah-canada','ALH-CA-LEGACY1',?,'{}','client',?,?)").bind(id, JSON.stringify({ fullName: 'Legacy QA', phone: '+15550000000', email: 'legacy@example.test' }), now, now).run();
  await db.prepare("INSERT INTO application_authorizations(candidate_id,version,accepted_at,authorization_text,terms_text,snapshot,snapshot_hash) VALUES(?,?,?,?,?,?,?)").bind(id, 'intake-2026-11-v3', now, 'A', '[]', snapshot, sha(snapshot)).run();
  assert.equal((await one('SELECT signature_id s FROM application_authorizations WHERE candidate_id=?', id)).s, null);
  await assert.rejects(db.prepare("UPDATE application_authorizations SET signature_id='x' WHERE candidate_id=?").bind(id).run(), /IMMUTABLE_SIGNATURE_BINDING/, 'no retroactive signature');
  const token = 'b'.repeat(64);
  await db.prepare("INSERT INTO client_cases(candidate_id,request_id,payload_hash,access_hash,access_encrypted,details,consent_version,submitted_at) VALUES(?,?,?,?,?,'{}','intake-2026-11-v3',?)").bind(id, randomUUID(), sha('legacy-payload'), sha('legacy-access'), 'x', now).run();
  await db.prepare("INSERT INTO client_sessions(token_hash,candidate_id,method,created_at,expires_at,scope) VALUES(?,?,'otp_email',?,?,'full_case')").bind(sha(token), id, Date.now(), Date.now() + 600000).run();
  const pdf = await send('/api/client/authorization/pdf', 'GET', undefined, { cookie: 'alh_client_session=' + token });
  assert.equal(pdf.status, 200); assert.equal(pdf.headers.get('content-type'), 'application/pdf');
  assert.equal((await one('SELECT signature_id s FROM application_authorizations WHERE candidate_id=?', id)).s, null, 'rendering did not add a signature');
});

test('passwords: account password needs a fresh email OTP; email+password opens the account; a legacy case password opens only its case', async () => {
  const c = { cookie: A.cookie };
  await json(await send('/api/client/password', 'POST', { scope: 'account', password: 'a strong client passphrase 2026' }, c), 200);
  const login = await send('/api/client/password/login', 'POST', { email: 'new@example.test', password: 'a strong client passphrase 2026' });
  const body = await json(login, 200); assert.deepEqual([body.intent, body.caseReferences], ['RETURN', [A.reference]]);
  const pwCookie = cookieOf(login, 'alh_application_account');
  assert.equal((await send('/api/client/password', 'POST', { scope: 'account', password: 'another strong passphrase 2026' }, { cookie: pwCookie })).status, 403, 'a password session cannot set the password');
  const wrong = await json(await send('/api/client/password/login', 'POST', { email: 'new@example.test', password: 'wrong passphrase value 1' }), 401);
  const unknown = await json(await send('/api/client/password/login', 'POST', { email: 'ghost@example.test', password: 'wrong passphrase value 1' }), 401);
  assert.equal(wrong.error, unknown.error, 'no account enumeration');
  // Two cases share an email; a case password for one never opens the other.
  const now = new Date().toISOString(), second = randomUUID();
  await db.prepare("INSERT INTO candidates(id,owner_id,reference,profile,assessment,source,created_at,updated_at) VALUES(?,'office:alhijrah-canada','ALH-CA-SECOND1',?,'{}','client',?,?)").bind(second, JSON.stringify({ fullName: 'QA New Client', phone: '+15551230001', email: 'new@example.test' }), now, now).run();
  await db.prepare("INSERT INTO client_cases(candidate_id,request_id,payload_hash,access_hash,access_encrypted,details,consent_version,submitted_at) VALUES(?,?,?,?,?,'{}','x',?)").bind(second, randomUUID(), sha(second), sha('a' + second), 'x', now).run();
  await json(await send('/api/client/password', 'POST', { password: 'case one passphrase value 2026' }, { cookie: A.session }), 200);
  const caseLogin = await send('/api/client/password/login', 'POST', { reference: A.reference, password: 'case one passphrase value 2026' });
  await json(caseLogin, 200);
  assert.equal(cookieOf(caseLogin, 'alh_application_account'), '', 'case password never issues an account session');
  A.caseSession = cookieOf(caseLogin, 'alh_client_session');
  assert.equal((await send('/api/client', 'GET', undefined, { cookie: A.session })).status, 401, 'setting the case password ended the earlier case sessions');
  const own = await json(await send('/api/client', 'GET', undefined, { cookie: A.caseSession }), 200);
  assert.ok(JSON.stringify(own).includes(A.reference), 'the case password opens its own case');
  assert.ok(!JSON.stringify(own).includes('ALH-CA-SECOND1'), 'the other file sharing the email is not reachable');
  assert.equal((await send('/api/client/password/login', 'POST', { reference: 'ALH-CA-SECOND1', password: 'case one passphrase value 2026' })).status, 401);
});

test('session indicator: account or full case session only; never the limited lookup token', async () => {
  assert.deepEqual(await json(await send('/api/client/account?view=session'), 200), { authenticated: false, scope: 'none', expiresAt: null, secureTransport: true });
  const s = await json(await send('/api/client/account?view=session', 'GET', undefined, { cookie: A.cookie }), 200);
  assert.equal(s.scope, 'account'); assert.ok(s.expiresAt > Date.now());
  assert.equal((await json(await send('/api/client/account?view=session', 'GET', undefined, { cookie: A.caseSession }), 200)).scope, 'case');
});

test('status lookup: identical 202 for matched/unmatched/failed delivery, purpose-bound codes, 5-minute case_status token with a minimal answer', async () => {
  assert.equal((await send('/api/client/status-lookup', 'POST', { identifier: '555 123 0001', requestKey: randomUUID(), locale: 'ar' })).status, 400, 'no country code guessed for a local number');
  assert.equal((await send('/api/client/status-lookup', 'POST', { identifier: 'new@example.test', requestKey: randomUUID(), locale: 'ar', destination: 'x@evil.test' })).status, 400, 'no destination accepted');
  const req = async (identifier) => send('/api/client/status-lookup', 'POST', { identifier, requestKey: randomUUID(), locale: 'ar' });
  const matched = await req(A.reference), unmatched = await req('ALH-CA-NOPE-0000');
  mailMode = 'fail'; const failed = await req('legacy@example.test'); mailMode = 'ok';
  const shapes = await Promise.all([matched, unmatched, failed].map(async r => { assert.equal(r.status, 202); const b = await r.json(); return [Object.keys(b).sort().join(','), b.messageKey, b.resendAfter]; }));
  assert.deepEqual(shapes[0], shapes[1]); assert.deepEqual(shapes[0], shapes[2]);
  await db.prepare('DELETE FROM rate_limits').run();
  const sent = mails.length, m = await (await req('new@example.test')).json();
  // Delivery runs after the 202 (durable row + dispatcher); wait for the captured message.
  for (let i = 0; i < 100 && !mails.slice(sent).some(x => x.to.includes('new@example.test')); i++) await new Promise(r => setTimeout(r, 20));
  assert.ok(mails.slice(sent).some(x => x.to.includes('new@example.test')), 'code delivered to the registered email');
  const code = lastCode('new@example.test');
  assert.equal((await send('/api/client/otp/verify', 'POST', { requestId: m.requestId, code })).status, 400, 'a lookup code cannot open a case session');
  assert.equal((await send('/api/client/status-lookup/verify', 'POST', { requestId: m.requestId, code: code === '000000' ? '111111' : '000000' })).status, 400);
  const proof = await json(await send('/api/client/status-lookup/verify', 'POST', { requestId: m.requestId, code }), 200);
  assert.deepEqual(proof.caseOptions.map(o => o.caseNumber).sort(), ['ALH-CA-SECOND1', A.reference].sort(), 'after proof only, case numbers without names');
  assert.ok(!JSON.stringify(proof).match(/QA New Client|new@example/));
  assert.equal((await send('/api/client/status-lookup/verify', 'POST', { requestId: m.requestId, code })).status, 400, 'one use');
  const sel = await send('/api/client/status-lookup/verify', 'POST', { proofTicket: proof.proofTicket, caseNumber: A.reference });
  await json(sel, 200);
  const raw = sel.headers.get('set-cookie'); assert.match(raw, /Path=\/api\/client\/status-lookup/); assert.match(raw, /HttpOnly/); assert.match(raw, /Max-Age=300/); assert.doesNotMatch(raw, /alh_application_account|alh_client_session/);
  const token = cookieOf(sel, 'alh_status_lookup'), result = await json(await send('/api/client/status-lookup', 'GET', undefined, { cookie: token }), 200);
  assert.deepEqual(Object.keys(result).sort(), ['caseNumber', 'nextAction', 'statusCode', 'updatedAt']);
  assert.equal(result.caseNumber, A.reference); assert.ok(!JSON.stringify(result).match(/QA New Client|new@example|5551230001/));
  const asCase = 'alh_client_session=' + token.split('=')[1];
  assert.equal((await send('/api/client', 'GET', undefined, { cookie: asCase })).status, 401, 'limited token cannot read the file');
  assert.equal((await send('/api/client/vault', 'GET', undefined, { cookie: asCase })).status, 401);
  assert.equal((await send('/api/client/authorization/pdf', 'GET', undefined, { cookie: asCase })).status, 401);
  assert.equal((await json(await send('/api/client/account?view=session', 'GET', undefined, { cookie: asCase }), 200)).authenticated, false);
  await db.prepare("UPDATE client_sessions SET expires_at=? WHERE scope='case_status'").bind(Date.now() - 1).run();
  assert.equal((await send('/api/client/status-lookup', 'GET', undefined, { cookie: token })).status, 401, 'expired after 5 minutes');
  // An account_login challenge cannot be redeemed on the lookup path.
  await db.prepare('DELETE FROM rate_limits').run();
  const acc = await json(await send('/api/client/account', 'POST', { action: 'request', email: 'new@example.test', intent: 'RETURN', requestKey: randomUUID(), locale: 'ar' }), 200);
  assert.equal((await send('/api/client/status-lookup/verify', 'POST', { requestId: acc.requestId, code: lastCode('new@example.test') })).status, 400);
});
// v2.2 Gate 6 — AC-29 integrated journey: the client registered, verified by OTP, drafted, chose a path, signed and
// submitted in the tests above (A); the same file now goes through chat → human handoff → Rapid Assessment from the
// shared engine → invoice → partial and full payment with a private receipt → AR/EN PDF → payment notice delivered
// through the outbox → public status lookup — on the same Worker, database and storage.
test('integrated journey (AC-29): signed submission → chat → handoff → rapid assessment → invoice → payments → PDF → notice → status lookup', async () => {
  const s = await signIn('new@example.test', 'RETURN');
  const opened = await send('/api/client/account', 'POST', { action: 'open', reference: A.reference }, { cookie: s.cookie });
  await json(opened, 200); const client = { cookie: cookieOf(opened, 'alh_client_session') };
  const file = await json(await send('/api/client', 'GET', undefined, client), 200); assert.equal(file.reference, A.reference); assert.ok(file.authorization, 'signed authorization on file');
  const cid = randomUUID();
  await json(await send('/api/client/chat', 'POST', { action: 'send', message: { clientMessageId: cid, repliedToMessageId: null, kind: 'TEXT', text: 'Journey question' } }, client), 201);
  let page = await json(await send('/api/client/chat', 'GET', undefined, client), 200); assert.equal(page.conversation.state, 'HANDOFF_PENDING');
  const staffView = await json(await send(`/api/candidates/${A.caseId}/chat`, 'GET', undefined, admin), 200);
  await json(await send(`/api/candidates/${A.caseId}/chat`, 'POST', { action: 'transition', transition: { action: 'claim', expectedRevision: staffView.conversation.conversationRevision, requestKey: randomUUID() } }, admin), 200);
  await json(await send(`/api/candidates/${A.caseId}/chat`, 'POST', { action: 'send', message: { clientMessageId: randomUUID(), repliedToMessageId: null, kind: 'TEXT', text: 'Journey answer' } }, admin), 201);
  page = await json(await send('/api/client/chat', 'GET', undefined, client), 200);
  assert.deepEqual(page.items.map(i => i.text), ['Journey question', 'Journey answer']); assert.equal(page.conversation.assignedStaffId, 'office');
  const b64 = t => Buffer.from(t, 'utf8').toString('base64');
  for (const [sid, src] of Object.entries(SOURCES)) await json(await send('/api/office/rules/import', 'POST', { action: 'source', sourceId: sid, officialUrl: src.officialUrl, authority: 'TEST_ONLY', contentBase64: b64(src.text) }, admin), 201);
  const up = async b => (await json(await send('/api/office/rules/import', 'POST', { action: 'bundle', payload: b.payload, payloadHash: b.hash }, admin), 201)).bundleId;
  const W = { crs: await up(await crsBundle()), fsw: await up(await programBundle()), noc: await up(await nocBundle()) };
  const iv = (programId, family, from, bundleId) => ({ programId, family, phase: 'PROFILE', dateBasis: 'PROFILE', effectiveFrom: from, effectiveToExclusive: null, bundleId });
  const intervals = [iv('EE_CRS', 'CRS', '2026-11-03', W.crs), iv('EE_FSWP', 'ELIGIBILITY', '2026-01-01', W.fsw), iv('NOC_2021', 'NOC_CATALOG', '2026-01-01', W.noc)];
  const pv = await json(await send('/api/office/rules/releases', 'POST', { action: 'preview', intervals }, admin), 200);
  await json(await send('/api/office/rules/releases', 'POST', { action: 'seal', intervals, manifestHash: pv.manifestHash, activate: { expectedGeneration: 0, reasonCode: 'journey' } }, admin), 201);
  const rapid = await json(await send('/api/client/chat', 'POST', { action: 'rapid_assessment', requestKey: randomUUID(), confirmed: true }, client), 201);
  assert.equal(rapid.purpose, 'RAPID_SCREENING');
  assert.equal((await one('SELECT latest_rapid_assessment_id r FROM candidates WHERE id=?', A.caseId)).r, rapid.assessmentId);
  await json(await send('/api/office', 'POST', { action: 'billing_currency', currency: 'CAD' }, admin), 200);
  const inv = await json(await send(`/api/candidates/${A.caseId}/invoices`, 'POST', { currency: 'CAD', items: [{ kind: 'CUSTOM', serviceName: 'File preparation', unitPriceCents: 30000, isFree: false, referencePriceCents: null }], discountCents: 2500, deadline: '2026-12-31', note: null, requestKey: randomUUID() }, admin), 201);
  const p1 = await json(await send(`/api/invoices/${inv.invoiceId}/payments`, 'POST', { expectedVersion: inv.version, amountText: '75.00', method: 'CASH', paidAt: new Date().toISOString(), notes: null, idempotencyKey: 'pay-' + randomUUID() }, admin), 201);
  assert.equal(p1.status, 'PARTIAL');
  const form = new FormData(); form.append('payload', JSON.stringify({ expectedVersion: p1.version, amountCents: p1.remainingCents, method: 'ZELLE', paidAt: new Date().toISOString(), notes: null, notify: true, idempotencyKey: 'pay-' + randomUUID() }));
  form.append('receipt', new Blob([signaturePng()], { type: 'image/png' }), 'receipt.png');
  const p2 = await json(await send(`/api/invoices/${inv.invoiceId}/payments`, 'POST', form, admin), 201);
  assert.deepEqual([p2.status, p2.remainingCents, p2.paidCents], ['PAID', 0, 27500]);
  for (const locale of ['ar', 'en']) { const r = await send(`/api/invoices/${inv.invoiceId}/pdf?locale=${locale}`, 'GET', undefined, admin); assert.equal(r.status, 200); assert.equal(new TextDecoder().decode(new Uint8Array(await r.arrayBuffer()).slice(0, 5)), '%PDF-'); }
  const sent = mails.length; await (await mf.getWorker()).scheduled({ cron: '*/5 * * * *', scheduledTime: new Date() });
  const notice = mails.slice(sent).find(m => m.to.includes('new@example.test') && /0\.00 CAD/.test(m.text));
  assert.ok(notice, 'payment notice delivered with the remaining balance and currency');
  assert.equal((await json(await send('/api/client', 'GET', undefined, client), 200)).billing[0].status, 'PAID', 'client sees the same invoice state');
  await db.prepare('DELETE FROM rate_limits').run();
  const before = mails.length, m = await json(await send('/api/client/status-lookup', 'POST', { identifier: A.reference, requestKey: randomUUID(), locale: 'en' }), 202);
  for (let i = 0; i < 100 && mails.length === before; i++) await new Promise(r => setTimeout(r, 20));
  const proof = await json(await send('/api/client/status-lookup/verify', 'POST', { requestId: m.requestId, code: lastCode('new@example.test') }), 200);
  const sel = await send('/api/client/status-lookup/verify', 'POST', { proofTicket: proof.proofTicket, caseNumber: A.reference }); await json(sel, 200);
  const status = await json(await send('/api/client/status-lookup', 'GET', undefined, { cookie: cookieOf(sel, 'alh_status_lookup') }), 200);
  assert.equal(status.caseNumber, A.reference);
});
