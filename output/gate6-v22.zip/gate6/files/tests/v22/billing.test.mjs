// v2.2 Gate 5 — billing on the built Worker (Miniflare D1/R2/KV, no mocks of the database). The seven required flows,
// plus discount bypass through EDIT, overpayment, case/currency mix, a failing batch leaving no partial row, referral
// lock, SYSTEM overdue refresh through the scheduled handler, and per-currency office totals.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { seedOfficeManager } from './office-fixture.mjs';
import { torontoDate } from '../../lib/v22-core.ts';

const require = createRequire(import.meta.url);
const { Miniflare } = createRequire(require.resolve('wrangler/package.json'))('miniflare');
const base = 'http://canada-desk.test';
const id = (uid, email) => ({ 'oai-authenticated-user-id': uid, 'oai-authenticated-user-email': email });
const admin = id('admin-1', 'admin@example.test'), staffA = id('staff-a', 'staff-a@example.test'), staffB = id('staff-b', 'staff-b@example.test');
let mf, db, bucket, send, raw;
const json = async (r, status = 200) => { const t = await r.text(); assert.equal(r.status, status, t); return t ? JSON.parse(t) : null; };
const key = () => crypto.randomUUID();
const profile = (n, phone) => ({ fullName: 'QA Billing ' + n, phone, email: 'billing-' + n.toLowerCase() + '@example.test', consent: true, jobs: [{ title: 'QA role', employer: 'QA employer', country: 'Yemen', start: '2024-01', end: '2024-12', weekly_hours: 40 }], occupation: 'Synthetic test', noc: '72401', teer: 2, experience3: 12, experience10: 24, englishMin: 5, englishDate: '2026-10-01' });
const today = torontoDate(Date.now());
const plusDays = n => new Date(Date.parse(today + 'T12:00:00Z') + n * 86400000).toISOString().slice(0, 10);
const perms = () => send('/api/office/permissions', 'GET', undefined, admin).then(r => json(r));
async function toggle(user, k, value) {
  const st = await perms(), s = st.staff.find(x => x.userId === user);
  return json(await send('/api/office/permissions', 'POST', { action: 'toggle', target: 'USER', targetUserId: user, key: k, value, expectedVersion: s.version, expectedEpoch: st.epoch, requestKey: key() }, admin));
}
const pngBytes = () => new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 13, 73, 72, 68, 82]);
const count = async (sql, ...b) => (await db.prepare(sql).bind(...b).first()).n;

test.before(async () => {
  const files = await readdir('dist/server', { recursive: true });
  mf = new Miniflare({
    modules: ['index.js', ...files.filter(f => f !== 'index.js' && f.endsWith('.js'))].map(f => ({ type: 'ESModule', path: path.resolve('dist/server', f) })),
    modulesRoot: path.resolve('dist/server'), compatibilityDate: '2026-05-15', compatibilityFlags: ['nodejs_compat'],
    d1Databases: { DB: 'billing-db' }, r2Buckets: ['BUCKET'], kvNamespaces: { PERMISSIONS_KV: 'billing-kv' },
    bindings: { TRUST_SITES_IDENTITY_HEADERS: '1', OFFICE_ADMIN_EMAIL: 'admin@example.test', APP_SECRET: 'b'.repeat(64), PERMISSIONS_KV_NAMESPACE: 'test' },
    outboundService: async () => new Response('blocked', { status: 599 }),
  });
  send = (p, method = 'GET', body, headers = {}) => mf.dispatchFetch(base + p, { method, headers: { ...(body ? { 'content-type': 'application/json' } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined });
  raw = (url, init) => mf.dispatchFetch(url, init);
  db = await mf.getD1Database('DB'); bucket = await mf.getR2Bucket('BUCKET');
  for (const f of (await readdir('drizzle')).filter(f => f.endsWith('.sql')).sort())
    for (const s of (await readFile('drizzle/' + f, 'utf8')).split('--> statement-breakpoint').map(s => s.trim()).filter(Boolean)) await db.prepare(s).run();
  await seedOfficeManager(db, 'admin-1');
  await json(await send('/api/office', 'GET', undefined, admin));
  for (const s of [['staff-a@example.test', 'QA Staff A'], ['staff-b@example.test', 'QA Staff B']])
    await json(await send('/api/office', 'POST', { action: 'member', email: s[0], name: s[1], active: true }, admin));
});
test.after(async () => { await mf?.dispose(); });

const st = {};
test('1 · create: explicit office currency, catalog + custom + free items and discount, server totals and audit', async () => {
  st.c1 = await json(await send('/api/candidates', 'POST', profile('One', '+15554440001'), admin), 201);
  st.c2 = await json(await send('/api/candidates', 'POST', profile('Two', '+15554440002'), admin), 201);
  const item = [{ kind: 'CUSTOM', serviceName: 'File review', unitPriceCents: 10000, isFree: false, referencePriceCents: null }];
  assert.equal((await send(`/api/candidates/${st.c1.id}/invoices`, 'POST', { currency: 'CAD', items: item, discountCents: 0, deadline: null, note: null, requestKey: key() }, staffA)).status, 409, 'no office currency yet: refused, nothing assumed');
  assert.equal((await send('/api/office', 'POST', { action: 'billing_currency', currency: 'CAD' }, staffA)).status, 403, 'currency is MANAGER-only');
  await json(await send('/api/office', 'POST', { action: 'billing_currency', currency: 'CAD' }, admin));
  assert.equal((await send('/api/office', 'POST', { action: 'service', serviceId: 'usd-svc', nameAr: 'خدمة', nameEn: 'Svc', priceCents: 100, currency: 'USD', active: true, expectedVersion: null }, admin)).status, 422, 'catalog currency must match office currency');
  await json(await send('/api/office', 'POST', { action: 'service', serviceId: 'profile-prep', nameAr: 'تجهيز الملف', nameEn: 'Profile preparation', priceCents: 25000, currency: 'CAD', active: true, expectedVersion: null }, admin));
  assert.equal((await send(`/api/candidates/${st.c1.id}/invoices`, 'POST', { currency: 'USD', items: item, discountCents: 0, deadline: null, note: null, requestKey: key() }, staffA)).status, 422, 'invoice currency must equal office currency');
  const body = { currency: 'CAD', discountCents: 5000, deadline: plusDays(30), note: 'QA note', requestKey: key(), items: [
    { kind: 'CATALOG', serviceId: 'profile-prep', isFree: false },
    { kind: 'CUSTOM', serviceName: 'Translation support', unitPriceCents: 7550, isFree: false, referencePriceCents: null },
    { kind: 'CATALOG', serviceId: 'profile-prep', isFree: true },
  ] };
  const inv = await json(await send(`/api/candidates/${st.c1.id}/invoices`, 'POST', body, staffA), 201);
  assert.deepEqual([inv.subtotalCents, inv.discountCents, inv.totalCents, inv.paidCents, inv.remainingCents, inv.version, inv.status, inv.currency], [32550, 5000, 27550, 0, 27550, 1, 'DRAFT', 'CAD']);
  const again = await json(await send(`/api/candidates/${st.c1.id}/invoices`, 'POST', body, staffA), 201);
  assert.equal(again.invoiceId, inv.invoiceId, 'same request key replays the same invoice');
  assert.equal(await count('SELECT count(*) n FROM invoices WHERE case_id=?', st.c1.id), 1);
  const detail = await json(await send('/api/invoices/' + inv.invoiceId, 'GET', undefined, staffB));
  assert.equal(detail.items.length, 3); const free = detail.items.find(i => i.isFree);
  assert.deepEqual([free.unitPriceCents, free.referencePriceCents], [0, 25000], 'free item is 0 with its catalog reference price');
  assert.equal(await count("SELECT count(*) n FROM financial_audit_logs WHERE invoice_id=? AND action_type='CREATE' AND expected_version=0", inv.invoiceId), 1);
  assert.equal((await send(`/api/candidates/${st.c1.id}/invoices`, 'POST', { ...body, requestKey: key(), items: [{ kind: 'CUSTOM', serviceName: 'x', unitPriceCents: 100, isFree: true, referencePriceCents: null }] }, staffA)).status, 422, 'free item with a price is refused');
  assert.equal((await send(`/api/candidates/${st.c1.id}/invoices`, 'POST', { ...body, requestKey: key(), discountCents: 999999 }, staffA)).status, 422, 'discount above subtotal');
  st.inv = inv;
});
test('2 · CASH partial payment → PARTIAL, immutable ledger row, audited version bump', async () => {
  const r = await json(await send(`/api/invoices/${st.inv.invoiceId}/payments`, 'POST', { expectedVersion: 1, amountText: '100.50', method: 'CASH', paidAt: new Date().toISOString(), notes: null, idempotencyKey: 'pay-' + key() }, staffA), 201);
  assert.deepEqual([r.paidCents, r.remainingCents, r.status, r.version], [10050, 17500, 'PARTIAL', 2]);
  await assert.rejects(db.prepare('UPDATE payments_ledger SET amount_cents=1').run(), /IMMUTABLE_PAYMENT/);
  await assert.rejects(db.prepare('DELETE FROM financial_audit_logs').run(), /IMMUTABLE_FINANCIAL_AUDIT/);
  st.inv = r;
});
test('3 · ZELLE full payment with a private R2 receipt → PAID; receipt only for view_financials', async () => {
  const form = new FormData();
  form.set('payload', JSON.stringify({ expectedVersion: st.inv.version, amountCents: 17500, method: 'ZELLE', paidAt: new Date().toISOString(), notes: 'Zelle ref QA', idempotencyKey: 'pay-' + key() }));
  form.set('receipt', new File([pngBytes()], 'receipt.png', { type: 'image/png' }));
  const req = new Request(base + `/api/invoices/${st.inv.invoiceId}/payments`, { method: 'POST', body: form, headers: staffA });
  const r = await json(await raw(req.url, { method: 'POST', headers: Object.fromEntries(req.headers), body: await req.arrayBuffer() }), 201);
  assert.deepEqual([r.paidCents, r.remainingCents, r.status], [27550, 0, 'PAID']);
  const p = await db.prepare("SELECT payment_id,receipt_r2_key,receipt_sha256 FROM payments_ledger WHERE invoice_id=? AND method='ZELLE'").bind(st.inv.invoiceId).first();
  assert.match(p.receipt_r2_key, /^finance\/receipts\//); assert.equal(p.receipt_sha256.length, 64);
  assert.ok(await bucket.get(p.receipt_r2_key), 'receipt stored in R2');
  const got = await raw(base + `/api/invoices/${st.inv.invoiceId}/payments?receipt=${p.payment_id}`, { headers: staffB });
  assert.equal(got.status, 200); assert.equal(got.headers.get('content-type'), 'image/png'); assert.equal(got.headers.get('cache-control'), 'private, no-store');
  st.inv = r; st.paymentId = p.payment_id;
});
test('4 · duplicates: same key replays, other payload 409; overpayment, case/currency mix and a failing batch leave nothing', async () => {
  const inv = await json(await send(`/api/candidates/${st.c2.id}/invoices`, 'POST', { currency: 'CAD', items: [{ kind: 'CUSTOM', serviceName: 'Consultation', unitPriceCents: 20000, isFree: false, referencePriceCents: null }], discountCents: 0, deadline: null, note: null, requestKey: key() }, staffA), 201);
  const pk = 'pay-' + key(), at = new Date().toISOString(), pay = { expectedVersion: 1, amountCents: 5000, method: 'CHEQUE', paidAt: at, notes: null, idempotencyKey: pk };
  const a = await json(await send(`/api/invoices/${inv.invoiceId}/payments`, 'POST', pay, staffA), 201);
  const b = await json(await send(`/api/invoices/${inv.invoiceId}/payments`, 'POST', pay, staffA), 201);
  assert.equal(a.version, b.version, 'retry replays'); assert.equal(await count('SELECT count(*) n FROM payments_ledger WHERE invoice_id=?', inv.invoiceId), 1);
  assert.equal((await send(`/api/invoices/${inv.invoiceId}/payments`, 'POST', { ...pay, amountCents: 6000 }, staffA)).status, 409, 'same key, different amount');
  assert.equal((await send(`/api/invoices/${inv.invoiceId}/payments`, 'POST', { ...pay, expectedVersion: 2, amountCents: 15001, idempotencyKey: 'pay-' + key() }, staffA)).status, 409, 'overpayment');
  assert.equal((await send(`/api/invoices/${inv.invoiceId}/payments`, 'POST', { ...pay, expectedVersion: 1, idempotencyKey: 'pay-' + key() }, staffA)).status, 409, 'stale version');
  assert.equal((await send(`/api/invoices/${inv.invoiceId}/payments`, 'POST', { ...pay, expectedVersion: 2, amountText: '1.234', amountCents: undefined, idempotencyKey: 'pay-' + key() }, staffA)).status, 422, 'more than two decimals');
  // A batch whose payment row violates the guard (another case / currency) rolls back its audit row too.
  const cur = await db.prepare('SELECT * FROM invoices WHERE invoice_id=?').bind(inv.invoiceId).first(), epoch = (await db.prepare('SELECT version FROM permission_runtime').first()).version;
  const audits0 = await count('SELECT count(*) n FROM financial_audit_logs'), logId = key(), ik = 'raw-' + key();
  const snap = { subtotal_cents: cur.subtotal_cents, discount_cents: cur.discount_cents, total_cents: cur.total_cents, paid_cents: cur.paid_cents, remaining_cents: cur.remaining_cents, version: cur.version, status: cur.status };
  const auditStmt = db.prepare("INSERT INTO financial_audit_logs(log_id,invoice_id,modified_by,action_type,old_value,new_value,expected_version,permissions_epoch,authz_expires_at_ms,request_hash,idempotency_key,timestamp) VALUES(?,?,?,'PAYMENT',?,?,?,?,?,?,?,?)")
    .bind(logId, inv.invoiceId, 'admin-1', JSON.stringify(snap), JSON.stringify({ ...snap, version: cur.version + 1 }), cur.version, epoch, Date.now() + 60000, 'a'.repeat(64), ik, at);
  for (const [caseId, currency] of [[st.c1.id, 'CAD'], [st.c2.id, 'USD']]) {
    await assert.rejects(db.batch([auditStmt, db.prepare("INSERT INTO payments_ledger(payment_id,invoice_id,case_id,currency,amount_cents,method,paid_at,idempotency_key,operation_id,created_by,created_at) VALUES(?,?,?,?,100,'CASH',?,?,?,?,?)").bind(key(), inv.invoiceId, caseId, currency, at, ik, logId, 'admin-1', at)]));
  }
  assert.equal(await count('SELECT count(*) n FROM financial_audit_logs'), audits0, 'no partial audit row after the failed batch');
  await assert.rejects(db.prepare('UPDATE invoices SET status=? WHERE invoice_id=?').bind('PAID', inv.invoiceId).run(), /INVALID_INVOICE_UPDATE|AUDITED_OPERATION_REQUIRED/, 'direct update without an audited operation');
  // EDIT that would put the total below what was paid is refused.
  assert.equal((await send('/api/invoices/' + inv.invoiceId, 'PATCH', { action: 'edit', expectedVersion: 2, items: [{ kind: 'CUSTOM', serviceName: 'Consultation', unitPriceCents: 4000, isFree: false, referencePriceCents: null }], discountCents: 0, deadline: null, note: null, requestKey: key() }, staffA)).status, 409);
  st.inv2 = await json(await send('/api/invoices/' + inv.invoiceId, 'GET', undefined, staffA));
});
test('5 · referral locks the invoice (PENDING_APPROVAL) until one MANAGER approves', async () => {
  const i = st.inv2;
  const ref = await json(await send(`/api/invoices/${i.invoiceId}/approval`, 'POST', { action: 'refer', expectedVersion: i.version, requestKey: key() }, staffA));
  assert.equal(ref.status, 'PENDING_APPROVAL');
  assert.equal((await send('/api/invoices/' + i.invoiceId, 'PATCH', { action: 'discount', expectedVersion: ref.version, discountCents: 100, requestKey: key() }, staffA)).status, 423, 'edit locked');
  assert.equal((await send(`/api/invoices/${i.invoiceId}/payments`, 'POST', { expectedVersion: ref.version, amountCents: 100, method: 'CASH', paidAt: new Date().toISOString(), notes: null, idempotencyKey: 'pay-' + key() }, staffA)).status, 423, 'payment locked');
  assert.equal((await send(`/api/invoices/${i.invoiceId}/approval`, 'POST', { action: 'approve', expectedVersion: ref.version, requestKey: key() }, staffA)).status, 403, 'STAFF cannot approve');
  const ok = await json(await send(`/api/invoices/${i.invoiceId}/approval`, 'POST', { action: 'approve', expectedVersion: ref.version, requestKey: key() }, admin));
  assert.equal(ok.status, 'PARTIAL', 'approval restores the computed status'); assert.equal(ok.version, ref.version + 1);
  assert.equal((await send(`/api/invoices/${i.invoiceId}/approval`, 'POST', { action: 'approve', expectedVersion: ok.version, requestKey: key() }, admin)).status, 409, 'nothing pending');
  st.inv2 = ok;
});
test('6 · payment notice through the outbox (EMAIL only, limited payload) and AR/EN PDF from server data', async () => {
  const i = st.inv2;
  assert.equal((await send(`/api/invoices/${i.invoiceId}/notice`, 'POST', { expectedVersion: i.version, channel: 'SMS', requestKey: key() }, staffA)).status, 409, 'SMS not configured');
  assert.equal((await send(`/api/invoices/${i.invoiceId}/notice`, 'POST', { expectedVersion: i.version, channel: 'EMAIL', requestKey: key() }, staffA)).status, 409, 'email not configured');
  await json(await send('/api/office', 'POST', { action: 'mail', sender: 'office@example.test', key: 're_' + 'q'.repeat(20) }, admin));
  const n = await json(await send(`/api/invoices/${i.invoiceId}/notice`, 'POST', { expectedVersion: i.version, channel: 'EMAIL', requestKey: key() }, staffA), 202);
  const n2 = await json(await send(`/api/invoices/${i.invoiceId}/notice`, 'POST', { expectedVersion: i.version, channel: 'EMAIL', requestKey: key() }, staffA), 202);
  assert.equal(n2.eventId, n.eventId); assert.equal(n2.replayed, true, 'one notice per invoice version');
  const row = await db.prepare('SELECT kind,state,payload_encrypted FROM delivery_outbox WHERE event_id=?').bind(n.eventId).first();
  assert.equal(row.kind, 'PAYMENT_NOTICE'); assert.equal(row.state, 'PENDING');
  assert.ok(!row.payload_encrypted.includes('billing-two'), 'payload encrypted at rest');
  for (const locale of ['ar', 'en']) {
    const r = await raw(base + `/api/invoices/${i.invoiceId}/pdf?locale=${locale}`, { headers: staffB });
    assert.equal(r.status, 200); assert.equal(r.headers.get('content-type'), 'application/pdf');
    const bytes = new Uint8Array(await r.arrayBuffer()); assert.equal(new TextDecoder().decode(bytes.slice(0, 5)), '%PDF-');
    assert.match(r.headers.get('x-invoice-data-hash'), /^[a-f0-9]{64}$/);
  }
  // Payment with notify=true puts the notice in the same batch.
  const p = await json(await send(`/api/invoices/${i.invoiceId}/payments`, 'POST', { expectedVersion: i.version, amountCents: 1000, method: 'CASH_APP', paidAt: new Date().toISOString(), notes: null, notify: true, idempotencyKey: 'pay-' + key() }, staffA), 201);
  assert.equal(await count("SELECT count(*) n FROM delivery_outbox WHERE business_key=?", 'payment-notice:' + i.invoiceId + ':' + p.version + ':EMAIL'), 1);
  st.inv2 = p;
});
test('7 · 403 and hidden money without view_financials; discount bypass through EDIT is refused (route and trigger)', async () => {
  await toggle('staff:staff-b@example.test', 'edit_discount', false);
  const i = st.inv2, items = (await json(await send('/api/invoices/' + i.invoiceId, 'GET', undefined, staffB))).items.map(x => ({ kind: 'CUSTOM', serviceName: x.serviceName, unitPriceCents: x.unitPriceCents, isFree: x.isFree, referencePriceCents: x.referencePriceCents }));
  assert.equal((await send('/api/invoices/' + i.invoiceId, 'PATCH', { action: 'edit', expectedVersion: i.version, items, discountCents: 500, deadline: null, note: null, requestKey: key() }, staffB)).status, 403, 'EDIT changing the discount needs edit_discount');
  assert.equal((await send('/api/invoices/' + i.invoiceId, 'PATCH', { action: 'discount', expectedVersion: i.version, discountCents: 500, requestKey: key() }, staffB)).status, 403);
  const e = await json(await send('/api/invoices/' + i.invoiceId, 'PATCH', { action: 'edit', expectedVersion: i.version, items, discountCents: i.discountCents, deadline: null, note: 'edited', requestKey: key() }, staffB));
  assert.equal(e.version, i.version + 1, 'EDIT without a discount change is allowed');
  // Trigger level: a hand-written audited EDIT by staff-b that changes the discount aborts.
  const cur = await db.prepare('SELECT * FROM invoices WHERE invoice_id=?').bind(i.invoiceId).first(), epoch = (await db.prepare('SELECT version FROM permission_runtime').first()).version;
  const snap = { subtotal_cents: cur.subtotal_cents, discount_cents: cur.discount_cents, total_cents: cur.total_cents, paid_cents: cur.paid_cents, remaining_cents: cur.remaining_cents, version: cur.version, status: cur.status };
  await assert.rejects(db.prepare("INSERT INTO financial_audit_logs(log_id,invoice_id,modified_by,action_type,old_value,new_value,expected_version,permissions_epoch,authz_expires_at_ms,request_hash,idempotency_key,timestamp) VALUES(?,?,'staff:staff-b@example.test','EDIT',?,?,?,?,?,?,?,?)")
    .bind(key(), i.invoiceId, JSON.stringify(snap), JSON.stringify({ ...snap, discount_cents: cur.discount_cents + 100, version: cur.version + 1 }), cur.version, epoch, Date.now() + 60000, 'b'.repeat(64), 'raw-' + key(), new Date().toISOString()).run(), /DISCOUNT_PERMISSION_REQUIRED/);
  await toggle('staff:staff-b@example.test', 'view_financials', false);
  for (const [p, m] of [[`/api/candidates/${st.c1.id}/invoices`, 'GET'], ['/api/invoices/' + i.invoiceId, 'GET'], [`/api/invoices/${i.invoiceId}/pdf`, 'GET'], ['/api/office?view=billing', 'GET'], [`/api/invoices/${i.invoiceId}/payments?receipt=${st.paymentId}`, 'GET']])
    assert.equal((await send(p, m, undefined, staffB)).status, 403, p);
  assert.equal((await send(`/api/invoices/${i.invoiceId}/payments`, 'POST', { expectedVersion: e.version, amountCents: 100, method: 'CASH', paidAt: new Date().toISOString(), notes: null, idempotencyKey: 'pay-' + key() }, staffB)).status, 403);
  const office = await json(await send('/api/office?view=billing', 'GET', undefined, staffA));
  assert.ok(office.collected.every(c => c.currency === 'CAD'), 'totals grouped by currency'); assert.ok(office.items.length >= 2);
});
test('8 · SYSTEM overdue refresh (scheduled): unpaid past-deadline invoice → OVERDUE through an audited operation', async () => {
  const inv = await json(await send(`/api/candidates/${st.c1.id}/invoices`, 'POST', { currency: 'CAD', items: [{ kind: 'CUSTOM', serviceName: 'Late fee test', unitPriceCents: 3000, isFree: false, referencePriceCents: null }], discountCents: 0, deadline: today, note: null, requestKey: key() }, staffA), 201);
  assert.equal(inv.status, 'DRAFT');
  // Simulate the day passing: a MANAGER-audited EDIT moves the deadline to yesterday while keeping DRAFT.
  const cur = await db.prepare('SELECT * FROM invoices WHERE invoice_id=?').bind(inv.invoiceId).first(), epoch = (await db.prepare('SELECT version FROM permission_runtime').first()).version, logId = key(), now = new Date().toISOString();
  const snap = { subtotal_cents: cur.subtotal_cents, discount_cents: 0, total_cents: cur.total_cents, paid_cents: 0, remaining_cents: cur.remaining_cents, version: cur.version, status: 'DRAFT' };
  await db.batch([
    db.prepare("INSERT INTO financial_audit_logs(log_id,invoice_id,modified_by,action_type,old_value,new_value,expected_version,permissions_epoch,authz_expires_at_ms,request_hash,idempotency_key,timestamp) VALUES(?,?,'admin-1','EDIT',?,?,?,?,?,?,?,?)").bind(logId, inv.invoiceId, JSON.stringify(snap), JSON.stringify({ ...snap, version: cur.version + 1 }), cur.version, epoch, Date.now() + 60000, 'c'.repeat(64), 'raw-' + key(), now),
    db.prepare('UPDATE invoices SET deadline=?,version=?,last_operation_id=?,updated_at=? WHERE invoice_id=?').bind(plusDays(-1), cur.version + 1, logId, now, inv.invoiceId),
  ]);
  const worker = await mf.getWorker();
  await worker.scheduled({ cron: '17 8 * * *', scheduledTime: new Date() });
  const after = await db.prepare('SELECT status,version FROM invoices WHERE invoice_id=?').bind(inv.invoiceId).first();
  assert.equal(after.status, 'OVERDUE'); assert.equal(after.version, cur.version + 2);
  assert.equal(await count("SELECT count(*) n FROM financial_audit_logs WHERE invoice_id=? AND action_type='OVERDUE_REFRESH' AND modified_by='system:v2.2'", inv.invoiceId), 1);
  await worker.scheduled({ cron: '17 8 * * *', scheduledTime: new Date() });
  assert.equal(await count("SELECT count(*) n FROM financial_audit_logs WHERE invoice_id=? AND action_type='OVERDUE_REFRESH'", inv.invoiceId), 1, 'repeat run does nothing');
});
