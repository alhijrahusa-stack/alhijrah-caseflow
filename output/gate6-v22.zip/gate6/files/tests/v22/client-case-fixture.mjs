// Test fixture: a client-portal case (candidates + client_cases) and a full_case client session, as the intake and
// OTP flows leave them in production. Synthetic data only.
import { randomUUID, randomBytes, createHash } from 'node:crypto';
const sha = s => createHash('sha256').update(s).digest('hex');
// candidateId: attach the portal records to a case created through the staff API (with its computed assessment).
export async function clientCaseFixture(db, { name, email, phone, details = {}, profile = {}, candidateId = null }) {
  const now = new Date().toISOString(); let id = candidateId, reference;
  if (candidateId) reference = (await db.prepare('SELECT reference FROM candidates WHERE id=?').bind(candidateId).first()).reference;
  else { id = randomUUID(); reference = 'ALH-CA-' + randomBytes(4).toString('hex').toUpperCase(); await db.prepare("INSERT INTO candidates(id,owner_id,reference,profile,assessment,source,created_at,updated_at) VALUES(?,'office:alhijrah-canada',?,?,'{}','client',?,?)").bind(id, reference, JSON.stringify({ fullName: name, email, phone, consent: true, jobs: [], ...profile }), now, now).run(); }
  await db.prepare("INSERT INTO client_cases(candidate_id,request_id,payload_hash,access_hash,access_encrypted,details,consent_version,submitted_at) VALUES(?,?,?,?,?,?,'intake-2026-11-v3',?)").bind(id, randomUUID(), sha('payload:' + id), sha('access:' + id), 'x', JSON.stringify({ jobs: [], companions: [], ...details }), now).run();
  const token = randomBytes(32).toString('hex');
  await db.prepare("INSERT INTO client_sessions(token_hash,candidate_id,method,created_at,expires_at,scope) VALUES(?,?,'otp_email',?,?,'full_case')").bind(sha(token), id, Date.now(), Date.now() + 3600000).run();
  return { id, reference, token, cookie: 'alh_client_session=' + token, tokenHash: sha(token) };
}
export async function grantConsent(db, caseId, purpose, granted = true) {
  await db.prepare("INSERT INTO case_purpose_consents(case_id,purpose,granted,notice_version,updated_by,updated_at) VALUES(?,?,?,'2026-11-v1','client:'||?,?) ON CONFLICT(case_id,purpose) DO UPDATE SET granted=excluded.granted").bind(caseId, purpose, granted ? 1 : 0, caseId, new Date().toISOString()).run();
}
