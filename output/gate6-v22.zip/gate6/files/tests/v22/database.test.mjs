// v2.2 Gate 1 — database and contracts on a real D1 engine (Miniflare, no D1 mocks).
// Fresh install (0000–0031) and upgrade (0000–0023 with legacy rows, then 0024–0031) on isolated databases:
// foreign_key_check empty, quick_check ok, legacy row counts and fingerprints unchanged, manager/staff mapping from
// trusted records only, INTEGER money with fraction/negative/overflow rejection, JSON validity in TEXT, append-only
// history/payments/audit, fixed signatures (AC-46), batch atomicity, no multi-tenancy, no duplicate tables, ORM == SQL.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, readdir } from 'node:fs/promises';
import { createHash, randomUUID } from 'node:crypto';
import * as schema from '../../db/schema.ts';
import { getTableConfig, SQLiteTable } from 'drizzle-orm/sqlite-core';
import { parseCents, invoiceTotals, invoiceStatus, effectivePermission, torontoDate, nextTorontoMidnightMs, ROLES, STAFF_CAPABILITIES } from '../../lib/v22-core.ts';

const require = createRequire(import.meta.url);
const { Miniflare } = createRequire(require.resolve('wrangler/package.json'))('miniflare');
const MIGRATIONS = (await readdir('drizzle')).filter(f => /^\d{4}_.*\.sql$/.test(f)).sort();
const V22 = ['0024_client_portal_upgrade.sql', '0025_v2_2_controls_billing.sql', '0026_v22_runtime.sql', '0027_v22_scope_guards.sql', '0028_v22_engine_revisions.sql', '0029_v22_facts_cutover.sql', '0030_v22_operations.sql', '0031_v22_privacy.sql'];
const sha = s => createHash('sha256').update(s).digest('hex');
const now = () => new Date().toISOString();
const statements = async f => (await readFile('drizzle/' + f, 'utf8')).split('--> statement-breakpoint').map(s => s.trim()).filter(Boolean);

async function database() {
  const mf = new Miniflare({ modules: true, script: 'export default {fetch(){return new Response("ok")}}', d1Databases: ['DB'] });
  return { mf, db: await mf.getD1Database('DB') };
}
async function migrate(db, files) { for (const f of files) for (const s of await statements(f)) await db.prepare(s).run(); }
const all = async (db, q, ...b) => (await db.prepare(q).bind(...b).all()).results;
const one = async (db, q, ...b) => (await db.prepare(q).bind(...b).first());
const tables = async db => (await all(db, "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_cf_%' AND name<>'d1_migrations' ORDER BY name")).map(r => r.name);
const columns = async (db, t) => all(db, `PRAGMA table_info("${t}")`);
async function integrity(db) {
  const fk = await all(db, 'PRAGMA foreign_key_check');
  const qc = await one(db, 'PRAGMA quick_check');
  return { fk, qc: Object.values(qc)[0] };
}
/** Insert a row filling every NOT NULL column without a default with a type-correct value; overrides win. */
async function insert(db, t, overrides = {}) {
  const row = {};
  for (const c of await columns(db, t)) {
    if (Object.hasOwn(overrides, c.name)) row[c.name] = overrides[c.name];
    else if (c.notnull && c.dflt_value === null) row[c.name] = /INT/i.test(c.type) ? 1 : (c.pk ? randomUUID() : c.name.endsWith('_json') || c.name === 'details' ? '{}' : 'x');
  }
  const keys = Object.keys(row);
  await db.prepare(`INSERT INTO "${t}"(${keys.map(k => `"${k}"`).join(',')}) VALUES(${keys.map(() => '?').join(',')})`).bind(...keys.map(k => row[k])).run();
  return row;
}
async function fingerprint(db, t, cols) {
  const list = cols.map(c => `"${c}"`).join(',');
  const rows = await all(db, `SELECT ${list} FROM "${t}" ORDER BY rowid`);
  return { count: rows.length, digest: sha(JSON.stringify(rows)) };
}
async function rejects(promise, code) {
  await assert.rejects(promise, e => (code ? String(e.message).includes(code) : true) || assert.fail(`expected ${code}, got ${e.message}`));
}

test('static: no duplicate CREATE TABLE, no REAL/JSONB, no tenancy, every *_cents INTEGER with an integer CHECK', async () => {
  const created = new Map();
  for (const f of MIGRATIONS) for (const s of await statements(f)) {
    const m = s.match(/^CREATE TABLE\s+(?:IF NOT EXISTS\s+)?[`"]?(\w+)/i);
    if (m) { assert.ok(!created.has(m[1]), `table ${m[1]} created in ${created.get(m[1])} and ${f}`); created.set(m[1], f); }
  }
  for (const f of V22) {
    const text = await readFile('drizzle/' + f, 'utf8');
    assert.doesNotMatch(text, /\bREAL\b|\bJSONB\b|\bFLOAT\b|\bDOUBLE\b|\bNUMERIC\b/i, f);
    assert.doesNotMatch(text, /tenant/i, f);
    assert.doesNotMatch(text, /IF NOT EXISTS/i, f);
    for (const m of text.matchAll(/\n\s*(\w+_cents)\s+(\w+)([^\n]*)/g)) {
      assert.equal(m[2].toUpperCase(), 'INTEGER', `${f}: ${m[1]}`);
      assert.match(m[3], new RegExp(`typeof\\(${m[1]}\\)='integer'`), `${f}: ${m[1]} lacks integer CHECK`);
    }
  }
  for (const p of ['db/schema.ts', 'lib/v22-core.ts']) assert.doesNotMatch(await readFile(p, 'utf8'), /tenant/i, p);
});

test('fresh install 0000–0031: integrity, four roles only, seeded singletons, ORM == SQL', async () => {
  const { mf, db } = await database();
  try {
    await migrate(db, MIGRATIONS);
    const { fk, qc } = await integrity(db);
    assert.deepEqual(fk, []); assert.equal(qc, 'ok');
    assert.equal((await one(db, "SELECT count(*) n FROM users WHERE role='SYSTEM'")).n, 1);
    assert.equal((await one(db, 'SELECT version v FROM permission_runtime WHERE singleton=1')).v, 1);
    const fresh = await one(db, "SELECT version v,permissions_json p FROM role_permissions WHERE role='STAFF'");
    assert.equal(fresh.v, 1);
    assert.deepEqual(Object.keys(JSON.parse(fresh.p)).sort(), [...STAFF_CAPABILITIES].sort(), 'office policy: every STAFF capability allowed by default');
    assert.ok(Object.values(JSON.parse(fresh.p)).every(v => v === true));
    await rejects(db.prepare("INSERT INTO users(user_id,role,created_at) VALUES('u-admin','ADMIN',?)").bind(now()).run(), 'CHECK');
    assert.deepEqual([...ROLES], ['CLIENT', 'STAFF', 'MANAGER', 'SYSTEM']);
    // ORM == SQL for every table, column, type, NOT NULL and primary key.
    const orm = {};
    for (const v of Object.values(schema)) if (v instanceof SQLiteTable) {
      const c = getTableConfig(v); orm[c.name] = Object.fromEntries(c.columns.map(x => [x.name, { type: x.getSQLType().toLowerCase(), notNull: x.notNull, pk: x.primary }]));
      for (const pk of c.primaryKeys) for (const col of pk.columns) orm[c.name][col.name].pk = true;
    }
    for (const t of await tables(db)) {
      assert.ok(orm[t], `table ${t} missing from db/schema.ts`);
      const sqlCols = await columns(db, t);
      assert.deepEqual(Object.keys(orm[t]).sort(), sqlCols.map(c => c.name).sort(), `columns of ${t}`);
      for (const c of sqlCols) {
        assert.equal(orm[t][c.name].type, c.type.toLowerCase(), `${t}.${c.name} type`);
        assert.equal(Boolean(orm[t][c.name].pk), c.pk > 0, `${t}.${c.name} pk`);
        if (!c.pk) assert.equal(orm[t][c.name].notNull, c.notnull === 1, `${t}.${c.name} notNull`);
      }
    }
  } finally { await mf.dispose(); }
});

test('upgrade 0023 -> 0031 on legacy data (incl. facts cutover): counts and fingerprints unchanged, trusted mapping, append-only, money, JSON, atomicity', async () => {
  const { mf, db } = await database();
  try {
    const legacy = MIGRATIONS.filter(f => !V22.includes(f));
    assert.equal(legacy.at(-1), '0023_case_facts_rules_registry.sql');
    await migrate(db, legacy);
    const t0 = now(), ms = Date.now();
    // Legacy office with a manager recorded by the authenticated admin session and two staff members (one inactive).
    await insert(db, 'office_settings', { id: 'office', primary_owner_id: 'admin-user-1', updated_at: t0 });
    await insert(db, 'office_members', { email: 'Staff.One@Example.test', active: 1, created_at: t0 });
    await insert(db, 'office_members', { email: 'old@example.test', active: 0, created_at: t0 });
    const cases = ['c-1', 'c-2', 'c-3'];
    for (const [i, id] of cases.entries()) await insert(db, 'candidates', { id, owner_id: 'admin-user-1', reference: 'ALH-' + i, profile: JSON.stringify({ n: i }), assessment: '{}', assigned_to: i === 0 ? 'staff.one@example.test' : '', created_at: t0, updated_at: t0 });
    await insert(db, 'documents', { id: 'd-1', owner_id: 'admin-user-1', candidate_id: 'c-1', name: 'p.pdf', object_key: 'k/d-1', size: 10, mime: 'application/pdf', category: 'identity', sha256: sha('doc'), created_at: t0 });
    const snapshot = JSON.stringify({ profile: { n: 0 }, signed: true });
    await insert(db, 'application_authorizations', { candidate_id: 'c-1', version: 'v1', accepted_at: t0, authorization_text: 'A', terms_text: '[]', snapshot, snapshot_hash: sha(snapshot) });
    await insert(db, 'application_authorizations', { candidate_id: 'c-2', version: 'v1', accepted_at: t0, authorization_text: 'A', terms_text: '[]', snapshot: '{}', snapshot_hash: sha('{}') });
    await insert(db, 'assessment_history', { id: 'h-legacy', candidate_id: 'c-1', computed_at: t0, inputs_hash: sha('i'), engine_version: 'case-engine-1.1.0', rules_version: 'r', output_json: '{"score":1}', explanation_trace_json: '[]' });
    await insert(db, 'auth_challenges', { id: 'ch-1', channel: 'account_email', code_hash: sha('c'), request_key: 'rk-1', state: 'pending', expires_at: ms + 60000, created_at: ms });
    await insert(db, 'auth_challenges', { id: 'ch-2', channel: 'email', candidate_id: 'c-1', code_hash: sha('d'), request_key: 'rk-2', state: 'pending', expires_at: ms + 60000, created_at: ms });
    await insert(db, 'client_sessions', { token_hash: sha('s'), candidate_id: 'c-1', method: 'otp', created_at: ms, expires_at: ms + 60000 });
    // Legacy facts for the cutover: REPORTED->VERIFIED history, a key whose latest version is CONFLICTED, one whose
    // conflict was later superseded by REPORTED, an UNKNOWN row and a CONFIRMED_ABSENT row.
    const fact = (id, cid, key, version, status, evidence = null) => insert(db, 'case_facts', { id, candidate_id: cid, fact_key: key, version, status, value_json: JSON.stringify({ text: 'legacy ' + id }), source: 'client_skills_card', evidence_document_id: evidence, recorded_by: 'client', recorded_at: t0 });
    await fact('f-1', 'c-1', 'additional_skills', 1, 'REPORTED'); await fact('f-2', 'c-1', 'additional_skills', 2, 'VERIFIED', 'd-1');
    await fact('f-3', 'c-2', 'k2', 1, 'REPORTED'); await fact('f-4', 'c-2', 'k2', 2, 'CONFLICTED');
    await fact('f-5', 'c-2', 'k5', 1, 'CONFLICTED'); await fact('f-6', 'c-2', 'k5', 2, 'REPORTED');
    await fact('f-7', 'c-3', 'k3', 1, 'UNKNOWN'); await fact('f-8', 'c-3', 'k4', 1, 'CONFIRMED_ABSENT');

    const before = {};
    for (const t of await tables(db)) before[t] = { cols: (await columns(db, t)).map(c => c.name) };
    for (const t of Object.keys(before)) Object.assign(before[t], await fingerprint(db, t, before[t].cols));

    await migrate(db, V22);
    const { fk, qc } = await integrity(db);
    assert.deepEqual(fk, []); assert.equal(qc, 'ok');
    for (const [t, b] of Object.entries(before)) {
      const after = await fingerprint(db, t, b.cols);
      if (t === 'auth_challenges' || t === 'candidates') { assert.equal(after.count, b.count, t); continue; }
      // The cutover only appends its review tasks and one counts row; every pre-existing row stays byte-identical.
      if (t === 'tasks' || t === 'operation_logs') {
        const rows = await all(db, `SELECT ${b.cols.map(c => `"${c}"`).join(',')} FROM "${t}" WHERE id NOT LIKE 'legacy-conflict:%' AND id<>'v22-facts-cutover' ORDER BY rowid`);
        assert.deepEqual({ count: rows.length, digest: sha(JSON.stringify(rows)) }, { count: b.count, digest: b.digest }, `legacy table ${t} changed`); continue;
      }
      assert.deepEqual(after, { count: b.count, digest: b.digest }, `legacy table ${t} changed`);
    }
    // Pre-existing columns of auth_challenges/candidates are untouched; only new columns were added.
    for (const t of ['auth_challenges', 'candidates']) assert.equal((await fingerprint(db, t, before[t].cols)).digest, before[t].digest, t);
    assert.equal((await one(db, "SELECT purpose p FROM auth_challenges WHERE id='ch-1'")).p, 'account_login');
    assert.equal((await one(db, "SELECT purpose p FROM auth_challenges WHERE id='ch-2'")).p, 'case_login');
    assert.equal((await one(db, 'SELECT scope s FROM client_sessions')).s, 'full_case');

    // Facts cutover acceptance (FACTS_COEXISTENCE Phase B): REPORTED/VERIFIED copied under UNKNOWN, no head, conflicts
    // and confirmed-absent rows become review tasks, counts logged without values, legacy table frozen, UNKNOWN reserved.
    assert.deepEqual((await all(db, "SELECT fact_id,subject_id,state,evidence_ids,created_by FROM case_fact_revisions ORDER BY fact_id")).map(r => [r.fact_id, r.subject_id, r.state, r.evidence_ids, r.created_by]),
      [['f-1', 'UNKNOWN', 'REPORTED', '[]', 'system:v2.2'], ['f-2', 'UNKNOWN', 'VERIFIED', '["d-1"]', 'system:v2.2'], ['f-3', 'UNKNOWN', 'REPORTED', '[]', 'system:v2.2'], ['f-6', 'UNKNOWN', 'REPORTED', '[]', 'system:v2.2']]);
    assert.equal(JSON.parse((await one(db, "SELECT review_note n FROM case_fact_revisions WHERE fact_id='f-2'")).n).legacy.recordedBy, 'client');
    assert.equal((await one(db, 'SELECT count(*) n FROM case_fact_heads')).n, 0, 'no head for UNKNOWN');
    assert.deepEqual((await all(db, "SELECT id,status FROM tasks WHERE id LIKE 'legacy-conflict:%' ORDER BY id")).map(r => r.id), ['legacy-conflict:c-2:k2', 'legacy-conflict:c-3:k4']);
    assert.deepEqual(JSON.parse((await one(db, "SELECT code FROM operation_logs WHERE id='v22-facts-cutover'")).code), { legacyRows: 8, copied: 4, notCopiedUnknown: 1, notCopiedConflicted: 2, notCopiedConfirmedAbsent: 1, reviewTasks: 2, heads: 0 });
    await rejects(db.prepare("INSERT INTO case_facts(id,candidate_id,fact_key,version,status,value_json,source,recorded_by,recorded_at) VALUES('f-9','c-1','x',1,'REPORTED','{}','s','r',?)").bind(t0).run(), 'LEGACY_FACTS_FROZEN');
    await rejects(db.prepare("UPDATE case_facts SET status='VERIFIED' WHERE id='f-1'").run(), 'LEGACY_FACTS_FROZEN');
    await rejects(db.prepare("DELETE FROM case_facts WHERE id='f-1'").run(), 'LEGACY_FACTS_FROZEN');
    await rejects(db.prepare("INSERT INTO case_fact_revisions(fact_id,case_id,fact_key,subject_id,value_json,state,source_hash,created_by,created_at) VALUES('f-u','c-1','x','UNKNOWN','{}','REPORTED',?,'system:v2.2',?)").bind(sha('u'), t0).run(), 'UNKNOWN_SUBJECT_RESERVED');
    await rejects(db.prepare("INSERT INTO case_fact_heads(case_id,subject_id,fact_key,fact_id) VALUES('c-1','UNKNOWN','additional_skills','f-1')").run(), 'UNKNOWN_SUBJECT_HAS_NO_HEAD');
    for (const f of ['0029_v22_facts_cutover.sql']) for (const st of (await statements(f)).filter(x => x.startsWith('INSERT'))) await db.prepare(st).run();
    assert.equal((await one(db, 'SELECT count(*) n FROM case_fact_revisions')).n, 4, 'cutover copy is re-runnable without duplicates');
    assert.equal((await one(db, "SELECT count(*) n FROM tasks WHERE id LIKE 'legacy-conflict:%'")).n, 2);

    // Mapping only from trusted records: manager = office_settings.primary_owner_id; staff = office_members.
    assert.deepEqual(await all(db, 'SELECT user_id,role,active FROM users ORDER BY user_id'), [
      { user_id: 'admin-user-1', role: 'MANAGER', active: 1 },
      { user_id: 'staff:old@example.test', role: 'STAFF', active: 0 },
      { user_id: 'staff:staff.one@example.test', role: 'STAFF', active: 1 },
      { user_id: 'system:v2.2', role: 'SYSTEM', active: 1 },
    ]);
    assert.deepEqual(await all(db, 'SELECT case_id,user_id,granted_by FROM case_access'), [{ case_id: 'c-1', user_id: 'staff:staff.one@example.test', granted_by: 'admin-user-1' }]);
    const policy = await one(db, "SELECT version,permissions_json p FROM role_permissions WHERE role='STAFF'");
    assert.equal(policy.version, 1, 'the upgrade does not narrow the default STAFF policy');
    for (const cap of STAFF_CAPABILITIES) assert.equal(JSON.parse(policy.p)[cap], true, `${cap} allowed by default`);
    for (const cap of ['manage_permissions', 'open_staff_access', 'seal_rules', 'approve_invoice']) assert.equal(JSON.parse(policy.p)[cap], undefined, `${cap} stays MANAGER-only`);
    await rejects(db.prepare("UPDATE users SET role='MANAGER' WHERE user_id='staff:staff.one@example.test'").run(), 'ROLE_CHANGE_NOT_ALLOWED');
    await rejects(db.prepare("UPDATE users SET custom_permissions='{\"x\":true}' WHERE user_id='admin-user-1'").run(), 'ROOT_PERMISSIONS_IMMUTABLE');
    await rejects(db.prepare("UPDATE users SET custom_permissions='{\"view_crm\":true}',permission_version=2 WHERE user_id='staff:staff.one@example.test'").run(), 'PERMISSION_AUDIT_REQUIRED');
    await rejects(db.prepare("INSERT INTO users(user_id,role,custom_permissions,created_at) VALUES('u-j','STAFF','not-json',?)").bind(now()).run(), 'CHECK');

    // assessment_history: extended in place, engine shape still accepted, append-only, JSON and canonical guards.
    await db.prepare("INSERT INTO assessment_history(id,candidate_id,computed_at,inputs_hash,engine_version,rules_version,output_json,explanation_trace_json) VALUES('h-new','c-2',?,?,'case-engine-1.1.0','r','{}','[]')").bind(now(), sha('j')).run();
    await rejects(db.prepare("UPDATE assessment_history SET output_json='{}' WHERE id='h-legacy'").run(), 'IMMUTABLE_ASSESSMENT');
    await rejects(db.prepare("DELETE FROM assessment_history WHERE id='h-legacy'").run(), 'IMMUTABLE_ASSESSMENT');
    await rejects(db.prepare("INSERT INTO assessment_history(id,candidate_id,computed_at,inputs_hash,engine_version,rules_version,output_json,explanation_trace_json) VALUES('h-bad','c-2',?,?,'e','r','{bad','[]')").bind(now(), sha('k')).run(), 'ASSESSMENT_JSON_INVALID');
    await rejects(db.prepare("INSERT INTO assessment_history(id,candidate_id,computed_at,inputs_hash,engine_version,rules_version,output_json,explanation_trace_json) VALUES('h-x','missing',?,?,'e','r','{}','[]')").bind(now(), sha('l')).run(), 'ASSESSMENT_CASE_REQUIRED');
    await rejects(db.prepare("INSERT INTO assessment_history(id,candidate_id,computed_at,inputs_hash,engine_version,rules_version,output_json,explanation_trace_json,canonical_input_hash) VALUES('h-p','c-2',?,?,'e','r','{}','[]',?)").bind(now(), sha('m'), sha('n')).run(), 'ASSESSMENT_CANONICAL_FIELDS_INCOMPLETE');
    const canon = ['c-3', now(), sha('o'), 'e', 'r', '{}', '[]', 0, sha('p'), sha('q'), 'PRODUCTION', 'RAPID_SCREENING', 'system:v2.2'];
    const canonSql = 'INSERT INTO assessment_history(id,candidate_id,computed_at,inputs_hash,engine_version,rules_version,output_json,explanation_trace_json,case_revision,canonical_input_hash,rule_bundle_hash,assessment_mode,assessment_purpose,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
    await db.prepare(canonSql).bind('h-c1', ...canon).run();
    await rejects(db.prepare(canonSql).bind('h-c2', ...canon).run(), 'UNIQUE');

    // AC-46: signature fixed on its original snapshot; editing the case later does not touch it or its hash.
    await rejects(db.prepare("UPDATE application_authorizations SET signature_id='sig-1',signature_object_key='sig/1.png',signature_sha256=?,signed_payload_hash=?,signature_signed_at=? WHERE candidate_id='c-1'").bind(sha('png'), sha(snapshot), now()).run(), 'IMMUTABLE_SIGNATURE_BINDING');
    assert.equal((await one(db, "SELECT signature_id s FROM application_authorizations WHERE candidate_id='c-1'")).s, null, 'historical unsigned record is never back-filled');
    const revBefore = (await one(db, "SELECT data_revision r FROM candidates WHERE id='c-1'")).r;
    await db.prepare("UPDATE candidates SET profile='{\"n\":99}' WHERE id='c-1'").run();
    const auth = await one(db, "SELECT snapshot,snapshot_hash FROM application_authorizations WHERE candidate_id='c-1'");
    assert.equal(auth.snapshot, snapshot); assert.equal(auth.snapshot_hash, sha(snapshot));
    assert.equal((await one(db, "SELECT data_revision r FROM candidates WHERE id='c-1'")).r, revBefore + 1, 'profile edit is a new data revision, not a new signature');

    // Money: server-only integer cents through the guarded batch path; fractions, negatives and overflow rejected.
    const manager = 'admin-user-1', epoch = (await one(db, 'SELECT version v FROM permission_runtime')).v, exp = Date.now() + 3600000;
    const inv = 'inv-1', zeros = { subtotal_cents: 0, discount_cents: 0, total_cents: 0, paid_cents: 0, remaining_cents: 0, version: 0, status: 'DRAFT' };
    const totals = invoiceTotals([{ unitPriceCents: 150000, isFree: false }, { unitPriceCents: 0, isFree: true }], 25000, []);
    const created = { ...totals, version: 1, status: invoiceStatus(totals, null, false, Date.now()) };
    const audit = (id, kind, oldV, newV, key) => db.prepare('INSERT INTO financial_audit_logs(log_id,invoice_id,modified_by,action_type,old_value,new_value,expected_version,permissions_epoch,authz_expires_at_ms,request_hash,idempotency_key,timestamp) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').bind(id, inv, manager, kind, JSON.stringify(oldV), JSON.stringify(newV), oldV.version, epoch, exp, sha(id), key, now());
    const setInvoice = (v, op) => db.prepare('UPDATE invoices SET subtotal_cents=?,discount_cents=?,total_cents=?,paid_cents=?,remaining_cents=?,version=?,status=?,last_operation_id=?,updated_at=? WHERE invoice_id=?').bind(v.subtotal_cents, v.discount_cents, v.total_cents, v.paid_cents, v.remaining_cents, v.version, v.status, op, now(), inv);
    const item = (id, price, free, op) => db.prepare('INSERT INTO invoice_items(item_id,invoice_id,service_name,is_custom,is_free,unit_price_cents,last_operation_id) VALUES(?,?,?,?,?,?,?)').bind(id, inv, 'svc-' + id, 0, free, price, op);
    await rejects(db.prepare("INSERT INTO invoices(invoice_id,case_id,currency,subtotal_cents,created_by,created_at,updated_at) VALUES('inv-x','c-1','CAD',100,?,?,?)").bind(manager, now(), now()).run(), 'SERVER_TOTALS_REQUIRED');
    // A failing step inside the creation batch leaves nothing behind.
    await rejects(db.batch([
      db.prepare("INSERT INTO invoices(invoice_id,case_id,currency,created_by,created_at,updated_at) VALUES(?,'c-1','CAD',?,?,?)").bind(inv, manager, now(), now()),
      audit('op-1', 'CREATE', zeros, created, 'k-1'), item('i-1', 150000, 0, 'op-1'), item('i-2', 0.5, 0, 'op-1'), setInvoice(created, 'op-1'),
    ]));
    for (const t of ['invoices', 'financial_audit_logs', 'invoice_items']) assert.equal((await one(db, `SELECT count(*) n FROM ${t}`)).n, 0, `partial ${t}`);
    await db.batch([
      db.prepare("INSERT INTO invoices(invoice_id,case_id,currency,created_by,created_at,updated_at) VALUES(?,'c-1','CAD',?,?,?)").bind(inv, manager, now(), now()),
      audit('op-1', 'CREATE', zeros, created, 'k-1'), item('i-1', 150000, 0, 'op-1'), item('i-2', 0, 1, 'op-1'), setInvoice(created, 'op-1'),
    ]);
    assert.deepEqual(await one(db, 'SELECT subtotal_cents s,discount_cents d,total_cents t,remaining_cents r,status st,version v FROM invoices'), { s: 150000, d: 25000, t: 125000, r: 125000, st: 'DRAFT', v: 1 });
    const pay = (id, amount, key) => db.prepare("INSERT INTO payments_ledger(payment_id,invoice_id,case_id,currency,amount_cents,method,paid_at,idempotency_key,operation_id,created_by,created_at) VALUES(?,?,'c-1','CAD',?,'CASH',?,?,?,?,?)").bind(id, inv, amount, now(), key, id.replace('p', 'op'), manager, now());
    const partial = { ...created, paid_cents: 50000, remaining_cents: 75000, version: 2, status: 'PARTIAL' };
    for (const bad of [100.5, -1, 9007199254740992, 125001]) {
      await rejects(db.batch([audit('op-p', 'PAYMENT', created, partial, 'pk-x'), pay('p-p', bad, 'pk-x'), setInvoice(partial, 'op-p')]));
      assert.equal((await one(db, 'SELECT count(*) n FROM payments_ledger')).n, 0);
      assert.equal((await one(db, "SELECT count(*) n FROM financial_audit_logs WHERE action_type='PAYMENT'")).n, 0, `no partial audit for ${bad}`);
    }
    await db.batch([audit('op-p', 'PAYMENT', created, partial, 'pk-1'), pay('p-p', 50000, 'pk-1'), setInvoice(partial, 'op-p')]);
    await rejects(db.batch([audit('op-q', 'PAYMENT', partial, { ...partial, version: 3 }, 'pk-1'), pay('p-q', 50000, 'pk-1')]), 'UNIQUE');
    await rejects(db.prepare("UPDATE payments_ledger SET amount_cents=1").run(), 'IMMUTABLE_PAYMENT');
    await rejects(db.prepare("DELETE FROM financial_audit_logs").run(), 'IMMUTABLE_FINANCIAL_AUDIT');
    await rejects(db.prepare("DELETE FROM invoices").run(), 'INVOICE_HISTORY_REQUIRED');
    assert.deepEqual(await one(db, 'SELECT paid_cents p,remaining_cents r,status s,version v FROM invoices'), { p: 50000, r: 75000, s: 'PARTIAL', v: 2 });
    const end = await integrity(db);
    assert.deepEqual(end.fk, []); assert.equal(end.qc, 'ok');
  } finally { await mf.dispose(); }
});

test('v22-core controls: integer cents, totals, status, permissions, Toronto day', () => {
  assert.equal(parseCents('1250.50'), 125050); assert.equal(parseCents('0'), 0);
  for (const bad of ['1.234', '-1', '1e3', ' 1', '90071992547409.92']) assert.throws(() => parseCents(bad));
  assert.throws(() => invoiceTotals([{ unitPriceCents: 10.5, isFree: false }], 0, []), /INTEGER_CENTS_REQUIRED/);
  assert.throws(() => invoiceTotals([{ unitPriceCents: 100, isFree: false }], 101, []), /INVALID_DISCOUNT_OR_TOTAL/);
  assert.throws(() => invoiceTotals([{ unitPriceCents: 100, isFree: false }], 0, [101]), /OVERPAYMENT_NOT_SUPPORTED/);
  assert.throws(() => invoiceTotals([{ unitPriceCents: 1, isFree: true }], 0, []), /FREE_ITEM_MUST_BE_ZERO/);
  const zero = invoiceTotals([{ unitPriceCents: 0, isFree: true }], 0, []);
  assert.equal(invoiceStatus(zero, null, false, Date.now()), 'PAID');
  const staff = { role: 'STAFF', active: true }, closed = { enabled: false, localDate: null, untilMs: 0 };
  assert.equal(effectivePermission(staff, 'record_payment', { record_payment: true }, { record_payment: false }, closed, Date.now()), false, 'custom boolean wins');
  assert.equal(effectivePermission(staff, 'approve_invoice', {}, { approve_invoice: true }, closed, Date.now()), false, 'manager capability is reserved');
  const t = Date.UTC(2026, 2, 8, 12), mid = nextTorontoMidnightMs(t);
  assert.equal(torontoDate(mid - 1), '2026-03-08'); assert.equal(torontoDate(mid), '2026-03-09');
  assert.equal(mid - nextTorontoMidnightMs(Date.UTC(2026, 2, 7, 12)), 23 * 3600000, 'DST spring day is 23 hours');
  assert.equal(nextTorontoMidnightMs(Date.UTC(2026, 10, 1, 12)) - nextTorontoMidnightMs(Date.UTC(2026, 9, 31, 12)), 25 * 3600000, 'DST fall day is 25 hours');
});

test('negative: assessment pointers cannot cross cases or purposes; fact heads cannot cross subject or key', async () => {
  const { mf, db } = await database();
  try {
    await migrate(db, MIGRATIONS);
    const t0 = now(), sys = 'system:v2.2';
    for (const id of ['c-A', 'c-B']) await insert(db, 'candidates', { id, owner_id: 'office', reference: 'R-' + id, profile: '{}', assessment: '{}', created_at: t0, updated_at: t0 });
    const add = (id, c, mode, purpose) => db.prepare('INSERT INTO assessment_history(id,candidate_id,computed_at,inputs_hash,engine_version,rules_version,output_json,explanation_trace_json,case_revision,canonical_input_hash,rule_bundle_hash,assessment_mode,assessment_purpose,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)').bind(id, c, t0, sha(id), 'e', 'r', '{}', '[]', 0, sha('in' + id), sha('rb'), mode, purpose, sys).run();
    await add('a-A', 'c-A', 'PRODUCTION', 'VERIFIED_SCREENING');
    await add('a-B', 'c-B', 'PRODUCTION', 'VERIFIED_SCREENING');
    await add('r-A', 'c-A', 'PRODUCTION', 'RAPID_SCREENING');
    await add('r-B', 'c-B', 'PRODUCTION', 'RAPID_SCREENING');
    await add('s-A', 'c-A', 'SHADOW', 'VERIFIED_SCREENING');
    await db.prepare("INSERT INTO assessment_history(id,candidate_id,computed_at,inputs_hash,engine_version,rules_version,output_json,explanation_trace_json) VALUES('l-A','c-A',?,?,'e','r','{}','[]')").bind(t0, sha('legacy')).run();
    const point = (col, v, c = 'c-A') => db.prepare(`UPDATE candidates SET ${col}=? WHERE id=?`).bind(v, c).run();
    await rejects(point('latest_verified_assessment_id', 'a-B'), 'ASSESSMENT_POINTER_CASE_MISMATCH');
    await rejects(point('latest_rapid_assessment_id', 'r-B'), 'ASSESSMENT_POINTER_CASE_MISMATCH');
    await rejects(point('latest_verified_assessment_id', 'r-A'), 'ASSESSMENT_POINTER_PURPOSE_MISMATCH');
    await rejects(point('latest_rapid_assessment_id', 'a-A'), 'ASSESSMENT_POINTER_PURPOSE_MISMATCH');
    await rejects(point('latest_verified_assessment_id', 's-A'), 'ASSESSMENT_POINTER_PURPOSE_MISMATCH');
    await rejects(point('latest_verified_assessment_id', 'l-A'), 'ASSESSMENT_POINTER_PURPOSE_MISMATCH');
    await rejects(insert(db, 'candidates', { id: 'c-C', owner_id: 'office', reference: 'R-c-C', profile: '{}', assessment: '{}', latest_verified_assessment_id: 'a-A', created_at: t0, updated_at: t0 }), 'ASSESSMENT_POINTER_CASE_MISMATCH');
    assert.deepEqual(await one(db, "SELECT latest_verified_assessment_id v,latest_rapid_assessment_id r FROM candidates WHERE id='c-A'"), { v: null, r: null }, 'rejected writes left no pointer');
    await point('latest_verified_assessment_id', 'a-A'); await point('latest_rapid_assessment_id', 'r-A');
    assert.deepEqual(await one(db, "SELECT latest_verified_assessment_id v,latest_rapid_assessment_id r FROM candidates WHERE id='c-A'"), { v: 'a-A', r: 'r-A' });
    await point('latest_verified_assessment_id', null);

    const fact = (id, c, subject, key) => db.prepare("INSERT INTO case_fact_revisions(fact_id,case_id,fact_key,subject_id,value_json,state,source_hash,created_by,created_at) VALUES(?,?,?,?,'{}','REPORTED',?,?,?)").bind(id, c, key, subject, sha(id), sys, t0).run();
    await fact('f-1', 'c-A', 'principal', 'language');
    await fact('f-2', 'c-A', 'spouse', 'language');
    await fact('f-3', 'c-A', 'principal', 'education');
    await fact('f-4', 'c-B', 'principal', 'language');
    const head = id => db.prepare("INSERT INTO case_fact_heads(case_id,subject_id,fact_key,fact_id) VALUES('c-A','principal','language',?)").bind(id).run();
    await rejects(head('f-2'), 'FACT_HEAD_SCOPE_MISMATCH');
    await rejects(head('f-3'), 'FACT_HEAD_SCOPE_MISMATCH');
    await rejects(head('f-4'), 'FACT_HEAD_SCOPE_MISMATCH');
    assert.equal((await one(db, 'SELECT count(*) n FROM case_fact_heads')).n, 0);
    await head('f-1');
    await rejects(db.prepare("UPDATE case_fact_heads SET fact_id='f-2' WHERE case_id='c-A'").run(), 'FACT_HEAD_SCOPE_MISMATCH');
    await rejects(db.prepare("UPDATE case_fact_heads SET fact_id='f-3' WHERE case_id='c-A'").run(), 'FACT_HEAD_SCOPE_MISMATCH');
    await rejects(db.prepare("UPDATE case_fact_heads SET subject_id='spouse',fact_id='f-2' WHERE case_id='c-A'").run(), 'FACT_HEAD_KEY_IMMUTABLE');
    assert.deepEqual(await one(db, 'SELECT subject_id s,fact_key k,fact_id f FROM case_fact_heads'), { s: 'principal', k: 'language', f: 'f-1' });
    const { fk, qc } = await integrity(db);
    assert.deepEqual(fk, []); assert.equal(qc, 'ok');
  } finally { await mf.dispose(); }
});

test('static: no dual-write — after the Gate 3 cutover only lib/facts.ts reads or writes facts, and only the canonical tables', async () => {
  const canonical = [], legacy = [];
  async function scan(dir) {
    for (const e of await readdir(dir, { withFileTypes: true })) {
      const p = dir + '/' + e.name;
      if (e.isDirectory()) await scan(p);
      else if (/\.(ts|tsx|mjs|js)$/.test(e.name)) {
        const text = await readFile(p, 'utf8');
        if (/caseFactRevisions|caseFactHeads|case_fact_revisions|case_fact_heads/.test(text) && p !== 'lib/facts.ts') canonical.push(p);
        if (/import\s*\{[^}]*\bcaseFacts\b[^}]*\}\s*from\s*['"]@\/db\/schema['"]|\bcase_facts\b/.test(text)) legacy.push(p);
      }
    }
  }
  for (const d of ['lib', 'app', 'worker']) await scan(d);
  assert.deepEqual(canonical, [], 'Phase C (docs/v22/FACTS_COEXISTENCE.md): lib/facts.ts is the single reader/writer');
  assert.deepEqual(legacy, [], 'legacy case_facts is a frozen archive: no application reader or writer');
  assert.match(await readFile('lib/facts.ts', 'utf8'), /caseFactRevisions, caseFactHeads/);
});
