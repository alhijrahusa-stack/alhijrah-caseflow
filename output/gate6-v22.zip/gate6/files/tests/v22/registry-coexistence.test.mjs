// v2.2 Gate 4 follow-up (owner instruction): the legacy rule registry (lib/rules/registry.ts) stays until a sealed pack
// is imported, without a read conflict with the v2.2 engine. Proven here: (1) the registry can never decide RCIP or AIP
// (secondary sources => RULE_UNAVAILABLE on every date), so program routing comes only from sealed releases;
// (2) the legacy preliminary never offers RCIP/AIP as an option; (3) no v2.2 engine module reads the registry;
// (4) client-facing RCIP text carries no transition/grace wording.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { getRulesVersion } from '../../lib/rules/registry.ts';

test('registry never resolves RCIP or AIP on any date (no competing decision with sealed releases)', () => {
  for (const key of ['RCIP', 'AIP']) for (const d of ['2026-01-01', '2026-11-13', '2026-12-31', '2027-01-01', '2028-06-30']) {
    const r = getRulesVersion(key, d, { applicationDate: d });
    assert.equal(r.status, 'RULE_UNAVAILABLE', `${key} ${d}`);
  }
});
test('v2.2 engine modules do not read the legacy registry; the legacy preliminary lists RCIP/AIP only as unavailable', async () => {
  for (const f of ['lib/rule-resolver.ts', 'lib/rule-import.ts', 'lib/rule-release.ts', 'lib/normalization.ts', 'lib/assessment-store.ts', 'lib/pathways.ts', 'lib/crs.ts'])
    assert.doesNotMatch(await readFile(f, 'utf8'), /rules\/registry/, f);
  const pre = await readFile('lib/preliminary.ts', 'utf8');
  assert.match(pre, /\(x\.k==='RCIP'\|\|x\.k==='AIP'\)&&x\.r\.status!=='RESOLVED'/, 'RCIP/AIP enter the preliminary only as RULE_UNAVAILABLE');
  assert.doesNotMatch(pre, /programId:'RCIP/, 'no RCIP option is built in the legacy preliminary');
});
test('client-facing RCIP text has no transition or grace wording', async () => {
  for (const f of ['lib/faq.ts', 'lib/pathways.ts', 'lib/assessment.ts', 'components/client/application.tsx']) {
    const t = await readFile(f, 'utf8');
    assert.doesNotMatch(t, /انتقال 2027|قبل انتهائها|before it expires|انتهى استقبال توصيات|يحدد إن كان طلبك ضمن/, f);
  }
});
