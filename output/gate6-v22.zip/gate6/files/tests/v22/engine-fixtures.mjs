// v2.2 Gate 3 — TEST_ONLY rule payloads for tests/v22/engines.test.mjs. They are never imported by application code
// and never written to a production database. Program obligations below are synthetic test predicates, not legal
// thresholds. The CRS tables reproduce the point values of lib/crs.ts (checked against the consolidated Ministerial
// Instructions by tests/mi-consolidated.test.mjs) so the policy engine can be differentially tested against it; they
// are not an approved rule pack (I04/I05 stay open) and are not activated anywhere outside the test database.
import { jcsHash, sha256Hex } from '../../lib/v22-core.ts';

export const ENGINE = 'v22-engine-1.0.0';
export const SOURCES = {
  'SRC-TEST-CRS': { officialUrl: 'https://www.canada.ca/en/test-only/crs.html', text: 'TEST_ONLY synthetic CRS source for automated tests.' },
  'SRC-TEST-PROGRAM': { officialUrl: 'https://www.canada.ca/en/test-only/program.html', text: 'TEST_ONLY synthetic program source for automated tests.' },
  'SRC-TEST-RCIP': { officialUrl: 'https://www.canada.ca/en/test-only/rcip.html', text: 'TEST_ONLY synthetic RCIP source for automated tests.' },
  'SRC-TEST-NOC': { officialUrl: 'https://noc.esdc.gc.ca/test-only/catalog', text: 'TEST_ONLY synthetic NOC catalog for automated tests.' },
};
export async function sourceFacts() {
  const m = new Map();
  for (const [id, s] of Object.entries(SOURCES)) { const h = await sha256Hex(s.text); m.set(id, { contentSha256: h, storedSha256: h }); }
  return m;
}
const EDU = ['LESS_THAN_SECONDARY', 'SECONDARY', 'ONE_YEAR', 'TWO_YEAR', 'BACHELOR', 'TWO_OR_MORE', 'MASTERS_OR_PROFESSIONAL', 'DOCTORATE'];
const CLASSES = ['WITHOUT_SPOUSE', 'WITH_SPOUSE'];
const row = (dimensionValues, points, src = 'SRC-TEST-CRS') => ({ dimensionValues, points, sourceId: src, locator: 'test-only' });
async function table(tableId, dimensions, rows) { return { tableId, dimensions, rows, expectedRowSetHash: await jcsHash(rows) }; }
const range = (a, b) => Array.from({ length: b - a + 1 }, (_, i) => a + i);
function crsTables() {
  const ageRows = [[18, 99, 90], [19, 105, 95], [30, 105, 95], [31, 99, 90], [32, 94, 85], [33, 88, 80], [34, 83, 75], [35, 77, 70], [36, 72, 65], [37, 66, 60], [38, 61, 55], [39, 55, 50], [40, 50, 45], [41, 39, 35], [42, 28, 25], [43, 17, 15], [44, 6, 5]];
  const age = (cls, a) => { const s = cls === 'WITH_SPOUSE'; if (a >= 20 && a <= 29) return s ? 100 : 110; const r = ageRows.find(x => x[0] === a); return r ? (s ? r[2] : r[1]) : 0; };
  const eduS = [0, 30, 90, 98, 120, 128, 135, 150], eduM = [0, 28, 84, 91, 112, 119, 126, 140];
  const first = (cls, l) => { const s = cls === 'WITH_SPOUSE'; return l < 4 ? 0 : l <= 5 ? 6 : l === 6 ? (s ? 8 : 9) : l === 7 ? (s ? 16 : 17) : l === 8 ? (s ? 22 : 23) : l === 9 ? (s ? 29 : 31) : (s ? 32 : 34); };
  const workS = [0, 40, 53, 64, 72, 80], workM = [0, 35, 46, 56, 63, 70];
  const pair = (g, b) => !g || !b ? 0 : g === 2 ? (b === 2 ? 50 : 25) : (b === 2 ? 25 : 13);
  return {
    CRS_AGE: [['family.spouseClassification', 'person.ageYears'], CLASSES.flatMap(c => range(0, 120).map(a => row([c, a], age(c, a))))],
    CRS_EDUCATION: [['family.spouseClassification', 'education.level'], CLASSES.flatMap(c => EDU.map((e, i) => row([c, e], (c === 'WITH_SPOUSE' ? eduM : eduS)[i])))],
    CRS_FIRST_LANGUAGE: [['family.spouseClassification', 'clb'], CLASSES.flatMap(c => range(0, 12).map(l => row([c, l], first(c, l))))],
    CRS_SECOND_LANGUAGE: [['clb'], range(0, 12).map(l => row([l], l < 5 ? 0 : l <= 6 ? 1 : l <= 8 ? 3 : 6))],
    CRS_CANADIAN_WORK: [['family.spouseClassification', 'work.canadianYears'], CLASSES.flatMap(c => range(0, 5).map(y => row([c, y], (c === 'WITH_SPOUSE' ? workM : workS)[y])))],
    CRS_HIGH_WAGE_WORK: [['work.highWageTier'], [row(['NONE'], 0), row(['TIER_130'], 20), row(['TIER_150'], 40), row(['TIER_200'], 70)]],
    CRS_HIGH_WAGE_OFFER: [['offer.highWageTier'], [row(['NONE'], 0), row(['TIER_130'], 50), row(['TIER_150'], 70), row(['TIER_200'], 100)]],
    CRS_SPOUSE_EDUCATION: [['spouse.education.level'], EDU.map((e, i) => row([e], [0, 2, 6, 7, 8, 9, 10, 10][i]))],
    CRS_SPOUSE_LANGUAGE: [['clb'], range(0, 12).map(l => row([l], l < 5 ? 0 : l <= 6 ? 1 : l <= 8 ? 3 : 5))],
    CRS_SPOUSE_WORK: [['spouse.canadianWorkYears'], range(0, 5).map(y => row([y], [0, 5, 7, 8, 9, 10][y]))],
    CRS_LANGUAGE_BAND: [['clb'], range(0, 12).map(l => row([l], l >= 9 ? 2 : l >= 7 ? 1 : 0))],
    CRS_EDUCATION_GROUP: [['education.level'], EDU.map((e, i) => row([e], i >= 5 ? 2 : i >= 2 ? 1 : 0))],
    CRS_CANADIAN_WORK_BAND: [['work.canadianYears'], range(0, 5).map(y => row([y], y >= 2 ? 2 : y >= 1 ? 1 : 0))],
    CRS_FOREIGN_WORK_BAND: [['work.foreignYears'], range(0, 3).map(y => row([y], y >= 3 ? 2 : y >= 1 ? 1 : 0))],
    CRS_TRANSFER_EDUCATION_LANGUAGE: [['educationGroup', 'languageBand'], range(0, 2).flatMap(g => range(0, 2).map(b => row([g, b], pair(g, b))))],
    CRS_TRANSFER_EDUCATION_CANADIAN_WORK: [['educationGroup', 'canadianWorkBand'], range(0, 2).flatMap(g => range(0, 2).map(b => row([g, b], pair(g, b))))],
    CRS_TRANSFER_FOREIGN_LANGUAGE: [['foreignWorkBand', 'languageBand'], range(0, 2).flatMap(g => range(0, 2).map(b => row([g, b], pair(g, b))))],
    CRS_TRANSFER_FOREIGN_CANADIAN_WORK: [['foreignWorkBand', 'canadianWorkBand'], range(0, 2).flatMap(g => range(0, 2).map(b => row([g, b], pair(g, b))))],
    CRS_TRADE_LANGUAGE_BAND: [['clb'], range(0, 12).map(l => row([l], l >= 7 ? 2 : l >= 5 ? 1 : 0))],
    CRS_TRANSFER_TRADE: [['additional.tradeCertificate', 'tradeLanguageBand'], [false, true].flatMap(t => range(0, 2).map(b => row([t, b], !t || !b ? 0 : b === 2 ? 50 : 25)))],
    CRS_ADDITIONAL_SIBLING: [['additional.sibling'], [row([false], 0), row([true], 15)]],
    CRS_FRENCH_BAND: [['clb'], range(0, 12).map(l => row([l], l >= 7 ? 1 : 0))],
    CRS_ENGLISH_BAND: [['clb'], range(0, 12).map(l => row([l], l >= 5 ? 1 : 0))],
    CRS_ADDITIONAL_FRENCH: [['frenchBand', 'englishBand'], [row([0, 0], 0), row([0, 1], 0), row([1, 0], 25), row([1, 1], 50)]],
    CRS_ADDITIONAL_CANADIAN_EDUCATION: [['additional.canadianEducation'], [row(['NONE'], 0), row(['ONE_TWO'], 15), row(['THREE_PLUS'], 30)]],
    CRS_ADDITIONAL_NOMINATION: [['additional.eeNomination'], [row([false], 0), row([true], 600)]],
  };
}
export const CRS_CAPS = { CRS_SECOND_LANGUAGE_CAP_WITH_SPOUSE: 22, CRS_SECOND_LANGUAGE_CAP_WITHOUT_SPOUSE: 24, CRS_LMIF_CAP_WITH_SPOUSE: 140, CRS_LMIF_CAP_WITHOUT_SPOUSE: 150, CRS_SPOUSE_CAP: 40, CRS_TRANSFER_EDUCATION_CAP: 50, CRS_TRANSFER_FOREIGN_CAP: 50, CRS_TRANSFER_TOTAL_CAP: 100, CRS_ADDITIONAL_CAP: 600, CRS_MAX_TOTAL_WITH_SPOUSE: 1270, CRS_MAX_TOTAL_WITHOUT_SPOUSE: 1270 };
export const WAGE_ROWS = [{ nocCode: '21231', tier: 'TIER_200' }, { nocCode: '72401', tier: 'TIER_130' }, { nocCode: '31102', tier: 'TIER_150' }];
const leaf = (id, path, operator, expected, src, dateBasis = 'PROFILE') => ({ obligationId: id, expression: { operator, normalizedFactPath: path, expected, dateBasis }, sourceIds: [src], sourceLocator: 'test-only ' + id, scopeLimitations: [] });
const node = (id, operator, nodeIds, src) => ({ obligationId: id, expression: { operator, nodeIds }, sourceIds: [src], sourceLocator: 'test-only ' + id, scopeLimitations: [] });
async function finish(b) {
  const required = b.obligations.map(o => o.obligationId);
  const payload = { schemaVersion: '2.0.0', ...b, requiredObligationIds: required, obligationManifestHash: await jcsHash([...required].sort()), dependencyBundleHashes: [], engineCompatibility: [ENGINE], independentFixtureHash: await sha256Hex('TEST_ONLY fixture ' + b.family + ' ' + b.program.programId) };
  return { payload, hash: await jcsHash(payload) };
}
export async function crsBundle(overrides = {}) {
  const tables = [];
  for (const [id, [dims, rows]] of Object.entries(crsTables())) tables.push(await table(id, dims, rows));
  const caps = Object.entries({ ...CRS_CAPS, ...(overrides.caps ?? {}) }).map(([capId, points]) => ({ capId, points, sourceId: 'SRC-TEST-CRS' }));
  return finish({ program: { programId: 'EE_CRS', streamId: null, phase: 'PROFILE' }, family: 'CRS', authorityClass: 'MINISTERIAL_INSTRUCTIONS', sourceIds: ['SRC-TEST-CRS'], rootObligationId: 'crs.scope', obligations: [leaf('crs.scope', 'education.level', 'PRESENT', true, 'SRC-TEST-CRS')], decisionTables: overrides.tables ? overrides.tables(tables) : tables, normalizerPolicies: [], caps, dataSets: [{ kind: 'HIGH_WAGE_BANDS', datasetId: 'wage-test', nocVersion: 'NOC2021-test', sourceId: 'SRC-TEST-CRS', rows: WAGE_ROWS, invitationLockPolicyId: 'lock-at-invitation-test' }] });
}
export async function programBundle(programId = 'EE_FSWP', mutate) {
  const s = 'SRC-TEST-PROGRAM';
  const obligations = [node('p.root', 'ALL', ['p.age', 'p.language', 'p.support'], s), leaf('p.age', 'person.ageYears', 'GE', 18, s), leaf('p.language', 'language.first.min', 'GE', 7, s), node('p.support', 'ANY', ['p.funds', 'p.offer'], s), leaf('p.funds', 'funds.satisfied', 'EQ', true, s), leaf('p.offer', 'offer.present', 'EQ', true, s)];
  const b = { program: { programId, streamId: null, phase: 'PROFILE' }, family: 'ELIGIBILITY', authorityClass: 'OFFICIAL_GUIDANCE', sourceIds: [s], rootObligationId: 'p.root', obligations, decisionTables: [], normalizerPolicies: [], caps: [], dataSets: [] };
  return finish(mutate ? mutate(b) : b);
}
export async function rcipBundle(programId) {
  const s = 'SRC-TEST-RCIP';
  return finish({ program: { programId, streamId: null, phase: 'APPLICATION' }, family: 'ELIGIBILITY', authorityClass: 'OFFICIAL_GUIDANCE', sourceIds: [s], rootObligationId: 'r.root', obligations: [node('r.root', 'ALL', ['r.rec'], s), leaf('r.rec', 'rcip.recommendationPresent', 'EQ', true, s, 'APPROVAL_TORONTO')], decisionTables: [], normalizerPolicies: [], caps: [], dataSets: [] });
}
export const NOC_ROWS = [
  { nocCode: '21231', teer: 1, officialTitle: 'Software engineers and designers (TEST_ONLY)', leadStatement: 'Research, design and develop software systems (TEST_ONLY).', mainDuties: [{ dutyId: '21231-d1', text: 'Design and develop software applications.' }, { dutyId: '21231-d2', text: 'Test and maintain software systems.' }], exclusions: [] },
  { nocCode: '72401', teer: 2, officialTitle: 'Heavy-duty equipment mechanics (TEST_ONLY)', leadStatement: 'Repair and maintain heavy equipment (TEST_ONLY).', mainDuties: [{ dutyId: '72401-d1', text: 'Repair heavy-duty equipment.' }], exclusions: [] },
];
export async function nocBundle() {
  const s = 'SRC-TEST-NOC';
  return finish({ program: { programId: 'NOC_2021', streamId: null, phase: 'PROFILE' }, family: 'NOC_CATALOG', authorityClass: 'OFFICIAL_GUIDANCE', sourceIds: [s], rootObligationId: 'noc.scope', obligations: [leaf('noc.scope', 'work.primaryNoc', 'PRESENT', true, s)], decisionTables: [], normalizerPolicies: [], caps: [], dataSets: [{ kind: 'NOC_CATALOG', datasetId: 'noc-test', version: 'NOC2021-test', sourceId: s, rows: NOC_ROWS }] });
}
