// v2.2 Gate 6 — proof of the outbox lease/settle compare-and-set (M2) on a real SQLite engine with forced interleaving.
// Miniflare does not interleave two scheduled dispatchers between "select due row" and "lease", so this test drives the
// production functions (lib/outbox-lease.ts, the exact drizzle queries the Worker runs) through drizzle's SQLite proxy
// driver over node:sqlite, with an artificial delay before every statement, and the real delivery_outbox DDL (0026).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import { drizzle } from 'drizzle-orm/sqlite-proxy';
import { leaseOutboxRow, settleOutboxRow } from '../../lib/outbox-lease.ts';

const ddl = readFileSync('drizzle/0026_v22_runtime.sql', 'utf8').split('--> statement-breakpoint').map(s => s.trim()).filter(s => /^CREATE (TABLE|INDEX) delivery_outbox/.test(s) || /^CREATE INDEX delivery_outbox/.test(s));
const sleep = ms => new Promise(r => setTimeout(r, ms));
function engine(delay) {
  const sqlite = new DatabaseSync(':memory:', { enableForeignKeyConstraints: false });
  for (const s of ddl) sqlite.exec(s);
  const statements = [];
  const db = drizzle(async (query, params, method) => {
    await sleep(delay());                                   // artificial delay → interleaving between dispatchers
    statements.push(query);
    const stmt = sqlite.prepare(query);
    if (method === 'run') { stmt.run(...params); return { rows: [] }; }
    const rows = stmt.all(...params).map(r => Object.values(r));
    return { rows: method === 'get' ? rows[0] : rows };
  });
  return { sqlite, db, statements };
}
const insert = (sqlite, id) => sqlite.prepare("INSERT INTO delivery_outbox(event_id,case_id,kind,business_key,payload_encrypted,next_at_ms,created_at) VALUES(?,?,'PAYMENT_NOTICE',?,'x',0,'2026-11-15T00:00:00Z')").run(id, 'case-1', 'bk-' + id);
const row = (sqlite, id) => ({ ...sqlite.prepare('SELECT state,fence,attempts FROM delivery_outbox WHERE event_id=?').get(id) });

test('the DDL under test is the real 0026 delivery_outbox table', () => {
  assert.ok(ddl.some(s => s.startsWith('CREATE TABLE delivery_outbox')));
});
test('two dispatchers that observed the same PENDING row: exactly one lease wins, the second gets null', async () => {
  const { sqlite, db, statements } = engine(() => 5);
  insert(sqlite, 'e1');
  const seen = row(sqlite, 'e1');                           // both dispatchers read state=PENDING, fence=0 before either leases
  const [a, b] = await Promise.all([
    leaseOutboxRow(db, 'e1', seen.state, seen.fence, Date.now(), 60000),
    leaseOutboxRow(db, 'e1', seen.state, seen.fence, Date.now(), 60000),
  ]);
  assert.equal([a, b].filter(Boolean).length, 1, 'one winner');
  assert.equal([a, b].filter(x => x === null).length, 1, 'the second request fails the CAS');
  assert.deepEqual(row(sqlite, 'e1'), { state: 'LEASED', fence: 1, attempts: 1 }, 'attempts counted once, fence bumped once');
  assert.ok(statements.every(s => /"fence" = \?/.test(s) && /"state" = \?/.test(s)), 'every lease statement carries the state+fence guard');
});
test('random interleaving, 25 dispatchers × 20 rows: every row is leased exactly once', async () => {
  const { sqlite, db } = engine(() => Math.floor(Math.random() * 8));
  const ids = Array.from({ length: 20 }, (_, i) => 'r' + i); ids.forEach(id => insert(sqlite, id));
  const snapshot = Object.fromEntries(ids.map(id => [id, row(sqlite, id)]));
  const wins = new Map(ids.map(id => [id, 0]));
  await Promise.all(Array.from({ length: 25 }, async () => { for (const id of [...ids].sort(() => Math.random() - 0.5)) { const r = await leaseOutboxRow(db, id, snapshot[id].state, snapshot[id].fence, Date.now(), 60000); if (r) wins.set(id, wins.get(id) + 1); } }));
  assert.ok([...wins.values()].every(n => n === 1), JSON.stringify(Object.fromEntries(wins)));
});
test('a stale dispatcher (lease expired, row re-leased) cannot settle; the current holder can', async () => {
  const { sqlite, db } = engine(() => 2);
  insert(sqlite, 'e2');
  const a = await leaseOutboxRow(db, 'e2', 'PENDING', 0, Date.now(), 1);
  sqlite.prepare("UPDATE delivery_outbox SET state='AMBIGUOUS',lease_until_ms=0 WHERE event_id='e2'").run(); // reclaimExpired
  const b = await leaseOutboxRow(db, 'e2', 'AMBIGUOUS', a.fence, Date.now(), 60000);
  assert.equal(b.fence, a.fence + 1);
  assert.equal(await settleOutboxRow(db, 'e2', a.fence, { state: 'DELIVERED', providerReference: 'late' }), false, 'stale fence refused');
  assert.equal(row(sqlite, 'e2').state, 'LEASED', 'the stale settle changed nothing');
  assert.equal(await settleOutboxRow(db, 'e2', b.fence, { state: 'DELIVERED', providerReference: 'ok' }), true);
  assert.equal(await settleOutboxRow(db, 'e2', b.fence, { state: 'RETRY' }), false, 'a settled row cannot be settled again');
  assert.equal(row(sqlite, 'e2').state, 'DELIVERED');
});
