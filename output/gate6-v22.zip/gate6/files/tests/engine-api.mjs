// Engine contract, step 1 (STOP GATE 1) on a real D1 database (Miniflare, all 23 migrations, no mocks of D1):
// migration objects, single writer + assessment_history, determinism by inputs_hash, verified-only documents,
// concurrent identical payloads, case_state_view, derived TEER/experience with no manual fields, one job source
// and pathway projection, CRS/eligibility prefill, and the shadow calculation with explained differences.
import assert from 'node:assert/strict';
import { seedOfficeManager } from './v22/office-fixture.mjs';
import {createRequire} from 'node:module';
import {readFile,readdir} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {intakeSessionFixture} from './intake-session-fixture.mjs';
import {signIntake} from './signed-intake-fixture.mjs';
const require=createRequire(import.meta.url);
const {Miniflare}=createRequire(require.resolve('wrangler/package.json'))('miniflare');
const files=await readdir('dist/server',{recursive:true});
const base='http://canada-desk.test',admin={'oai-authenticated-user-id':'admin-1','oai-authenticated-user-email':'admin@example.test'},staffUser={'oai-authenticated-user-id':'staff-1','oai-authenticated-user-email':'staff@example.test'};
const mf=new Miniflare({modules:['index.js',...files.filter(f=>f!=='index.js'&&f.endsWith('.js'))].map(f=>({type:'ESModule',path:path.resolve('dist/server',f)})),modulesRoot:path.resolve('dist/server'),compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:{DB:'engine-db'},r2Buckets:['BUCKET'],bindings:{TRUST_SITES_IDENTITY_HEADERS:'1',OFFICE_ADMIN_EMAIL:'admin@example.test',APP_SECRET:'a'.repeat(64)},outboundService:async req=>{const u=new URL(req.url);if(u.hostname==='api.resend.com')return Response.json({id:'m1'});return new Response('blocked',{status:599});}});
const send=async(p,method='GET',body,headers={})=>{if(p==='/api/intake'&&method==='POST'&&body)body=await signIntake(mf,base,body,headers);return mf.dispatchFetch(base+p,{method,headers:{...(body?{'content-type':'application/json'}:{}),...headers},body:body?JSON.stringify(body):undefined});};
const json=async(r,status=200)=>{const t=await r.text();assert.equal(r.status,status,t);return t?JSON.parse(t):null;};
const now=new Date(),ym=back=>{const d=new Date(Date.UTC(now.getUTCFullYear(),now.getUTCMonth()-back,1));return d.toISOString().slice(0,7);};
const intake=async(email,phone,name,details)=>send('/api/intake','POST',{requestId:randomUUID(),profile:{fullName:name,phone,email,consent:true,occupation:'Welder',noc:'72106',education:'bachelor',englishMin:7,englishDate:new Date(Date.now()-30*86400000).toISOString().slice(0,10)},details,consentVersion:'intake-2026-11-v4',legalAuthorization:true},await intakeSessionFixture(mf,email,'a'.repeat(64),{}));
try{
 const db=await mf.getD1Database('DB');
 for(const file of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())for(const s of (await readFile('drizzle/'+file,'utf8')).split('--> statement-breakpoint').map(s=>s.trim()).filter(Boolean))await db.prepare(s).run();await seedOfficeManager(db,'admin-1');
 const objects=(await db.prepare("select type,name from sqlite_master where name in ('assessment_history','decision_audit','case_outcomes','rules_versions','draw_thresholds','pnp_streams','case_state_view','idx_client_cases_payload_hash')").all()).results.map(r=>r.type+':'+r.name).sort();
 assert.deepEqual(objects,['index:idx_client_cases_payload_hash','table:assessment_history','table:case_outcomes','table:decision_audit','table:draw_thresholds','table:pnp_streams','table:rules_versions','view:case_state_view']);

 // Client intake: engine writes candidates.assessment + its assessment_history row; pathway is projected from details.
 const jobsClient=[{title:'Welder',employer:'Shop',country:'Yemen',start:ym(30),end:ym(1),weekly_hours:40}];
 assert.equal((await intake('nohours@example.test','+15551110001','No Hours',{category:'trades',pathway:'fstp',jobs:[{...jobsClient[0],weekly_hours:null}]})).status,400,'a dated client job needs weekly hours');
 assert.equal((await send('/api/intake','POST',{requestId:randomUUID(),profile:{fullName:'Profile Jobs',phone:'+15551110009',email:'pj@example.test',consent:true,jobs:jobsClient},details:{},consentVersion:'intake-2026-11-v4',legalAuthorization:true},await intakeSessionFixture(mf,'pj@example.test','a'.repeat(64),{}))).status,400,'client jobs only in details (one source)');
 const r1=await json(await intake('engine1@example.test','+15551110002','Engine One',{category:'trades',pathway:'fstp',jobs:jobsClient,birthDate:'1994-05-20',marital:'single'}),201);
 const c1=await db.prepare('select id,assessment,pathway,profile from candidates where reference=?').bind(r1.reference).first();
 const a1=JSON.parse(c1.assessment);assert.equal(c1.pathway,'fstp','candidates.pathway = details.pathway');
 assert.equal(a1.derived.teer,2,'TEER 2 derived from NOC 72106 (second digit)');assert.equal(a1.derived.experience3,30,'30 FTE months from the job (40 h capped at 30)');assert.match(a1.inputsHash,/^[0-9a-f]{64}$/);
 const h1=await db.prepare('select inputs_hash,engine_version,rules_version,output_json,explanation_trace_json from assessment_history where candidate_id=?').bind(c1.id).all();
 assert.equal(h1.results.length,1);assert.equal(h1.results[0].inputs_hash,a1.inputsHash);assert.equal(h1.results[0].output_json,c1.assessment,'history output = stored assessment');assert.ok(JSON.parse(h1.results[0].explanation_trace_json).some(t=>t.rule_id==='derived_teer'&&t.output===2));
 assert.equal('teer' in JSON.parse(c1.profile)||'experience3' in JSON.parse(c1.profile),false,'no manual TEER or experience fields stored');

 // Office-created file: jobs required, manual TEER/experience ignored, derived from NOC + jobs.
 const officeJobs=[{title:'Cook',employer:'Hotel',country:'Canada',start:ym(23),end:'',weekly_hours:35}];
 assert.equal((await send('/api/candidates','POST',{fullName:'Office NoJobs',phone:'+15552220001',consent:true},admin)).status,400,'office file without jobs is rejected');
 const o1=await json(await send('/api/candidates','POST',{fullName:'Office Engine',phone:'+15552220002',consent:true,noc:'63200',teer:0,experience3:36,experience10:120,jobs:officeJobs},admin),201);
 const oc=await db.prepare('select id,assessment,profile from candidates where id=?').bind(o1.id).first(),oa=JSON.parse(oc.assessment);
 assert.equal(oa.derived.teer,3,'TEER 3 from NOC 63200, not the posted 0');assert.equal(oa.derived.experience3,24,'24 months incl. current month');assert.equal(oa.derived.canadianMonths10,24);
 assert.equal(['teer','experience3','experience10'].some(k=>k in JSON.parse(oc.profile)),false,'posted manual fields are not stored');

 // Pathway: staff cannot edit a client file's pathway; office files can be set to a registry id.
 const v1=(await db.prepare('select version from candidates where id=?').bind(c1.id).first()).version;
 assert.equal((await send('/api/candidates/'+c1.id,'PATCH',{version:v1,pathway:'pnp'},admin)).status,400,'client pathway is a projection');
 const ov=(await db.prepare('select version from candidates where id=?').bind(o1.id).first()).version;
 await json(await send('/api/candidates/'+o1.id,'PATCH',{version:ov,pathway:'fstp'},admin));
 assert.equal((await db.prepare('select pathway from candidates where id=?').bind(o1.id).first()).pathway,'fstp');

 // A write that does not touch engine inputs gives the same inputs_hash, so no duplicate evaluation is recorded
 // (Gate 2: identical inputs + engine + rules version = no new history row). Determinism of the output itself is
 // checked by the two explicit shadow runs below.
 await json(await send('/api/candidates/'+c1.id,'PATCH',{version:v1,assignedTo:'QA'},admin));
 const hist=(await db.prepare('select inputs_hash,output_json from assessment_history where candidate_id=? order by computed_at').bind(c1.id).all()).results;
 assert.equal(hist.length,1,'same inputs -> no duplicate evaluation');

 // Unverified documents never change the assessment; verification does (through the engine).
 const before=(await db.prepare('select assessment from candidates where id=?').bind(c1.id).first()).assessment;
 const form=new FormData();form.append('category','resume');form.append('file',new File([new Uint8Array([0x25,0x50,0x44,0x46,0x2d,0x31,0x2e,0x34,10])],'cv.pdf',{type:'application/pdf'}));
 const reqUp=new Request(base+'/api/candidates/'+c1.id+'/documents',{method:'POST',headers:admin,body:form});
 assert.equal((await mf.dispatchFetch(reqUp.url,{method:'POST',headers:Object.fromEntries(reqUp.headers),body:Buffer.from(await reqUp.arrayBuffer())})).status,201);
 assert.equal((await db.prepare('select assessment from candidates where id=?').bind(c1.id).first()).assessment,before,'an unverified document does not change the assessment');
 const doc=await db.prepare("select id from documents where candidate_id=? and category='resume'").bind(c1.id).first();
 await json(await send('/api/documents/'+doc.id,'PATCH',{verified:true},admin));
 const after=JSON.parse((await db.prepare('select assessment from candidates where id=?').bind(c1.id).first()).assessment);
 assert.ok(!after.missingDocuments.includes('resume')&&JSON.parse(before).missingDocuments.includes('resume'),'verified resume leaves missingDocuments');

 // Concurrency: identical payload submitted twice at once -> exactly one candidate and one client_cases row.
 const raceDetails={category:'visit',pathway:'visitor_visa'};const raceProfile={fullName:'Race Same',phone:'+15553330001',email:'race@example.test',consent:true};
 const cookie=await intakeSessionFixture(mf,'race@example.test','a'.repeat(64),{});
 const raced=await Promise.all([1,2].map(()=>send('/api/intake','POST',{requestId:randomUUID(),profile:raceProfile,details:raceDetails,consentVersion:'intake-2026-11-v4',legalAuthorization:true},cookie)));
 assert.equal(raced.filter(r=>r.status===201).length,1,'one accepted');
 assert.equal((await db.prepare("select count(*) n from candidates where json_extract(profile,'$.email')='race@example.test'").first()).n,1);
 const ph=(await db.prepare("select payload_hash from client_cases c join candidates k on k.id=c.candidate_id where json_extract(k.profile,'$.email')='race@example.test'").first()).payload_hash;
 await assert.rejects(db.prepare("insert into client_cases (candidate_id,request_id,payload_hash,access_hash,access_encrypted,inbox,details,instructions,requested_documents,consent_version,submitted_at,version,follow_up_date,lmia_stream,lmia_complete_date,lmia_evidence_id,otp_only) values (?,?,?,?,?,'pending','{}','','[]','v','2026-01-01',1,'','','','',0)").bind(o1.id,randomUUID(),ph,randomUUID(),'x').run(),/UNIQUE constraint failed: client_cases\.payload_hash/,'unique index on client_cases.payload_hash');

 // case_state_view: every file has a unified state; none is unknown (office file without a client request included).
 const st=await json(await send('/api/office/engine/state','GET',undefined,admin));
 const total=(await db.prepare('select count(*) n from candidates').first()).n;
 assert.equal(st.files,total);assert.equal(st.rows.some(r=>r.unified_state==='unknown'),false);
 assert.equal(st.rows.find(r=>r.candidate_id===o1.id).unified_state,'new','office file without client_cases resolves from status');
 assert.equal(st.rows.find(r=>r.candidate_id===c1.id).unified_state,'awaiting_intake_review');

 // Prefill: CRS and eligibility forms open filled from central records (exact values only).
 const crs=await json(await send('/api/candidates/'+c1.id+'/crs','GET',undefined,admin));
 const age=new Date().getUTCFullYear()-1994-((new Date().toISOString().slice(5,10)<'05-20')?1:0);
 assert.equal(crs.inputs,null);assert.equal(crs.prefill.values.age,age);assert.equal(crs.prefill.values.education,'bachelor');assert.equal(crs.prefill.values.withSpouse,false);assert.equal(crs.prefill.values.firstLanguage,'english');assert.equal(crs.prefill.values.canadianYears,0);assert.ok(crs.prefill.origin.age);
 const el=await json(await send('/api/candidates/'+c1.id+'/eligibility','GET',undefined,admin));
 assert.equal(el.prefill.values.noc,'72106');assert.equal(el.prefill.values.fswYears10,2);assert.equal(el.prefill.values.education,'bachelor');

 // Shadow: history only, candidates.assessment untouched; differences explained; tampered output flagged.
 await json(await send('/api/office','POST',{action:'member',name:'Staff',email:'staff@example.test',active:true},admin));
 assert.equal((await send('/api/office/engine/shadow','POST',undefined,staffUser)).status,403,'shadow is admin-only');
 // Legacy file: stored assessment computed when its jobs gave 24 months; its profile still carries the legacy
 // manual fields (24). Jobs are then shortened to 6 months, so the engine's derived value differs.
 const leg=await json(await send('/api/candidates','POST',{fullName:'Legacy Manual',phone:'+15554440001',consent:true,noc:'72106',englishMin:6,englishDate:new Date(Date.now()-30*86400000).toISOString().slice(0,10),jobs:[{title:'Welder',employer:'X',country:'Yemen',start:ym(24),end:ym(1),weekly_hours:40}]},admin),201);
 await db.prepare("update candidates set profile=json_set(profile,'$.teer',2,'$.experience3',24,'$.experience10',24,'$.jobs',json(?)) where id=?").bind(JSON.stringify([{title:'Welder',employer:'X',country:'Yemen',start:ym(6),end:ym(1),weekly_hours:40,fullTime:false,schedule:'unknown',duties:''}]),leg.id).run();
 const tampered=await json(await send('/api/candidates','POST',{fullName:'Tampered Row',phone:'+15554440002',consent:true,jobs:officeJobs},admin),201);
 await db.prepare("update candidates set assessment=json_set(assessment,'$.completeness',99) where id=?").bind(tampered.id).run();
 const storedBefore=(await db.prepare('select id,assessment from candidates order by id').all()).results;
 const histBefore=(await db.prepare('select count(*) n from assessment_history').first()).n;
 const sh=await json(await send('/api/office/engine/shadow','POST',undefined,admin));
 assert.equal(sh.summary.files,total+2);assert.equal((await db.prepare('select count(*) n from assessment_history').first()).n,histBefore+total+2,'one shadow history row per file');
 assert.deepEqual((await db.prepare('select id,assessment from candidates order by id').all()).results,storedBefore,'shadow never touches candidates.assessment');
 const legRow=sh.rows.find(r=>r.candidateId===leg.id);assert.equal(legRow.status,'explained');assert.deepEqual(legRow.causes,['legacy_manual_experience_teer']);assert.ok(legRow.differences.some(d=>/rcip check 1: pass -> fail/.test(d)),JSON.stringify(legRow.differences));
 assert.equal(sh.rows.find(r=>r.candidateId===tampered.id).status,'unexplained','an output no legacy variant reproduces is flagged');
 assert.equal(sh.rows.find(r=>r.candidateId===o1.id).status,'identical');
 assert.ok(sh.causes.legacy_manual_experience_teer);
 // Shadow twice on unchanged inputs: same inputs_hash and identical output per file (determinism).
 const sh2=await json(await send('/api/office/engine/shadow','POST',undefined,admin));
 for(const r of sh2.rows){const prev=sh.rows.find(x=>x.candidateId===r.candidateId);assert.equal(r.inputsHash,prev.inputsHash);const outs=(await db.prepare('select output_json from assessment_history where id in (?,?)').bind(prev.historyId,r.historyId).all()).results;assert.equal(outs[0].output_json,outs[1].output_json);}
 console.log('Engine API (step 1) passed: 6 tables + view + unique index; engine-written assessment with history and inputs_hash; derived TEER/experience (IRCC 30 h cap) with no manual fields; one job source; pathway projection; determinism; verified-only documents; concurrent identical payload -> one row; unique payload_hash; case_state_view without unknown; CRS/eligibility prefill; shadow explained/unexplained/identical, admin-only, history-only.');
}finally{await mf.dispose();}
