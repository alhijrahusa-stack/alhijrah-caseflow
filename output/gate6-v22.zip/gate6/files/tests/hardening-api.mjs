// Hardening suite: security headers, purpose-separated keys with legacy compatibility, ai_analysis_consent,
// identity-conflict flagging and the client-portal lock on office-assessed fields.
// Runs the built Worker in Miniflare with synthetic records. No provider is called.
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,readdir,mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {intakeSessionFixture} from './intake-session-fixture.mjs';
import {signIntake} from './signed-intake-fixture.mjs';
const require=createRequire(import.meta.url);
const {Miniflare}=createRequire(require.resolve('wrangler/package.json'))('miniflare');
const files=await readdir('dist/server',{recursive:true});
const modules=['index.js',...files.filter(f=>f!=='index.js'&&f.endsWith('.js'))].map(f=>({type:'ESModule',path:path.resolve('dist/server',f)}));
const LEGACY='a'.repeat(64),base='http://canada-desk.test',admin={'oai-authenticated-user-id':'admin-1','oai-authenticated-user-email':'admin@example.test'};
const state=await mkdtemp(path.join(tmpdir(),'canada-hardening-'));
const start=bindings=>new Miniflare({modules,modulesRoot:path.resolve('dist/server'),compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:{DB:'hardening-db'},r2Buckets:['BUCKET'],d1Persist:path.join(state,'d1'),r2Persist:path.join(state,'r2'),bindings:{TRUST_SITES_IDENTITY_HEADERS:'1',OFFICE_ADMIN_EMAIL:'admin@example.test',APP_SECRET:LEGACY,...bindings}});
const send=async(mf,p,method='GET',body,headers={})=>{if(p==='/api/intake'&&method==='POST'&&body)body=await signIntake(mf,base,body,headers);return mf.dispatchFetch(base+p,{method,headers:{...(body?{'content-type':'application/json'}:{}),...headers},body:body?JSON.stringify(body):undefined});};
const json=async(r,status=200)=>{const t=await r.text();assert.equal(r.status,status,t);return t?JSON.parse(t):null;};
const session=r=>(r.headers.get('set-cookie')||'').match(/alh_client_session=([a-f0-9]{64})/)?.[1];
const intake=async(mf,email,fullName,phone,requestId=randomUUID())=>send(mf,'/api/intake','POST',{requestId,profile:{fullName,phone,email,consent:true},details:{},consentVersion:'intake-2026-11-v4',legalAuthorization:true},await intakeSessionFixture(mf,email,LEGACY,{}));
try{
 // ---------- Phase 1: legacy APP_SECRET only ----------
 let mf=start({});let legacyRequest,legacyReceipt,legacyCaseId;
 try{
  const db=await mf.getD1Database('DB');
  for(const file of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())for(const s of (await readFile('drizzle/'+file,'utf8')).split('--> statement-breakpoint').map(s=>s.trim()).filter(Boolean))await db.prepare(s).run();
  for(const p of ['/staff/login','/client','/apply']){const r=await send(mf,p);await r.arrayBuffer();assert.equal(r.headers.get('x-frame-options'),'SAMEORIGIN',p);assert.match(r.headers.get('content-security-policy')||'',/frame-ancestors 'self'/,p);}
  legacyRequest=randomUUID();const r=await intake(mf,'legacy@example.test','Legacy Client','+15550002000',legacyRequest);legacyReceipt=await json(r,201);
  await json(await send(mf,'/api/client/password','POST',{password:'legacy synthetic passphrase 42'},{cookie:'alh_client_session='+session(r)}));
  const row=await db.prepare("select candidate_id,access_encrypted from client_cases where request_id=?").bind(legacyRequest).first();legacyCaseId=row.candidate_id;
  assert.ok(!row.access_encrypted.startsWith('v2:'),'legacy ciphertext has no version prefix');
 }finally{await mf.dispose();}

 // ---------- Phase 2: purpose-separated keys configured ----------
 mf=start({VAULT_ENCRYPTION_KEY:'b'.repeat(64),SIGNING_SECRET:'signing-secret-for-tests-0123456789',PASSWORD_PEPPER:'pepper-for-tests-0123456789'});
 try{
  const db=await mf.getD1Database('DB');
  // Legacy data still decrypts (idempotent replay returns the stored access code) and legacy receipt links still verify.
  const replay=await json(await intake(mf,'legacy@example.test','Legacy Client','+15550002000',legacyRequest));
  assert.equal(replay.accessCode,legacyReceipt.accessCode,'legacy AES ciphertext readable after VAULT_ENCRYPTION_KEY is set');
  await json(await send(mf,'/api/client/password/login','POST',{reference:legacyReceipt.reference,password:'legacy synthetic passphrase 42'}),200);
  const legacyPage=await (await send(mf,new URL(legacyReceipt.verificationUrl).pathname)).text();assert.ok(legacyPage.includes('إشعار استلام مسجّل'),'legacy receipt link verifies');
  // New data uses the vault key and the signing secret.
  let r=await intake(mf,'modern@example.test','Modern Client','+15550003000');const modern=await json(r,201);let cookie='alh_client_session='+session(r);
  const enc=await db.prepare("select access_encrypted from client_cases c join candidates p on p.id=c.candidate_id where p.reference=?").bind(modern.reference).first();
  assert.ok(enc.access_encrypted.startsWith('v2:'),'new ciphertext uses VAULT_ENCRYPTION_KEY');
  assert.notEqual(new URL(modern.verificationUrl).pathname.split('.')[1],new URL(legacyReceipt.verificationUrl).pathname.split('.')[1]);
  const modernPage=await (await send(mf,new URL(modern.verificationUrl).pathname)).text();assert.ok(modernPage.includes('إشعار استلام مسجّل'),'new receipt link verifies');
  const forged=new URL(modern.verificationUrl).pathname.replace(/\.[a-f0-9]{64}$/,'.'+'0'.repeat(64));assert.ok(!(await (await send(mf,forged)).text()).includes('إشعار استلام مسجّل'),'forged signature rejected');
  // New password hashes use PASSWORD_PEPPER and log in.
  r=await send(mf,'/api/client/password','POST',{password:'a long synthetic passphrase 42'},{cookie});await json(r);
  assert.equal((await send(mf,'/api/client','GET',undefined,{cookie})).status,401,'password change revokes earlier sessions');cookie='alh_client_session='+session(r);
  const hashOf=async ref=>JSON.parse((await db.prepare("select l.password_hash h from login_credentials l join candidates c on l.id='client:'||c.id where c.reference=?").bind(ref).first()).h);
  assert.equal((await hashOf(modern.reference)).p,2,'new hash uses PASSWORD_PEPPER');assert.equal((await hashOf(legacyReceipt.reference)).p,undefined,'legacy hash keeps APP_SECRET pepper');
  await json(await send(mf,'/api/client/password/login','POST',{reference:modern.reference,password:'a long synthetic passphrase 42'}));
  assert.equal((await send(mf,'/api/client/password/login','POST',{reference:modern.reference,password:'a wrong synthetic passphrase 42'})).status,401);

  // Client portal cannot overwrite office-assessed fields already recorded; blank ones can still be filled.
  await db.prepare("update candidates set profile=json_set(profile,'$.noc','21231','$.jobOffer','no') where reference=?").bind(modern.reference).run();
  const v=(await db.prepare('select version from candidates where reference=?').bind(modern.reference).first()).version;
  await json(await send(mf,'/api/client','PATCH',{version:v,profile:{noc:'85100',jobOffer:'yes',designated:'yes',occupation:'Dairy worker'},details:{}},{cookie}));
  const after=JSON.parse((await db.prepare('select profile from candidates where reference=?').bind(modern.reference).first()).profile);
  assert.deepEqual([after.noc,after.jobOffer,after.designated,after.occupation],['21231','no','yes','Dairy worker']);
  assert.equal((await send(mf,'/api/client','PATCH',{version:v+1,profile:{teer:0},details:{}},{cookie})).status,400,'TEER cannot be entered: it is derived from NOC');

  // ai_analysis_consent: staff-created cases need a recorded consent before any provider call.
  await json(await send(mf,'/api/office','POST',{action:'professional',provider:'anthropic',model:'synthetic-model',key:'sk-synthetic-not-a-real-key-0000'},admin));
  r=await send(mf,'/api/candidates','POST',{fullName:'Office Created',phone:'+15550004000',consent:true,jobs:[{title:'QA role',employer:'QA employer',country:'Yemen',start:'2024-01',end:'2024-12',weekly_hours:40}],occupation:'Synthetic'},admin);const staffCase=await json(r,201);
  const blocked=await json(await send(mf,`/api/candidates/${staffCase.id}/analysis`,'POST',undefined,admin),409);assert.match(blocked.error,/ai_analysis_consent/);
  await json(await send(mf,`/api/candidates/${staffCase.id}/ai-consent`,'POST',{consent:true},admin),400);
  await json(await send(mf,`/api/candidates/${staffCase.id}/ai-consent`,'POST',{consent:true,confirmed:true},admin));
  assert.equal((await db.prepare('select consent from document_ai_permissions where candidate_id=?').bind(staffCase.id).first()).consent,1);
  await json(await send(mf,`/api/candidates/${legacyCaseId}/ai-consent`,'POST',{consent:true,confirmed:true},admin));
  assert.equal((await send(mf,`/api/candidates/${staffCase.id}/ai-consent`,'POST',{consent:true,confirmed:true})).status,401,'staff only');

  // Identity conflict: same name+phone with a different verified email is refused and flagged for the office.
  await json(await intake(mf,'claimant@example.test','Modern Client','+15550003000'),409);
  const conflict=await db.prepare("select count(*) n from tasks where system_key like 'identity-conflict:%'").first();assert.equal(conflict.n,1);
  // Recovery with a mismatching email still goes only to the stored contact path and is flagged once.
  const before=(await db.prepare("select count(*) n from tasks where system_key like 'identity-conflict:%'").first()).n;
  await json(await send(mf,'/api/intake/recover','POST',{profile:{fullName:'Modern Client',phone:'+15550003000',email:'other@example.test'},channel:'email',locale:'ar',requestKey:randomUUID()}),503);
  assert.equal((await db.prepare("select count(*) n from tasks where system_key like 'identity-conflict:%'").first()).n,before+1);
 }finally{await mf.dispose();}
 console.log('Hardening API passed: security headers on pages, legacy APP_SECRET data and receipt links readable after key separation, VAULT_ENCRYPTION_KEY v2 ciphertext, SIGNING_SECRET receipts with forgery rejection, PASSWORD_PEPPER p:2 hashes and login, client lock on recorded NOC/TEER/offer, ai_analysis_consent gate and staff-only recording, identity-conflict flagging at intake and recovery. No provider was called.');
}finally{await rm(state,{recursive:true,force:true});}
