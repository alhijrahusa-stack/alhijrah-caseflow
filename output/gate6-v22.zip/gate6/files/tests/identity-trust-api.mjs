// Plain Cloudflare Workers deployment: Sites identity headers must be ignored, and the administrator
// is bootstrapped once with ADMIN_SETUP_TOKEN, then signs in with a password. Built Worker in Miniflare.
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,readdir} from 'node:fs/promises';
import path from 'node:path';
const require=createRequire(import.meta.url);
const {Miniflare}=createRequire(require.resolve('wrangler/package.json'))('miniflare');
const files=await readdir('dist/server',{recursive:true});
const modules=['index.js',...files.filter(f=>f!=='index.js'&&f.endsWith('.js'))].map(f=>({type:'ESModule',path:path.resolve('dist/server',f)}));
const base='https://canada-desk.test',TOKEN='t'.repeat(40),PASSWORD='a long synthetic admin passphrase 7';
const start=bindings=>new Miniflare({modules,modulesRoot:path.resolve('dist/server'),compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:{DB:'trust-db'},r2Buckets:['BUCKET'],bindings:{OFFICE_ADMIN_EMAIL:'Admin@Example.test',APP_SECRET:'a'.repeat(64),...bindings}});
const migrate=async mf=>{const db=await mf.getD1Database('DB');for(const file of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())for(const s of (await readFile('drizzle/'+file,'utf8')).split('--> statement-breakpoint').map(s=>s.trim()).filter(Boolean))await db.prepare(s).run();};
const spoof={'oai-authenticated-user-id':'attacker','oai-authenticated-user-email':'admin@example.test'};
const send=(mf,p,method='GET',body,headers={})=>mf.dispatchFetch(base+p,{method,headers:{...(body?{'content-type':'application/json'}:{}),...headers},body:body?JSON.stringify(body):undefined});
// 1. No setup token configured: spoofed headers are ignored and setup is unavailable.
let mf=start({});
try{
 await migrate(mf);
 assert.equal((await send(mf,'/api/office','GET',undefined,spoof)).status,401,'spoofed Sites headers rejected');
 assert.equal((await send(mf,'/api/candidates','GET',undefined,spoof)).status,401);
 assert.equal((await send(mf,'/api/staff/setup','POST',{token:TOKEN,password:PASSWORD})).status,404,'setup hidden without ADMIN_SETUP_TOKEN');
}finally{await mf.dispose();}
// 2. With ADMIN_SETUP_TOKEN: one-time password setup, then password sign-in.
mf=start({ADMIN_SETUP_TOKEN:TOKEN});
try{
 await migrate(mf);
 assert.equal((await send(mf,'/api/staff/setup','POST',{token:'x'.repeat(40),password:PASSWORD})).status,403,'wrong token');
 assert.equal((await send(mf,'/api/staff/setup','POST',{token:TOKEN,password:'short'})).status,400,'weak password');
 assert.equal((await send(mf,'/api/staff/setup','POST',{token:TOKEN,password:PASSWORD},{origin:'https://attacker.example'})).status,403,'cross-site');
 assert.equal((await send(mf,'/api/staff/setup','POST',{token:TOKEN,password:PASSWORD})).status,200);
 assert.equal((await send(mf,'/api/staff/setup','POST',{token:TOKEN,password:PASSWORD+'x'})).status,409,'single use');
 const login=await send(mf,'/api/staff/login','POST',{email:'admin@example.test',password:PASSWORD});
 assert.equal(login.status,200,await login.clone().text());
 const cookie=(login.headers.get('set-cookie')||'').split(';')[0];assert.match(cookie,/^alh_staff_session=[a-f0-9]{64}$/);
 const office=await send(mf,'/api/office','GET',undefined,{cookie});assert.equal(office.status,200);assert.equal((await office.json()).role,'MANAGER');
 assert.equal((await send(mf,'/api/staff/login','POST',{email:'admin@example.test',password:'wrong synthetic passphrase 77'})).status,401);
 console.log('Identity trust passed: Sites identity headers ignored on plain Workers, setup hidden without a token, wrong/weak/cross-site setup rejected, one-time admin password, password sign-in grants admin.');
}finally{await mf.dispose();}
