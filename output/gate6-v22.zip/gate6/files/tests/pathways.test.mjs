import {test} from 'node:test';
import assert from 'node:assert/strict';
import {categories,pathways,pathwaysOf,pathwayById,pathwayReadiness,suggestPathways,guideComplete,blankGuide,RULES_VERSION,pathwayConsistent} from '../lib/pathways.ts';
const blankProfile={fullName:'',phone:'',email:'',country:'',nationality:'',occupation:'',noc:'',teer:null,education:'unknown',eca:'unknown',englishMin:null,frenchMin:null,jobOffer:'unknown'};
const base={jobs:[],recommendationDate:'',industry:'unknown'};
test('registry: 5 categories with the specified sub-pathways, each with a target form and a verified official source',()=>{
 assert.deepEqual(categories.map(c=>c.id),['pr','work','study','visit','trades']);
 assert.deepEqual(pathwaysOf('pr').map(p=>p.id),['express_entry','pnp','aip','rcip','fcip']);
 assert.deepEqual(pathwaysOf('work').map(p=>p.id),['work_offer','job_search','work_other']);
 assert.deepEqual(pathwaysOf('study').map(p=>p.id),['admission','study_permit','pgwp']);
 assert.deepEqual(pathwaysOf('visit').map(p=>p.id),['visitor_visa','super_visa','eta']);
 assert.deepEqual(pathwaysOf('trades').map(p=>p.id),['fstp','field_work','regional_pr']);
 for(const p of pathways){assert.ok(p.targetForm.startsWith('intake:'),p.id);assert.ok(p.required.length>=2,p.id);if(p.engine!=='job_matching')assert.match(p.sourceURL,/^https:\/\/www\.canada\.ca\//,p.id);if(p.sourceURL)assert.match(p.effectiveDate,/^\d{4}-\d{2}-\d{2}$/,p.id);}
 assert.equal(RULES_VERSION,'pathways-2026-11-15');
});
test('FSTP shares the Express Entry engine; RCIP and FCIP are separate programs with their own rules',()=>{
 assert.equal(pathwayById('fstp').engine,'express_entry');assert.equal(pathwayById('express_entry').engine,'express_entry');
 assert.notEqual(pathwayById('rcip').sourceURL,pathwayById('fcip').sourceURL);
 assert.ok(pathwayById('fcip').required.some(r=>r.key==='frenchMin'),'FCIP requires French');assert.ok(!pathwayById('rcip').required.some(r=>r.key==='frenchMin'));
 const p={...blankProfile,nationality:'YEM',country:'YE',occupation:'Welder',education:'diploma',englishMin:6,jobOffer:'yes'};
 assert.match(pathwayReadiness('rcip',p,{...base,recommendationDate:'2026-12-31'}).notes.at(-1).en,/pilot/);
 assert.match(pathwayReadiness('rcip',p,{...base,recommendationDate:'2027-01-01'}).notes.at(-1).en,/permanent program/);
});
test('job matching is not a work permit application; Agri-Food Pilot is not offered as an open intake',()=>{
 assert.equal(pathwayById('job_search').engine,'job_matching');assert.equal(pathwayById('job_search').sourceURL,'');assert.match(pathwayById('job_search').noteEn,/not a work permit/);
 assert.match(pathwayById('field_work').noteEn,/closed on May 14, 2025/);assert.ok(!pathways.some(p=>/agri.?food pilot/i.test(p.en)));
 assert.notEqual(pathwayById('work_offer').engine,pathwayById('job_search').engine);
});
test('PGWP, visitor visa and eTA validate independently',()=>{
 for(const id of ['pgwp','visitor_visa','eta','admission'])assert.ok(pathwayById(id),id);
 const p={...blankProfile,nationality:'YEM',country:'YE'};
 assert.equal(pathwayReadiness('visitor_visa',p,base).status,'READY');assert.equal(pathwayReadiness('eta',p,base).status,'READY');
 const g=pathwayReadiness('pgwp',p,base);assert.equal(g.status,'INCOMPLETE_DATA');assert.ok(g.missing.some(m=>m.key==='language'),'PGWP needs language results');
 assert.equal(pathwayReadiness('admission',{...p,education:'secondary',englishMin:7},base).status,'READY');
});
test('missing data yields INCOMPLETE_DATA with the missing items and never a score',()=>{
 const r=pathwayReadiness('express_entry',{...blankProfile},base);assert.equal(r.status,'INCOMPLETE_DATA');assert.ok(r.missing.length>=5);assert.equal('score' in r,false);assert.equal('probability' in r,false);
 assert.equal(pathwayReadiness('nope',{...blankProfile},base).status,'INCOMPLETE_DATA');
 const full={...blankProfile,nationality:'YEM',country:'YE',occupation:'Engineer',education:'bachelor',englishMin:9,eca:'yes'};
 assert.equal(pathwayReadiness('express_entry',full,{...base,jobs:[{title:'Engineer',start:'2020-01'}]}).status,'READY');
});
test('not sure: guide completes and fixed rules suggest pathways',()=>{
 assert.equal(guideComplete(blankGuide),false);assert.equal(guideComplete({...blankGuide,goal:'visit'}),true);
 assert.deepEqual(suggestPathways({...blankGuide,goal:'visit'}).map(s=>s.id),['visitor_visa','eta','super_visa']);
 const t=suggestPathways({goal:'settle',offer:'no',trade:'yes',degree:'no',french:'no'}).map(s=>s.id);assert.ok(t.includes('fstp')&&t.includes('regional_pr'));assert.ok(!t.includes('express_entry'));
 const w=suggestPathways({goal:'work',offer:'no',trade:'no',degree:'yes',french:'no'}).map(s=>s.id);assert.ok(w.includes('job_search'));assert.ok(!w.includes('work_offer'));
 const f=suggestPathways({goal:'settle',offer:'yes',trade:'no',degree:'yes',french:'yes'}).map(s=>s.id);assert.ok(f.includes('fcip')&&f.includes('work_offer')&&f.includes('express_entry'));
 assert.deepEqual(suggestPathways({goal:'settle',offer:'no',trade:'no',degree:'yes',french:'no'}),suggestPathways({goal:'settle',offer:'no',trade:'no',degree:'yes',french:'no'}),'deterministic');
});
test('a pathway must belong to its category',()=>{
 assert.equal(pathwayConsistent({category:'pr',pathway:'express_entry'}),true);assert.equal(pathwayConsistent({category:'visit',pathway:'express_entry'}),false);assert.equal(pathwayConsistent({category:'not_sure',pathway:'fstp'}),true);
});
