// Automation suite: daily scheduled maintenance (security-record purge + passport-validity staff tasks),
// Server-Timing telemetry and staff-only intake triage. Built Worker in Miniflare; no provider is called.
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,readdir} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {intakeSessionFixture} from './intake-session-fixture.mjs';
import {signIntake} from './signed-intake-fixture.mjs';
const require=createRequire(import.meta.url);
const {Miniflare}=createRequire(require.resolve('wrangler/package.json'))('miniflare');
const files=await readdir('dist/server',{recursive:true});
const SECRET='a'.repeat(64),base='http://canada-desk.test',admin={'oai-authenticated-user-id':'admin-1','oai-authenticated-user-email':'admin@example.test'};
const mf=new Miniflare({modules:['index.js',...files.filter(f=>f!=='index.js'&&f.endsWith('.js'))].map(f=>({type:'ESModule',path:path.resolve('dist/server',f)})),modulesRoot:path.resolve('dist/server'),compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:{DB:'automation-db'},r2Buckets:['BUCKET'],bindings:{TRUST_SITES_IDENTITY_HEADERS:'1',OFFICE_ADMIN_EMAIL:'admin@example.test',APP_SECRET:SECRET}});
const send=async(p,method='GET',body,headers={})=>{if(p==='/api/intake'&&method==='POST'&&body)body=await signIntake(mf,base,body,headers);return mf.dispatchFetch(base+p,{method,headers:{...(body?{'content-type':'application/json'}:{}),...headers},body:body?JSON.stringify(body):undefined});};
const json=async(r,status=200)=>{const t=await r.text();assert.equal(r.status,status,t);return t?JSON.parse(t):null;};
try{
 const db=await mf.getD1Database('DB');
 for(const file of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())for(const s of (await readFile('drizzle/'+file,'utf8')).split('--> statement-breakpoint').map(s=>s.trim()).filter(Boolean))await db.prepare(s).run();
 const day=86400000,iso=ms=>new Date(ms).toISOString().slice(0,10),now=Date.now();
 const submit=async(email,fullName,phone,details)=>{const r=await json(await send('/api/intake','POST',{requestId:randomUUID(),profile:{fullName,phone,email,consent:true},details:{},consentVersion:'intake-2026-11-v4',legalAuthorization:true},await intakeSessionFixture(mf,email,SECRET,{})),201);/* Intake now blocks passports under 6 months; set the expiry afterwards to exercise maintenance on existing files. */await db.prepare("update client_cases set details=json_set(details,'$.passportExpiry',?) where candidate_id=(select id from candidates where reference=?)").bind(details.passportExpiry,r.reference).run();return r;};
 const soon=await submit('soon@example.test','Passport Soon','+15550005001',{passportExpiry:iso(now+60*day)});
 const expired=await submit('expired@example.test','Passport Expired','+15550005002',{passportExpiry:iso(now-5*day)});
 await submit('valid@example.test','Passport Valid','+15550005003',{passportExpiry:iso(now+800*day)});
 // Stale security records that maintenance must purge, plus a live one it must keep.
 await db.prepare('insert into rate_limits (key,count,expires) values (?,?,?),(?,?,?)').bind('old',1,Math.floor((now-day)/1000),'live',1,Math.floor((now+day)/1000)).run();
 const cand=(await db.prepare('select id from candidates limit 1').first()).id;
 await db.prepare('insert into client_sessions (token_hash,candidate_id,method,created_at,expires_at) values (?,?,?,?,?)').bind('stale-session',cand,'otp_email',now-30*day,now-29*day).run();

 // Telemetry header on every response.
 const page=await send('/apply');await page.arrayBuffer();assert.match(page.headers.get('server-timing')||'',/^app;dur=\d+$/);

 // Run the cron trigger twice: the second run must not duplicate tasks.
 const worker=await mf.getWorker();
 for(let i=0;i<2;i++){const r=await worker.scheduled({cron:'17 8 * * *',scheduledTime:new Date()});assert.equal(r.outcome,'ok');}
 const taskFor=async ref=>(await db.prepare("select t.title,t.priority,t.due_date from tasks t join candidates c on c.id=t.candidate_id where c.reference=? and t.system_key like 'passport-expiry:%'").bind(ref).all()).results;
 const soonTasks=await taskFor(soon.reference),expiredTasks=await taskFor(expired.reference);
 assert.equal(soonTasks.length,1,'one reminder per case and expiry, idempotent across runs');assert.equal(soonTasks[0].priority,'high');assert.equal(soonTasks[0].due_date,iso(now+60*day));
 assert.equal(expiredTasks.length,1);assert.match(expiredTasks[0].title,/مضى/);
 assert.equal((await db.prepare("select count(*) n from tasks where system_key like 'passport-expiry:%'").first()).n,2,'valid passports produce no task');
 assert.equal((await db.prepare("select count(*) n from rate_limits where key in ('old','live')").first()).n,1,'expired throttle purged, live one kept');
 assert.equal((await db.prepare("select count(*) n from client_sessions where token_hash='stale-session'").first()).n,0,'stale session purged');
 const logs=(await db.prepare("select code from operation_logs where operation='scheduled_maintenance'").all()).results;
 assert.equal(logs.length,2);assert.ok(!logs.some(l=>/@|Passport/.test(l.code)),'maintenance log has counts only, no personal data');

 // Staff-only triage in the New Clients queue.
 const queue=await json(await send('/api/new-clients?inbox=all&sort=triage','GET',undefined,admin));
 assert.ok(queue.items.every(i=>['attention','ready_for_review','incomplete'].includes(i.triage.level)));
 assert.equal(queue.items[0].reference,expired.reference,'critical (expired passport) first');
 const clientView=await json(await send('/api/new-clients','GET'),401);assert.ok(clientView.error);
 console.log('Automation API passed: Server-Timing telemetry, idempotent daily maintenance (expired throttles/sessions purged, live records kept, passport-validity staff tasks only, counts-only log), staff-only triage ordering with expired passport first. No message was sent and no provider was called.');
}finally{await mf.dispose();}
