// Gate 2 end to end on a real D1 database (Miniflare, all migrations), SHADOW_ONLY=true as in production:
// rule registry rows, Skills Card -> REPORTED -> evidence -> VERIFIED (staff) -> recompute -> preliminary updated,
// idempotent saves, access control, and candidates.assessment byte-identical throughout.
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,readdir} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {intakeSessionFixture} from './intake-session-fixture.mjs';
import {signIntake} from './signed-intake-fixture.mjs';
const require=createRequire(import.meta.url);
const {Miniflare}=createRequire(require.resolve('wrangler/package.json'))('miniflare');
const files=await readdir('dist/server',{recursive:true});
const base='http://canada-desk.test',admin={'oai-authenticated-user-id':'admin-1','oai-authenticated-user-email':'admin@example.test'};
const mf=new Miniflare({modules:['index.js',...files.filter(f=>f!=='index.js'&&f.endsWith('.js'))].map(f=>({type:'ESModule',path:path.resolve('dist/server',f)})),modulesRoot:path.resolve('dist/server'),compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:{DB:'gate2-db'},r2Buckets:['BUCKET'],bindings:{TRUST_SITES_IDENTITY_HEADERS:'1',OFFICE_ADMIN_EMAIL:'admin@example.test',APP_SECRET:'a'.repeat(64),SHADOW_ONLY:'true'},outboundService:async req=>{const u=new URL(req.url);if(u.hostname==='api.resend.com')return Response.json({id:'m1'});return new Response('blocked',{status:599});}});
const send=async(p,method='GET',body,headers={})=>{if(p==='/api/intake'&&method==='POST'&&body)body=await signIntake(mf,base,body,headers);return mf.dispatchFetch(base+p,{method,headers:{...(body?{'content-type':'application/json'}:{}),...headers},body:body?JSON.stringify(body):undefined});};
const json=async(r,status=200)=>{const t=await r.text();assert.equal(r.status,status,t);return t?JSON.parse(t):null;};
const session=r=>(r.headers.get('set-cookie')||'').match(/alh_client_session=([a-f0-9]{64})/)?.[1];
const now=new Date(),ym=back=>{const d=new Date(Date.UTC(now.getUTCFullYear(),now.getUTCMonth()-back,1));return d.toISOString().slice(0,7);};
const jobs=[{title:'Farm worker',employer:'Dairy',country:'Yemen',start:ym(30),end:ym(1),weekly_hours:40,duties:'feed cattle and operate milking machines'}];
const detailsOf=extra=>({category:'trades',pathway:'fstp',jobs,birthDate:'1994-05-20',marital:'single',...extra});
const intake=async(email,phone,name,details)=>send('/api/intake','POST',{requestId:randomUUID(),profile:{fullName:name,phone,email,consent:true,occupation:'Farm worker',noc:'84120',education:'secondary'},details,consentVersion:'intake-2026-11-v4',legalAuthorization:true},await intakeSessionFixture(mf,email,'a'.repeat(64),{}));
try{
 const db=await mf.getD1Database('DB');
 for(const file of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())for(const s of (await readFile('drizzle/'+file,'utf8')).split('--> statement-breakpoint').map(s=>s.trim()).filter(Boolean))await db.prepare(s).run();
 // Re-running the seed inserts nothing new (idempotent).
 for(const s of (await readFile('drizzle/0023_case_facts_rules_registry.sql','utf8')).split('--> statement-breakpoint').map(s=>s.trim()).filter(s=>s.startsWith('INSERT')))await db.prepare(s).run();
 const rules=(await db.prepare('select id,rule_key,effective_from,effective_until,source_url,payload_json from rules_versions order by id').all()).results;
 assert.deepEqual(rules.map(r=>r.id),['AIP-2026','CRS-2026-11-03','EE-2026-02-18','HIGH-WAGE-2026-11-03','LMIF-2026-11-03','RCIP-2026']);
 for(const r of rules){const p=JSON.parse(r.payload_json);assert.match(p.sourceSha256,/^[0-9a-f]{64}$/);assert.ok(r.source_url.startsWith('https://www.canada.ca/'));}
 assert.equal(JSON.parse(rules.find(r=>r.id==='LMIF-2026-11-03').payload_json).verification,'VERIFIED_OFFICIAL_TEXT');
 assert.equal(JSON.parse(rules.find(r=>r.id==='RCIP-2026').payload_json).verification,'UNVERIFIED_SECONDARY');

 // Empty Skills Card: no fact is created.
 const e=await json(await intake('empty@example.test','+15557770001','Empty Card',detailsOf({})),201);
 const eId=(await db.prepare('select id from candidates where reference=?').bind(e.reference).first()).id;
 assert.equal((await db.prepare('select count(*) n from case_fact_revisions where case_id=?').bind(eId).first()).n,0);
 const factItems=async id=>(await json(await send('/api/candidates/'+id+'/facts','GET',undefined,admin))).items.filter(f=>f.subjectId==='PRINCIPAL').sort((a,b)=>a.version-b.version);

 // Skills Card at intake -> REPORTED fact v1 and a preliminary that lists it as reported (not verified).
 const r1=await intake('skills@example.test','+15557770002','Skills Card',detailsOf({additionalSkills:'I drive tractors and milk 60 cows a day. Class C licence from Yemen.'}));
 const created=await json(r1,201),cookie='alh_client_session='+session(r1);
 const c=await db.prepare('select id,assessment,version from candidates where reference=?').bind(created.reference).first();
 const original=c.assessment;
 let facts=await factItems(c.id);
 assert.deepEqual(facts.map(f=>[f.version,f.status,f.source]),[[1,'REPORTED','client_skills_card']]);
 assert.equal(facts[0].value.text,'I drive tractors and milk 60 cows a day. Class C licence from Yemen.','text kept as written');
 let pre=await json(await send('/api/candidates/'+c.id+'/preliminary','GET',undefined,admin));
 assert.equal(pre.state,'available');assert.deepEqual(pre.preliminary.facts,{reported:['additional_skills'],verified:[],conflicted:[]});
 assert.ok(pre.preliminary.pathways.items.length<=3);assert.deepEqual(pre.preliminary.pathways.unavailable.map(u=>u.programId),['RCIP','AIP']);
 assert.equal(pre.preliminary.occupation.status,'MATCH_UNAVAILABLE','no official NOC catalog bundled, no model');
 assert.ok(['INCOMPLETE','INVALID_INPUT'].includes(pre.preliminary.crs.status),'CRS from the file alone is not a final score');

 // Same text saved again: no new fact version and no new history row (idempotent).
 const histBefore=(await db.prepare('select count(*) n from assessment_history where candidate_id=?').bind(c.id).first()).n;
 const v=c.version,details=detailsOf({additionalSkills:'I drive tractors and milk 60 cows a day. Class C licence from Yemen.'});
 await json(await send('/api/client','PATCH',{version:v,profile:{},details},{cookie}));
 assert.equal((await db.prepare('select count(*) n from case_fact_revisions where case_id=?').bind(c.id).first()).n,1,'no duplicate fact');
 assert.equal((await db.prepare('select count(*) n from assessment_history where candidate_id=?').bind(c.id).first()).n,histBefore,'no duplicate evaluation for identical inputs');

 // Client adds a skill: new REPORTED version, new evaluation.
 const v2=(await db.prepare('select version from candidates where id=?').bind(c.id).first()).version;
 await json(await send('/api/client','PATCH',{version:v2,profile:{},details:detailsOf({additionalSkills:'I drive tractors and milk 60 cows a day. Class C licence from Yemen. I can weld.'})},{cookie}));
 facts=await factItems(c.id);
 assert.deepEqual(facts.map(f=>[f.version,f.status]),[[1,'REPORTED'],[2,'REPORTED']]);
 assert.equal((await db.prepare('select count(*) n from assessment_history where candidate_id=?').bind(c.id).first()).n,histBefore+1);

 // Evidence workflow: only staff, only a verified document of the same file.
 assert.equal((await send('/api/candidates/'+c.id+'/facts','POST',{key:'additional_skills',documentId:'doc-x',outcome:'verified'},{cookie})).status,401,'clients cannot verify facts');
 const ins=(id,cid,verified)=>db.prepare("insert into documents (id,owner_id,candidate_id,name,object_key,size,mime,category,sha256,verified,created_at) select ?,owner_id,id,'licence.pdf','qa/licence.pdf',25,'application/pdf','other','abc',?,? from candidates where id=?").bind(id,verified,new Date().toISOString(),cid).run();
 await ins('doc-unverified',c.id,0);await ins('doc-other',eId,1);await ins('doc-licence',c.id,1);
 assert.equal((await send('/api/candidates/'+c.id+'/facts','POST',{key:'additional_skills',documentId:'doc-unverified',outcome:'verified'},admin)).status,409,'document must be verified first');
 assert.equal((await send('/api/candidates/'+c.id+'/facts','POST',{key:'additional_skills',documentId:'doc-other',outcome:'verified'},admin)).status,404,'document of another file');
 const reviewed=await json(await send('/api/candidates/'+c.id+'/facts','POST',{key:'additional_skills',documentId:'doc-licence',outcome:'verified'},admin));
 assert.equal(reviewed.fact.status,'VERIFIED');assert.equal(reviewed.fact.evidenceDocumentId,'doc-licence');assert.equal(reviewed.fact.version,3);
 pre=await json(await send('/api/candidates/'+c.id+'/preliminary','GET',undefined,admin));
 assert.deepEqual(pre.preliminary.facts,{reported:[],verified:['additional_skills'],conflicted:[]},'recomputed after verification');
 const history=await json(await send('/api/candidates/'+c.id+'/facts','GET',undefined,admin));
 assert.deepEqual(history.items.filter(f=>f.subjectId==='PRINCIPAL').map(f=>[f.version,f.status]),[[3,'VERIFIED'],[2,'REPORTED'],[1,'REPORTED']],'full history kept');

 // A later client edit is unverified again; clearing the card records UNKNOWN (history kept).
 const v3=(await db.prepare('select version from candidates where id=?').bind(c.id).first()).version;
 await json(await send('/api/client','PATCH',{version:v3,profile:{},details:detailsOf({additionalSkills:''})},{cookie}));
 facts=await factItems(c.id);
 assert.deepEqual({version:facts.at(-1).version,status:facts.at(-1).status},{version:4,status:'UNKNOWN'});
 assert.equal((await db.prepare('select count(*) n from case_facts').first()).n,0,'legacy table frozen and unused');

 // Gate 1 preserved: SHADOW_ONLY never touched candidates.assessment.
 assert.equal((await db.prepare('select assessment from candidates where id=?').bind(c.id).first()).assessment,original,'candidates.assessment byte-identical');
 const latest=JSON.parse((await db.prepare('select output_json from assessment_history where candidate_id=? order by computed_at desc limit 1').bind(c.id).first()).output_json);
 assert.equal(latest.engineVersion,'case-engine-1.1.0');assert.ok(latest.preliminary);
 console.log('Gate 2 API passed: 6 source-linked rules seeded idempotently; Skills Card -> REPORTED -> verified document (staff only) -> VERIFIED -> recompute -> preliminary updated; idempotent saves (no duplicate facts or evaluations); empty card creates nothing; RCIP/AIP RULE_UNAVAILABLE; NOC MATCH_UNAVAILABLE; candidates.assessment byte-identical under SHADOW_ONLY.');
}finally{await mf.dispose();}
