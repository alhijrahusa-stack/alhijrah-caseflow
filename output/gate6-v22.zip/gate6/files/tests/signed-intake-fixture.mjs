// v2.2 Gate 4 test fixture: every new /api/intake submission needs the account draft and its saved signature. This
// helper goes through the real API (create draft, save payload, save a real RGBA PNG signature) for an account cookie
// already present in the headers, and returns the submit body with draftId/expectedDraftRevision/signatureId/
// signedPayloadHash. Results are cached per requestId so replays send identical bodies. Test-only; never imported by
// application code. Only the account profile row is inserted directly (like intake-session-fixture's session row).
import { deflateSync } from 'node:zlib';
import { createHash, randomUUID } from 'node:crypto';
import { jcsHash } from '../lib/v22-core.ts';
import { AUTHORIZATION_TEXT, LEGAL_VERSION } from '../lib/legal.ts';

const CRC = Array.from({ length: 256 }, (_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
const crc32 = buf => { let c = 0xffffffff; for (const b of buf) c = CRC[(c ^ b) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
const chunk = (type, data) => { const len = Buffer.alloc(4); len.writeUInt32BE(data.length); const body = Buffer.concat([Buffer.from(type, 'ascii'), data]); const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(body)); return Buffer.concat([len, body, crc]); };
/** 8-bit RGBA PNG; with ink=true a 3px diagonal stroke is drawn, otherwise the image is fully transparent. */
export function signaturePng(width = 320, height = 120, ink = true) {
  const rows = [];
  for (let y = 0; y < height; y++) {
    const row = Buffer.alloc(1 + width * 4);
    if (ink) for (let x = 0; x < width; x++) if (Math.abs(Math.round(x * height / width) - y) <= 1) { const o = 1 + x * 4; row[o] = 20; row[o + 1] = 40; row[o + 2] = 60; row[o + 3] = 255; }
    rows.push(row);
  }
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(width, 0); ihdr.writeUInt32BE(height, 4); ihdr[8] = 8; ihdr[9] = 6;
  return new Uint8Array(Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', deflateSync(Buffer.concat(rows))), chunk('IEND', Buffer.alloc(0))]));
}
const sha = s => createHash('sha256').update(s).digest('hex');
export async function signingHash(accountKey, draftId, payload) {
  return jcsHash({ accountKey, draftId, profile: payload.profile, details: payload.details, pathSelection: payload.pathSelection, legalVersion: LEGAL_VERSION, authorizationText: AUTHORIZATION_TEXT, mandatoryAcceptanceValues: { legalAuthorization: true } });
}
export function signedIntakeFixture(mf, base) {
  const cache = new Map();
  return async function sign(body, headers = {}) {
    const cookie = headers.cookie || '';
    if (!body || body.draftId || !body.profile?.email || !cookie.includes('alh_application_account=')) return body;
    if (cache.has(body.requestId)) return { ...body, ...cache.get(body.requestId) };
    const call = async (p, method, b) => { if (b instanceof FormData) { const r = new Request(base + p, { method, body: b }); return mf.dispatchFetch(base + p, { method, headers: { cookie, 'content-type': r.headers.get('content-type') }, body: await r.arrayBuffer() }); } return mf.dispatchFetch(base + p, { method, headers: { cookie, ...(b ? { 'content-type': 'application/json' } : {}) }, body: b ? JSON.stringify(b) : undefined }); };
    try {
      const email = body.profile.email.trim().toLowerCase(), accountKey = sha('client-account:v1:' + email), now = new Date().toISOString(), db = await mf.getD1Database('DB');
      await db.prepare('INSERT INTO client_account_profiles(account_key,display_name,created_at,updated_at) VALUES(?,?,?,?) ON CONFLICT DO NOTHING').bind(accountKey, (body.profile.fullName || 'QA Client').slice(0, 150).padEnd(2, 'x'), now, now).run();
      const created = await call('/api/intake/drafts', 'POST', { requestKey: randomUUID() }); if (created.status >= 300) return body;
      const draft = await created.json(), profile = { ...body.profile }; delete profile.consent;
      const saved = await call('/api/intake/drafts/' + draft.draftId, 'PUT', { expectedRevision: draft.revision, mutationId: randomUUID(), payload: { profile: { ...draft.payload.profile, ...profile }, details: { ...draft.payload.details, ...(body.details || {}) }, pathSelection: draft.payload.pathSelection, step: 4 } });
      if (saved.status >= 300) return body;
      const current = await (await call('/api/intake/drafts/' + draft.draftId, 'GET')).json(), signedPayloadHash = await signingHash(accountKey, draft.draftId, current.payload);
      const form = new FormData(); form.append('manifest', JSON.stringify({ expectedRevision: current.revision, mutationId: randomUUID(), signedPayloadHash, legalVersion: LEGAL_VERSION })); form.append('image', new Blob([signaturePng()], { type: 'image/png' }), 'signature.png');
      const signed = await call('/api/intake/drafts/' + draft.draftId + '/signature', 'PUT', form); if (signed.status >= 300) return body;
      const record = await signed.json(), fields = { draftId: draft.draftId, expectedDraftRevision: record.draftRevision, signatureId: record.signatureId, signedPayloadHash };
      cache.set(body.requestId, fields);
      return { ...body, ...fields };
    } catch { return body; }
  };
}
// One cached fixture per Miniflare instance (replays of the same requestId reuse the same draft and signature).
const fixtures = new WeakMap();
export function signIntake(mf, base, body, headers) {
  let f = fixtures.get(mf); if (!f) { f = signedIntakeFixture(mf, base); fixtures.set(mf, f); }
  return f(body, headers);
}
