// Office hub suite: broadcast announcements (staff publish/switch/delete, public live feed with expiry),
// internal FAQ notes (staff only), notification feed, pathway dispatch and the staff assistant with a mocked
// Groq transport (identifiers masked, FAQ grounding, precise provider errors). No real provider is called.
import assert from 'node:assert/strict';
import { seedOfficeManager } from './v22/office-fixture.mjs';
import {createRequire} from 'node:module';
import {readFile,readdir} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {intakeSessionFixture} from './intake-session-fixture.mjs';
import {signIntake} from './signed-intake-fixture.mjs';
const require=createRequire(import.meta.url);
const {Miniflare}=createRequire(require.resolve('wrangler/package.json'))('miniflare');
const files=await readdir('dist/server',{recursive:true});
const base='http://canada-desk.test',admin={'oai-authenticated-user-id':'admin-1','oai-authenticated-user-email':'admin@example.test'};
let groqStatus=200,lastGroq=null,groqCalls=0,openaiBodies=[],openaiMode='tools',mails=[];
const mf=new Miniflare({modules:['index.js',...files.filter(f=>f!=='index.js'&&f.endsWith('.js'))].map(f=>({type:'ESModule',path:path.resolve('dist/server',f)})),modulesRoot:path.resolve('dist/server'),compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:{DB:'hub-db'},r2Buckets:['BUCKET'],bindings:{TRUST_SITES_IDENTITY_HEADERS:'1',OFFICE_ADMIN_EMAIL:'admin@example.test',APP_SECRET:'a'.repeat(64)},
 outboundService:async req=>{const u=new URL(req.url);
 if(u.hostname==='api.resend.com'){mails.push({body:await req.json(),key:req.headers.get('idempotency-key')});return Response.json({id:'m1'});}
 if(u.hostname==='api.openai.com'&&u.pathname==='/v1/models')return Response.json({data:[{id:'gpt-old',created:1},{id:'text-embedding-3-large',created:9},{id:'gpt-new',created:5},{id:'gpt-realtime',created:8}]});
 if(u.hostname==='api.openai.com'&&u.pathname==='/v1/responses'){const body=await req.json();openaiBodies.push(body);
  if(body.text?.format?.name==='support_reply'){globalThis.__supportBody=body;return Response.json({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify({reply:'المستندات الناقصة: جواز السفر ونتيجة اختبار اللغة.',handoff:false,reason:''})}]}]});}
  if(typeof body.instructions==='string'&&body.instructions.startsWith('اكتب ردًا واحدًا'))return Response.json({status:'completed',output:[{type:'message',content:[{type:'output_text',text:'مرحبًا، سيتواصل معك فريق المكتب بخصوص طلبك.'}]}]});
  if(body.text?.format?.name==='case_review'){globalThis.__reviewBody=body;const path=(n,f,url)=>({name:n,category:'express_entry',fit:f,why:'سبب الملاءمة بحسب الخبرة واللغة.',client_requirements:['نتيجة اختبار لغة معتمد'],office_next_steps:['حساب CRS'],official_url:url});return Response.json({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify({summary:'ملخص مراجعة الملف بلا بيانات شخصية.',legal_layers:{initial_analysis:'تحليل مبدئي.',nationality_considerations:'يحتاج تأشيرة زائر وبصمات.',tailored_recommendations:['التقديم من بلد إقامة ثالث']},strengths:['خبرة مهنية'],gaps:['العمر غير مسجل'],pathways:[path('Express Entry · FSW','strong','https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/express-entry.html'),path('Ontario PNP','possible','https://www.ontario.ca/page/ontario-immigrant-nominee-program-oinp'),path('RCIP','weak','https://evil.example/fake'),path('Extra','weak','')],questions_for_client:['ما تاريخ ميلادك؟'],documents_to_request:['جواز السفر','نتيجة IELTS'],client_message_ar:'مرحبًا، نحتاج منك المستندات التالية.',caveats:['القرار للمختص']})}]}]});}
  if(body.text?.format?.name==='office_document'){globalThis.__draftBody=body;return Response.json({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify({title:'Resume',summary:'Experienced professional.',sections:[{heading:'Experience',items:[{text:'Performed duties listed in the uploaded CV.',evidenceIds:['uploaded-cv']}]}],warnings:[]})}]}]});}
  if(openaiMode==='docs'&&!body.input.some(i=>i.type==='function_call_output'))return Response.json({status:'completed',output:[{type:'function_call',call_id:'d1',name:'generate_document',arguments:JSON.stringify({reference:globalThis.__ref,kind:'cv'})},{type:'function_call',call_id:'d2',name:'review_case',arguments:JSON.stringify({reference:globalThis.__ref})}]});
  if(openaiMode==='nosearch'&&body.tools.some(t=>t.type==='web_search'))return Response.json({error:{message:"Tool 'web_search' is not supported with this model."}},{status:400});
  const hasOutput=body.input.some(i=>i.type==='function_call_output');
  if(openaiMode==='tools'&&!hasOutput){const ref=globalThis.__ref;return Response.json({status:'completed',output:[{type:'reasoning',id:'rs_1',encrypted_content:'enc'},{type:'function_call',call_id:'c1',name:'get_case',arguments:JSON.stringify({reference:ref})},{type:'function_call',call_id:'c2',name:'propose_tasks',arguments:JSON.stringify({tasks:[{reference:ref,title:'متابعة مستند الخبرة',due_date:'2026-12-01',priority:'high'},{reference:'CA-2026-FFFFFFFF',title:'ملف غير موجود',due_date:'',priority:'normal'}]})}]});}
  return Response.json({status:'completed',output:[{type:'web_search_call',status:'completed'},{type:'message',content:[{type:'output_text',text:'**الأولوية**\n- الملف '+globalThis.__ref+' يحتاج متابعة.\nآخر سحب: راجع canada.ca',annotations:[{type:'url_citation',url:'https://www.canada.ca/en/immigration-refugees-citizenship/corporate/mandate/policies-operational-instructions-agreements/ministerial-instructions/express-entry-rounds.html',title:'Express Entry rounds'}]}]}]});}if(u.hostname==='api.groq.com'&&u.pathname==='/openai/v1/models'){assert.match(req.headers.get('authorization')||'',/^Bearer gsk_/);return Response.json({object:'list',data:[{id:'openai/gpt-oss-120b',active:true},{id:'whisper-large-v3',active:true},{id:'llama-3.3-70b-versatile',active:true},{id:'old-model',active:false},{id:'meta-llama/llama-guard-4-12b',active:true}]});}if(u.hostname==='api.groq.com'){groqCalls++;lastGroq=await req.json();if(groqStatus!==200)return Response.json({error:{message:'Invalid API Key',code:'invalid_api_key'}},{status:groqStatus});if(lastGroq.model==='openai/gpt-oss-120b')return Response.json({choices:[{message:{content:'<think>internal reasoning</think>Express Entry نظام فيدرالي، وPNP ترشيح من المقاطعة.'},finish_reason:'stop'}]});if(lastGroq.model==='qwen/qwen3.8-27b')return Response.json({choices:[{message:{content:''},finish_reason:'length'}]});return Response.json({choices:[{message:{content:'Express Entry نظام فيدرالي لإدارة الطلبات، وPNP ترشيح من المقاطعة. تحقّق من canada.ca.'}}]});}throw new Error('Unmocked host '+u.hostname);}});
const send=async(p,method='GET',body,headers={})=>{if(p==='/api/intake'&&method==='POST'&&body)body=await signIntake(mf,base,body,headers);return mf.dispatchFetch(base+p,{method,headers:{...(body?{'content-type':'application/json'}:{}),...headers},body:body?JSON.stringify(body):undefined});};
const json=async(r,status=200)=>{const t=await r.text();assert.equal(r.status,status,t);return t?JSON.parse(t):null;};
try{
 const db=await mf.getD1Database('DB');
 for(const file of (await readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())for(const s of (await readFile('drizzle/'+file,'utf8')).split('--> statement-breakpoint').map(s=>s.trim()).filter(Boolean))await db.prepare(s).run();await seedOfficeManager(db,'admin-1');
 // Broadcast
 assert.equal((await send('/api/announcements','POST',{title:'Draw update',tone:'urgent',duration:'24h'})).status,401,'publishing is staff-only');
 assert.equal((await send('/api/announcements','POST',{title:'x',tone:'urgent',duration:'24h'},admin)).status,400,'title validated');
 assert.equal((await send('/api/announcements','POST',{title:'Draw update',tone:'red',duration:'24h'},admin)).status,400,'tone whitelist');
 const a=await json(await send('/api/announcements','POST',{title:'فتح التقديم لبرنامج مقاطعة أونتاريو',body:'تفاصيل مختصرة',tone:'programs',duration:'7d'},admin),201);
 const b=await json(await send('/api/announcements','POST',{title:'إشعار إداري دائم',tone:'admin',duration:'permanent'},admin),201);
 await db.prepare("insert into announcements (id,title,body,tone,active,expires_at,created_by,created_at,updated_at) values ('expired-1','Old','', 'urgent',1,'2020-01-01T00:00:00.000Z','x','2020-01-01','2020-01-01')").run();
 let pub=await json(await send('/api/broadcast'));assert.deepEqual(pub.items.map(i=>i.id).sort(),[a.id,b.id].sort(),'live only, expired hidden');assert.ok(!('createdBy' in pub.items[0]),'public feed omits staff identity');
 await json(await send('/api/announcements','PATCH',{id:a.id,active:false},admin));pub=await json(await send('/api/broadcast'));assert.deepEqual(pub.items.map(i=>i.id),[b.id],'switched off disappears');
 const list=await json(await send('/api/announcements','GET',undefined,admin));assert.equal(list.items.find(i=>i.id==='expired-1').live,false);
 await json(await send('/api/announcements','DELETE',{id:b.id},admin));assert.equal((await json(await send('/api/broadcast'))).items.length,0);
 // FAQ notes
 assert.equal((await send('/api/faq-notes','GET')).status,401,'notes are staff-only');
 assert.equal((await send('/api/faq-notes','PUT',{entryId:'faq-99-9',note:'x'},admin)).status,404);
 await json(await send('/api/faq-notes','PUT',{entryId:'faq-1-1',note:'اذكر أن المكتب لا يمثل العميل أمام IRCC.'},admin));
 let notes=await json(await send('/api/faq-notes','GET',undefined,admin));assert.equal(notes.items[0].entryId,'faq-1-1');assert.equal(notes.items[0].updatedBy,'admin@example.test');
 await json(await send('/api/faq-notes','PUT',{entryId:'faq-1-1',note:''},admin));notes=await json(await send('/api/faq-notes','GET',undefined,admin));assert.equal(notes.items.length,0,'empty note removes it');
 // Notifications and pathways
 assert.equal((await send('/api/notifications')).status,401);assert.ok(Array.isArray((await json(await send('/api/notifications','GET',undefined,admin))).items));
 const c=await json(await send('/api/candidates','POST',{fullName:'Hub Synthetic',phone:'+15550007000',consent:true,jobs:[{title:'QA role',employer:'QA employer',country:'Yemen',start:'2024-01',end:'2024-12',weekly_hours:40}],occupation:'Synthetic'},admin),201);
 const hub=await json(await send('/api/pathways?id=fsw','GET',undefined,admin));assert.ok(hub.summary.fsw&&hub.summary.pnp);assert.equal(hub.scanned,1);
 const cand=await json(await send('/api/candidates/'+c.id,'GET',undefined,admin));await json(await send('/api/candidates/'+c.id,'PATCH',{version:cand.version,pathway:'pnp'},admin));
 const pnp=await json(await send('/api/pathways?id=pnp','GET',undefined,admin));assert.equal(pnp.summary.pnp.assigned,1);assert.equal(pnp.items[0].state,'assigned');
 assert.equal((await send('/api/pathways')).status,401);
 // Assistant
 assert.equal((await send('/api/assistant','POST',{messages:[{role:'user',content:'test'}]})).status,401,'assistant is staff-only');
 const noKey=await json(await send('/api/assistant','POST',{messages:[{role:'user',content:'ما الفرق بين Express Entry وPNP؟'}]},admin),503);assert.match(noKey.error,/لم يُربط محرك للمساعد/);
 await json(await send('/api/office','POST',{action:'ai',model:'llama-3.3-70b-versatile',key:'gsk_'+'b'.repeat(52)},admin));
 const r=await json(await send('/api/assistant','POST',{messages:[{role:'user',content:'العميل client@example.test رقمه +15551234567 جوازه AB1234567: ما الفرق بين Express Entry وPNP؟'}]},admin));
 assert.ok(r.answer.includes('Express Entry'));const sent=JSON.stringify(lastGroq);assert.ok(!sent.includes('client@example.test')&&!sent.includes('15551234567')&&!sent.includes('AB1234567'),'identifiers masked before leaving');assert.ok(lastGroq.messages[0].content.includes('لقطة العمل')&&lastGroq.messages[0].content.includes('غير متحقق'),'work snapshot and no-live-search rule in the Groq prompt');assert.equal(r.engine,'groq');assert.ok(!JSON.stringify(lastGroq).includes('Hub Synthetic'),'client names never sent');assert.equal(lastGroq.model,'llama-3.3-70b-versatile');
 groqStatus=401;const bad=await json(await send('/api/office/ai-check','POST',undefined,admin),502);assert.match(bad.error,/401/);assert.match(bad.error,/Invalid API Key/);assert.ok(!bad.error.includes('gsk_'),'error never echoes the key');
 groqStatus=200;const ok=await json(await send('/api/office/ai-check','POST',undefined,admin));assert.equal(ok.model,'llama-3.3-70b-versatile');
 const models=await json(await send('/api/office/ai-models','POST',undefined,admin));assert.deepEqual(models.models,['llama-3.3-70b-versatile','openai/gpt-oss-120b'],'chat models only: inactive, speech and guard models excluded');assert.equal(models.currentAvailable,true);
 assert.equal((await send('/api/office/ai-models','POST')).status,401,'model list is admin-only');
 await json(await send('/api/office','POST',{action:'ai',model:'openai/gpt-oss-120b'},admin));await json(await send('/api/assistant','POST',{messages:[{role:'user',content:'Express Entry'}]},admin));assert.equal(lastGroq.model,'openai/gpt-oss-120b','vendor/model ids from the account list are accepted');assert.ok(lastGroq.max_completion_tokens>=2000,'reasoning models get a thinking budget');
 const reasoned=await json(await send('/api/assistant','POST',{messages:[{role:'user',content:'Express Entry'}]},admin));assert.ok(!reasoned.answer.includes('<think>')&&reasoned.answer.startsWith('Express Entry'),'thinking text is stripped');
 await json(await send('/api/office','POST',{action:'ai',model:'qwen/qwen3.8-27b'},admin));const cut=await json(await send('/api/office/ai-check','POST',undefined,admin),502);assert.match(cut.error,/حد الرموز/,'token exhaustion is reported precisely');
 assert.equal((await send('/api/office','POST',{action:'ai',model:'bad model; drop'},admin)).status,400,'model id validated');
 await json(await send('/api/office','POST',{action:'ai',model:'llama-3.3-70b-versatile'},admin));
 // OpenAI engine: web search + office tools, pseudonymous data, confirm-to-create proposals, citations.
 const due=new Date(Date.now()-86400000).toISOString().slice(0,10);
 await json(await send('/api/tasks','POST',{mode:'manual',candidateId:c.id,title:'اتصال بـ Hub Synthetic بخصوص الجواز',dueDate:due,priority:'high'},admin),201);
 globalThis.__ref=cand.reference;
 await json(await send('/api/office','POST',{action:'professional',provider:'openai',model:'gpt-new',key:'sk-test-'+'x'.repeat(30)},admin));
 const pm=await json(await send('/api/office/professional-models','POST',undefined,admin));assert.deepEqual(pm.models,['gpt-new','gpt-old'],'chat models only, newest first');assert.equal(pm.currentAvailable,true);
 const o=await json(await send('/api/assistant','POST',{messages:[{role:'user',content:'رتّب لي أولويات العمل اليوم'}]},admin));
 assert.equal(o.engine,'openai');assert.equal(o.webSearch,true);assert.equal(openaiBodies.length,2,'tool round-trip');
 const first=openaiBodies[0],second=openaiBodies[1];assert.ok(first.tools.some(t=>t.type==='web_search'),'web search enabled');assert.equal(first.store,false);assert.ok(first.instructions.includes(cand.reference)&&first.instructions.includes('متأخرة'),'snapshot lists overdue task by reference');
 const allSent=JSON.stringify(openaiBodies);assert.ok(!allSent.includes('Hub Synthetic')&&!allSent.includes('+15550007000'),'names and phones never leave the system');
 const caseOut=second.input.find(i=>i.type==='function_call_output'&&i.call_id==='c1');assert.ok(JSON.parse(caseOut.output).reference===cand.reference);assert.ok(second.input.some(i=>i.type==='reasoning'),'reasoning items passed back for stateless continuation');
 assert.equal(o.proposals.length,1,'proposals for unknown files dropped');assert.equal(o.proposals[0].candidateId,c.id);assert.equal(o.proposals[0].priority,'high');
 assert.equal(o.sources[0].title,'Express Entry rounds');assert.equal(o.refs[cand.reference],c.id,'file numbers resolve to clickable files');
 // Client-portal references (ALH-CA-…, 12 hex) survive masking and resolve with or without the ALH- prefix.
 await db.prepare("update candidates set reference='ALH-CA-2026-9098A2F68D6E' where id=?").bind(c.id).run();globalThis.__ref='CA-2026-9098A2F68D6E';openaiBodies=[];
 const alh=await json(await send('/api/assistant','POST',{messages:[{role:'user',content:'ALH-CA-2026-9098A2F68D6E موعد 2026-11-11 هاتف +1 555 000 7000'}]},admin));
 const sentUser=JSON.stringify(openaiBodies[0].input);assert.ok(sentUser.includes('ALH-CA-2026-9098A2F68D6E')&&sentUser.includes('2026-11-11'),'reference and date kept');assert.ok(!sentUser.includes('555 000 7000')&&sentUser.includes('[number]'),'phone masked');
 const found=JSON.parse(openaiBodies[1].input.find(i=>i.type==='function_call_output'&&i.call_id==='c1').output);assert.equal(found.reference,'ALH-CA-2026-9098A2F68D6E','lookup without ALH- prefix finds the portal file');
 assert.equal(alh.refs['CA-2026-9098A2F68D6E'],c.id);assert.equal(alh.proposals[0].candidateId,c.id);
 // Dashboard health counts and the daily briefing email (counts only, once per day).
 const brief=await json(await send('/api/dashboard/brief','GET',undefined,admin));assert.equal(brief.unassigned,1,'file without a responsible staff member');assert.equal(brief.noFollowUp,0,'file has an open task');
 await json(await send('/api/office','POST',{action:'mail',sender:'office@example.test',key:'re_'+'k'.repeat(20)},admin));const worker=await mf.getWorker();await worker.scheduled({cron:'17 8 * * *',scheduledTime:new Date()});
 const daily=mails.find(m=>m.key&&m.key.startsWith('daily-brief/'));assert.ok(daily,'daily briefing sent');assert.deepEqual(daily.body.to,['admin@example.test']);assert.match(daily.body.text,/ملفات بلا مسؤول: 1/);assert.ok(!JSON.stringify(daily.body).includes('Hub Synthetic'),'no client names in the briefing');
 assert.equal((await db.prepare("select count(*) n from operation_logs where operation='daily_briefing' and result='sent'").first()).n,1);
 // Comprehensive review: de-identified input, 3 pathways max, non-official links dropped, saved + noted.
 const rv=await json(await send('/api/candidates/'+c.id+'/ai-review','POST',undefined,admin),201);assert.equal(rv.latest.review.pathways.length,3);assert.equal(rv.latest.review.legal_layers.tailored_recommendations[0],'التقديم من بلد إقامة ثالث');assert.ok(globalThis.__reviewBody.reasoning?.effort==='low','fast reasoning setting');assert.equal(rv.latest.review.pathways[2].official_url,'','non-official URL removed');assert.ok(rv.latest.review.pathways[1].official_url.startsWith('https://www.ontario.ca/'));
 const rb=JSON.stringify(globalThis.__reviewBody);assert.ok(!rb.includes('Hub Synthetic')&&!rb.includes('15550007000')&&!rb.includes('admin@example.test'),'review input is de-identified');assert.ok(!globalThis.__reviewBody.tools,'no web search in the review (speed)');
 assert.equal((await json(await send('/api/candidates/'+c.id+'/ai-review','GET',undefined,admin))).latest.id,rv.latest.id);assert.equal((await send('/api/candidates/'+c.id+'/ai-review','GET')).status,401);
 assert.equal((await db.prepare("select count(*) n from events where candidate_id=? and action like 'مراجعة شاملة%'").bind(c.id).first()).n,1,'review recorded as a file note');
 // Assistant prepares a CV from the uploaded CV file (consent recorded) and runs the review via tools.
 const bucket=await mf.getR2Bucket('BUCKET');await bucket.put('qa/resume.pdf',new TextEncoder().encode('%PDF-1.4 synthetic resume'));
 await db.prepare("insert into documents (id,owner_id,candidate_id,name,object_key,size,mime,category,sha256,verified,created_at) select 'doc-cv',owner_id,id,'resume.pdf','qa/resume.pdf',25,'application/pdf','resume','abc',0,? from candidates where id=?").bind(new Date().toISOString(),c.id).run();
 assert.equal((await send('/api/assistant','POST',{messages:[{role:'user',content:'x'}]},admin)).status,200);
 openaiMode='docs';openaiBodies=[];const noConsent=await json(await send('/api/assistant','POST',{messages:[{role:'user',content:'جهز CV للملف '+globalThis.__ref}]},admin));
 assert.match(JSON.stringify(openaiBodies.at(-1).input.find(i=>i.type==='function_call_output'&&i.call_id==='d1')),/تفويض/,'CV generation refused without recorded consent');
 await json(await send('/api/candidates/'+c.id+'/ai-consent','POST',{consent:true,confirmed:true},admin));openaiBodies=[];
 const docs=await json(await send('/api/assistant','POST',{messages:[{role:'user',content:'جهز CV للملف '+globalThis.__ref}]},admin));
 const attached=globalThis.__draftBody.input[0].content.find(p=>p.type==='input_file');assert.ok(attached&&attached.file_data.startsWith('data:application/pdf;base64,'),'uploaded CV attached to the generation request');
 const d1=JSON.parse(openaiBodies.at(-1).input.find(i=>i.type==='function_call_output'&&i.call_id==='d1').output);assert.equal(d1.state,'draft');assert.equal((await db.prepare("select count(*) n from cv_generation_log where candidate_id=? and state='draft'").bind(c.id).first()).n,1);
 const d2=JSON.parse(openaiBodies.at(-1).input.find(i=>i.type==='function_call_output'&&i.call_id==='d2').output);assert.equal(d2.saved,true);assert.equal(d2.pathways.length,3);void noConsent;void docs;
 // A new client request is reviewed automatically on arrival (OpenAI configured).
 const intakeRes=await send('/api/intake','POST',{requestId:randomUUID(),profile:{fullName:'Auto Review Client',phone:'+15550008000',email:'auto@example.test',consent:true,occupation:'Welder'},details:{},consentVersion:'intake-2026-11-v4',legalAuthorization:true},await intakeSessionFixture(mf,'auto@example.test','a'.repeat(64),{}));assert.equal(intakeRes.status,201,await intakeRes.clone().text());const autoRef=(await intakeRes.json()).reference;
 let auto=null;for(let i=0;i<40&&!auto;i++){auto=await db.prepare("select r.created_by from ai_case_reviews r join candidates c on c.id=r.candidate_id where c.reference=?").bind(autoRef).first();if(!auto)await new Promise(r=>setTimeout(r,100));}
 assert.equal(auto?.created_by,'system','automatic review saved for the new request');assert.ok(!JSON.stringify(globalThis.__reviewBody).includes('Auto Review Client'),'automatic review input is de-identified');
 // Client support chat (v2.2 Gate 5): the legacy endpoints are adapters over the canonical case chat. Without the
 // client's LLM_CHAT_ASSISTANT consent no AI provider is called and the message goes to the staff queue; claims are CAS
 // transitions (one owner); uploads go through quarantine and are not playable before a scanner marks them CLEAN.
 const chatCookie=(intakeRes.headers.get('set-cookie')||'').match(/alh_client_session=[a-f0-9]{64}/)[0];const autoId=(await db.prepare('select id from candidates where reference=?').bind(autoRef).first()).id;
 assert.equal((await send('/api/client/support')).status,401,'chat needs a client session');
 let chat=await json(await send('/api/client/support','GET',undefined,{cookie:chatCookie}));assert.equal(chat.messages.length,0);
 globalThis.__supportBody=undefined;
 chat=await json(await send('/api/client/support','POST',{body:'ما المستندات الناقصة في ملفي؟'},{cookie:chatCookie}));assert.equal(chat.messages.at(-1).sender,'client');assert.equal(chat.withStaff,true,'no assistant consent: handed to staff');assert.equal(globalThis.__supportBody,undefined,'no AI call without consent');
 assert.equal((await db.prepare("select count(*) n from support_messages where candidate_id=?").bind(autoId).first()).n,0,'no new legacy rows');
 const inbox=await json(await send('/api/support','GET',undefined,admin));assert.equal(inbox.waiting,1);assert.equal(inbox.items[0].candidateId,autoId);
 assert.ok((await json(await send('/api/notifications','GET',undefined,admin))).items.some(i=>i.kind==='chat'),'waiting chat in the notification bell');
 // State machine + atomic claim: one staff member holds it, the other gets 409.
 let sv=await json(await send('/api/support/'+autoId,'GET',undefined,admin));assert.equal(sv.state,'HANDOFF_PENDING');
 await json(await send('/api/office','POST',{action:'member',name:'QA Employee',email:'employee@example.test',active:true},admin));const employee={'oai-authenticated-user-id':'employee-1','oai-authenticated-user-email':'employee@example.test'};
 assert.equal((await json(await send('/api/support/'+autoId+'/claim','POST',undefined,employee))).state,'HUMAN_ACTIVE');
 assert.equal((await send('/api/support/'+autoId+'/claim','POST',undefined,admin)).status,409,'second claim refused');
 assert.equal((await send('/api/support/'+autoId,'POST',{body:'رد متعارض'},admin)).status,409,'cannot reply on a thread held by another staff member');
 sv=await json(await send('/api/support/'+autoId,'PATCH',{status:'ai'},employee));assert.equal(sv.state,'BOT_ACTIVE');assert.equal(sv.assignedTo,'');
 assert.ok((await db.prepare("select count(*) n from case_chat_transitions t join case_conversations c on c.conversation_id=t.conversation_id where c.case_id=? and t.new_state='HUMAN_ACTIVE' and t.actor_id='staff:employee@example.test'").bind(autoId).first()).n>=1,'claim logged');
 await json(await send('/api/client/support','POST',{body:'أريد موظف',human:true},{cookie:chatCookie}));
 const dr=await json(await send('/api/support/'+autoId+'/draft','POST',undefined,admin));assert.ok(dr.draft.length>5);
 await json(await send('/api/support/'+autoId,'POST',{body:'سيتواصل معك المكتب اليوم بخصوص الدفعة.'},admin));
 chat=await json(await send('/api/client/support','GET',undefined,{cookie:chatCookie}));assert.equal(chat.messages.at(-1).sender,'staff');
 chat=await json(await send('/api/client/support','POST',{body:'شكرًا'},{cookie:chatCookie}));
 // Voice note / file: content-signature check, normal upload pipeline (QUARANTINED + INGESTION), no playback before CLEAN.
 const upload=async(url,bytes,type,name,headers)=>{const f=new FormData();f.append('file',new File([bytes],name,{type}));const req=new Request(base+url,{method:'POST',headers,body:f});return mf.dispatchFetch(req.url,{method:'POST',headers:Object.fromEntries(req.headers),body:Buffer.from(await req.arrayBuffer())});};
 const webm=new Uint8Array(2048);webm.set([0x1a,0x45,0xdf,0xa3]);
 const up=await upload('/api/client/support/attachment',webm,'audio/webm','voice.webm',{cookie:chatCookie});assert.equal(up.status,201,await up.clone().text());const voice=await up.json();
 assert.equal((await upload('/api/client/support/attachment',new TextEncoder().encode('not audio at all'),'audio/webm','x.webm',{cookie:chatCookie})).status,415,'signature mismatch refused');
 assert.equal((await upload('/api/client/support/attachment',webm,'audio/webm','v.webm',{})).status,401,'anonymous upload refused');
 assert.equal((await db.prepare('select integrity_state s from documents where id=?').bind(voice.evidenceId).first()).s,'QUARANTINED');
 assert.equal((await send('/api/client/chat?media='+voice.evidenceId,'GET',undefined,{cookie:chatCookie})).status,423,'not playable before a clean scan');
 assert.equal((await send('/api/client/chat?media='+voice.evidenceId)).status,401,'anonymous read refused');
 assert.equal((await send('/api/candidates/'+autoId+'/chat?media='+voice.evidenceId,'GET',undefined,admin)).status,423,'staff too');
 const png=new Uint8Array(64);png.set([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]);const staffUp=await upload('/api/support/'+autoId+'/attachment',png,'image/png','scan.png',admin);assert.equal(staffUp.status,201,await staffUp.clone().text());
 const listed=(await json(await send('/api/client/support','GET',undefined,{cookie:chatCookie}))).messages;assert.ok(listed.some(m=>m.body==='رسالة صوتية'&&m.sender==='client'));assert.ok(listed.some(m=>m.body==='مرفق'&&m.sender==='staff'));assert.ok(!JSON.stringify(listed).includes(autoId+'/'),'storage keys never exposed');
 assert.equal((await send('/api/client/support','PATCH',{resume:true},{cookie:chatCookie})).status,409,'after a handoff the office keeps the conversation');assert.equal((await send('/api/client/support','PATCH',{resume:true})).status,401);
 await json(await send('/api/support/'+autoId,'PATCH',{status:'ai'},admin));assert.equal((await send('/api/support/'+autoId,'GET')).status,401);
 // Pathway registry: mismatched category/pathway rejected; valid pathway stored and drives the service.
 assert.equal((await send('/api/intake','POST',{requestId:randomUUID(),profile:{fullName:'Path Bad',phone:'+15550008211',email:'pathbad@example.test',consent:true},details:{category:'visit',pathway:'express_entry'},consentVersion:'intake-2026-11-v4',legalAuthorization:true},await intakeSessionFixture(mf,'pathbad@example.test','a'.repeat(64),{}))).status,400,'pathway outside its category rejected');
 assert.equal((await send('/api/intake','POST',{requestId:randomUUID(),profile:{fullName:'Path Unknown',phone:'+15550008212',email:'pathunk@example.test',consent:true},details:{category:'trades',pathway:'agri_food_pilot'},consentVersion:'intake-2026-11-v4',legalAuthorization:true},await intakeSessionFixture(mf,'pathunk@example.test','a'.repeat(64),{}))).status,400,'unregistered pathway rejected');
 const okPath=await send('/api/intake','POST',{requestId:randomUUID(),profile:{fullName:'Path Good',phone:'+15550008213',email:'pathgood@example.test',consent:true},details:{category:'trades',pathway:'fstp',service:'other'},consentVersion:'intake-2026-11-v4',legalAuthorization:true},await intakeSessionFixture(mf,'pathgood@example.test','a'.repeat(64),{}));assert.equal(okPath.status,201,await okPath.clone().text());
 const stored=JSON.parse((await db.prepare("select c.details from client_cases c join candidates k on k.id=c.candidate_id where k.reference=?").bind((await okPath.json()).reference).first()).details);assert.equal(stored.pathway,'fstp');assert.equal(stored.category,'trades');assert.equal(stored.service,'immigration','service derived from the pathway');
 // Case workflow: computed from the stored file, staff only.
 const pathCand=(await db.prepare('select id from candidates where reference=?').bind(JSON.parse(await (await send('/api/candidates?q=Path%20Good','GET',undefined,admin)).text()).items?.[0]?.reference||'').first())?.id||(await db.prepare("select id from candidates where json_extract(profile,'$.fullName')='Path Good'").first()).id;
 assert.equal((await send('/api/candidates/'+pathCand+'/workflow')).status,401,'workflow is staff-only');
 const wf=await json(await send('/api/candidates/'+pathCand+'/workflow','GET',undefined,admin));assert.equal(wf.steps.length,6);assert.equal(wf.current.id,'assign');assert.equal(wf.steps.find(x=>x.id==='data').detail.includes('برنامج الحرفيين'),true);assert.ok(wf.steps.find(x=>x.id==='data').items.length>0,'FSTP gaps listed');assert.ok(wf.missingDocumentKeys.length>0);
 await json(await send('/api/candidates/'+pathCand,'PATCH',{version:(await db.prepare('select version from candidates where id=?').bind(pathCand).first()).version,assignedTo:'QA Staff'},admin));
 assert.equal((await json(await send('/api/candidates/'+pathCand+'/workflow','GET',undefined,admin))).current.id,'data','assignment completes step 1');
 const visit=await send('/api/intake','POST',{requestId:randomUUID(),profile:{fullName:'Visit Docs',phone:'+15550008214',email:'visitdocs@example.test',consent:true,occupation:'Welder',education:'diploma',englishMin:6},details:{category:'visit',pathway:'visitor_visa'},consentVersion:'intake-2026-11-v4',legalAuthorization:true},await intakeSessionFixture(mf,'visitdocs@example.test','a'.repeat(64),{}));assert.equal(visit.status,201);
 const visitId=(await db.prepare("select id from candidates where json_extract(profile,'$.fullName')='Visit Docs'").first()).id;const vd=(await json(await send('/api/candidates/'+visitId+'/workflow','GET',undefined,admin))).steps.find(x=>x.id==='documents');
 assert.deepEqual(vd.items,['ناقص: جواز السفر'],'visit pathways ask for the passport only, not work or education documents');
 // Routing: new request scored, internal tier stored, client sees only a professional track; admin thresholds apply.
 assert.ok(!JSON.stringify(await (await send('/api/intake','POST',{requestId:randomUUID(),profile:{fullName:'Track Client',phone:'+15550008111',email:'track@example.test',consent:true},details:{},consentVersion:'intake-2026-11-v4',legalAuthorization:true},await intakeSessionFixture(mf,'track@example.test','a'.repeat(64),{}))).text()).match(/hot|warm|nurture/),'internal tier words never in client responses');
 const lead=await json(await send('/api/candidates/'+autoId+'/lead','GET',undefined,admin));assert.ok(['hot','warm','nurture'].includes(lead.tier));assert.equal((await send('/api/candidates/'+autoId+'/lead','GET')).status,401);
 assert.equal((await send('/api/office/scoring','PUT',{weights:{completeness:25,pathway:25,language:15,experience:15,funds:10,passport:10},hot:30,warm:40},admin)).status,400,'warm threshold below hot');
 await json(await send('/api/office/scoring','PUT',{weights:{completeness:100,pathway:0,language:0,experience:0,funds:0,passport:0},hot:1,warm:0},admin));
 const rc=await json(await send('/api/office/scoring/recompute','POST',undefined,admin));assert.ok(rc.recomputed>=1);assert.ok(rc.counts.hot>=1,'new thresholds applied immediately');
 // Analytics and audit trail
 const an=await json(await send('/api/analytics','GET',undefined,admin));assert.equal(an.months.length,12);assert.ok(an.audit.length>0&&an.audit[0].reference);assert.equal((await send('/api/analytics')).status,401);
 // Client domain home redirects to the client portal
 const usa=await mf.dispatchFetch('https://alhijrah-usa.com/canada-assessment',{redirect:'manual'});assert.equal(usa.status,302);assert.equal(usa.headers.get('location'),'https://canada.careergate.us/apply','alhijrah-usa.com/canada-assessment opens the application form');
 const home=await mf.dispatchFetch('https://canada.careergate.us/',{redirect:'manual'});assert.equal(home.status,302);assert.equal(home.headers.get('location'),'https://canada.careergate.us/client/account');
 openaiMode='nosearch';openaiBodies=[];const ns=await json(await send('/api/assistant','POST',{messages:[{role:'user',content:'سؤال عام'}]},admin));assert.equal(ns.webSearch,false,'falls back without web search when the model lacks it');assert.equal(openaiBodies.length,2);
 console.log(`Office hub API passed: staff-only broadcast publish/switch/delete with tone/duration validation and expiry, public live feed without staff identity, staff-only FAQ notes, notification feed, pathway dispatch summary and assignment, staff assistant grounded on the office reference with identifiers masked, precise Groq error reporting without the key. Mocked Groq calls: ${groqCalls}.`);
}finally{await mf.dispose();}
