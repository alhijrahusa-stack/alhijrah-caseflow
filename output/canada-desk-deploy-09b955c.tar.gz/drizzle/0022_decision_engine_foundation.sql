-- v15.23 decision-engine foundation (engine contract, step 1). Additive only; no existing data is changed.
-- Approved deviations from the contract text: (1) the payload_hash unique index is on client_cases, where the
-- column exists; (2) case_state_view maps the real status values so no file resolves to 'unknown'.
CREATE TABLE assessment_history (
  id TEXT PRIMARY KEY,
  candidate_id TEXT NOT NULL,
  computed_at TEXT NOT NULL DEFAULT (datetime('now')),
  inputs_hash TEXT NOT NULL,
  engine_version TEXT NOT NULL,
  rules_version TEXT NOT NULL,
  output_json TEXT NOT NULL,
  explanation_trace_json TEXT NOT NULL
);--> statement-breakpoint
CREATE INDEX idx_assessment_candidate ON assessment_history(candidate_id, computed_at DESC);--> statement-breakpoint
CREATE INDEX idx_assessment_hash ON assessment_history(inputs_hash);--> statement-breakpoint
CREATE TABLE decision_audit (
  id TEXT PRIMARY KEY,
  case_id TEXT NOT NULL,
  decided_at TEXT NOT NULL DEFAULT (datetime('now')),
  rules_version TEXT NOT NULL,
  engine_version TEXT NOT NULL,
  inputs_hash TEXT NOT NULL,
  top_pathways_json TEXT NOT NULL,
  gap_analysis_json TEXT NOT NULL,
  human_reviewer_id TEXT NOT NULL,
  decision_taken TEXT NOT NULL
);--> statement-breakpoint
CREATE INDEX idx_decision_case ON decision_audit(case_id, decided_at DESC);--> statement-breakpoint
CREATE TABLE case_outcomes (
  id TEXT PRIMARY KEY,
  case_id TEXT NOT NULL UNIQUE,
  pathway_chosen TEXT NOT NULL,
  crs_at_decision INTEGER,
  outcome TEXT NOT NULL,
  outcome_date TEXT,
  processing_days INTEGER,
  rules_version_at_decision TEXT NOT NULL,
  notes TEXT
);--> statement-breakpoint
CREATE INDEX idx_outcomes_pathway ON case_outcomes(pathway_chosen, outcome);--> statement-breakpoint
CREATE TABLE rules_versions (
  id TEXT PRIMARY KEY,
  rule_key TEXT NOT NULL,
  version TEXT NOT NULL,
  effective_from TEXT NOT NULL,
  effective_until TEXT,
  payload_json TEXT NOT NULL,
  source_url TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(rule_key, version)
);--> statement-breakpoint
CREATE INDEX idx_rules_effective ON rules_versions(rule_key, effective_from, effective_until);--> statement-breakpoint
CREATE TABLE draw_thresholds (
  id TEXT PRIMARY KEY,
  category TEXT NOT NULL,
  draw_date TEXT NOT NULL,
  crs_min INTEGER NOT NULL,
  invitations INTEGER NOT NULL,
  source_url TEXT NOT NULL,
  UNIQUE(category, draw_date)
);--> statement-breakpoint
CREATE INDEX idx_thresholds_category_date ON draw_thresholds(category, draw_date DESC);--> statement-breakpoint
CREATE TABLE pnp_streams (
  id TEXT PRIMARY KEY,
  province TEXT NOT NULL,
  stream_name TEXT NOT NULL,
  required_noc_codes TEXT NOT NULL,
  min_score INTEGER,
  effective_from TEXT NOT NULL,
  effective_until TEXT,
  source_url TEXT NOT NULL,
  UNIQUE(province, stream_name, effective_from)
);--> statement-breakpoint
CREATE VIEW case_state_view AS
SELECT
  c.id AS candidate_id,
  c.status,
  cc.inbox,
  cr.state AS review_state,
  CASE
    WHEN c.status = 'archived' THEN 'archived'
    WHEN cr.state = 'in_review' THEN 'in_review'
    WHEN cr.state = 'changes_requested' THEN 'changes_requested'
    WHEN cc.inbox = 'needs_info' THEN 'needs_client_info'
    WHEN cc.inbox = 'pending' AND c.status = 'new' THEN 'awaiting_intake_review'
    WHEN c.status = 'referred' THEN 'referred'
    WHEN c.status = 'shortlisted' THEN 'shortlisted'
    WHEN c.status = 'hold' THEN 'on_hold'
    WHEN cr.state = 'approved' THEN 'review_approved'
    WHEN cr.state = 'stale' THEN 'review_stale'
    WHEN c.status = 'documents' THEN 'collecting_documents'
    WHEN c.status = 'reviewing' THEN 'reviewing'
    WHEN c.status = 'new' THEN 'new'
    ELSE c.status
  END AS unified_state
FROM candidates c
LEFT JOIN client_cases cc ON cc.candidate_id = c.id
LEFT JOIN case_reviews cr ON cr.candidate_id = c.id;--> statement-breakpoint
CREATE UNIQUE INDEX idx_client_cases_payload_hash ON client_cases(payload_hash);
