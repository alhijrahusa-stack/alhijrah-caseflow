CREATE TABLE `tasks` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`candidate_id` text NOT NULL,
	`title` text NOT NULL,
	`due_date` text DEFAULT '' NOT NULL,
	`priority` text DEFAULT 'normal' NOT NULL,
	`status` text DEFAULT 'open' NOT NULL,
	`system_key` text,
	`version` integer DEFAULT 1 NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `task_owner_status_due` ON `tasks` (`owner_id`,`status`,`due_date`);--> statement-breakpoint
CREATE INDEX `task_owner_candidate` ON `tasks` (`owner_id`,`candidate_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `task_system_key` ON `tasks` (`owner_id`,`candidate_id`,`system_key`);--> statement-breakpoint
ALTER TABLE `candidates` ADD `dedupe_key` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `candidates` ADD `email_key` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `candidates` ADD `priority` text DEFAULT 'normal' NOT NULL;--> statement-breakpoint
ALTER TABLE `candidates` ADD `pathway` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `candidates` ADD `assigned_to` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `candidates` ADD `referral_to` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `candidates` ADD `sharing_consent` integer DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `candidates` ADD `source` text DEFAULT 'staff' NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX `candidate_owner_identity` ON `candidates` (`owner_id`,`dedupe_key`) WHERE "candidates"."dedupe_key" <> '';--> statement-breakpoint
CREATE UNIQUE INDEX `candidate_owner_email_identity` ON `candidates` (`owner_id`,`email_key`) WHERE "candidates"."email_key" <> '';--> statement-breakpoint
CREATE INDEX `candidate_owner_status` ON `candidates` (`owner_id`,`status`);