CREATE TABLE `auth_security_log` (
	`id` text PRIMARY KEY NOT NULL,
	`scope` text NOT NULL,
	`action` text NOT NULL,
	`subject_hash` text NOT NULL,
	`ip_hash` text NOT NULL,
	`result` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `security_scope_date` ON `auth_security_log` (`scope`,`created_at`);--> statement-breakpoint
CREATE TABLE `login_credentials` (
	`id` text PRIMARY KEY NOT NULL,
	`scope` text NOT NULL,
	`subject` text NOT NULL,
	`password_hash` text NOT NULL,
	`version` integer DEFAULT 1 NOT NULL,
	`changed_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `credential_scope_subject` ON `login_credentials` (`scope`,`subject`);--> statement-breakpoint
CREATE TABLE `staff_challenges` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`purpose` text NOT NULL,
	`code_hash` text NOT NULL,
	`request_key` text NOT NULL,
	`state` text NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`expires_at` integer NOT NULL,
	`created_at` integer NOT NULL,
	`used_at` integer,
	`consumed_by` text DEFAULT '' NOT NULL,
	`provider_id` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `staff_challenges_request_key_unique` ON `staff_challenges` (`request_key`);--> statement-breakpoint
CREATE INDEX `staff_challenge_expiry` ON `staff_challenges` (`expires_at`);--> statement-breakpoint
CREATE INDEX `staff_challenge_email` ON `staff_challenges` (`email`,`created_at`);--> statement-breakpoint
CREATE TABLE `staff_sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`method` text NOT NULL,
	`created_at` integer NOT NULL,
	`expires_at` integer NOT NULL,
	`revoked_at` integer
);
--> statement-breakpoint
CREATE INDEX `staff_session_email` ON `staff_sessions` (`email`,`expires_at`);