-- v15.11: AI comprehensive file reviews (top pathways, client requirements), one row per run (additive).
CREATE TABLE IF NOT EXISTS `ai_case_reviews` (`id` text PRIMARY KEY NOT NULL, `candidate_id` text NOT NULL REFERENCES `candidates`(`id`), `source_version` integer NOT NULL, `provider` text NOT NULL, `model` text NOT NULL, `content` text NOT NULL, `created_by` text NOT NULL, `created_at` text NOT NULL);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `ai_case_review_candidate_date` ON `ai_case_reviews` (`candidate_id`,`created_at`);
