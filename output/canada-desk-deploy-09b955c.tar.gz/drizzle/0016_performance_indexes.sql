-- v15.4: indexes for hot lookups and the daily maintenance purge (additive, idempotent).
CREATE INDEX IF NOT EXISTS `document_candidate_date` ON `documents` (`candidate_id`,`created_at`);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `rate_limit_expiry` ON `rate_limits` (`expires`);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `challenge_expiry` ON `auth_challenges` (`expires_at`);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `client_session_expiry` ON `client_sessions` (`expires_at`);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `staff_session_expiry` ON `staff_sessions` (`expires_at`);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `operation_kind_date` ON `operation_logs` (`operation`,`created_at`);
