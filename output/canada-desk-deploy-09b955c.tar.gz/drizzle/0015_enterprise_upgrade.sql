CREATE TABLE `client_feedback` (
	`candidate_id` text PRIMARY KEY NOT NULL,
	`rating` integer NOT NULL,
	`comment` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `crs_history` (
	`id` text PRIMARY KEY NOT NULL,
	`candidate_id` text NOT NULL,
	`inputs` text NOT NULL,
	`result` text NOT NULL,
	`source_hash` text NOT NULL,
	`actor` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `crs_history_candidate` ON `crs_history` (`candidate_id`,`created_at`);
--> statement-breakpoint
CREATE TABLE `document_ai_permissions` (
	`candidate_id` text PRIMARY KEY NOT NULL,
	`provider` text NOT NULL,
	`consent` integer NOT NULL,
	`version` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `document_revisions` (
	`id` text PRIMARY KEY NOT NULL,
	`document_id` text NOT NULL,
	`snapshot` text NOT NULL,
	`actor` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`document_id`) REFERENCES `cv_generation_log`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `document_revision_date` ON `document_revisions` (`document_id`,`created_at`);
--> statement-breakpoint
CREATE TABLE `eligibility_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`candidate_id` text NOT NULL,
	`inputs` text NOT NULL,
	`result` text NOT NULL,
	`source_hash` text NOT NULL,
	`actor` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `eligibility_candidate_date` ON `eligibility_runs` (`candidate_id`,`created_at`);
--> statement-breakpoint
CREATE TABLE `cv_generation_log` (
	`id` text PRIMARY KEY NOT NULL,
	`candidate_id` text NOT NULL,
	`request_key` text NOT NULL,
	`kind` text NOT NULL,
	`state` text NOT NULL,
	`source_hash` text NOT NULL,
	`source_snapshot` text NOT NULL,
	`content` text DEFAULT '' NOT NULL,
	`provider` text NOT NULL,
	`model` text NOT NULL,
	`object_key` text DEFAULT '' NOT NULL,
	`cover_key` text DEFAULT '' NOT NULL,
	`sha256` text DEFAULT '' NOT NULL,
	`cover_sha256` text DEFAULT '' NOT NULL,
	`verification_token` text NOT NULL,
	`created_by` text NOT NULL,
	`reviewed_by` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	`approved_at` text DEFAULT '' NOT NULL,
	`error_code` text DEFAULT '' NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `cv_generation_log_request_key_unique` ON `cv_generation_log` (`request_key`);
--> statement-breakpoint
CREATE UNIQUE INDEX `cv_generation_log_verification_token_unique` ON `cv_generation_log` (`verification_token`);
--> statement-breakpoint
CREATE INDEX `generated_candidate_date` ON `cv_generation_log` (`candidate_id`,`created_at`);
--> statement-breakpoint
CREATE TABLE `notification_preferences` (
	`candidate_id` text PRIMARY KEY NOT NULL,
	`whatsapp` integer DEFAULT false NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `operation_logs` (
	`id` text PRIMARY KEY NOT NULL,
	`candidate_id` text,
	`operation` text NOT NULL,
	`actor` text NOT NULL,
	`result` text NOT NULL,
	`code` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `operation_date` ON `operation_logs` (`created_at`);
--> statement-breakpoint
CREATE TABLE `status_notifications` (
	`id` text PRIMARY KEY NOT NULL,
	`candidate_id` text NOT NULL,
	`case_version` integer NOT NULL,
	`channel` text NOT NULL,
	`state` text NOT NULL,
	`provider_id` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `one_status_notification` ON `status_notifications` (`candidate_id`,`case_version`,`channel`);
--> statement-breakpoint
ALTER TABLE `office_settings` ADD `professional_provider` text DEFAULT '' NOT NULL;
--> statement-breakpoint
ALTER TABLE `office_settings` ADD `professional_key` text DEFAULT '' NOT NULL;
--> statement-breakpoint
ALTER TABLE `office_settings` ADD `professional_model` text DEFAULT '' NOT NULL;
--> statement-breakpoint
ALTER TABLE `office_settings` ADD `calendar_url` text DEFAULT '' NOT NULL;
--> statement-breakpoint
ALTER TABLE `office_settings` ADD `captcha_site_key` text DEFAULT '' NOT NULL;
--> statement-breakpoint
ALTER TABLE `office_settings` ADD `captcha_secret` text DEFAULT '' NOT NULL;
--> statement-breakpoint
ALTER TABLE `office_settings` ADD `whatsapp_status_template` text DEFAULT '' NOT NULL;
