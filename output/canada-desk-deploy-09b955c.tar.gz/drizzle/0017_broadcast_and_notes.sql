-- v15.8: client broadcast announcements and internal staff notes per FAQ entry (additive).
CREATE TABLE IF NOT EXISTS `announcements` (`id` text PRIMARY KEY NOT NULL, `title` text NOT NULL, `body` text DEFAULT '' NOT NULL, `tone` text DEFAULT 'admin' NOT NULL, `active` integer DEFAULT 1 NOT NULL, `expires_at` text DEFAULT '' NOT NULL, `created_by` text NOT NULL, `created_at` text NOT NULL, `updated_at` text NOT NULL);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `announcement_active_expiry` ON `announcements` (`active`,`expires_at`);--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `faq_notes` (`entry_id` text PRIMARY KEY NOT NULL, `note` text NOT NULL, `updated_by` text NOT NULL, `updated_at` text NOT NULL);
