-- v15.13: in-app client support chat (AI first responder with human handoff) (additive).
CREATE TABLE IF NOT EXISTS `support_threads` (`candidate_id` text PRIMARY KEY NOT NULL REFERENCES `candidates`(`id`), `status` text DEFAULT 'ai' NOT NULL, `handoff_reason` text DEFAULT '' NOT NULL, `staff_unread` integer DEFAULT 0 NOT NULL, `client_unread` integer DEFAULT 0 NOT NULL, `last_message_at` text NOT NULL, `updated_at` text NOT NULL);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `support_thread_status_date` ON `support_threads` (`status`,`last_message_at`);--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `support_messages` (`id` text PRIMARY KEY NOT NULL, `candidate_id` text NOT NULL REFERENCES `candidates`(`id`), `sender` text NOT NULL, `author` text DEFAULT '' NOT NULL, `body` text NOT NULL, `created_at` text NOT NULL);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `support_message_candidate_date` ON `support_messages` (`candidate_id`,`created_at`);
