-- v15.14: readiness scoring and routing (admin-editable weights/thresholds; internal tiers never shown to clients).
CREATE TABLE IF NOT EXISTS `scoring_config` (`id` text PRIMARY KEY NOT NULL, `weights` text NOT NULL, `hot_threshold` integer NOT NULL, `warm_threshold` integer NOT NULL, `updated_by` text NOT NULL, `updated_at` text NOT NULL);--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `lead_scores` (`candidate_id` text PRIMARY KEY NOT NULL REFERENCES `candidates`(`id`), `score` integer NOT NULL, `tier` text NOT NULL, `factors` text NOT NULL, `computed_at` text NOT NULL);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `lead_score_tier` ON `lead_scores` (`tier`,`score`);
