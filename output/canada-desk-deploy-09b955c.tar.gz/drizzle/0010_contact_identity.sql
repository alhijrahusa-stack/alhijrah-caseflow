ALTER TABLE `candidates` ADD `contact_pair_key` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `candidates` ADD `identity_version` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX `candidate_owner_contact_pair` ON `candidates` (`owner_id`,`contact_pair_key`) WHERE "candidates"."contact_pair_key" <> '';--> statement-breakpoint
CREATE INDEX `candidate_legacy_identity` ON `candidates` (`owner_id`,`identity_version`);--> statement-breakpoint
CREATE UNIQUE INDEX `office_name_phone_identity` ON `candidates` (`dedupe_key`) WHERE "candidates"."identity_version" = 1 AND "candidates"."dedupe_key" <> '';--> statement-breakpoint
CREATE UNIQUE INDEX `office_name_email_identity` ON `candidates` (`email_key`) WHERE "candidates"."identity_version" = 1 AND "candidates"."email_key" <> '';--> statement-breakpoint
CREATE UNIQUE INDEX `office_contact_pair_identity` ON `candidates` (`contact_pair_key`) WHERE "candidates"."identity_version" = 1 AND "candidates"."contact_pair_key" <> '';