CREATE TABLE `client_cases` (
	`candidate_id` text PRIMARY KEY NOT NULL,
	`request_id` text NOT NULL,
	`payload_hash` text NOT NULL,
	`access_hash` text NOT NULL,
	`access_encrypted` text NOT NULL,
	`inbox` text DEFAULT 'pending' NOT NULL,
	`details` text DEFAULT '{}' NOT NULL,
	`instructions` text DEFAULT '' NOT NULL,
	`requested_documents` text DEFAULT '[]' NOT NULL,
	`consent_version` text NOT NULL,
	`submitted_at` text NOT NULL,
	`version` integer DEFAULT 1 NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `client_cases_request_id_unique` ON `client_cases` (`request_id`);--> statement-breakpoint
CREATE INDEX `client_inbox_date` ON `client_cases` (`inbox`,`submitted_at`);--> statement-breakpoint
CREATE UNIQUE INDEX `client_access_hash` ON `client_cases` (`access_hash`);--> statement-breakpoint
CREATE TABLE `client_messages` (
	`id` text PRIMARY KEY NOT NULL,
	`candidate_id` text NOT NULL,
	`kind` text NOT NULL,
	`recipient` text NOT NULL,
	`subject` text NOT NULL,
	`body` text NOT NULL,
	`state` text DEFAULT 'pending' NOT NULL,
	`provider_id` text DEFAULT '' NOT NULL,
	`error` text DEFAULT '' NOT NULL,
	`actor` text NOT NULL,
	`request_key` text NOT NULL,
	`created_at` text NOT NULL,
	`sent_at` text DEFAULT '' NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `client_messages_request_key_unique` ON `client_messages` (`request_key`);--> statement-breakpoint
CREATE INDEX `message_candidate_date` ON `client_messages` (`candidate_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `office_members` (
	`email` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `office_settings` (
	`id` text PRIMARY KEY NOT NULL,
	`primary_owner_id` text DEFAULT '' NOT NULL,
	`mail_key` text DEFAULT '' NOT NULL,
	`mail_from` text DEFAULT '' NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `rate_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`expires` integer NOT NULL
);
