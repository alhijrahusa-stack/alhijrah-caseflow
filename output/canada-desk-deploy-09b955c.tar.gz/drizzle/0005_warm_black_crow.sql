CREATE TABLE `auth_challenges` (
	`id` text PRIMARY KEY NOT NULL,
	`candidate_id` text,
	`channel` text NOT NULL,
	`code_hash` text NOT NULL,
	`request_key` text NOT NULL,
	`state` text NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`expires_at` integer NOT NULL,
	`created_at` integer NOT NULL,
	`used_at` integer,
	`consumed_by` text DEFAULT '' NOT NULL,
	`provider_id` text DEFAULT '' NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `auth_challenges_request_key_unique` ON `auth_challenges` (`request_key`);--> statement-breakpoint
CREATE INDEX `challenge_candidate_date` ON `auth_challenges` (`candidate_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `client_sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`candidate_id` text NOT NULL,
	`method` text NOT NULL,
	`created_at` integer NOT NULL,
	`expires_at` integer NOT NULL,
	`revoked_at` integer,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `session_candidate_expiry` ON `client_sessions` (`candidate_id`,`expires_at`);--> statement-breakpoint
CREATE TABLE `contact_requests` (
	`id` text PRIMARY KEY NOT NULL,
	`candidate_id` text NOT NULL,
	`requested_name` text DEFAULT '' NOT NULL,
	`requested_email` text DEFAULT '' NOT NULL,
	`requested_phone` text DEFAULT '' NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`state` text DEFAULT 'pending' NOT NULL,
	`created_at` text NOT NULL,
	`resolved_at` text DEFAULT '' NOT NULL,
	`resolved_by` text DEFAULT '' NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `contact_request_candidate` ON `contact_requests` (`candidate_id`,`created_at`);--> statement-breakpoint
ALTER TABLE `client_cases` ADD `lmia_stream` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `client_cases` ADD `lmia_complete_date` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `client_cases` ADD `lmia_evidence_id` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `office_settings` ADD `whatsapp_sid` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `office_settings` ADD `whatsapp_token` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `office_settings` ADD `whatsapp_from` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `office_settings` ADD `whatsapp_template` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `office_settings` ADD `ai_key` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `office_settings` ADD `ai_model` text DEFAULT 'llama-3.1-8b-instant' NOT NULL;--> statement-breakpoint
ALTER TABLE `office_settings` ADD `market_snapshot` text DEFAULT '' NOT NULL;