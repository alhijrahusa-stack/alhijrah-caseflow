CREATE TABLE IF NOT EXISTS application_authorizations (
 candidate_id TEXT PRIMARY KEY NOT NULL REFERENCES candidates(id),
 version TEXT NOT NULL,
 accepted_at TEXT NOT NULL,
 authorization_text TEXT NOT NULL,
 terms_text TEXT NOT NULL,
 snapshot TEXT NOT NULL,
 snapshot_hash TEXT NOT NULL,
 pdf_object_key TEXT NOT NULL DEFAULT '',
 pdf_sha256 TEXT NOT NULL DEFAULT '',
 pdf_generated_at TEXT NOT NULL DEFAULT ''
);
