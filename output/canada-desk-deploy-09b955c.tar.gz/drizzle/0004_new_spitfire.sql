CREATE TABLE `case_reviews` (
	`candidate_id` text PRIMARY KEY NOT NULL,
	`state` text DEFAULT 'draft' NOT NULL,
	`prepared_by` text DEFAULT '' NOT NULL,
	`reviewed_by` text DEFAULT '' NOT NULL,
	`checklist` text DEFAULT '{}' NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`content_version` integer DEFAULT 0 NOT NULL,
	`version` integer DEFAULT 1 NOT NULL,
	`submitted_at` text DEFAULT '' NOT NULL,
	`reviewed_at` text DEFAULT '' NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `review_state_date` ON `case_reviews` (`state`,`updated_at`);--> statement-breakpoint
ALTER TABLE `client_cases` ADD `follow_up_date` text DEFAULT '' NOT NULL;