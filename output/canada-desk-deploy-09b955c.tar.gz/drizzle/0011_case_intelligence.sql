CREATE TABLE IF NOT EXISTS case_intelligence (
 candidate_id TEXT PRIMARY KEY NOT NULL REFERENCES candidates(id),
 version INTEGER NOT NULL,
 rule_version TEXT NOT NULL,
 state TEXT NOT NULL,
 report TEXT NOT NULL DEFAULT '{}',
 model TEXT NOT NULL DEFAULT '',
 generated_at TEXT NOT NULL DEFAULT '',
 lease_until INTEGER NOT NULL DEFAULT 0
);

--> statement-breakpoint
CREATE INDEX IF NOT EXISTS candidate_account_email ON candidates(lower(trim(json_extract(profile,'$.email'))));
