-- v15.19: chat assignment (atomic claim), transition audit log, voice/file attachments. Additive only; no data removed.
ALTER TABLE `support_threads` ADD COLUMN `assigned_to` text NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `support_threads` ADD COLUMN `assigned_at` text NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `support_messages` ADD COLUMN `attachment_key` text NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `support_messages` ADD COLUMN `attachment_type` text NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `support_messages` ADD COLUMN `attachment_name` text NOT NULL DEFAULT '';--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `support_transitions` (`id` text PRIMARY KEY NOT NULL, `candidate_id` text NOT NULL REFERENCES `candidates`(`id`), `from_state` text NOT NULL, `to_state` text NOT NULL, `actor` text NOT NULL, `at` text NOT NULL);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `support_transition_candidate` ON `support_transitions` (`candidate_id`,`at`);
