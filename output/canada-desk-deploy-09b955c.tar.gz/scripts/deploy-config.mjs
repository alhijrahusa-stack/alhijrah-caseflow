// Builds dist/server/wrangler.deploy.json from the generated build config, replacing the local placeholder
// bindings with the real Cloudflare resources given in the environment. Refuses placeholders.
import { readFile, writeFile } from 'node:fs/promises';
const need = name => { const v = (process.env[name] || '').trim(); if (!v) throw new Error(`Missing ${name}`); return v; };
const workerName = (process.env.CF_WORKER_NAME || 'alhijrah-canada-desk').trim();
const dbId = need('CF_D1_DATABASE_ID'), dbName = need('CF_D1_DATABASE_NAME'), bucket = need('CF_R2_BUCKET'), adminEmail = need('OFFICE_ADMIN_EMAIL');
if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(dbId) || dbId === '00000000-0000-4000-8000-000000000000')
  throw new Error('CF_D1_DATABASE_ID must be the real D1 UUID (see `wrangler d1 list`), not a placeholder.');
if (/site-creator|placeholder|prod-db-id|prod-kv-id/i.test(dbName + bucket)) throw new Error('Placeholder resource names are not allowed.');
if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(adminEmail)) throw new Error('OFFICE_ADMIN_EMAIL is not a valid email.');
const config = JSON.parse(await readFile('dist/server/wrangler.json', 'utf8'));
config.name = config.topLevelName = workerName;
config.d1_databases = [{ binding: 'DB', database_name: dbName, database_id: dbId, migrations_dir: '../../drizzle' }];
config.r2_buckets = [{ binding: 'BUCKET', bucket_name: bucket }];
config.vars = { ...config.vars, OFFICE_ADMIN_EMAIL: adminEmail, ...(process.env.STAFF_ALLOWED_IPS ? { STAFF_ALLOWED_IPS: process.env.STAFF_ALLOWED_IPS } : {}) };
// Engine mode must be stated on every deploy so a redeploy can never silently leave shadow mode.
const shadowOnly = (process.env.SHADOW_ONLY || '').trim().toLowerCase();
if (shadowOnly !== 'true' && shadowOnly !== 'false') throw new Error('Set SHADOW_ONLY to true or false (engine mode).');
config.vars.SHADOW_ONLY = shadowOnly;
// CF_ENGINE_SHADOW_CRON=1 adds the temporary cron that runs the production shadow once (lib/engine-mode.ts).
config.triggers = { crons: ['17 8 * * *', ...(process.env.CF_ENGINE_SHADOW_CRON === '1' ? ['*/5 * * * *'] : [])] };
// One or more custom domains, comma separated (e.g. "canada.careergate.us,desk.careergate.us").
const domains = (process.env.CF_CUSTOM_DOMAIN || '').split(',').map(d => d.trim().toLowerCase()).filter(Boolean);
for (const d of domains) if (!/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(d)) throw new Error('Invalid custom domain: ' + d);
// Path routes on another zone (e.g. "alhijrah-usa.com/canada-assessment*"): only that path reaches the Worker.
const pathRoutes = (process.env.CF_PATH_ROUTES || '').split(',').map(r => r.trim().toLowerCase()).filter(Boolean);
for (const r of pathRoutes) if (!/^[a-z0-9-]+(\.[a-z0-9-]+)+\/[a-z0-9\-\/]*\*?$/.test(r)) throw new Error('Invalid path route: ' + r);
const routes = [...domains.map(pattern => ({ pattern, custom_domain: true })), ...pathRoutes.map(pattern => { const host = pattern.split('/')[0]; return { pattern, zone_name: host.split('.').slice(-2).join('.') }; })];
if (routes.length) config.routes = routes;
// Keep the workers.dev address live: wrangler turns it off when custom domains are listed unless this is explicit.
config.workers_dev = true;
delete config.dev;
await writeFile('dist/server/wrangler.deploy.json', JSON.stringify(config, null, 2) + '\n');
console.log(`Deploy config written: worker=${workerName} d1=${dbName} r2=${bucket} SHADOW_ONLY=${shadowOnly} crons=${config.triggers.crons.join(',')}${process.env.CF_CUSTOM_DOMAIN ? ' domain=' + process.env.CF_CUSTOM_DOMAIN : ''}`);
